﻿Public Class frmEditHistory
    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub
    Private Sub LoadHistoryType()

        Dim rs As New ADODB.Recordset

        strSQL = "SELECT ID, DESCRIPTION FROM HISTORY_TYPE_CODE WHERE ACTIVE = 1"

        cboType.DisplayMember = "DESCRIPTION"
        cboType.ValueMember = "ID"

        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If
        tb.Rows.Add("", -1)

        cboType.DataSource = tb
        cboType.Enabled = True

        rs.Close()
        rs = Nothing

        cboType.SelectedIndex = 0

    End Sub
    Private Sub LoadEmployees()

        Dim rs As New ADODB.Recordset

        strSQL = "SELECT STAFF_ID, NAME FROM tblStaff"

        cboEmployee.DisplayMember = "NAME"
        cboEmployee.ValueMember = "STAFF_ID"

        Dim tb As New DataTable
        tb.Columns.Add("NAME", GetType(String))
        tb.Columns.Add("STAFF_ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("NAME").Value, rs.Fields("STAFF_ID").Value)
                rs.MoveNext()
            Loop
        End If
        tb.Rows.Add("", -1)

        cboEmployee.DataSource = tb
        cboEmployee.Enabled = True

        rs.Close()
        rs = Nothing

    End Sub
    Private Sub Init()
        Dim strSQL As String
        Dim temp As String
        Dim rsEdit As New ADODB.Recordset

        ' Populate the drop down lists
        Call LoadEmployees()
        Call LoadHistoryType()

        dtRecord.Format = DateTimePickerFormat.Custom
        dtRecord.CustomFormat = "MM/dd/yyyy"

        strSQL = "SELECT Convert(nvarchar(1000), REMARKS) AS STR_REMARKS, [DATE], STAFF_ID, HISTORY_TYPE_ID " _
                  & "FROM tblStopHistory " & "WHERE HISTORY_ID = " & gEditHistoryID

        rsEdit.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not rsEdit.EOF Then
            dtRecord.Value = CDate(rsEdit.Fields("DATE").Value)
            cboEmployee.SelectedValue = rsEdit.Fields("STAFF_ID").Value
            cboType.SelectedValue = rsEdit.Fields("HISTORY_TYPE_ID").Value
            txtRemarks.Text = IIf(IsDBNull(rsEdit.Fields("STR_REMARKS").Value), "", rsEdit.Fields("STR_REMARKS").Value)
        Else
            MsgBox("No history record found!", MsgBoxStyle.Exclamation)
        End If

        rsEdit.Close()
        rsEdit = Nothing
    End Sub

    Private Sub cmdDuplicateRecord_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdDuplicateRecord.Click
        Dim vResponse As Object
        Dim intType As Short
        Dim intEmployee As Short
        Dim strDate As String
        Dim strRemarks As String
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim strSANZID As String

        vResponse = InputBox("Enter the Bus Stop ID", "Duplicate History")
        If IsNumeric(vResponse) Then
            strSQL = "SELECT SANZ_ID FROM dbo.tblBusStopInformation WHERE OCTA_ID = " & vResponse & ""
            rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)

            If Not rs.EOF Then
                strSANZID = rs.Fields("SANZ_ID").Value
            Else
                MsgBox("Not a valid Bus Stop ID.", MsgBoxStyle.Critical, "Try Again...")
                Exit Sub
            End If

            rs.Close()
            rs = Nothing

            intType = cboType.SelectedValue
            intEmployee = cboEmployee.SelectedValue
            strDate = dtRecord.Value
            strRemarks = txtRemarks.Text

            ' insert the new history item
            strSQL = "INSERT INTO tblStopHistory " _
                    & "(OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " _
                    & "HISTORY_TYPE_ID, REMARKS) " _
                    & "VALUES (" & vResponse & ", '" & strSANZID & "', '" & strDate & "', " & intEmployee & ", " & intType & ", " & cV2Q_String(strRemarks) & ")"

            db.Execute(strSQL)

            MsgBox("Bus Stop History has been added to Bus Stop #" & vResponse & "", MsgBoxStyle.Information, "Record added")
        Else
            MsgBox("Not a valid Bus Stop ID.", MsgBoxStyle.Critical, "Try Again...")
        End If

    End Sub

    Private Sub cmdSave_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSave.Click
        Dim strSQL As String
        Dim strDate As String
        Dim intStaffID As Short
        Dim intTypeID As Short

        If cboEmployee.SelectedIndex = -1 Or cboType.SelectedIndex = -1 Then
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        strDate = dtRecord.Value.ToShortDateString
        intStaffID = cboEmployee.SelectedValue
        intTypeID = cboType.SelectedValue

        If Not (intStaffID = -1 Or intTypeID = -1) Then
            strSQL = "UPDATE tblStopHistory SET [DATE] = '" _
                 & strDate & "', STAFF_ID = " & intStaffID & ", HISTORY_TYPE_ID = " & intTypeID & ", REMARKS = " & cV2Q_String((txtRemarks.Text)) & " WHERE HISTORY_ID = " & gEditHistoryID
            db.Execute(strSQL)
            MsgBox("Record has been saved.", vbInformation, "Saved")
            Me.Close()
        Else
            MsgBox("Both EMPLOYEE and TYPE fields are required")
        End If


    End Sub

    Private Sub frmEditHistory_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Call Init()
    End Sub

    Private Sub txtRemarks_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtRemarks.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
End Class