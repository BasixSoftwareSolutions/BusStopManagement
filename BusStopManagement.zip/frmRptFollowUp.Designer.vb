﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRptFollowUp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRptFollowUp))
        Me.cmdExportToExcel = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdPrint = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmdClearStopFile = New System.Windows.Forms.Button()
        Me.cmdClearHastus = New System.Windows.Forms.Button()
        Me.optFollowup5 = New System.Windows.Forms.RadioButton()
        Me.optFollowup4 = New System.Windows.Forms.RadioButton()
        Me.optFollowup3 = New System.Windows.Forms.RadioButton()
        Me.optFollowup2 = New System.Windows.Forms.RadioButton()
        Me.optFollowup1 = New System.Windows.Forms.RadioButton()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdExportToExcel
        '
        Me.cmdExportToExcel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExportToExcel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExportToExcel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExportToExcel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExportToExcel.Location = New System.Drawing.Point(124, 188)
        Me.cmdExportToExcel.Name = "cmdExportToExcel"
        Me.cmdExportToExcel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExportToExcel.Size = New System.Drawing.Size(105, 25)
        Me.cmdExportToExcel.TabIndex = 15
        Me.cmdExportToExcel.Text = "&Export to Excel"
        Me.cmdExportToExcel.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(236, 188)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(81, 25)
        Me.cmdCancel.TabIndex = 14
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdPrint
        '
        Me.cmdPrint.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPrint.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPrint.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPrint.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPrint.Location = New System.Drawing.Point(20, 188)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPrint.Size = New System.Drawing.Size(97, 25)
        Me.cmdPrint.TabIndex = 13
        Me.cmdPrint.Text = "&Print Report"
        Me.cmdPrint.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.cmdClearStopFile)
        Me.Frame1.Controls.Add(Me.cmdClearHastus)
        Me.Frame1.Controls.Add(Me.optFollowup5)
        Me.Frame1.Controls.Add(Me.optFollowup4)
        Me.Frame1.Controls.Add(Me.optFollowup3)
        Me.Frame1.Controls.Add(Me.optFollowup2)
        Me.Frame1.Controls.Add(Me.optFollowup1)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.Color.DimGray
        Me.Frame1.Location = New System.Drawing.Point(12, 12)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(313, 161)
        Me.Frame1.TabIndex = 12
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Type of Work Required"
        '
        'cmdClearStopFile
        '
        Me.cmdClearStopFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClearStopFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClearStopFile.Enabled = False
        Me.cmdClearStopFile.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClearStopFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClearStopFile.Location = New System.Drawing.Point(232, 128)
        Me.cmdClearStopFile.Name = "cmdClearStopFile"
        Me.cmdClearStopFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClearStopFile.Size = New System.Drawing.Size(65, 21)
        Me.cmdClearStopFile.TabIndex = 9
        Me.cmdClearStopFile.Text = "Clear"
        Me.cmdClearStopFile.UseVisualStyleBackColor = False
        Me.cmdClearStopFile.Visible = False
        '
        'cmdClearHastus
        '
        Me.cmdClearHastus.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClearHastus.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClearHastus.Enabled = False
        Me.cmdClearHastus.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClearHastus.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClearHastus.Location = New System.Drawing.Point(232, 104)
        Me.cmdClearHastus.Name = "cmdClearHastus"
        Me.cmdClearHastus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClearHastus.Size = New System.Drawing.Size(65, 21)
        Me.cmdClearHastus.TabIndex = 8
        Me.cmdClearHastus.Text = "Clear"
        Me.cmdClearHastus.UseVisualStyleBackColor = False
        Me.cmdClearHastus.Visible = False
        '
        'optFollowup5
        '
        Me.optFollowup5.BackColor = System.Drawing.Color.Transparent
        Me.optFollowup5.Cursor = System.Windows.Forms.Cursors.Default
        Me.optFollowup5.Enabled = False
        Me.optFollowup5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optFollowup5.ForeColor = System.Drawing.Color.DimGray
        Me.optFollowup5.Location = New System.Drawing.Point(16, 128)
        Me.optFollowup5.Name = "optFollowup5"
        Me.optFollowup5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optFollowup5.Size = New System.Drawing.Size(225, 17)
        Me.optFollowup5.TabIndex = 7
        Me.optFollowup5.TabStop = True
        Me.optFollowup5.Text = "Needs Create/Update Stop File"
        Me.optFollowup5.UseVisualStyleBackColor = False
        Me.optFollowup5.Visible = False
        '
        'optFollowup4
        '
        Me.optFollowup4.BackColor = System.Drawing.Color.Transparent
        Me.optFollowup4.Cursor = System.Windows.Forms.Cursors.Default
        Me.optFollowup4.Enabled = False
        Me.optFollowup4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optFollowup4.ForeColor = System.Drawing.Color.DimGray
        Me.optFollowup4.Location = New System.Drawing.Point(16, 104)
        Me.optFollowup4.Name = "optFollowup4"
        Me.optFollowup4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optFollowup4.Size = New System.Drawing.Size(225, 17)
        Me.optFollowup4.TabIndex = 6
        Me.optFollowup4.TabStop = True
        Me.optFollowup4.Text = "Needs Update Hastus"
        Me.optFollowup4.UseVisualStyleBackColor = False
        Me.optFollowup4.Visible = False
        '
        'optFollowup3
        '
        Me.optFollowup3.BackColor = System.Drawing.Color.Transparent
        Me.optFollowup3.Cursor = System.Windows.Forms.Cursors.Default
        Me.optFollowup3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optFollowup3.ForeColor = System.Drawing.Color.DimGray
        Me.optFollowup3.Location = New System.Drawing.Point(16, 80)
        Me.optFollowup3.Name = "optFollowup3"
        Me.optFollowup3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optFollowup3.Size = New System.Drawing.Size(225, 17)
        Me.optFollowup3.TabIndex = 3
        Me.optFollowup3.TabStop = True
        Me.optFollowup3.Text = "Needs Photographs Taken"
        Me.optFollowup3.UseVisualStyleBackColor = False
        '
        'optFollowup2
        '
        Me.optFollowup2.BackColor = System.Drawing.Color.Transparent
        Me.optFollowup2.Cursor = System.Windows.Forms.Cursors.Default
        Me.optFollowup2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optFollowup2.ForeColor = System.Drawing.Color.DimGray
        Me.optFollowup2.Location = New System.Drawing.Point(16, 56)
        Me.optFollowup2.Name = "optFollowup2"
        Me.optFollowup2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optFollowup2.Size = New System.Drawing.Size(233, 17)
        Me.optFollowup2.TabIndex = 2
        Me.optFollowup2.TabStop = True
        Me.optFollowup2.Text = "Needs Permanent Cassette Insert"
        Me.optFollowup2.UseVisualStyleBackColor = False
        '
        'optFollowup1
        '
        Me.optFollowup1.BackColor = System.Drawing.Color.Transparent
        Me.optFollowup1.Checked = True
        Me.optFollowup1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optFollowup1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optFollowup1.ForeColor = System.Drawing.Color.DimGray
        Me.optFollowup1.Location = New System.Drawing.Point(16, 32)
        Me.optFollowup1.Name = "optFollowup1"
        Me.optFollowup1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optFollowup1.Size = New System.Drawing.Size(217, 17)
        Me.optFollowup1.TabIndex = 1
        Me.optFollowup1.TabStop = True
        Me.optFollowup1.Text = "Needs GPS Survey"
        Me.optFollowup1.UseVisualStyleBackColor = False
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(12, 180)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(313, 41)
        Me.Shape1.TabIndex = 16
        '
        'frmRptFollowUp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(335, 234)
        Me.Controls.Add(Me.cmdExportToExcel)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdPrint)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Shape1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmRptFollowUp"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Follow Up Work Report"
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents cmdExportToExcel As Button
    Public WithEvents cmdCancel As Button
    Public WithEvents cmdPrint As Button
    Public WithEvents Frame1 As GroupBox
    Public WithEvents cmdClearStopFile As Button
    Public WithEvents cmdClearHastus As Button
    Public WithEvents optFollowup5 As RadioButton
    Public WithEvents optFollowup4 As RadioButton
    Public WithEvents optFollowup3 As RadioButton
    Public WithEvents optFollowup2 As RadioButton
    Public WithEvents optFollowup1 As RadioButton
    Public WithEvents Shape1 As Label
End Class
