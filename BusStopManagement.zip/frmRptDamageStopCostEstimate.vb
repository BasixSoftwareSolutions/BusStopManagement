﻿Public Class frmRptDamageStopCostEstimate

    Public OID As Short
    Public srchFlag As Boolean
    Dim rowIndex As Short
    Dim taxPercent, overHPercent As Double

    Private Sub cmdExit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExit.Click
        Me.Close()
    End Sub

    Private Sub cmdSave_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSave.Click

        Dim i As Short
        Dim temp As String
        Dim tempStr As String
        Dim filePath As String
        Dim strFPath As String
        Dim ct As Short
        Dim objFile As New Scripting.FileSystemObject
        Dim fileExists As Boolean
        Dim directoryExists As Boolean
        Dim rs As New ADODB.Recordset
        Dim histId As Integer
        Dim tempDt, remarks As String
        Dim typeID As Short
        Dim location_Renamed As String

        If (txtOCTAID.Text <> "" And txtSANZID.Text <> "") Then
            strSQL = "DELETE  FROM [tblDamageStopCost]"
            dbRep.Execute(strSQL)

            For i = 0 To TDBGrid1.RowCount - 1
                If TDBGrid1.Rows(i).Cells(1).Value Then
                    strSQL = ""
                    temp = Replace(TDBGrid1.Rows(i).Cells(0).Value, "'", "''")
                    strSQL = strSQL & "INSERT INTO [tblDamageStopCost] (QUANTITY, DESCRIPTION, COST) " & "VALUES (" & TDBGrid1.Rows(i).Cells(2).Value & "," & "'" & TDBGrid1.Rows(i).Cells(0).Value & "'" & "," & "'" & formatcurrency(TDBGrid1.Rows(i).Cells(4).Value, 2) & "'" & ");"
                    dbRep.Execute(strSQL)
                End If
            Next

            ' set up report
            Dim sSubjectLine As String = ""
            Dim sPDNO As String = ""
            Dim sIncidentNo As String = ""
            Dim dIncidentDate As String = ""
            Dim sFrom As String = ""
            Dim sSubTotal As String = 0
            Dim sTax As String = 0
            Dim sLabor As String = 0
            Dim sOverhead As String = 0
            Dim sTotal As String = 0

            location_Renamed = txtSt1.Text & " " & txtSt2.Text & " " & txtSt3.Text & " / " & txtCRS1.Text & " " & txtCRS2.Text & " " & txtCRS3.Text & " " & txtCRS4.Text

            sSubjectLine = (("Damaged Bus Stop: " & location_Renamed))

            If txtPDNO.Text <> "" Then
                sPDNO = txtPDNO.Text
            End If

            If txtIncidentNo.Text <> "" Then
                sIncidentNo = txtIncidentNo.Text
            End If

            dIncidentDate = dtIncident.Value.ToString("MMMM dd, yyyy")

            sFrom = CurrentLoginFullName & ", Stops & Zones"

            sSubTotal = txtSTotal.Text
            sTax = txtTax.Text
            sLabor = txtLabor.Text
            sOverhead = txtOverhead.Text
            sTotal = txtTotal.Text

            tempStr = dtIncident.Value.ToString("MMddyyyy")

            dbRep.Close()
            dbRep.Open()

            strFPath = GetAppValue("DamageStopCostEstReportPath")
            filePath = strFPath & "DC-" & tempStr & "-" & OID & ".pdf"

            ct = 0

            fileExists = True

            Do While fileExists = True
                directoryExists = objFile.FolderExists(strFPath)

                If directoryExists = False Then
                    MsgBox("Cannot find the folder, please set a valid path")
                    Exit Sub
                End If

                fileExists = objFile.FileExists(filePath)

                If fileExists Then
                    ct = ct + 1
                    filePath = strFPath & "DC-" & tempStr & "-" & OID & "_" & ct & ".pdf"
                End If
            Loop

            frmCrystalReportsWP.LoadDamageCostReport(filePath, sSubjectLine, sPDNO, sIncidentNo, dIncidentDate, sFrom, sSubTotal, sTax, sLabor, sOverhead, sTotal, taxPercent, overHPercent)

            ' Update the History Table
            tempDt = "'" & dtIncident.Value.ToString("MM/dd/yyyy") & "'"
            remarks = "'A MEMO WAS ISSUED TO THE RISK MANAGEMENT SECTION FOR DAMAGES WHICH OCCURRED AT THIS BUS STOP'"
            typeID = 32 ' DSCE Code

            strSQL = "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) VALUES (" & txtOCTAID.Text & "," & "'" & txtSANZID.Text & "'" & "," & tempDt & "," & CurrentLoginUserID & "," & typeID & "," & remarks & ");"

            db.Execute(strSQL)

            strSQL = "SELECT * FROM [tblStopHistory];"

            rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)

            rs.MoveLast()

            histId = rs.Fields("HISTORY_ID").Value

            rs.Close()

            ' Update tblHistoryDoc
            strSQL = "INSERT INTO [tblHistoryDoc] (HISTORY_ID, DOC_PATH) VALUES (" & histId & ",'" & filePath & "');"

            db.Execute(strSQL)

        Else
            MsgBox("Please select a valid stop")
        End If

    End Sub

    Private Sub frmRptDamageStopCostEstimate_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        Me.TblDamageStopCostTableAdapter.Fill(Me.DsDamageReport.tblDamageStopCost)

        TDBGrid1.Columns(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
        TDBGrid1.Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        TDBGrid1.Columns(2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
        TDBGrid1.Columns(3).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight
        TDBGrid1.Columns(4).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight

        ' Create RecordSet for Hardware
        txtSTotal.Text = "$0.00"
        txtTax.Text = "$0.00"
        txtLabor.Text = "$0.00"
        txtOverhead.Text = "$0.00"
        txtTotal.Text = "$0.00"

        dtIncident.Format = DateTimePickerFormat.Custom
        dtIncident.CustomFormat = "MM/dd/yyyy"

    End Sub

    Private Sub cmdFind_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdFind.Click

        frmSearchBusStopMisc.rptIndex = 2

        frmSearchBusStopMisc.ShowDialog()

        Dim rs As New ADODB.Recordset
        Dim strSQL As String
        Dim tmparr(9) As Object
        Dim i As Short

        If srchFlag Then
            ' for bus stop information
            strSQL = "" & "SELECT " _
                    & "bs.OCTA_ID, bs.SANZ_ID, stdir.DIR, bs.STREET_OF_TRAVEL, sttpc1.TYPE, bsloc.LOC, " _
                    & "bs.CROSS_STREET, sttpc2.TYPE, bs.CROSS_STREET_1, ct.CITY " _
                    & "FROM " & "tblBusStopInformation bs, " _
                    & "ST_DIR_CODE stdir, " _
                    & "BS_LOC_CODE bsloc, " _
                    & "CITY_CODE ct, " _
                    & "ST_TYPE_CODE sttpc1, " _
                    & "ST_TYPE_CODE sttpc2 " _
                    & "WHERE " & "(bs.OCTA_ID = " & OID & ") AND " _
                    & "(bs.ST_DIR_ID = stdir.ID) AND " _
                    & "(bs.BS_LOC_ID = bsloc.ID) AND " _
                    & "(bs.CITY_ID = ct.ID) AND " _
                    & "((bs.ST_TYPE_ID_1 = sttpc1.ID) OR (bs.ST_TYPE_ID_1 IS NULL AND sttpc1.ID = 0)) AND " _
                    & "((bs.ST_TYPE_ID_2 = sttpc2.ID) OR (bs.ST_TYPE_ID_2 IS NULL AND sttpc2.ID = 0));"

            rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)

            For i = 0 To 9
                tmparr(i) = rs.Fields(i).Value
                If IsDBNull(tmparr(i)) Then
                    tmparr(i) = ""
                End If
            Next i

            txtOCTAID.Text = tmparr(0)
            txtSANZID.Text = tmparr(1)
            txtSt1.Text = tmparr(2)
            txtSt2.Text = tmparr(3)
            txtSt3.Text = tmparr(4)
            txtCRS1.Text = tmparr(5)
            txtCRS2.Text = tmparr(6)
            txtCRS3.Text = tmparr(7)
            txtCRS4.Text = tmparr(8)
            txtCity.Text = tmparr(9)

            rs.Close()
        End If

    End Sub

    Private Sub txtLabor_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtLabor.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)

        If (KeyAscii >= 48 And KeyAscii <= 57) Or KeyAscii = 8 Or KeyAscii = 46 Or KeyAscii = 36 Then
            KeyAscii = KeyAscii
        Else
            KeyAscii = 0
        End If

        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtLabor_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtLabor.TextChanged

        Call CalculateTotals()

    End Sub

    Private Sub CalculateTotals()

        Dim labor, subtotal, tax, overhead As Double
        'Dim taxPercent, overHPercent As Double  --- Made variables global 
        Dim total As Double
        Dim i As Short
        Dim temp As String
        Dim sSQL As String
        'taxPercent = 0.0775
        'overHPercent = 0.43

        subtotal = 0

        Dim rs As New ADODB.Recordset
        sSQL = "SELECT Value FROM dbo.tblAppValues WHERE RTRIM(Name) = 'TaxRate'"
        rs.Open(sSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)
        rs.MoveFirst()
        If Not rs.EOF And Not rs.BOF Then
            taxPercent = rs.Fields("Value").Value
        Else
            taxPercent = 0.0775
        End If
        rs.Close()

        sSQL = "SELECT Value FROM dbo.tblAppValues WHERE RTRIM(Name) = 'OHRate'"
        rs.Open(sSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)
        rs.MoveFirst()
        If Not rs.EOF And Not rs.BOF Then
            overHPercent = rs.Fields("Value").Value
        Else
            overHPercent = 0.43
        End If
        rs.Close()
        rs = Nothing

        Me.lblTaxRate.Text = "Tax Rate = " & taxPercent * 100 & "%"
        Me.lblOverheadRate.Text = "Overhead Rate = " & overHPercent * 100 & "%"

        For i = 0 To TDBGrid1.RowCount - 1
            If TDBGrid1.Rows(i).Cells(1).Value Then
                temp = Replace(TDBGrid1.Rows(i).Cells(4).Value, "$", "")
                subtotal = subtotal + CDbl(temp)
            End If
        Next

        tax = subtotal * taxPercent
        overhead = subtotal * overHPercent

        txtSTotal.Text = "$" & FormatNumber(subtotal, 2)
        txtTax.Text = "$" & FormatNumber(tax, 2)
        txtOverhead.Text = "$" & FormatNumber(overhead, 2)

        temp = Replace(txtLabor.Text, "$", "")

        labor = Val(temp)

        total = subtotal + tax + labor + overhead

        txtTotal.Text = "$" & FormatNumber(total, 2)

    End Sub

    Private Sub TDBGrid1_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles TDBGrid1.CellValueChanged

        If TDBGrid1.RowCount = 0 Then Exit Sub

        For i = 0 To TDBGrid1.RowCount - 1
            Try
                If TDBGrid1.Rows(i).Cells(1).Value Then
                    If TDBGrid1.Rows(i).Cells(2).Value < 1 Then
                        TDBGrid1.Rows(i).Cells(2).Value = 1
                    End If
                    TDBGrid1.Rows(i).Cells(4).Value = TDBGrid1.Rows(i).Cells(2).Value * TDBGrid1.Rows(i).Cells(3).Value
                Else
                    If TDBGrid1.Rows(i).Cells(4).Value <> 0 Then
                        TDBGrid1.Rows(i).Cells(4).Value = 0
                    End If
                    If TDBGrid1.Rows(i).Cells(2).Value <> 0 Then
                        TDBGrid1.Rows(i).Cells(2).Value = 0
                    End If
                End If
            Catch ex As Exception
                MsgBox("Please enter a Numeric value for QTY")
                TDBGrid1.Rows(i).Cells(2).Value = 0
            End Try
        Next

        Call CalculateTotals()

    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click

        Me.TblDamageStopCostTableAdapter.Fill(Me.DsDamageReport.tblDamageStopCost)

        ' Create RecordSet for Hardware
        txtSTotal.Text = "$0.00"
        txtTax.Text = "$0.00"
        txtLabor.Text = "$0.00"
        txtOverhead.Text = "$0.00"
        txtTotal.Text = "$0.00"

        dtIncident.Format = DateTimePickerFormat.Custom
        dtIncident.CustomFormat = "MM/dd/yyyy"

    End Sub

    Private Sub txtLabor_LostFocus(sender As Object, e As EventArgs) Handles txtLabor.LostFocus

        txtLabor.Text = FormatCurrency(txtLabor.Text, 2)

    End Sub
End Class