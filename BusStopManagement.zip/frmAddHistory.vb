﻿Public Class frmAddHistory
    Private strOCTAID As String
    Private strSANZID As String

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOK.Click
        'Dim lngWONum As Integer
        Dim intType As Short
        Dim intEmployee As Short
        Dim strDate As String
        Dim strRemarks As String
        Dim strSQL As String
        Dim rsHist As New ADODB.Recordset

        If txtRemarks.Text = "" Then txtRemarks.Text = " "

        intType = cboHistType.SelectedValue
        intEmployee = cboEmployee.SelectedValue
        strDate = dtHistoryDate.Value
        strRemarks = txtRemarks.Text

        'If IsNumeric(txtWONum.Text) Then

        'lngWONum = CInt(txtWONum.Text)

        ' ensure that the WO_NUM is not already in the table
        'strSQL = "SELECT OCTA_ID FROM tblStopHistory WHERE WO_NUM = " & lngWONum
        'rsHist.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)
        'If rsHist.RecordCount = 0 Then
        ' insert the new history item
        'strSQL = "INSERT INTO tblStopHistory " & "(OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, WO_NUM, REMARKS) " & "VALUES (" & strOCTAID & ", '" & strSANZID & "', '" & strDate & "', " & intEmployee & ", " & intType & ", " & lngWONum & ", " & cV2Q_String(strRemarks) & ")"
        'db.Execute(strSQL)
        'Me.Close()
        'Else
        'MsgBox("Stop number " & rsHist.Fields("OCTA_ID").Value & " has Work Order #" & lngWONum)
        'End If
        'Else
        ' insert the new history item
        If Not (intType = -1 Or intEmployee = -1) Then
            strSQL = "INSERT INTO tblStopHistory " & "(OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) " & "VALUES (" & strOCTAID & ", '" & strSANZID & "', '" & strDate & "', " & intEmployee & ", " & intType & ", " & cV2Q_String(strRemarks) & ")"
            db.Execute(strSQL)
            Me.Close()
            'CreateObject("WScript.Shell").Popup("New History Record has been added", 1, "Saved")
            MsgBox("New History Record has been added", vbInformation, "Saved")
        Else
            MsgBox("Both EMPLOYEE and TYPE fields are required")
        End If
        'End If
    End Sub

    Private Sub frmAddHistory_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Dim rsAddHist As New ADODB.Recordset

        dtHistoryDate.Format = DateTimePickerFormat.Custom
        dtHistoryDate.CustomFormat = "MM/dd/yyyy"

        strOCTAID = frmUpdateStop.txtOCTAID.Text
        strSANZID = frmUpdateStop.txtSANZID.Text

        txtSANZID.Text = strSANZID

        ' Populate the drop down lists
        Call LoadEmployees()
        Call LoadHistoryType()

    End Sub
    Private Sub LoadHistoryType()

        Dim rs As New ADODB.Recordset

        strSQL = "SELECT ID, DESCRIPTION FROM HISTORY_TYPE_CODE WHERE ACTIVE = 1"

        cboHistType.DisplayMember = "DESCRIPTION"
        cboHistType.ValueMember = "ID"

        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        tb.Rows.Add("", -1)

        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If

        cboHistType.DataSource = tb
        cboHistType.Enabled = True
        cboHistType.SelectedIndex = 0

        rs.Close()
        rs = Nothing

        cboHistType.SelectedIndex = 0

    End Sub
    Private Sub LoadEmployees()

        Dim rs As New ADODB.Recordset

        strSQL = "SELECT STAFF_ID, NAME FROM tblStaff"

        cboEmployee.DisplayMember = "NAME"
        cboEmployee.ValueMember = "STAFF_ID"

        Dim tb As New DataTable
        tb.Columns.Add("NAME", GetType(String))
        tb.Columns.Add("STAFF_ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        tb.Rows.Add("", -1)

        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("NAME").Value, rs.Fields("STAFF_ID").Value)
                rs.MoveNext()
            Loop
        End If

        cboEmployee.DataSource = tb
        cboEmployee.Enabled = True
        cboEmployee.SelectedIndex = 0

        rs.Close()
        rs = Nothing

    End Sub
    Private Sub txtWONum_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs)
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub cmdSpellCheck_Click(sender As Object, e As EventArgs) Handles cmdSpellCheck.Click
        Dim strText As String
        Dim lngSuggWord As Integer
        Dim lngStart As Integer
        Dim lngPos As Integer
        Dim blnDone As Boolean
        Dim objWord As Microsoft.Office.Interop.Word.Application
        Dim objDoc As Microsoft.Office.Interop.Word.Document
        Dim colSuggestions As Microsoft.Office.Interop.Word.SpellingSuggestions
        Dim colSpellErrors As Microsoft.Office.Interop.Word.ProofreadingErrors

        On Error GoTo ErrorHandler

        objWord = CreateObject("word.application")
        objWord.Visible = False
        objWord.WindowState = Microsoft.Office.Interop.Word.WdWindowState.wdWindowStateMinimize

        objDoc = objWord.Documents.Add

        blnDone = False
        lngStart = 1
        lngPos = 0

        Do While Not blnDone
            lngStart = lngPos + 1
            lngPos = InStr(lngStart, txtRemarks.Text, " ")
            If lngPos = 0 Then
                lngPos = Len(txtRemarks.Text) + 1
                blnDone = True
            End If

            txtRemarks.SelectionStart = lngStart - 1
            txtRemarks.SelectionLength = lngPos - lngStart

            If txtRemarks.SelectedText <> "" Then
                objDoc.Range.Delete()
                objDoc.Range.Text = txtRemarks.SelectedText
                colSpellErrors = objDoc.SpellingErrors

                If colSpellErrors.Count > 0 Then
                    With frmSpellChecker
                        .txtBadWord.Text = colSpellErrors.Item(1).Text

                        colSuggestions = objWord.GetSpellingSuggestions(colSpellErrors.Item(1).Text)
                        .lstSuggestions.Items.Clear()

                        For lngSuggWord = 1 To colSuggestions.Count
                            .lstSuggestions.Items.Add(colSuggestions.Item(lngSuggWord).Name)
                        Next
                        .ShowDialog()
                        If .ReplacementWord <> "" Then
                            txtRemarks.SelectedText = .ReplacementWord
                            lngPos = lngPos + .LengthDifference
                        End If
                    End With
                End If
            End If
        Loop

        txtRemarks.SelectionStart = 0
        txtRemarks.SelectionLength = 0

        GoTo NormalExit

ErrorHandler:
        MsgBox("The following error occured during the document's spelling" & vbCrLf & Err.Description)

NormalExit:
        objDoc.Close(SaveChanges:=Microsoft.Office.Interop.Word.WdSaveOptions.wdDoNotSaveChanges)
        objWord.Quit(SaveChanges:=Microsoft.Office.Interop.Word.WdSaveOptions.wdDoNotSaveChanges)
        objWord = Nothing
        objDoc = Nothing
    End Sub
End Class