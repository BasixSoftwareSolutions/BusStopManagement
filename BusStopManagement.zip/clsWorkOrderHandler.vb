Option Strict Off
Option Explicit On
Friend Class clsWorkOrderHandler
	
	Private CN As ADODB.Connection
    Public rs As ADODB.Recordset ' make this public.....
    Private myFS As Scripting.FileSystemObject
    Private blnConnected As Boolean
    Private blnWithPending As Boolean
	Private strSQL As String
	
	Public Sub Init(ByRef aCN As ADODB.Connection)

        CN = aCN
        rs = New ADODB.Recordset

        ' Load pending work orders...
        strSQL = "SELECT * FROM tblWorkOrderReports ORDER BY CAST(LEFT(SANZ_ID, Patindex('%[^-.0-9]%', SANZ_ID + 'x') - 1) AS Float), [SANZ_ID]"
        rs.Open("tblWorkOrderReports", CN, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdTableDirect)
		
		If rs.Supports(ADODB.CursorOptionEnum.adIndex) And rs.Supports(ADODB.CursorOptionEnum.adSeek) Then
			rs.Index = "PrimaryKey"
		Else
			MsgBox("Database doesn't support Seek!", MsgBoxStyle.Exclamation)
		End If
		
		blnWithPending = False
		If Not rs.EOF Then blnWithPending = True
		
	End Sub
	
	Public Function MoveToRecord(ByRef aOCTA_ID As Integer) As Boolean
		If Not blnWithPending Then
			MoveToRecord = False
			Exit Function
		End If
		
		rs.MoveFirst()
        ' This will need to modify if base table has multiple keys as primary key...
        rs.Seek(New Object() {aOCTA_ID}, ADODB.SeekEnum.adSeekFirstEQ)

        If Not rs.EOF Then
			MoveToRecord = True
		Else
			MoveToRecord = False
		End If
	End Function

    Private Sub Class_Terminate_Renamed()
        myFS = Nothing
    End Sub
    Protected Overrides Sub Finalize()
		Class_Terminate_Renamed()
		MyBase.Finalize()
	End Sub
End Class