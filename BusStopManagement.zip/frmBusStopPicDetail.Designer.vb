﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBusStopPicDetail
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim OCTA_IDLabel As System.Windows.Forms.Label
        Dim SANZ_IDLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBusStopPicDetail))
        Me._Label1_47 = New System.Windows.Forms.Label()
        Me.cmdGoogleMaps = New System.Windows.Forms.Button()
        Me._Label1_57 = New System.Windows.Forms.Label()
        Me._Label1_54 = New System.Windows.Forms.Label()
        Me.bsNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.DetailStopImagesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BusStopManagementDataSet2 = New BusStopManagement.BusStopManagementDataSet2()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblStopImagesTableAdapter = New BusStopManagement.BusStopManagementDataSet2TableAdapters.tblStopImagesTableAdapter()
        Me.TableAdapterManager = New BusStopManagement.BusStopManagementDataSet2TableAdapters.TableAdapterManager()
        Me.txtPicNo = New System.Windows.Forms.TextBox()
        Me.OCTA_IDTextBox = New System.Windows.Forms.TextBox()
        Me.SANZ_IDTextBox = New System.Windows.Forms.TextBox()
        Me.txtPicNotes = New System.Windows.Forms.TextBox()
        Me.txtPicPath = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPicDate = New System.Windows.Forms.TextBox()
        Me.ZoomPictureBox1 = New ZPBlib.ZoomPictureBox()
        OCTA_IDLabel = New System.Windows.Forms.Label()
        SANZ_IDLabel = New System.Windows.Forms.Label()
        CType(Me.bsNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.bsNavigator.SuspendLayout()
        CType(Me.DetailStopImagesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusStopManagementDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OCTA_IDLabel
        '
        OCTA_IDLabel.AutoSize = True
        OCTA_IDLabel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        OCTA_IDLabel.ForeColor = System.Drawing.Color.DimGray
        OCTA_IDLabel.Location = New System.Drawing.Point(516, 679)
        OCTA_IDLabel.Name = "OCTA_IDLabel"
        OCTA_IDLabel.Size = New System.Drawing.Size(53, 14)
        OCTA_IDLabel.TabIndex = 34
        OCTA_IDLabel.Text = "OCTA ID:"
        '
        'SANZ_IDLabel
        '
        SANZ_IDLabel.AutoSize = True
        SANZ_IDLabel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        SANZ_IDLabel.ForeColor = System.Drawing.Color.DimGray
        SANZ_IDLabel.Location = New System.Drawing.Point(516, 706)
        SANZ_IDLabel.Name = "SANZ_IDLabel"
        SANZ_IDLabel.Size = New System.Drawing.Size(52, 14)
        SANZ_IDLabel.TabIndex = 36
        SANZ_IDLabel.Text = "SANZ ID:"
        '
        '_Label1_47
        '
        Me._Label1_47.AutoSize = True
        Me._Label1_47.BackColor = System.Drawing.Color.Transparent
        Me._Label1_47.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_47.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_47.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_47.Location = New System.Drawing.Point(19, 663)
        Me._Label1_47.Name = "_Label1_47"
        Me._Label1_47.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_47.Size = New System.Drawing.Size(45, 14)
        Me._Label1_47.TabIndex = 27
        Me._Label1_47.Text = "NOTES:"
        Me._Label1_47.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cmdGoogleMaps
        '
        Me.cmdGoogleMaps.BackColor = System.Drawing.SystemColors.Control
        Me.cmdGoogleMaps.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdGoogleMaps.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdGoogleMaps.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdGoogleMaps.Image = CType(resources.GetObject("cmdGoogleMaps.Image"), System.Drawing.Image)
        Me.cmdGoogleMaps.Location = New System.Drawing.Point(890, 658)
        Me.cmdGoogleMaps.Name = "cmdGoogleMaps"
        Me.cmdGoogleMaps.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdGoogleMaps.Size = New System.Drawing.Size(84, 77)
        Me.cmdGoogleMaps.TabIndex = 30
        Me.cmdGoogleMaps.Text = "Google Maps"
        Me.cmdGoogleMaps.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdGoogleMaps.UseVisualStyleBackColor = False
        '
        '_Label1_57
        '
        Me._Label1_57.AutoSize = True
        Me._Label1_57.BackColor = System.Drawing.Color.Transparent
        Me._Label1_57.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_57.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_57.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_57.Location = New System.Drawing.Point(693, 706)
        Me._Label1_57.Name = "_Label1_57"
        Me._Label1_57.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_57.Size = New System.Drawing.Size(63, 14)
        Me._Label1_57.TabIndex = 29
        Me._Label1_57.Text = "IMAGE NO:"
        '
        '_Label1_54
        '
        Me._Label1_54.AutoSize = True
        Me._Label1_54.BackColor = System.Drawing.Color.Transparent
        Me._Label1_54.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_54.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_54.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_54.Location = New System.Drawing.Point(682, 679)
        Me._Label1_54.Name = "_Label1_54"
        Me._Label1_54.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_54.Size = New System.Drawing.Size(74, 14)
        Me._Label1_54.TabIndex = 28
        Me._Label1_54.Text = "DATE TAKEN:"
        '
        'bsNavigator
        '
        Me.bsNavigator.AddNewItem = Nothing
        Me.bsNavigator.BindingSource = Me.DetailStopImagesBindingSource
        Me.bsNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.bsNavigator.DeleteItem = Nothing
        Me.bsNavigator.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.bsNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2})
        Me.bsNavigator.Location = New System.Drawing.Point(0, 735)
        Me.bsNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.bsNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.bsNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.bsNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.bsNavigator.Name = "bsNavigator"
        Me.bsNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.bsNavigator.Size = New System.Drawing.Size(994, 25)
        Me.bsNavigator.TabIndex = 32
        Me.bsNavigator.Text = "BindingNavigator1"
        '
        'DetailStopImagesBindingSource
        '
        Me.DetailStopImagesBindingSource.DataMember = "tblStopImages"
        Me.DetailStopImagesBindingSource.DataSource = Me.BusStopManagementDataSet2
        '
        'BusStopManagementDataSet2
        '
        Me.BusStopManagementDataSet2.DataSetName = "BusStopManagementDataSet2"
        Me.BusStopManagementDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblStopImagesTableAdapter
        '
        Me.TblStopImagesTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.tblStopImagesTableAdapter = Me.TblStopImagesTableAdapter
        Me.TableAdapterManager.UpdateOrder = BusStopManagement.BusStopManagementDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'txtPicNo
        '
        Me.txtPicNo.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DetailStopImagesBindingSource, "ID", True))
        Me.txtPicNo.ForeColor = System.Drawing.Color.DimGray
        Me.txtPicNo.Location = New System.Drawing.Point(762, 703)
        Me.txtPicNo.Name = "txtPicNo"
        Me.txtPicNo.Size = New System.Drawing.Size(100, 20)
        Me.txtPicNo.TabIndex = 33
        '
        'OCTA_IDTextBox
        '
        Me.OCTA_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DetailStopImagesBindingSource, "OCTA_ID", True))
        Me.OCTA_IDTextBox.ForeColor = System.Drawing.Color.DimGray
        Me.OCTA_IDTextBox.Location = New System.Drawing.Point(574, 677)
        Me.OCTA_IDTextBox.Name = "OCTA_IDTextBox"
        Me.OCTA_IDTextBox.Size = New System.Drawing.Size(92, 20)
        Me.OCTA_IDTextBox.TabIndex = 35
        '
        'SANZ_IDTextBox
        '
        Me.SANZ_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DetailStopImagesBindingSource, "SANZ_ID", True))
        Me.SANZ_IDTextBox.ForeColor = System.Drawing.Color.DimGray
        Me.SANZ_IDTextBox.Location = New System.Drawing.Point(574, 703)
        Me.SANZ_IDTextBox.Name = "SANZ_IDTextBox"
        Me.SANZ_IDTextBox.Size = New System.Drawing.Size(92, 20)
        Me.SANZ_IDTextBox.TabIndex = 37
        '
        'txtPicNotes
        '
        Me.txtPicNotes.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DetailStopImagesBindingSource, "IMAGE_DESC", True))
        Me.txtPicNotes.ForeColor = System.Drawing.Color.DimGray
        Me.txtPicNotes.Location = New System.Drawing.Point(15, 680)
        Me.txtPicNotes.Multiline = True
        Me.txtPicNotes.Name = "txtPicNotes"
        Me.txtPicNotes.Size = New System.Drawing.Size(224, 40)
        Me.txtPicNotes.TabIndex = 45
        '
        'txtPicPath
        '
        Me.txtPicPath.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DetailStopImagesBindingSource, "IMAGE_PATH", True))
        Me.txtPicPath.ForeColor = System.Drawing.Color.DimGray
        Me.txtPicPath.Location = New System.Drawing.Point(255, 680)
        Me.txtPicPath.Multiline = True
        Me.txtPicPath.Name = "txtPicPath"
        Me.txtPicPath.Size = New System.Drawing.Size(249, 40)
        Me.txtPicPath.TabIndex = 47
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(252, 663)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(75, 14)
        Me.Label1.TabIndex = 48
        Me.Label1.Text = "IMAGE PATH:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtPicDate
        '
        Me.txtPicDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DetailStopImagesBindingSource, "IMAGE_DATE", True))
        Me.txtPicDate.ForeColor = System.Drawing.Color.DimGray
        Me.txtPicDate.Location = New System.Drawing.Point(762, 676)
        Me.txtPicDate.Name = "txtPicDate"
        Me.txtPicDate.Size = New System.Drawing.Size(100, 20)
        Me.txtPicDate.TabIndex = 49
        '
        'ZoomPictureBox1
        '
        Me.ZoomPictureBox1.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.ZoomPictureBox1.EnableMouseDragging = True
        Me.ZoomPictureBox1.EnableMouseWheelZooming = True
        Me.ZoomPictureBox1.Image = Nothing
        Me.ZoomPictureBox1.ImagePosition = New System.Drawing.Point(0, 0)
        Me.ZoomPictureBox1.Location = New System.Drawing.Point(15, 18)
        Me.ZoomPictureBox1.MaximumZoomFactor = 64.0R
        Me.ZoomPictureBox1.MinimumImageHeight = 10
        Me.ZoomPictureBox1.MinimumImageWidth = 10
        Me.ZoomPictureBox1.MouseWheelDivisor = 4000
        Me.ZoomPictureBox1.Name = "ZoomPictureBox1"
        Me.ZoomPictureBox1.Size = New System.Drawing.Size(962, 640)
        Me.ZoomPictureBox1.TabIndex = 0
        Me.ZoomPictureBox1.ZoomFactor = 0R
        '
        'frmBusStopPicDetail
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(994, 760)
        Me.Controls.Add(Me.txtPicDate)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtPicNo)
        Me.Controls.Add(OCTA_IDLabel)
        Me.Controls.Add(Me.OCTA_IDTextBox)
        Me.Controls.Add(SANZ_IDLabel)
        Me.Controls.Add(Me.SANZ_IDTextBox)
        Me.Controls.Add(Me.txtPicNotes)
        Me.Controls.Add(Me.txtPicPath)
        Me.Controls.Add(Me.bsNavigator)
        Me.Controls.Add(Me._Label1_47)
        Me.Controls.Add(Me.cmdGoogleMaps)
        Me.Controls.Add(Me._Label1_57)
        Me.Controls.Add(Me._Label1_54)
        Me.Controls.Add(Me.ZoomPictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmBusStopPicDetail"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Bus Stop Picture Detail"
        CType(Me.bsNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.bsNavigator.ResumeLayout(False)
        Me.bsNavigator.PerformLayout()
        CType(Me.DetailStopImagesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusStopManagementDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ZoomPictureBox1 As ZoomPictureBox
    Public WithEvents _Label1_47 As Label
    Public WithEvents cmdGoogleMaps As Button
    Public WithEvents _Label1_57 As Label
    Public WithEvents _Label1_54 As Label
    Friend WithEvents bsNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents BusStopManagementDataSet2 As BusStopManagementDataSet2
    Friend WithEvents DetailStopImagesBindingSource As BindingSource
    Friend WithEvents TblStopImagesTableAdapter As BusStopManagementDataSet2TableAdapters.tblStopImagesTableAdapter
    Friend WithEvents TableAdapterManager As BusStopManagementDataSet2TableAdapters.TableAdapterManager
    Friend WithEvents txtPicNo As TextBox
    Friend WithEvents OCTA_IDTextBox As TextBox
    Friend WithEvents SANZ_IDTextBox As TextBox
    Friend WithEvents txtPicNotes As TextBox
    Friend WithEvents txtPicPath As TextBox
    Public WithEvents Label1 As Label
    Friend WithEvents txtPicDate As TextBox
End Class
