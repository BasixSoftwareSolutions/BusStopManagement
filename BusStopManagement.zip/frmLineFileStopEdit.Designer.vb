﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLineFileStopEdit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLineFileStopEdit))
        Me.lblRouteInfo = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtXStreet = New System.Windows.Forms.TextBox()
        Me.txtLOC = New System.Windows.Forms.TextBox()
        Me.txtStreet = New System.Windows.Forms.TextBox()
        Me.txtDIR = New System.Windows.Forms.TextBox()
        Me.txtSANZ_ID = New System.Windows.Forms.TextBox()
        Me.txtOCTA_ID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtSeqNo = New System.Windows.Forms.TextBox()
        Me.optTimePoint1 = New System.Windows.Forms.RadioButton()
        Me.txtTransferInfo = New System.Windows.Forms.TextBox()
        Me.optTimePoint0 = New System.Windows.Forms.RadioButton()
        Me.lstLandmarks = New System.Windows.Forms.ListBox()
        Me.cmdAddLandmark = New System.Windows.Forms.Button()
        Me.txtTPID = New System.Windows.Forms.TextBox()
        Me.txtTPDesc = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cboComment = New System.Windows.Forms.ComboBox()
        Me.cboHardware = New System.Windows.Forms.ComboBox()
        Me.cboTPID = New System.Windows.Forms.ComboBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblRouteInfo
        '
        Me.lblRouteInfo.BackColor = System.Drawing.Color.Transparent
        Me.lblRouteInfo.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblRouteInfo.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRouteInfo.ForeColor = System.Drawing.Color.DimGray
        Me.lblRouteInfo.Location = New System.Drawing.Point(83, 20)
        Me.lblRouteInfo.Name = "lblRouteInfo"
        Me.lblRouteInfo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblRouteInfo.Size = New System.Drawing.Size(517, 25)
        Me.lblRouteInfo.TabIndex = 23
        Me.lblRouteInfo.Text = "TO BE REPLACED WITH ROUTE INFORMATION"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(30, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(51, 25)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "ROUTE:"
        '
        'txtXStreet
        '
        Me.txtXStreet.AcceptsReturn = True
        Me.txtXStreet.BackColor = System.Drawing.SystemColors.Window
        Me.txtXStreet.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtXStreet.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXStreet.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtXStreet.Location = New System.Drawing.Point(16, 286)
        Me.txtXStreet.MaxLength = 0
        Me.txtXStreet.Name = "txtXStreet"
        Me.txtXStreet.ReadOnly = True
        Me.txtXStreet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtXStreet.Size = New System.Drawing.Size(185, 20)
        Me.txtXStreet.TabIndex = 37
        Me.txtXStreet.TabStop = False
        '
        'txtLOC
        '
        Me.txtLOC.AcceptsReturn = True
        Me.txtLOC.BackColor = System.Drawing.SystemColors.Window
        Me.txtLOC.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLOC.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLOC.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLOC.Location = New System.Drawing.Point(16, 230)
        Me.txtLOC.MaxLength = 0
        Me.txtLOC.Name = "txtLOC"
        Me.txtLOC.ReadOnly = True
        Me.txtLOC.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLOC.Size = New System.Drawing.Size(49, 20)
        Me.txtLOC.TabIndex = 36
        Me.txtLOC.TabStop = False
        '
        'txtStreet
        '
        Me.txtStreet.AcceptsReturn = True
        Me.txtStreet.BackColor = System.Drawing.SystemColors.Window
        Me.txtStreet.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtStreet.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStreet.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtStreet.Location = New System.Drawing.Point(16, 182)
        Me.txtStreet.MaxLength = 0
        Me.txtStreet.Name = "txtStreet"
        Me.txtStreet.ReadOnly = True
        Me.txtStreet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtStreet.Size = New System.Drawing.Size(185, 20)
        Me.txtStreet.TabIndex = 35
        Me.txtStreet.TabStop = False
        '
        'txtDIR
        '
        Me.txtDIR.AcceptsReturn = True
        Me.txtDIR.BackColor = System.Drawing.SystemColors.Window
        Me.txtDIR.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDIR.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDIR.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDIR.Location = New System.Drawing.Point(16, 134)
        Me.txtDIR.MaxLength = 0
        Me.txtDIR.Name = "txtDIR"
        Me.txtDIR.ReadOnly = True
        Me.txtDIR.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDIR.Size = New System.Drawing.Size(49, 20)
        Me.txtDIR.TabIndex = 34
        Me.txtDIR.TabStop = False
        '
        'txtSANZ_ID
        '
        Me.txtSANZ_ID.AcceptsReturn = True
        Me.txtSANZ_ID.BackColor = System.Drawing.SystemColors.Window
        Me.txtSANZ_ID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSANZ_ID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSANZ_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSANZ_ID.Location = New System.Drawing.Point(16, 86)
        Me.txtSANZ_ID.MaxLength = 0
        Me.txtSANZ_ID.Name = "txtSANZ_ID"
        Me.txtSANZ_ID.ReadOnly = True
        Me.txtSANZ_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSANZ_ID.Size = New System.Drawing.Size(89, 20)
        Me.txtSANZ_ID.TabIndex = 33
        Me.txtSANZ_ID.TabStop = False
        '
        'txtOCTA_ID
        '
        Me.txtOCTA_ID.AcceptsReturn = True
        Me.txtOCTA_ID.BackColor = System.Drawing.SystemColors.Window
        Me.txtOCTA_ID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtOCTA_ID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOCTA_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOCTA_ID.Location = New System.Drawing.Point(16, 38)
        Me.txtOCTA_ID.MaxLength = 0
        Me.txtOCTA_ID.Name = "txtOCTA_ID"
        Me.txtOCTA_ID.ReadOnly = True
        Me.txtOCTA_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtOCTA_ID.Size = New System.Drawing.Size(89, 20)
        Me.txtOCTA_ID.TabIndex = 38
        Me.txtOCTA_ID.TabStop = False
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(16, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(89, 17)
        Me.Label4.TabIndex = 44
        Me.Label4.Text = "OCTA ID"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(16, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(89, 17)
        Me.Label2.TabIndex = 43
        Me.Label2.Text = "SANZ ID"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(16, 118)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(49, 17)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "DIR"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DimGray
        Me.Label5.Location = New System.Drawing.Point(16, 166)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(137, 17)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "STREET OF TRAVEL"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DimGray
        Me.Label6.Location = New System.Drawing.Point(16, 214)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(49, 17)
        Me.Label6.TabIndex = 40
        Me.Label6.Text = "LOC"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DimGray
        Me.Label7.Location = New System.Drawing.Point(16, 270)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(137, 17)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "CROSS STREET"
        '
        'txtSeqNo
        '
        Me.txtSeqNo.AcceptsReturn = True
        Me.txtSeqNo.BackColor = System.Drawing.SystemColors.Window
        Me.txtSeqNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSeqNo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSeqNo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSeqNo.Location = New System.Drawing.Point(99, 103)
        Me.txtSeqNo.MaxLength = 0
        Me.txtSeqNo.Name = "txtSeqNo"
        Me.txtSeqNo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSeqNo.Size = New System.Drawing.Size(89, 20)
        Me.txtSeqNo.TabIndex = 49
        '
        'optTimePoint1
        '
        Me.optTimePoint1.BackColor = System.Drawing.Color.Transparent
        Me.optTimePoint1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optTimePoint1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optTimePoint1.ForeColor = System.Drawing.Color.DimGray
        Me.optTimePoint1.Location = New System.Drawing.Point(159, 17)
        Me.optTimePoint1.Name = "optTimePoint1"
        Me.optTimePoint1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optTimePoint1.Size = New System.Drawing.Size(57, 25)
        Me.optTimePoint1.TabIndex = 46
        Me.optTimePoint1.TabStop = True
        Me.optTimePoint1.Text = "NO"
        Me.optTimePoint1.UseVisualStyleBackColor = False
        '
        'txtTransferInfo
        '
        Me.txtTransferInfo.AcceptsReturn = True
        Me.txtTransferInfo.BackColor = System.Drawing.SystemColors.Window
        Me.txtTransferInfo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTransferInfo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTransferInfo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTransferInfo.Location = New System.Drawing.Point(12, 153)
        Me.txtTransferInfo.MaxLength = 45
        Me.txtTransferInfo.Multiline = True
        Me.txtTransferInfo.Name = "txtTransferInfo"
        Me.txtTransferInfo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTransferInfo.Size = New System.Drawing.Size(321, 33)
        Me.txtTransferInfo.TabIndex = 51
        '
        'optTimePoint0
        '
        Me.optTimePoint0.BackColor = System.Drawing.Color.Transparent
        Me.optTimePoint0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optTimePoint0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optTimePoint0.ForeColor = System.Drawing.Color.DimGray
        Me.optTimePoint0.Location = New System.Drawing.Point(95, 17)
        Me.optTimePoint0.Name = "optTimePoint0"
        Me.optTimePoint0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optTimePoint0.Size = New System.Drawing.Size(57, 25)
        Me.optTimePoint0.TabIndex = 45
        Me.optTimePoint0.TabStop = True
        Me.optTimePoint0.Text = "YES"
        Me.optTimePoint0.UseVisualStyleBackColor = False
        '
        'lstLandmarks
        '
        Me.lstLandmarks.BackColor = System.Drawing.SystemColors.Window
        Me.lstLandmarks.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstLandmarks.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstLandmarks.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstLandmarks.ItemHeight = 14
        Me.lstLandmarks.Location = New System.Drawing.Point(12, 216)
        Me.lstLandmarks.Name = "lstLandmarks"
        Me.lstLandmarks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstLandmarks.Size = New System.Drawing.Size(321, 46)
        Me.lstLandmarks.TabIndex = 53
        '
        'cmdAddLandmark
        '
        Me.cmdAddLandmark.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddLandmark.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddLandmark.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddLandmark.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddLandmark.Location = New System.Drawing.Point(212, 190)
        Me.cmdAddLandmark.Name = "cmdAddLandmark"
        Me.cmdAddLandmark.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAddLandmark.Size = New System.Drawing.Size(121, 23)
        Me.cmdAddLandmark.TabIndex = 52
        Me.cmdAddLandmark.Text = "ADD LANDMARK"
        Me.cmdAddLandmark.UseVisualStyleBackColor = False
        '
        'txtTPID
        '
        Me.txtTPID.AcceptsReturn = True
        Me.txtTPID.BackColor = System.Drawing.SystemColors.Window
        Me.txtTPID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTPID.Enabled = False
        Me.txtTPID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTPID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTPID.Location = New System.Drawing.Point(220, 46)
        Me.txtTPID.MaxLength = 0
        Me.txtTPID.Name = "txtTPID"
        Me.txtTPID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTPID.Size = New System.Drawing.Size(113, 20)
        Me.txtTPID.TabIndex = 55
        Me.txtTPID.Visible = False
        '
        'txtTPDesc
        '
        Me.txtTPDesc.AcceptsReturn = True
        Me.txtTPDesc.BackColor = System.Drawing.SystemColors.Window
        Me.txtTPDesc.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTPDesc.Enabled = False
        Me.txtTPDesc.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTPDesc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTPDesc.Location = New System.Drawing.Point(76, 73)
        Me.txtTPDesc.MaxLength = 0
        Me.txtTPDesc.Name = "txtTPDesc"
        Me.txtTPDesc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTPDesc.Size = New System.Drawing.Size(257, 20)
        Me.txtTPDesc.TabIndex = 48
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DimGray
        Me.Label8.Location = New System.Drawing.Point(12, 23)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(81, 17)
        Me.Label8.TabIndex = 63
        Me.Label8.Text = "TIME POINT"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.DimGray
        Me.Label9.Location = New System.Drawing.Point(12, 106)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(97, 17)
        Me.Label9.TabIndex = 62
        Me.Label9.Text = "SEQUENCE NO."
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DimGray
        Me.Label10.Location = New System.Drawing.Point(196, 105)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(89, 17)
        Me.Label10.TabIndex = 61
        Me.Label10.Text = "HARDWARE"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.DimGray
        Me.Label11.Location = New System.Drawing.Point(12, 137)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(313, 17)
        Me.Label11.TabIndex = 60
        Me.Label11.Text = "TRANSFER ROUTES INFORMATION"
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.DimGray
        Me.Label12.Location = New System.Drawing.Point(12, 200)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(89, 17)
        Me.Label12.TabIndex = 59
        Me.Label12.Text = "LANDMARKS"
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.DimGray
        Me.Label13.Location = New System.Drawing.Point(12, 271)
        Me.Label13.Name = "Label13"
        Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label13.Size = New System.Drawing.Size(89, 17)
        Me.Label13.TabIndex = 58
        Me.Label13.Text = "COMMENT"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label14.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.DimGray
        Me.Label14.Location = New System.Drawing.Point(12, 49)
        Me.Label14.Name = "Label14"
        Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label14.Size = New System.Drawing.Size(81, 17)
        Me.Label14.TabIndex = 57
        Me.Label14.Text = "TP ID"
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.DimGray
        Me.Label15.Location = New System.Drawing.Point(12, 73)
        Me.Label15.Name = "Label15"
        Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label15.Size = New System.Drawing.Size(81, 17)
        Me.Label15.TabIndex = 56
        Me.Label15.Text = "TP DESC."
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSave.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSave.Location = New System.Drawing.Point(398, 407)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSave.Size = New System.Drawing.Size(89, 27)
        Me.cmdSave.TabIndex = 64
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(495, 407)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(89, 27)
        Me.cmdClose.TabIndex = 65
        Me.cmdClose.Text = "&Cancel"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(383, 399)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(217, 41)
        Me.Shape1.TabIndex = 66
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.cboComment)
        Me.Panel1.Controls.Add(Me.cboHardware)
        Me.Panel1.Controls.Add(Me.cboTPID)
        Me.Panel1.Controls.Add(Me.txtSeqNo)
        Me.Panel1.Controls.Add(Me.optTimePoint1)
        Me.Panel1.Controls.Add(Me.txtTransferInfo)
        Me.Panel1.Controls.Add(Me.optTimePoint0)
        Me.Panel1.Controls.Add(Me.lstLandmarks)
        Me.Panel1.Controls.Add(Me.cmdAddLandmark)
        Me.Panel1.Controls.Add(Me.txtTPID)
        Me.Panel1.Controls.Add(Me.txtTPDesc)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Location = New System.Drawing.Point(250, 57)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(350, 330)
        Me.Panel1.TabIndex = 67
        '
        'cboComment
        '
        Me.cboComment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboComment.FormattingEnabled = True
        Me.cboComment.Location = New System.Drawing.Point(13, 286)
        Me.cboComment.Name = "cboComment"
        Me.cboComment.Size = New System.Drawing.Size(320, 21)
        Me.cboComment.TabIndex = 66
        '
        'cboHardware
        '
        Me.cboHardware.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboHardware.FormattingEnabled = True
        Me.cboHardware.Location = New System.Drawing.Point(263, 103)
        Me.cboHardware.Name = "cboHardware"
        Me.cboHardware.Size = New System.Drawing.Size(70, 21)
        Me.cboHardware.TabIndex = 65
        '
        'cboTPID
        '
        Me.cboTPID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTPID.FormattingEnabled = True
        Me.cboTPID.Location = New System.Drawing.Point(76, 46)
        Me.cboTPID.Name = "cboTPID"
        Me.cboTPID.Size = New System.Drawing.Size(121, 21)
        Me.cboTPID.TabIndex = 64
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.txtXStreet)
        Me.Panel3.Controls.Add(Me.txtLOC)
        Me.Panel3.Controls.Add(Me.txtStreet)
        Me.Panel3.Controls.Add(Me.txtDIR)
        Me.Panel3.Controls.Add(Me.txtSANZ_ID)
        Me.Panel3.Controls.Add(Me.txtOCTA_ID)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Location = New System.Drawing.Point(12, 57)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(242, 330)
        Me.Panel3.TabIndex = 68
        '
        'frmLineFileStopEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(615, 447)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.Shape1)
        Me.Controls.Add(Me.lblRouteInfo)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.Color.DimGray
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmLineFileStopEdit"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Edit Stop"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents lblRouteInfo As Label
    Public WithEvents Label1 As Label
    Public WithEvents txtXStreet As TextBox
    Public WithEvents txtLOC As TextBox
    Public WithEvents txtStreet As TextBox
    Public WithEvents txtDIR As TextBox
    Public WithEvents txtSANZ_ID As TextBox
    Public WithEvents txtOCTA_ID As TextBox
    Public WithEvents Label4 As Label
    Public WithEvents Label2 As Label
    Public WithEvents Label3 As Label
    Public WithEvents Label5 As Label
    Public WithEvents Label6 As Label
    Public WithEvents Label7 As Label
    Public WithEvents txtSeqNo As TextBox
    Public WithEvents optTimePoint1 As RadioButton
    Public WithEvents txtTransferInfo As TextBox
    Public WithEvents optTimePoint0 As RadioButton
    Public WithEvents lstLandmarks As ListBox
    Public WithEvents cmdAddLandmark As Button
    Public WithEvents txtTPID As TextBox
    Public WithEvents txtTPDesc As TextBox
    Public WithEvents Label8 As Label
    Public WithEvents Label9 As Label
    Public WithEvents Label10 As Label
    Public WithEvents Label11 As Label
    Public WithEvents Label12 As Label
    Public WithEvents Label13 As Label
    Public WithEvents Label14 As Label
    Public WithEvents Label15 As Label
    Public WithEvents cmdSave As Button
    Public WithEvents cmdClose As Button
    Public WithEvents Shape1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents cboComment As ComboBox
    Friend WithEvents cboHardware As ComboBox
    Friend WithEvents cboTPID As ComboBox
    Friend WithEvents Panel3 As Panel
End Class
