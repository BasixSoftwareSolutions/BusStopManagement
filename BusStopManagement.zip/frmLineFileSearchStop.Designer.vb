﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLineFileSearchStop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLineFileSearchStop))
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdClear = New System.Windows.Forms.Button()
        Me.cmdSelect = New System.Windows.Forms.Button()
        Me.cmdSearch = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cboSearchLoc = New System.Windows.Forms.ComboBox()
        Me.cboSearchDir = New System.Windows.Forms.ComboBox()
        Me.txtSearchXStreet = New System.Windows.Forms.TextBox()
        Me.txtSearchStreet = New System.Windows.Forms.TextBox()
        Me.txtSearchSANZID = New System.Windows.Forms.TextBox()
        Me.txtSearchOCTAID = New System.Windows.Forms.TextBox()
        Me.optSearchBy1 = New System.Windows.Forms.RadioButton()
        Me.optSearchBy2 = New System.Windows.Forms.RadioButton()
        Me.optSearchBy0 = New System.Windows.Forms.RadioButton()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lstResults = New System.Windows.Forms.ListBox()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(335, 251)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(81, 25)
        Me.cmdCancel.TabIndex = 24
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdClear
        '
        Me.cmdClear.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClear.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClear.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClear.Location = New System.Drawing.Point(239, 251)
        Me.cmdClear.Name = "cmdClear"
        Me.cmdClear.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClear.Size = New System.Drawing.Size(81, 25)
        Me.cmdClear.TabIndex = 23
        Me.cmdClear.Text = "Clear &Fields"
        Me.cmdClear.UseVisualStyleBackColor = False
        '
        'cmdSelect
        '
        Me.cmdSelect.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSelect.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSelect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSelect.Location = New System.Drawing.Point(143, 251)
        Me.cmdSelect.Name = "cmdSelect"
        Me.cmdSelect.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSelect.Size = New System.Drawing.Size(81, 25)
        Me.cmdSelect.TabIndex = 22
        Me.cmdSelect.Text = "Select Sto&p"
        Me.cmdSelect.UseVisualStyleBackColor = False
        '
        'cmdSearch
        '
        Me.cmdSearch.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSearch.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSearch.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSearch.Location = New System.Drawing.Point(47, 251)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSearch.Size = New System.Drawing.Size(81, 25)
        Me.cmdSearch.TabIndex = 21
        Me.cmdSearch.Text = "&Search"
        Me.cmdSearch.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.cboSearchLoc)
        Me.Frame1.Controls.Add(Me.cboSearchDir)
        Me.Frame1.Controls.Add(Me.txtSearchXStreet)
        Me.Frame1.Controls.Add(Me.txtSearchStreet)
        Me.Frame1.Controls.Add(Me.txtSearchSANZID)
        Me.Frame1.Controls.Add(Me.txtSearchOCTAID)
        Me.Frame1.Controls.Add(Me.optSearchBy1)
        Me.Frame1.Controls.Add(Me.optSearchBy2)
        Me.Frame1.Controls.Add(Me.optSearchBy0)
        Me.Frame1.Controls.Add(Me.Label5)
        Me.Frame1.Controls.Add(Me.Label4)
        Me.Frame1.Controls.Add(Me.Label3)
        Me.Frame1.Controls.Add(Me.Label2)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(31, 27)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(401, 209)
        Me.Frame1.TabIndex = 27
        Me.Frame1.TabStop = False
        '
        'cboSearchLoc
        '
        Me.cboSearchLoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSearchLoc.Enabled = False
        Me.cboSearchLoc.FormattingEnabled = True
        Me.cboSearchLoc.Location = New System.Drawing.Point(76, 168)
        Me.cboSearchLoc.Name = "cboSearchLoc"
        Me.cboSearchLoc.Size = New System.Drawing.Size(50, 22)
        Me.cboSearchLoc.TabIndex = 21
        '
        'cboSearchDir
        '
        Me.cboSearchDir.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSearchDir.Enabled = False
        Me.cboSearchDir.FormattingEnabled = True
        Me.cboSearchDir.Location = New System.Drawing.Point(76, 133)
        Me.cboSearchDir.Name = "cboSearchDir"
        Me.cboSearchDir.Size = New System.Drawing.Size(50, 22)
        Me.cboSearchDir.TabIndex = 20
        '
        'txtSearchXStreet
        '
        Me.txtSearchXStreet.AcceptsReturn = True
        Me.txtSearchXStreet.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtSearchXStreet.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearchXStreet.Enabled = False
        Me.txtSearchXStreet.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchXStreet.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchXStreet.Location = New System.Drawing.Point(200, 168)
        Me.txtSearchXStreet.MaxLength = 0
        Me.txtSearchXStreet.Name = "txtSearchXStreet"
        Me.txtSearchXStreet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSearchXStreet.Size = New System.Drawing.Size(185, 20)
        Me.txtSearchXStreet.TabIndex = 8
        '
        'txtSearchStreet
        '
        Me.txtSearchStreet.AcceptsReturn = True
        Me.txtSearchStreet.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtSearchStreet.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearchStreet.Enabled = False
        Me.txtSearchStreet.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchStreet.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchStreet.Location = New System.Drawing.Point(200, 136)
        Me.txtSearchStreet.MaxLength = 0
        Me.txtSearchStreet.Name = "txtSearchStreet"
        Me.txtSearchStreet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSearchStreet.Size = New System.Drawing.Size(185, 20)
        Me.txtSearchStreet.TabIndex = 6
        '
        'txtSearchSANZID
        '
        Me.txtSearchSANZID.AcceptsReturn = True
        Me.txtSearchSANZID.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtSearchSANZID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearchSANZID.Enabled = False
        Me.txtSearchSANZID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchSANZID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchSANZID.Location = New System.Drawing.Point(104, 64)
        Me.txtSearchSANZID.MaxLength = 0
        Me.txtSearchSANZID.Name = "txtSearchSANZID"
        Me.txtSearchSANZID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSearchSANZID.Size = New System.Drawing.Size(97, 20)
        Me.txtSearchSANZID.TabIndex = 3
        '
        'txtSearchOCTAID
        '
        Me.txtSearchOCTAID.AcceptsReturn = True
        Me.txtSearchOCTAID.BackColor = System.Drawing.SystemColors.Window
        Me.txtSearchOCTAID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearchOCTAID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchOCTAID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchOCTAID.Location = New System.Drawing.Point(104, 24)
        Me.txtSearchOCTAID.MaxLength = 0
        Me.txtSearchOCTAID.Name = "txtSearchOCTAID"
        Me.txtSearchOCTAID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSearchOCTAID.Size = New System.Drawing.Size(97, 20)
        Me.txtSearchOCTAID.TabIndex = 0
        '
        'optSearchBy1
        '
        Me.optSearchBy1.BackColor = System.Drawing.Color.Transparent
        Me.optSearchBy1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optSearchBy1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSearchBy1.ForeColor = System.Drawing.Color.DimGray
        Me.optSearchBy1.Location = New System.Drawing.Point(24, 64)
        Me.optSearchBy1.Name = "optSearchBy1"
        Me.optSearchBy1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optSearchBy1.Size = New System.Drawing.Size(73, 17)
        Me.optSearchBy1.TabIndex = 2
        Me.optSearchBy1.TabStop = True
        Me.optSearchBy1.Text = "SANZ ID:"
        Me.optSearchBy1.UseVisualStyleBackColor = False
        '
        'optSearchBy2
        '
        Me.optSearchBy2.BackColor = System.Drawing.Color.Transparent
        Me.optSearchBy2.Cursor = System.Windows.Forms.Cursors.Default
        Me.optSearchBy2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSearchBy2.ForeColor = System.Drawing.Color.DimGray
        Me.optSearchBy2.Location = New System.Drawing.Point(24, 104)
        Me.optSearchBy2.Name = "optSearchBy2"
        Me.optSearchBy2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optSearchBy2.Size = New System.Drawing.Size(121, 17)
        Me.optSearchBy2.TabIndex = 4
        Me.optSearchBy2.TabStop = True
        Me.optSearchBy2.Text = "Street/Cross Street:"
        Me.optSearchBy2.UseVisualStyleBackColor = False
        '
        'optSearchBy0
        '
        Me.optSearchBy0.BackColor = System.Drawing.Color.Transparent
        Me.optSearchBy0.Checked = True
        Me.optSearchBy0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optSearchBy0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSearchBy0.ForeColor = System.Drawing.Color.DimGray
        Me.optSearchBy0.Location = New System.Drawing.Point(24, 24)
        Me.optSearchBy0.Name = "optSearchBy0"
        Me.optSearchBy0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optSearchBy0.Size = New System.Drawing.Size(73, 17)
        Me.optSearchBy0.TabIndex = 0
        Me.optSearchBy0.TabStop = True
        Me.optSearchBy0.Text = "OCTA ID:"
        Me.optSearchBy0.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DimGray
        Me.Label5.Location = New System.Drawing.Point(136, 168)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(71, 14)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Cross Street:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(165, 136)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(39, 14)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "Street:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(19, 171)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(51, 14)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Location:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(18, 139)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(52, 14)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Direction:"
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(31, 243)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(401, 41)
        Me.Shape1.TabIndex = 28
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DimGray
        Me.Label6.Location = New System.Drawing.Point(31, 291)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(106, 16)
        Me.Label6.TabIndex = 29
        Me.Label6.Text = "Search Results:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(31, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(77, 16)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Search By:"
        '
        'lstResults
        '
        Me.lstResults.FormattingEnabled = True
        Me.lstResults.Location = New System.Drawing.Point(31, 310)
        Me.lstResults.Name = "lstResults"
        Me.lstResults.Size = New System.Drawing.Size(397, 147)
        Me.lstResults.TabIndex = 33
        '
        'frmLineFileSearchStop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(460, 472)
        Me.Controls.Add(Me.lstResults)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdClear)
        Me.Controls.Add(Me.cmdSelect)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Shape1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmLineFileSearchStop"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Locate Stop"
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents cmdCancel As Button
    Public WithEvents cmdClear As Button
    Public WithEvents cmdSelect As Button
    Public WithEvents cmdSearch As Button
    Public WithEvents Frame1 As GroupBox
    Public WithEvents txtSearchXStreet As TextBox
    Public WithEvents txtSearchStreet As TextBox
    Public WithEvents txtSearchSANZID As TextBox
    Public WithEvents txtSearchOCTAID As TextBox
    Public WithEvents optSearchBy1 As RadioButton
    Public WithEvents optSearchBy2 As RadioButton
    Public WithEvents optSearchBy0 As RadioButton
    Public WithEvents Label5 As Label
    Public WithEvents Label4 As Label
    Public WithEvents Label3 As Label
    Public WithEvents Label2 As Label
    Public WithEvents Shape1 As Label
    Public WithEvents Label6 As Label
    Public WithEvents Label1 As Label
    Friend WithEvents cboSearchLoc As ComboBox
    Friend WithEvents cboSearchDir As ComboBox
    Friend WithEvents lstResults As ListBox
End Class
