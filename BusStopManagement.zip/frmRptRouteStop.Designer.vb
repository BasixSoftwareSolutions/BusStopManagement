﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRptRouteStop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRptRouteStop))
        Me.cboContractorTo = New System.Windows.Forms.ComboBox()
        Me.cboContractorFrom = New System.Windows.Forms.ComboBox()
        Me.cboDriverTo = New System.Windows.Forms.ComboBox()
        Me.cboDriverFrom = New System.Windows.Forms.ComboBox()
        Me.cboOfficeTo = New System.Windows.Forms.ComboBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdPrint = New System.Windows.Forms.Button()
        Me.optCopy4 = New System.Windows.Forms.RadioButton()
        Me.optCopy5 = New System.Windows.Forms.RadioButton()
        Me.txtContractorFrom = New System.Windows.Forms.TextBox()
        Me.txtContractorTo = New System.Windows.Forms.TextBox()
        Me.optCopy2 = New System.Windows.Forms.RadioButton()
        Me.optCopy3 = New System.Windows.Forms.RadioButton()
        Me.txtDriverFrom = New System.Windows.Forms.TextBox()
        Me.txtDriverTo = New System.Windows.Forms.TextBox()
        Me.optCopy0 = New System.Windows.Forms.RadioButton()
        Me.optCopy1 = New System.Windows.Forms.RadioButton()
        Me.txtOfficeFrom = New System.Windows.Forms.TextBox()
        Me.txtOfficeTo = New System.Windows.Forms.TextBox()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cboOfficeFrom = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Frame3 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Frame1.SuspendLayout()
        Me.Frame3.SuspendLayout()
        Me.Frame2.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboContractorTo
        '
        Me.cboContractorTo.BackColor = System.Drawing.SystemColors.Window
        Me.cboContractorTo.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboContractorTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboContractorTo.Enabled = False
        Me.cboContractorTo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboContractorTo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboContractorTo.Location = New System.Drawing.Point(211, 260)
        Me.cboContractorTo.Name = "cboContractorTo"
        Me.cboContractorTo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboContractorTo.Size = New System.Drawing.Size(49, 22)
        Me.cboContractorTo.TabIndex = 54
        '
        'cboContractorFrom
        '
        Me.cboContractorFrom.BackColor = System.Drawing.SystemColors.Window
        Me.cboContractorFrom.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboContractorFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboContractorFrom.Enabled = False
        Me.cboContractorFrom.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboContractorFrom.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboContractorFrom.Location = New System.Drawing.Point(115, 260)
        Me.cboContractorFrom.Name = "cboContractorFrom"
        Me.cboContractorFrom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboContractorFrom.Size = New System.Drawing.Size(49, 22)
        Me.cboContractorFrom.TabIndex = 53
        '
        'cboDriverTo
        '
        Me.cboDriverTo.BackColor = System.Drawing.SystemColors.Window
        Me.cboDriverTo.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboDriverTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDriverTo.Enabled = False
        Me.cboDriverTo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboDriverTo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboDriverTo.Location = New System.Drawing.Point(211, 148)
        Me.cboDriverTo.Name = "cboDriverTo"
        Me.cboDriverTo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboDriverTo.Size = New System.Drawing.Size(49, 22)
        Me.cboDriverTo.TabIndex = 52
        '
        'cboDriverFrom
        '
        Me.cboDriverFrom.BackColor = System.Drawing.SystemColors.Window
        Me.cboDriverFrom.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboDriverFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDriverFrom.Enabled = False
        Me.cboDriverFrom.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboDriverFrom.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboDriverFrom.Location = New System.Drawing.Point(115, 148)
        Me.cboDriverFrom.Name = "cboDriverFrom"
        Me.cboDriverFrom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboDriverFrom.Size = New System.Drawing.Size(49, 22)
        Me.cboDriverFrom.TabIndex = 51
        '
        'cboOfficeTo
        '
        Me.cboOfficeTo.BackColor = System.Drawing.SystemColors.Window
        Me.cboOfficeTo.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboOfficeTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOfficeTo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboOfficeTo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboOfficeTo.Location = New System.Drawing.Point(211, 36)
        Me.cboOfficeTo.Name = "cboOfficeTo"
        Me.cboOfficeTo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboOfficeTo.Size = New System.Drawing.Size(49, 22)
        Me.cboOfficeTo.TabIndex = 50
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(190, 349)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(121, 25)
        Me.cmdCancel.TabIndex = 31
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdPrint
        '
        Me.cmdPrint.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPrint.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPrint.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPrint.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPrint.Location = New System.Drawing.Point(18, 350)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPrint.Size = New System.Drawing.Size(121, 25)
        Me.cmdPrint.TabIndex = 30
        Me.cmdPrint.Text = "&Print Stop List(s)"
        Me.cmdPrint.UseVisualStyleBackColor = False
        '
        'optCopy4
        '
        Me.optCopy4.BackColor = System.Drawing.Color.Ivory
        Me.optCopy4.Cursor = System.Windows.Forms.Cursors.Default
        Me.optCopy4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optCopy4.ForeColor = System.Drawing.Color.DimGray
        Me.optCopy4.Location = New System.Drawing.Point(28, 261)
        Me.optCopy4.Name = "optCopy4"
        Me.optCopy4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optCopy4.Size = New System.Drawing.Size(81, 17)
        Me.optCopy4.TabIndex = 42
        Me.optCopy4.TabStop = True
        Me.optCopy4.Tag = "4"
        Me.optCopy4.Text = "From Route"
        Me.optCopy4.UseVisualStyleBackColor = False
        '
        'optCopy5
        '
        Me.optCopy5.BackColor = System.Drawing.Color.Ivory
        Me.optCopy5.Cursor = System.Windows.Forms.Cursors.Default
        Me.optCopy5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optCopy5.ForeColor = System.Drawing.Color.DimGray
        Me.optCopy5.Location = New System.Drawing.Point(28, 293)
        Me.optCopy5.Name = "optCopy5"
        Me.optCopy5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optCopy5.Size = New System.Drawing.Size(73, 17)
        Me.optCopy5.TabIndex = 43
        Me.optCopy5.TabStop = True
        Me.optCopy5.Tag = "5"
        Me.optCopy5.Text = "All"
        Me.optCopy5.UseVisualStyleBackColor = False
        '
        'txtContractorFrom
        '
        Me.txtContractorFrom.AcceptsReturn = True
        Me.txtContractorFrom.BackColor = System.Drawing.SystemColors.Menu
        Me.txtContractorFrom.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtContractorFrom.Enabled = False
        Me.txtContractorFrom.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtContractorFrom.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtContractorFrom.Location = New System.Drawing.Point(115, 292)
        Me.txtContractorFrom.MaxLength = 0
        Me.txtContractorFrom.Name = "txtContractorFrom"
        Me.txtContractorFrom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtContractorFrom.Size = New System.Drawing.Size(49, 20)
        Me.txtContractorFrom.TabIndex = 36
        Me.txtContractorFrom.Visible = False
        '
        'txtContractorTo
        '
        Me.txtContractorTo.AcceptsReturn = True
        Me.txtContractorTo.BackColor = System.Drawing.SystemColors.Menu
        Me.txtContractorTo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtContractorTo.Enabled = False
        Me.txtContractorTo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtContractorTo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtContractorTo.Location = New System.Drawing.Point(211, 292)
        Me.txtContractorTo.MaxLength = 0
        Me.txtContractorTo.Name = "txtContractorTo"
        Me.txtContractorTo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtContractorTo.Size = New System.Drawing.Size(49, 20)
        Me.txtContractorTo.TabIndex = 37
        Me.txtContractorTo.Visible = False
        '
        'optCopy2
        '
        Me.optCopy2.BackColor = System.Drawing.Color.Ivory
        Me.optCopy2.Cursor = System.Windows.Forms.Cursors.Default
        Me.optCopy2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optCopy2.ForeColor = System.Drawing.Color.DimGray
        Me.optCopy2.Location = New System.Drawing.Point(28, 149)
        Me.optCopy2.Name = "optCopy2"
        Me.optCopy2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optCopy2.Size = New System.Drawing.Size(81, 17)
        Me.optCopy2.TabIndex = 40
        Me.optCopy2.TabStop = True
        Me.optCopy2.Tag = "2"
        Me.optCopy2.Text = "From Route"
        Me.optCopy2.UseVisualStyleBackColor = False
        '
        'optCopy3
        '
        Me.optCopy3.BackColor = System.Drawing.Color.Ivory
        Me.optCopy3.Cursor = System.Windows.Forms.Cursors.Default
        Me.optCopy3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optCopy3.ForeColor = System.Drawing.Color.DimGray
        Me.optCopy3.Location = New System.Drawing.Point(28, 181)
        Me.optCopy3.Name = "optCopy3"
        Me.optCopy3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optCopy3.Size = New System.Drawing.Size(73, 17)
        Me.optCopy3.TabIndex = 41
        Me.optCopy3.TabStop = True
        Me.optCopy3.Tag = "3"
        Me.optCopy3.Text = "All"
        Me.optCopy3.UseVisualStyleBackColor = False
        '
        'txtDriverFrom
        '
        Me.txtDriverFrom.AcceptsReturn = True
        Me.txtDriverFrom.BackColor = System.Drawing.SystemColors.Menu
        Me.txtDriverFrom.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDriverFrom.Enabled = False
        Me.txtDriverFrom.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDriverFrom.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDriverFrom.Location = New System.Drawing.Point(115, 180)
        Me.txtDriverFrom.MaxLength = 0
        Me.txtDriverFrom.Name = "txtDriverFrom"
        Me.txtDriverFrom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDriverFrom.Size = New System.Drawing.Size(49, 20)
        Me.txtDriverFrom.TabIndex = 34
        Me.txtDriverFrom.Visible = False
        '
        'txtDriverTo
        '
        Me.txtDriverTo.AcceptsReturn = True
        Me.txtDriverTo.BackColor = System.Drawing.SystemColors.Menu
        Me.txtDriverTo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDriverTo.Enabled = False
        Me.txtDriverTo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDriverTo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDriverTo.Location = New System.Drawing.Point(211, 180)
        Me.txtDriverTo.MaxLength = 0
        Me.txtDriverTo.Name = "txtDriverTo"
        Me.txtDriverTo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDriverTo.Size = New System.Drawing.Size(49, 20)
        Me.txtDriverTo.TabIndex = 35
        Me.txtDriverTo.Visible = False
        '
        'optCopy0
        '
        Me.optCopy0.BackColor = System.Drawing.Color.Ivory
        Me.optCopy0.Checked = True
        Me.optCopy0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optCopy0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optCopy0.ForeColor = System.Drawing.Color.DimGray
        Me.optCopy0.Location = New System.Drawing.Point(28, 36)
        Me.optCopy0.Name = "optCopy0"
        Me.optCopy0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optCopy0.Size = New System.Drawing.Size(81, 17)
        Me.optCopy0.TabIndex = 38
        Me.optCopy0.TabStop = True
        Me.optCopy0.Tag = "0"
        Me.optCopy0.Text = "From Route"
        Me.optCopy0.UseVisualStyleBackColor = False
        '
        'optCopy1
        '
        Me.optCopy1.BackColor = System.Drawing.Color.Ivory
        Me.optCopy1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optCopy1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optCopy1.ForeColor = System.Drawing.Color.DimGray
        Me.optCopy1.Location = New System.Drawing.Point(28, 68)
        Me.optCopy1.Name = "optCopy1"
        Me.optCopy1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optCopy1.Size = New System.Drawing.Size(73, 17)
        Me.optCopy1.TabIndex = 39
        Me.optCopy1.TabStop = True
        Me.optCopy1.Tag = "1"
        Me.optCopy1.Text = "All"
        Me.optCopy1.UseVisualStyleBackColor = False
        '
        'txtOfficeFrom
        '
        Me.txtOfficeFrom.AcceptsReturn = True
        Me.txtOfficeFrom.BackColor = System.Drawing.SystemColors.Window
        Me.txtOfficeFrom.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtOfficeFrom.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOfficeFrom.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOfficeFrom.Location = New System.Drawing.Point(115, 68)
        Me.txtOfficeFrom.MaxLength = 0
        Me.txtOfficeFrom.Name = "txtOfficeFrom"
        Me.txtOfficeFrom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtOfficeFrom.Size = New System.Drawing.Size(49, 20)
        Me.txtOfficeFrom.TabIndex = 32
        Me.txtOfficeFrom.Visible = False
        '
        'txtOfficeTo
        '
        Me.txtOfficeTo.AcceptsReturn = True
        Me.txtOfficeTo.BackColor = System.Drawing.SystemColors.Window
        Me.txtOfficeTo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtOfficeTo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOfficeTo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOfficeTo.Location = New System.Drawing.Point(211, 68)
        Me.txtOfficeTo.MaxLength = 0
        Me.txtOfficeTo.Name = "txtOfficeTo"
        Me.txtOfficeTo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtOfficeTo.Size = New System.Drawing.Size(49, 20)
        Me.txtOfficeTo.TabIndex = 33
        Me.txtOfficeTo.Visible = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Ivory
        Me.Frame1.Controls.Add(Me.cboOfficeFrom)
        Me.Frame1.Controls.Add(Me.Label4)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.Color.DimGray
        Me.Frame1.Location = New System.Drawing.Point(12, 12)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(305, 97)
        Me.Frame1.TabIndex = 46
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Office and Field Copy"
        '
        'cboOfficeFrom
        '
        Me.cboOfficeFrom.BackColor = System.Drawing.SystemColors.Window
        Me.cboOfficeFrom.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboOfficeFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOfficeFrom.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboOfficeFrom.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboOfficeFrom.Location = New System.Drawing.Point(103, 23)
        Me.cboOfficeFrom.Name = "cboOfficeFrom"
        Me.cboOfficeFrom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboOfficeFrom.Size = New System.Drawing.Size(49, 22)
        Me.cboOfficeFrom.TabIndex = 23
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(167, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(25, 19)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "To"
        '
        'Frame3
        '
        Me.Frame3.BackColor = System.Drawing.Color.Ivory
        Me.Frame3.Controls.Add(Me.Label6)
        Me.Frame3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame3.ForeColor = System.Drawing.Color.DimGray
        Me.Frame3.Location = New System.Drawing.Point(12, 236)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(305, 97)
        Me.Frame3.TabIndex = 45
        Me.Frame3.TabStop = False
        Me.Frame3.Text = "Contractor Copy"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DimGray
        Me.Label6.Location = New System.Drawing.Point(167, 27)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(25, 19)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "To"
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.Color.Ivory
        Me.Frame2.Controls.Add(Me.Label5)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.Color.DimGray
        Me.Frame2.Location = New System.Drawing.Point(12, 124)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(305, 97)
        Me.Frame2.TabIndex = 44
        Me.Frame2.TabStop = False
        Me.Frame2.Text = "Driver and CIC Copy"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DimGray
        Me.Label5.Location = New System.Drawing.Point(167, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(25, 19)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "To"
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(12, 343)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(305, 39)
        Me.Shape1.TabIndex = 55
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(156, 261)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(41, 17)
        Me.Label3.TabIndex = 49
        Me.Label3.Text = "to Route"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(156, 149)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(41, 17)
        Me.Label2.TabIndex = 48
        Me.Label2.Text = "to Route"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(156, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(41, 17)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "to Route"
        '
        'frmRptRouteStop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(334, 391)
        Me.Controls.Add(Me.cboContractorTo)
        Me.Controls.Add(Me.cboContractorFrom)
        Me.Controls.Add(Me.cboDriverTo)
        Me.Controls.Add(Me.cboDriverFrom)
        Me.Controls.Add(Me.cboOfficeTo)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdPrint)
        Me.Controls.Add(Me.optCopy4)
        Me.Controls.Add(Me.optCopy5)
        Me.Controls.Add(Me.txtContractorFrom)
        Me.Controls.Add(Me.txtContractorTo)
        Me.Controls.Add(Me.optCopy2)
        Me.Controls.Add(Me.optCopy3)
        Me.Controls.Add(Me.txtDriverFrom)
        Me.Controls.Add(Me.txtDriverTo)
        Me.Controls.Add(Me.optCopy0)
        Me.Controls.Add(Me.optCopy1)
        Me.Controls.Add(Me.txtOfficeFrom)
        Me.Controls.Add(Me.txtOfficeTo)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Frame3)
        Me.Controls.Add(Me.Frame2)
        Me.Controls.Add(Me.Shape1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmRptRouteStop"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Route Stop List"
        Me.Frame1.ResumeLayout(False)
        Me.Frame3.ResumeLayout(False)
        Me.Frame2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents cboContractorTo As ComboBox
    Public WithEvents cboContractorFrom As ComboBox
    Public WithEvents cboDriverTo As ComboBox
    Public WithEvents cboDriverFrom As ComboBox
    Public WithEvents cboOfficeTo As ComboBox
    Public WithEvents cmdCancel As Button
    Public WithEvents cmdPrint As Button
    Public WithEvents optCopy4 As RadioButton
    Public WithEvents optCopy5 As RadioButton
    Public WithEvents txtContractorFrom As TextBox
    Public WithEvents txtContractorTo As TextBox
    Public WithEvents optCopy2 As RadioButton
    Public WithEvents optCopy3 As RadioButton
    Public WithEvents txtDriverFrom As TextBox
    Public WithEvents txtDriverTo As TextBox
    Public WithEvents optCopy0 As RadioButton
    Public WithEvents optCopy1 As RadioButton
    Public WithEvents txtOfficeFrom As TextBox
    Public WithEvents txtOfficeTo As TextBox
    Public WithEvents Frame1 As GroupBox
    Public WithEvents cboOfficeFrom As ComboBox
    Public WithEvents Label4 As Label
    Public WithEvents Frame3 As GroupBox
    Public WithEvents Label6 As Label
    Public WithEvents Frame2 As GroupBox
    Public WithEvents Label5 As Label
    Public WithEvents Shape1 As Label
    Public WithEvents Label3 As Label
    Public WithEvents Label2 As Label
    Public WithEvents Label1 As Label
End Class
