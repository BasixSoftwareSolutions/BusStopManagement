﻿Public Class frmLineFileRouteAdd
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmLineFileRouteAdd
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmLineFileRouteAdd
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmLineFileRouteAdd()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region
    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        Me.Close()
    End Sub

    Private Sub cmdCreate_Click(sender As Object, e As EventArgs) Handles cmdCreate.Click

        If Trim(txtRouteNo.Text) = "" Then
            MsgBox("Please enter a route number!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If cboRouteDir.SelectedIndex = -1 Then
            MsgBox("Please select a route direction!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If cboRouteDes.SelectedIndex = -1 Then
            MsgBox("Please selelct a route designation!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        ' Check if route number and direction have been used...
        On Error GoTo errHandler
        If RouteExist(CShort(txtRouteNo.Text), CByte(cboRouteDir.SelectedValue)) Then

            If RouteActive(CShort(txtRouteNo.Text), CByte(cboRouteDir.SelectedValue)) Then
                MsgBox("Route: " & txtRouteNo.Text & " " & cboRouteDir.Text & " already exists, but has been deactivated! Please activate this route for editing.", MsgBoxStyle.Exclamation)
            Else
                MsgBox("Route: " & txtRouteNo.Text & " " & cboRouteDir.Text & " already exists! Please enter a different route number or direction.", MsgBoxStyle.Exclamation)
            End If


            Exit Sub
        End If

        ' now ready to create route...
        CreateRoute()

        ' reload all possible routes on frmLineFile form...
        frmLineFile.ReloadRoutes()

        Dim routeNo, routeDir As Short

        routeNo = CShort(txtRouteNo.Text)
        routeDir = cboRouteDir.SelectedValue

        frmLineFile.LoadStops4Route(routeNo, routeDir)

        Me.Close()

        Exit Sub

errHandler:
        MsgBox("Please enter a number less than 32767", MsgBoxStyle.Exclamation)
        Exit Sub

    End Sub

    Private Sub CreateRoute()
        Dim strSQL As String
        Dim rActive As Integer

        If optActive0.Checked Then
            rActive = 1
        Else
            rActive = 0
        End If

        strSQL = "INSERT INTO tblRoutes(RTE, RTE_DIR_ID, RTE_DESIGNATION_ID, " & "EFFECTIVE_DATE, ACTIVE) VALUES (" & txtRouteNo.Text & ", " & cboRouteDir.SelectedValue & ", " & cboRouteDes.SelectedValue & ", " & "'" & DateTimePicker1.Value.ToShortDateString & "', " & rActive & ")"
        db.Execute(strSQL)

        MsgBox("Route: " & txtRouteNo.Text & " " & cboRouteDir.Text & " has been added to the database.", MsgBoxStyle.Information)
    End Sub

    Private Function RouteExist(ByRef aRoute As Short, ByRef aDirID As Byte) As Boolean
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim bln As Boolean

        strSQL = "SELECT * FROM tblRoutes WHERE RTE = " & aRoute & " AND RTE_DIR_ID = " & aDirID
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        bln = False
        If Not rs.EOF Then
            bln = True
        End If

        rs.Close()
        rs = Nothing

        RouteExist = bln
    End Function
    Private Function RouteActive(ByRef aRoute As Short, ByRef aDirID As Byte) As Boolean
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim bln As Boolean

        strSQL = "SELECT * FROM tblRoutes WHERE RTE = " & aRoute & " AND RTE_DIR_ID = " & aDirID
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        bln = False
        If Not rs.EOF Then
            If rs.Fields("ACTIVE").Value = 0 Then
                bln = True
            End If
        End If

        rs.Close()
        rs = Nothing

        RouteActive = bln
    End Function

    Private Sub LoadDirection()
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT * FROM ROUTE_DIR_CODE WHERE ACTIVE =1 ORDER BY ID"

        cboRouteDir.DisplayMember = "DESCRIPTION"
        cboRouteDir.ValueMember = "ID"
        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If

        cboRouteDir.DataSource = tb
        cboRouteDir.Enabled = True

        rs.Close()
        rs = Nothing
        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub LoadDesignation()
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT * FROM ROUTE_DESIGNATION_CODE WHERE ACTIVE =1 ORDER BY ID"
        cboRouteDes.DisplayMember = "DESCRIPTION"
        cboRouteDes.ValueMember = "ID"
        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If

        cboRouteDes.DataSource = tb
        cboRouteDes.Enabled = True

        rs.Close()
        rs = Nothing
        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub txtRouteNo_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtRouteNo.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        '
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub frmLineFileRouteAdd_Load(sender As Object, e As EventArgs) Handles Me.Load
        LoadDirection()
        LoadDesignation()
        DateTimePicker1.Value = Today
        optActive0.Checked = True
    End Sub
End Class