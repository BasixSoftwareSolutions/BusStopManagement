﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmUpdateStop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim SANZ_IDLabel As System.Windows.Forms.Label
        Dim IDLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUpdateStop))
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.cmdSortOrder = New System.Windows.Forms.Button()
        Me.txtStopID = New System.Windows.Forms.TextBox()
        Me.Command1 = New System.Windows.Forms.Button()
        Me.txtCBOTravelDir = New System.Windows.Forms.TextBox()
        Me.txtCBOXLoc = New System.Windows.Forms.TextBox()
        Me.txtCBOXType = New System.Windows.Forms.TextBox()
        Me.txtCBOJurisd = New System.Windows.Forms.TextBox()
        Me.txtCBOTravelType = New System.Windows.Forms.TextBox()
        Me.Text1 = New System.Windows.Forms.TextBox()
        Me.txtCBOCity = New System.Windows.Forms.TextBox()
        Me.txtCBOCounty = New System.Windows.Forms.TextBox()
        Me.txtCBOBSStatus = New System.Windows.Forms.TextBox()
        Me.txtTBM = New System.Windows.Forms.TextBox()
        Me.cbxFieldWork = New System.Windows.Forms.CheckBox()
        Me.cmdFindRecord = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.fraTop = New System.Windows.Forms.GroupBox()
        Me.txtTPName = New System.Windows.Forms.TextBox()
        Me.VwTimePointsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsTimePoints = New BusStopManagement.dsTimePoints()
        Me.lblTPName = New System.Windows.Forms.Label()
        Me.lnkArchivedDocs = New System.Windows.Forms.LinkLabel()
        Me.cbxCurrentStop = New System.Windows.Forms.CheckBox()
        Me.TblBusStopInformationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsBusStops = New BusStopManagement.dsBusStops()
        Me.txtXStreet1 = New System.Windows.Forms.TextBox()
        Me.txtXStreet = New System.Windows.Forms.TextBox()
        Me.txtTravelStreet = New System.Windows.Forms.TextBox()
        Me.cboJurisd = New System.Windows.Forms.ComboBox()
        Me.CITYCODEBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsJurisdiction = New BusStopManagement.dsJurisdiction()
        Me.cboCity = New System.Windows.Forms.ComboBox()
        Me.CITYCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsCityCode = New BusStopManagement.dsCityCode()
        Me.cboTravelDir = New System.Windows.Forms.ComboBox()
        Me.STDIRCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsTravelDirectionCode = New BusStopManagement.dsTravelDirectionCode()
        Me.dtEffectDate = New System.Windows.Forms.DateTimePicker()
        Me.txtSANZID = New System.Windows.Forms.TextBox()
        Me.txtOCTAID = New System.Windows.Forms.TextBox()
        Me.cmdChangeActiveStop = New System.Windows.Forms.Button()
        Me.cboBSStatus = New System.Windows.Forms.ComboBox()
        Me.BSSTATUSCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsBusStopStatusCode = New BusStopManagement.dsBusStopStatusCode()
        Me.cboCounty = New System.Windows.Forms.ComboBox()
        Me.COUNTYCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsCountyCode = New BusStopManagement.dsCountyCode()
        Me.txtRouteServed = New System.Windows.Forms.TextBox()
        Me.cboXLoc = New System.Windows.Forms.ComboBox()
        Me.BSLOCCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsBusStopLocation = New BusStopManagement.dsBusStopLocation()
        Me.cboXType = New System.Windows.Forms.ComboBox()
        Me.STTYPECODEBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsStreetType = New BusStopManagement.dsStreetType()
        Me.cboTravelType = New System.Windows.Forms.ComboBox()
        Me.STTYPECODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.cmdAddNewRecord = New System.Windows.Forms.Button()
        Me._Label1_3 = New System.Windows.Forms.Label()
        Me._Label1_2 = New System.Windows.Forms.Label()
        Me._Label1_35 = New System.Windows.Forms.Label()
        Me._Label1_44 = New System.Windows.Forms.Label()
        Me._Label1_55 = New System.Windows.Forms.Label()
        Me._Label1_77 = New System.Windows.Forms.Label()
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me._Label1_87 = New System.Windows.Forms.Label()
        Me._Label1_11 = New System.Windows.Forms.Label()
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me.CITYCODEBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CITYCODEBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsBusStopStatusCode1 = New BusStopManagement.dsBusStopStatusCode()
        Me.cbxNiteOwl = New System.Windows.Forms.CheckBox()
        Me.cbxBRT = New System.Windows.Forms.CheckBox()
        Me.BusStopManagementDataSet4 = New BusStopManagement.BusStopManagementDataSet4()
        Me.Frame6 = New System.Windows.Forms.GroupBox()
        Me.cbxExpress = New System.Windows.Forms.CheckBox()
        Me.Frame7 = New System.Windows.Forms.GroupBox()
        Me._Label1_5 = New System.Windows.Forms.Label()
        Me.SSTab1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.cmdSaveADARecord = New System.Windows.Forms.Button()
        Me.fraADA = New System.Windows.Forms.GroupBox()
        Me.cbxADASurveyed = New System.Windows.Forms.CheckBox()
        Me.TblADAStatusBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsADA = New BusStopManagement.dsADA()
        Me.txtADARemarks = New System.Windows.Forms.TextBox()
        Me.dtADASurvey = New System.Windows.Forms.DateTimePicker()
        Me.dtADACompletion = New System.Windows.Forms.DateTimePicker()
        Me.btnADACreateHistory = New System.Windows.Forms.Button()
        Me.cboADAStatus = New System.Windows.Forms.ComboBox()
        Me.ADASTATUSCODEBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsADAStatusCode = New BusStopManagement.dsADAStatusCode()
        Me._Label1_84 = New System.Windows.Forms.Label()
        Me._Label1_7 = New System.Windows.Forms.Label()
        Me._Label1_6 = New System.Windows.Forms.Label()
        Me._Label1_83 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.cmdSaveTransAmenities = New System.Windows.Forms.Button()
        Me.fraTransit = New System.Windows.Forms.GroupBox()
        Me.OCTA_IDTextBox = New System.Windows.Forms.TextBox()
        Me.TblStopTransAmenitiesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsTransitAmenities = New BusStopManagement.dsTransitAmenities()
        Me.cboRstType = New System.Windows.Forms.ComboBox()
        Me.RESTRICTIVEPKTYPECODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsRestrictiveParking = New BusStopManagement.dsRestrictiveParking()
        Me.cboTrnType = New System.Windows.Forms.ComboBox()
        Me.TURNOUTTYPECODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsTurnOutType = New BusStopManagement.dsTurnOutType()
        Me.cboBsPdType = New System.Windows.Forms.ComboBox()
        Me.BUSPADCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsBusPadType = New BusStopManagement.dsBusPadType()
        Me.cbxTransSurvey = New System.Windows.Forms.CheckBox()
        Me.txtTranAmenRmk = New System.Windows.Forms.TextBox()
        Me.txtRstLen = New System.Windows.Forms.TextBox()
        Me.txtTrnEgress = New System.Windows.Forms.TextBox()
        Me.txtTrnBsBay = New System.Windows.Forms.TextBox()
        Me.txtBsPdLen = New System.Windows.Forms.TextBox()
        Me.txtBsPdWdth = New System.Windows.Forms.TextBox()
        Me.txtTrnIngress = New System.Windows.Forms.TextBox()
        Me.cbxRstrcPrk = New System.Windows.Forms.CheckBox()
        Me.cbxTurnout = New System.Windows.Forms.CheckBox()
        Me.cbxBusPad = New System.Windows.Forms.CheckBox()
        Me.txtTrnWidth = New System.Windows.Forms.TextBox()
        Me._Label1_26 = New System.Windows.Forms.Label()
        Me._Label1_25 = New System.Windows.Forms.Label()
        Me._Label1_14 = New System.Windows.Forms.Label()
        Me._Label1_24 = New System.Windows.Forms.Label()
        Me._Label1_16 = New System.Windows.Forms.Label()
        Me._Label1_23 = New System.Windows.Forms.Label()
        Me._Label1_20 = New System.Windows.Forms.Label()
        Me._Label1_22 = New System.Windows.Forms.Label()
        Me._Label1_13 = New System.Windows.Forms.Label()
        Me._Label1_12 = New System.Windows.Forms.Label()
        Me._Label1_10 = New System.Windows.Forms.Label()
        Me._Label1_4 = New System.Windows.Forms.Label()
        Me._Label1_27 = New System.Windows.Forms.Label()
        Me._Label1_60 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.cmdSaveAmenity = New System.Windows.Forms.Button()
        Me.cbxPassSurvey = New System.Windows.Forms.CheckBox()
        Me.txtPARemarks = New System.Windows.Forms.TextBox()
        Me.tdbPassAmen = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OCTAIDDataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.AMENITIESTYPECODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsAmenityType = New BusStopManagement.dsAmenityType()
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.AMENITIESOWNERCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsAmentityOwner = New BusStopManagement.dsAmentityOwner()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TIMESURVDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.TblStopPsgrAmenitiesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsPassAmenities = New BusStopManagement.dsPassAmenities()
        Me.cmdRemAmen = New System.Windows.Forms.Button()
        Me.cmdAddAmen = New System.Windows.Forms.Button()
        Me._Label1_88 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.OCTA_IDTextBox1 = New System.Windows.Forms.TextBox()
        Me.TblSignCassetteBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsSignCassetteHardware = New BusStopManagement.dsSignCassetteHardware()
        Me.cmdSaveSignCassRecord = New System.Windows.Forms.Button()
        Me.fraCassetteSurvey = New System.Windows.Forms.GroupBox()
        Me.Frame3 = New System.Windows.Forms.GroupBox()
        Me.cbxPlaceSolar = New System.Windows.Forms.CheckBox()
        Me.cbxExistSolar = New System.Windows.Forms.CheckBox()
        Me.cbxSignSpecific = New System.Windows.Forms.CheckBox()
        Me.cbxCitySignage = New System.Windows.Forms.CheckBox()
        Me.txtCitySignage = New System.Windows.Forms.TextBox()
        Me.txtSignSpecific = New System.Windows.Forms.TextBox()
        Me.txtNumRouteDisplay = New System.Windows.Forms.TextBox()
        Me.cboSPConfig = New System.Windows.Forms.ComboBox()
        Me.SIGNPOSTCONFIGCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsSignPostConfig = New BusStopManagement.dsSignPostConfig()
        Me.cboSCPostType = New System.Windows.Forms.ComboBox()
        Me.SIGNPOSTTYPECODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsSignPostType = New BusStopManagement.dsSignPostType()
        Me.cboCasHardware = New System.Windows.Forms.ComboBox()
        Me.CASSETTETYPECODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsCassetteMountingHardware = New BusStopManagement.dsCassetteMountingHardware()
        Me.cboCasPosition = New System.Windows.Forms.ComboBox()
        Me.CASSETTEPOSITIONCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsCassetteMountingPosition = New BusStopManagement.dsCassetteMountingPosition()
        Me._Label1_78 = New System.Windows.Forms.Label()
        Me._Label1_80 = New System.Windows.Forms.Label()
        Me._Label1_79 = New System.Windows.Forms.Label()
        Me._Label1_76 = New System.Windows.Forms.Label()
        Me._Label1_74 = New System.Windows.Forms.Label()
        Me.cbxReplacePermenent = New System.Windows.Forms.CheckBox()
        Me.cbxUpcomingChange = New System.Windows.Forms.CheckBox()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.txtDateIssued = New System.Windows.Forms.DateTimePicker()
        Me.txtIssuingAgency = New System.Windows.Forms.TextBox()
        Me.txtPermitNo = New System.Windows.Forms.TextBox()
        Me._Label1_82 = New System.Windows.Forms.Label()
        Me._Label1_72 = New System.Windows.Forms.Label()
        Me._Label1_53 = New System.Windows.Forms.Label()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.txtRouteDisplay = New System.Windows.Forms.TextBox()
        Me.txtCstRemarks = New System.Windows.Forms.TextBox()
        Me._Label1_52 = New System.Windows.Forms.Label()
        Me._Label1_73 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.cmdRemoveFilter = New System.Windows.Forms.Button()
        Me.cmdSearch = New System.Windows.Forms.Button()
        Me.lblStopHistoryCount = New System.Windows.Forms.Label()
        Me.tdbStopHist = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DATEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NAMEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TYPEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.REMARKSDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WONUMDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmdAttachments = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.OCTAIDDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblStopHistoryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsStopHistory = New BusStopManagement.dsStopHistory()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.cmdRemoveHistory = New System.Windows.Forms.Button()
        Me.cmdAddHistory = New System.Windows.Forms.Button()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.fraWorkOrders = New System.Windows.Forms.GroupBox()
        Me.cmdWOEmailAll = New System.Windows.Forms.Button()
        Me.cmdWOPrintAll = New System.Windows.Forms.Button()
        Me.cmdWOEmailCurrent = New System.Windows.Forms.Button()
        Me.cmWOPrintCurrent = New System.Windows.Forms.Button()
        Me.txtWOItems = New System.Windows.Forms.TextBox()
        Me.cmdSaveWORecord = New System.Windows.Forms.Button()
        Me.WOGrid1 = New System.Windows.Forms.DataGridView()
        Me.cboSelectedItem = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.cboDESCRIPTION = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cboID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmdPrintEmailAll = New System.Windows.Forms.Button()
        Me.cbxWO_Dig_AlertWO = New System.Windows.Forms.CheckBox()
        Me.cmdClearAllWO = New System.Windows.Forms.Button()
        Me.txtWorkOrdersWO = New System.Windows.Forms.TextBox()
        Me.cmdPrvWorkWO = New System.Windows.Forms.Button()
        Me.cboPriorityWO = New System.Windows.Forms.ComboBox()
        Me._Label1_32 = New System.Windows.Forms.Label()
        Me._Label1_29 = New System.Windows.Forms.Label()
        Me._Label1_28 = New System.Windows.Forms.Label()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.bnPictures = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem1 = New System.Windows.Forms.ToolStripButton()
        Me.TblStopImagesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BusStopManagementDataSet2 = New BusStopManagement.BusStopManagementDataSet2()
        Me.BindingNavigatorCountItem2 = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem2 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem2 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem2 = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem2 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem2 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdZoom = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.toolStripSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CancelToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.imgStopPic = New System.Windows.Forms.PictureBox()
        Me.fraStopPictures = New System.Windows.Forms.GroupBox()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPictureOCTA_ID = New System.Windows.Forms.TextBox()
        Me.txtPicDate = New System.Windows.Forms.DateTimePicker()
        Me.SANZ_IDTextBox = New System.Windows.Forms.TextBox()
        Me.txtPicNotes = New System.Windows.Forms.TextBox()
        Me.txtPicPath = New System.Windows.Forms.TextBox()
        Me.cboTakenBy = New System.Windows.Forms.ComboBox()
        Me.TblStaffBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.BusStopManagementDataSet = New BusStopManagement.BusStopManagementDataSet()
        Me.cmdPicsNeeded = New System.Windows.Forms.Button()
        Me.cmdPicBrowse = New System.Windows.Forms.Button()
        Me.cbxStopPhotoNeeded = New System.Windows.Forms.CheckBox()
        Me._Label1_58 = New System.Windows.Forms.Label()
        Me._Label1_56 = New System.Windows.Forms.Label()
        Me._Label1_54 = New System.Windows.Forms.Label()
        Me._Label1_47 = New System.Windows.Forms.Label()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtTPRemovalDesc = New System.Windows.Forms.TextBox()
        Me.QryBusStopStatusBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsBusStopStatus = New BusStopManagement.dsBusStopStatus()
        Me.lblTPRemoved = New System.Windows.Forms.Label()
        Me.cmdDeleteTP = New System.Windows.Forms.Button()
        Me.cmdUpdateRemoveTP = New System.Windows.Forms.Button()
        Me.dtpEndDate = New System.Windows.Forms.DateTimePicker()
        Me.dtpStartDate = New System.Windows.Forms.DateTimePicker()
        Me.cmdAddTP = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBusStopStatusID = New System.Windows.Forms.TextBox()
        Me.cmdSaveGPS = New System.Windows.Forms.Button()
        Me.cbxGPSRequired = New System.Windows.Forms.CheckBox()
        Me.TblStopCoordBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsGPS = New BusStopManagement.dsGPS()
        Me.fraGPS2 = New System.Windows.Forms.GroupBox()
        Me.dtGPSDate = New System.Windows.Forms.DateTimePicker()
        Me.txtLat = New System.Windows.Forms.TextBox()
        Me.txtLon = New System.Windows.Forms.TextBox()
        Me.txtGPS_OCTA_ID = New System.Windows.Forms.TextBox()
        Me.txtElev = New System.Windows.Forms.TextBox()
        Me.txtYCoord = New System.Windows.Forms.TextBox()
        Me.txtXCoord = New System.Windows.Forms.TextBox()
        Me._LATITUDE_9 = New System.Windows.Forms.Label()
        Me._Label1_8 = New System.Windows.Forms.Label()
        Me._Label1_59 = New System.Windows.Forms.Label()
        Me._Label1_46 = New System.Windows.Forms.Label()
        Me._Label1_45 = New System.Windows.Forms.Label()
        Me._Label1_43 = New System.Windows.Forms.Label()
        Me.HISTORYTYPECODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsStopHistoryType = New BusStopManagement.dsStopHistoryType()
        Me.ADASTATUSCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BusStopManagementDataSet5 = New BusStopManagement.BusStopManagementDataSet5()
        Me.TblStaffBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsPictures = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblStopImagesTableAdapter = New BusStopManagement.BusStopManagementDataSet2TableAdapters.tblStopImagesTableAdapter()
        Me.TableAdapterManager = New BusStopManagement.BusStopManagementDataSet2TableAdapters.TableAdapterManager()
        Me.bnBusStop = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem1 = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveFirstItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem1 = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbSaveBusStop = New System.Windows.Forms.ToolStripButton()
        Me.TblStaffTableAdapter = New BusStopManagement.BusStopManagementDataSetTableAdapters.tblStaffTableAdapter()
        Me.TblADAStatusTableAdapter = New BusStopManagement.dsADATableAdapters.tblADAStatusTableAdapter()
        Me.TableAdapterManager2 = New BusStopManagement.dsADATableAdapters.TableAdapterManager()
        Me.ADA_STATUS_CODETableAdapter = New BusStopManagement.BusStopManagementDataSet5TableAdapters.ADA_STATUS_CODETableAdapter()
        Me.ADA_STATUS_CODETableAdapter1 = New BusStopManagement.dsADAStatusCodeTableAdapters.ADA_STATUS_CODETableAdapter()
        Me.TblStopTransAmenitiesTableAdapter = New BusStopManagement.dsTransitAmenitiesTableAdapters.tblStopTransAmenitiesTableAdapter()
        Me.TableAdapterManager3 = New BusStopManagement.dsTransitAmenitiesTableAdapters.TableAdapterManager()
        Me.BS_STATUS_CODETableAdapter = New BusStopManagement.dsBusStopStatusCodeTableAdapters.BS_STATUS_CODETableAdapter()
        Me.COUNTY_CODETableAdapter = New BusStopManagement.dsCountyCodeTableAdapters.COUNTY_CODETableAdapter()
        Me.CITY_CODETableAdapter = New BusStopManagement.dsCityCodeTableAdapters.CITY_CODETableAdapter()
        Me.ST_DIR_CODETableAdapter = New BusStopManagement.dsTravelDirectionCodeTableAdapters.ST_DIR_CODETableAdapter()
        Me.BS_LOC_CODETableAdapter = New BusStopManagement.dsBusStopLocationTableAdapters.BS_LOC_CODETableAdapter()
        Me.ST_TYPE_CODETableAdapter = New BusStopManagement.dsStreetTypeTableAdapters.ST_TYPE_CODETableAdapter()
        Me.TblBusStopInformationTableAdapter = New BusStopManagement.dsBusStopsTableAdapters.tblBusStopInformationTableAdapter()
        Me.TableAdapterManager4 = New BusStopManagement.dsBusStopsTableAdapters.TableAdapterManager()
        Me.CITY_CODETableAdapter1 = New BusStopManagement.dsJurisdictionTableAdapters.CITY_CODETableAdapter()
        Me.TblStopHistoryTableAdapter = New BusStopManagement.dsStopHistoryTableAdapters.tblStopHistoryTableAdapter()
        Me.HISTORY_TYPE_CODETableAdapter = New BusStopManagement.dsStopHistoryTypeTableAdapters.HISTORY_TYPE_CODETableAdapter()
        Me.OCTAIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OCTA_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblStopPsgrAmenitiesTableAdapter = New BusStopManagement.dsPassAmenitiesTableAdapters.tblStopPsgrAmenitiesTableAdapter()
        Me.AMENITIES_TYPE_CODETableAdapter = New BusStopManagement.dsAmenityTypeTableAdapters.AMENITIES_TYPE_CODETableAdapter()
        Me.AMENITIES_OWNER_CODETableAdapter = New BusStopManagement.dsAmentityOwnerTableAdapters.AMENITIES_OWNER_CODETableAdapter()
        Me.TblBusStopInformationBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblStopCoordTableAdapter = New BusStopManagement.dsGPSTableAdapters.tblStopCoordTableAdapter()
        Me.BUS_PAD_CODETableAdapter = New BusStopManagement.dsBusPadTypeTableAdapters.BUS_PAD_CODETableAdapter()
        Me.TURNOUT_TYPE_CODETableAdapter = New BusStopManagement.dsTurnOutTypeTableAdapters.TURNOUT_TYPE_CODETableAdapter()
        Me.RESTRICTIVE_PK_TYPE_CODETableAdapter = New BusStopManagement.dsRestrictiveParkingTableAdapters.RESTRICTIVE_PK_TYPE_CODETableAdapter()
        Me.TblSignCassetteTableAdapter = New BusStopManagement.dsSignCassetteHardwareTableAdapters.tblSignCassetteTableAdapter()
        Me.TableAdapterManager1 = New BusStopManagement.dsSignCassetteHardwareTableAdapters.TableAdapterManager()
        Me.SIGN_POST_CONFIG_CODETableAdapter = New BusStopManagement.dsSignPostConfigTableAdapters.SIGN_POST_CONFIG_CODETableAdapter()
        Me.SIGN_POST_TYPE_CODETableAdapter = New BusStopManagement.dsSignPostTypeTableAdapters.SIGN_POST_TYPE_CODETableAdapter()
        Me.CASSETTE_TYPE_CODETableAdapter = New BusStopManagement.dsCassetteMountingHardwareTableAdapters.CASSETTE_TYPE_CODETableAdapter()
        Me.CASSETTE_POSITION_CODETableAdapter = New BusStopManagement.dsCassetteMountingPositionTableAdapters.CASSETTE_POSITION_CODETableAdapter()
        Me.DsWorkOrderItemCodes = New BusStopManagement.dsWorkOrderItemCodes()
        Me.WOITEMCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.WO_ITEM_CODETableAdapter = New BusStopManagement.dsWorkOrderItemCodesTableAdapters.WO_ITEM_CODETableAdapter()
        Me.WOITEMCODEBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblStaffBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VwTimePointsTableAdapter = New BusStopManagement.dsTimePointsTableAdapters.vwTimePointsTableAdapter()
        Me.QryBusStopStatusTableAdapter = New BusStopManagement.dsBusStopStatusTableAdapters.qryBusStopStatusTableAdapter()
        Me.cmdViewActiveList = New System.Windows.Forms.Button()
        SANZ_IDLabel = New System.Windows.Forms.Label()
        IDLabel = New System.Windows.Forms.Label()
        Me.fraTop.SuspendLayout()
        CType(Me.VwTimePointsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsTimePoints, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblBusStopInformationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsBusStops, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CITYCODEBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsJurisdiction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CITYCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsCityCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.STDIRCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsTravelDirectionCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BSSTATUSCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsBusStopStatusCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.COUNTYCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsCountyCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BSLOCCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsBusStopLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.STTYPECODEBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsStreetType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.STTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CITYCODEBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CITYCODEBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsBusStopStatusCode1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusStopManagementDataSet4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Frame6.SuspendLayout()
        Me.Frame7.SuspendLayout()
        Me.SSTab1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.fraADA.SuspendLayout()
        CType(Me.TblADAStatusBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsADA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ADASTATUSCODEBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsADAStatusCode, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.fraTransit.SuspendLayout()
        CType(Me.TblStopTransAmenitiesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsTransitAmenities, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RESTRICTIVEPKTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsRestrictiveParking, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TURNOUTTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsTurnOutType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BUSPADCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsBusPadType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.tdbPassAmen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AMENITIESTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsAmenityType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AMENITIESOWNERCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsAmentityOwner, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblStopPsgrAmenitiesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsPassAmenities, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.TblSignCassetteBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsSignCassetteHardware, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.fraCassetteSurvey.SuspendLayout()
        Me.Frame3.SuspendLayout()
        CType(Me.SIGNPOSTCONFIGCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsSignPostConfig, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SIGNPOSTTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsSignPostType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CASSETTETYPECODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsCassetteMountingHardware, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CASSETTEPOSITIONCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsCassetteMountingPosition, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Frame2.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        CType(Me.tdbStopHist, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblStopHistoryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsStopHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.fraWorkOrders.SuspendLayout()
        CType(Me.WOGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage8.SuspendLayout()
        CType(Me.bnPictures, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.bnPictures.SuspendLayout()
        CType(Me.TblStopImagesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusStopManagementDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgStopPic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.fraStopPictures.SuspendLayout()
        CType(Me.TblStaffBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusStopManagementDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage9.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.QryBusStopStatusBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsBusStopStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblStopCoordBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsGPS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.fraGPS2.SuspendLayout()
        CType(Me.HISTORYTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsStopHistoryType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ADASTATUSCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusStopManagementDataSet5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblStaffBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsPictures, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bnBusStop, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.bnBusStop.SuspendLayout()
        CType(Me.TblBusStopInformationBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsWorkOrderItemCodes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WOITEMCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WOITEMCODEBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblStaffBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SANZ_IDLabel
        '
        SANZ_IDLabel.AutoSize = True
        SANZ_IDLabel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        SANZ_IDLabel.ForeColor = System.Drawing.Color.DimGray
        SANZ_IDLabel.Location = New System.Drawing.Point(46, 104)
        SANZ_IDLabel.Name = "SANZ_IDLabel"
        SANZ_IDLabel.Size = New System.Drawing.Size(55, 15)
        SANZ_IDLabel.TabIndex = 261
        SANZ_IDLabel.Text = "SANZ ID:"
        '
        'IDLabel
        '
        IDLabel.AutoSize = True
        IDLabel.Enabled = False
        IDLabel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        IDLabel.ForeColor = System.Drawing.Color.DimGray
        IDLabel.Location = New System.Drawing.Point(41, 132)
        IDLabel.Name = "IDLabel"
        IDLabel.Size = New System.Drawing.Size(60, 15)
        IDLabel.TabIndex = 266
        IDLabel.Text = "IMAGE ID:"
        '
        'cmdSortOrder
        '
        Me.cmdSortOrder.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSortOrder.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSortOrder.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSortOrder.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSortOrder.Image = CType(resources.GetObject("cmdSortOrder.Image"), System.Drawing.Image)
        Me.cmdSortOrder.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdSortOrder.Location = New System.Drawing.Point(242, 19)
        Me.cmdSortOrder.Name = "cmdSortOrder"
        Me.cmdSortOrder.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSortOrder.Size = New System.Drawing.Size(113, 33)
        Me.cmdSortOrder.TabIndex = 307
        Me.cmdSortOrder.Text = "Sort By SANZ ID"
        Me.cmdSortOrder.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdSortOrder.UseVisualStyleBackColor = False
        '
        'txtStopID
        '
        Me.txtStopID.AcceptsReturn = True
        Me.txtStopID.BackColor = System.Drawing.SystemColors.Window
        Me.txtStopID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtStopID.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStopID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtStopID.Location = New System.Drawing.Point(99, 62)
        Me.txtStopID.MaxLength = 0
        Me.txtStopID.Name = "txtStopID"
        Me.txtStopID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtStopID.Size = New System.Drawing.Size(85, 22)
        Me.txtStopID.TabIndex = 282
        Me.txtStopID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Command1
        '
        Me.Command1.BackColor = System.Drawing.SystemColors.Control
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Image = CType(resources.GetObject("Command1.Image"), System.Drawing.Image)
        Me.Command1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Command1.Location = New System.Drawing.Point(364, 19)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command1.Size = New System.Drawing.Size(103, 33)
        Me.Command1.TabIndex = 304
        Me.Command1.Text = "Google Maps"
        Me.Command1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Command1.UseVisualStyleBackColor = False
        '
        'txtCBOTravelDir
        '
        Me.txtCBOTravelDir.AcceptsReturn = True
        Me.txtCBOTravelDir.BackColor = System.Drawing.SystemColors.Window
        Me.txtCBOTravelDir.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCBOTravelDir.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCBOTravelDir.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCBOTravelDir.Location = New System.Drawing.Point(974, 239)
        Me.txtCBOTravelDir.MaxLength = 0
        Me.txtCBOTravelDir.Name = "txtCBOTravelDir"
        Me.txtCBOTravelDir.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCBOTravelDir.Size = New System.Drawing.Size(10, 20)
        Me.txtCBOTravelDir.TabIndex = 302
        Me.txtCBOTravelDir.Visible = False
        '
        'txtCBOXLoc
        '
        Me.txtCBOXLoc.AcceptsReturn = True
        Me.txtCBOXLoc.BackColor = System.Drawing.SystemColors.Window
        Me.txtCBOXLoc.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCBOXLoc.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCBOXLoc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCBOXLoc.Location = New System.Drawing.Point(974, 239)
        Me.txtCBOXLoc.MaxLength = 0
        Me.txtCBOXLoc.Name = "txtCBOXLoc"
        Me.txtCBOXLoc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCBOXLoc.Size = New System.Drawing.Size(10, 20)
        Me.txtCBOXLoc.TabIndex = 301
        Me.txtCBOXLoc.Visible = False
        '
        'txtCBOXType
        '
        Me.txtCBOXType.AcceptsReturn = True
        Me.txtCBOXType.BackColor = System.Drawing.SystemColors.Window
        Me.txtCBOXType.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCBOXType.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCBOXType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCBOXType.Location = New System.Drawing.Point(974, 239)
        Me.txtCBOXType.MaxLength = 0
        Me.txtCBOXType.Name = "txtCBOXType"
        Me.txtCBOXType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCBOXType.Size = New System.Drawing.Size(10, 20)
        Me.txtCBOXType.TabIndex = 300
        Me.txtCBOXType.Visible = False
        '
        'txtCBOJurisd
        '
        Me.txtCBOJurisd.AcceptsReturn = True
        Me.txtCBOJurisd.BackColor = System.Drawing.SystemColors.Window
        Me.txtCBOJurisd.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCBOJurisd.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCBOJurisd.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCBOJurisd.Location = New System.Drawing.Point(974, 239)
        Me.txtCBOJurisd.MaxLength = 0
        Me.txtCBOJurisd.Name = "txtCBOJurisd"
        Me.txtCBOJurisd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCBOJurisd.Size = New System.Drawing.Size(10, 20)
        Me.txtCBOJurisd.TabIndex = 299
        Me.txtCBOJurisd.Visible = False
        '
        'txtCBOTravelType
        '
        Me.txtCBOTravelType.AcceptsReturn = True
        Me.txtCBOTravelType.BackColor = System.Drawing.SystemColors.Window
        Me.txtCBOTravelType.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCBOTravelType.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCBOTravelType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCBOTravelType.Location = New System.Drawing.Point(974, 239)
        Me.txtCBOTravelType.MaxLength = 0
        Me.txtCBOTravelType.Name = "txtCBOTravelType"
        Me.txtCBOTravelType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCBOTravelType.Size = New System.Drawing.Size(10, 20)
        Me.txtCBOTravelType.TabIndex = 298
        Me.txtCBOTravelType.Visible = False
        '
        'Text1
        '
        Me.Text1.AcceptsReturn = True
        Me.Text1.BackColor = System.Drawing.SystemColors.Window
        Me.Text1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text1.Location = New System.Drawing.Point(974, 239)
        Me.Text1.MaxLength = 0
        Me.Text1.Name = "Text1"
        Me.Text1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text1.Size = New System.Drawing.Size(10, 20)
        Me.Text1.TabIndex = 297
        Me.Text1.Visible = False
        '
        'txtCBOCity
        '
        Me.txtCBOCity.AcceptsReturn = True
        Me.txtCBOCity.BackColor = System.Drawing.SystemColors.Window
        Me.txtCBOCity.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCBOCity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCBOCity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCBOCity.Location = New System.Drawing.Point(974, 239)
        Me.txtCBOCity.MaxLength = 0
        Me.txtCBOCity.Name = "txtCBOCity"
        Me.txtCBOCity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCBOCity.Size = New System.Drawing.Size(10, 20)
        Me.txtCBOCity.TabIndex = 296
        Me.txtCBOCity.Visible = False
        '
        'txtCBOCounty
        '
        Me.txtCBOCounty.AcceptsReturn = True
        Me.txtCBOCounty.BackColor = System.Drawing.SystemColors.Window
        Me.txtCBOCounty.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCBOCounty.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCBOCounty.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCBOCounty.Location = New System.Drawing.Point(974, 239)
        Me.txtCBOCounty.MaxLength = 0
        Me.txtCBOCounty.Name = "txtCBOCounty"
        Me.txtCBOCounty.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCBOCounty.Size = New System.Drawing.Size(10, 20)
        Me.txtCBOCounty.TabIndex = 295
        Me.txtCBOCounty.Visible = False
        '
        'txtCBOBSStatus
        '
        Me.txtCBOBSStatus.AcceptsReturn = True
        Me.txtCBOBSStatus.BackColor = System.Drawing.SystemColors.Window
        Me.txtCBOBSStatus.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCBOBSStatus.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCBOBSStatus.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCBOBSStatus.Location = New System.Drawing.Point(974, 239)
        Me.txtCBOBSStatus.MaxLength = 0
        Me.txtCBOBSStatus.Name = "txtCBOBSStatus"
        Me.txtCBOBSStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCBOBSStatus.Size = New System.Drawing.Size(10, 20)
        Me.txtCBOBSStatus.TabIndex = 294
        Me.txtCBOBSStatus.Visible = False
        '
        'txtTBM
        '
        Me.txtTBM.AcceptsReturn = True
        Me.txtTBM.BackColor = System.Drawing.SystemColors.Window
        Me.txtTBM.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTBM.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTBM.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTBM.Location = New System.Drawing.Point(974, 239)
        Me.txtTBM.MaxLength = 0
        Me.txtTBM.Name = "txtTBM"
        Me.txtTBM.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTBM.Size = New System.Drawing.Size(10, 20)
        Me.txtTBM.TabIndex = 293
        Me.txtTBM.Visible = False
        '
        'cbxFieldWork
        '
        Me.cbxFieldWork.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.cbxFieldWork.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxFieldWork.Font = New System.Drawing.Font("Arial", 13.5!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxFieldWork.ForeColor = System.Drawing.Color.Blue
        Me.cbxFieldWork.Location = New System.Drawing.Point(974, 239)
        Me.cbxFieldWork.Name = "cbxFieldWork"
        Me.cbxFieldWork.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxFieldWork.Size = New System.Drawing.Size(10, 30)
        Me.cbxFieldWork.TabIndex = 289
        Me.cbxFieldWork.Text = "Field-Worked"
        Me.cbxFieldWork.UseVisualStyleBackColor = False
        Me.cbxFieldWork.Visible = False
        '
        'cmdFindRecord
        '
        Me.cmdFindRecord.BackColor = System.Drawing.SystemColors.Control
        Me.cmdFindRecord.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdFindRecord.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdFindRecord.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdFindRecord.Image = CType(resources.GetObject("cmdFindRecord.Image"), System.Drawing.Image)
        Me.cmdFindRecord.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdFindRecord.Location = New System.Drawing.Point(184, 19)
        Me.cmdFindRecord.Name = "cmdFindRecord"
        Me.cmdFindRecord.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdFindRecord.Size = New System.Drawing.Size(49, 33)
        Me.cmdFindRecord.TabIndex = 283
        Me.cmdFindRecord.Text = "Find"
        Me.cmdFindRecord.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdFindRecord.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Image = CType(resources.GetObject("cmdClose.Image"), System.Drawing.Image)
        Me.cmdClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdClose.Location = New System.Drawing.Point(473, 19)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(73, 33)
        Me.cmdClose.TabIndex = 284
        Me.cmdClose.Text = "Close"
        Me.cmdClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'fraTop
        '
        Me.fraTop.BackColor = System.Drawing.Color.Transparent
        Me.fraTop.Controls.Add(Me.txtTPName)
        Me.fraTop.Controls.Add(Me.lblTPName)
        Me.fraTop.Controls.Add(Me.lnkArchivedDocs)
        Me.fraTop.Controls.Add(Me.cbxCurrentStop)
        Me.fraTop.Controls.Add(Me.txtXStreet1)
        Me.fraTop.Controls.Add(Me.txtXStreet)
        Me.fraTop.Controls.Add(Me.txtTravelStreet)
        Me.fraTop.Controls.Add(Me.cboJurisd)
        Me.fraTop.Controls.Add(Me.cboCity)
        Me.fraTop.Controls.Add(Me.cboTravelDir)
        Me.fraTop.Controls.Add(Me.dtEffectDate)
        Me.fraTop.Controls.Add(Me.txtSANZID)
        Me.fraTop.Controls.Add(Me.txtOCTAID)
        Me.fraTop.Controls.Add(Me.cmdChangeActiveStop)
        Me.fraTop.Controls.Add(Me.cboBSStatus)
        Me.fraTop.Controls.Add(Me.cboCounty)
        Me.fraTop.Controls.Add(Me.txtRouteServed)
        Me.fraTop.Controls.Add(Me.cboXLoc)
        Me.fraTop.Controls.Add(Me.cboXType)
        Me.fraTop.Controls.Add(Me.cboTravelType)
        Me.fraTop.Controls.Add(Me.cmdAddNewRecord)
        Me.fraTop.Controls.Add(Me._Label1_3)
        Me.fraTop.Controls.Add(Me._Label1_2)
        Me.fraTop.Controls.Add(Me._Label1_35)
        Me.fraTop.Controls.Add(Me._Label1_44)
        Me.fraTop.Controls.Add(Me._Label1_55)
        Me.fraTop.Controls.Add(Me._Label1_77)
        Me.fraTop.Controls.Add(Me._Label1_1)
        Me.fraTop.Controls.Add(Me._Label1_87)
        Me.fraTop.Controls.Add(Me._Label1_11)
        Me.fraTop.Controls.Add(Me._Label1_0)
        Me.fraTop.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraTop.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraTop.Location = New System.Drawing.Point(18, 104)
        Me.fraTop.Name = "fraTop"
        Me.fraTop.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraTop.Size = New System.Drawing.Size(840, 155)
        Me.fraTop.TabIndex = 290
        Me.fraTop.TabStop = False
        '
        'txtTPName
        '
        Me.txtTPName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VwTimePointsBindingSource, "PLACE_ID", True))
        Me.txtTPName.Location = New System.Drawing.Point(70, 42)
        Me.txtTPName.Name = "txtTPName"
        Me.txtTPName.ReadOnly = True
        Me.txtTPName.Size = New System.Drawing.Size(55, 20)
        Me.txtTPName.TabIndex = 311
        '
        'VwTimePointsBindingSource
        '
        Me.VwTimePointsBindingSource.DataMember = "vwTimePoints"
        Me.VwTimePointsBindingSource.DataSource = Me.DsTimePoints
        '
        'DsTimePoints
        '
        Me.DsTimePoints.DataSetName = "dsTimePoints"
        Me.DsTimePoints.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblTPName
        '
        Me.lblTPName.AutoSize = True
        Me.lblTPName.BackColor = System.Drawing.Color.Transparent
        Me.lblTPName.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTPName.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTPName.ForeColor = System.Drawing.Color.DimGray
        Me.lblTPName.Location = New System.Drawing.Point(30, 46)
        Me.lblTPName.Name = "lblTPName"
        Me.lblTPName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTPName.Size = New System.Drawing.Size(37, 14)
        Me.lblTPName.TabIndex = 310
        Me.lblTPName.Text = "TP ID:"
        '
        'lnkArchivedDocs
        '
        Me.lnkArchivedDocs.AutoSize = True
        Me.lnkArchivedDocs.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lnkArchivedDocs.Location = New System.Drawing.Point(16, 124)
        Me.lnkArchivedDocs.Name = "lnkArchivedDocs"
        Me.lnkArchivedDocs.Size = New System.Drawing.Size(108, 14)
        Me.lnkArchivedDocs.TabIndex = 309
        Me.lnkArchivedDocs.TabStop = True
        Me.lnkArchivedDocs.Text = "Archived Documents"
        '
        'cbxCurrentStop
        '
        Me.cbxCurrentStop.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.TblBusStopInformationBindingSource, "ACTIVE_STOP", True))
        Me.cbxCurrentStop.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxCurrentStop.ForeColor = System.Drawing.Color.DimGray
        Me.cbxCurrentStop.Location = New System.Drawing.Point(735, 51)
        Me.cbxCurrentStop.Name = "cbxCurrentStop"
        Me.cbxCurrentStop.Size = New System.Drawing.Size(72, 24)
        Me.cbxCurrentStop.TabIndex = 258
        Me.cbxCurrentStop.Text = "ACTIVE"
        Me.cbxCurrentStop.UseVisualStyleBackColor = True
        '
        'TblBusStopInformationBindingSource
        '
        Me.TblBusStopInformationBindingSource.DataMember = "tblBusStopInformation"
        Me.TblBusStopInformationBindingSource.DataSource = Me.DsBusStops
        '
        'DsBusStops
        '
        Me.DsBusStops.DataSetName = "dsBusStops"
        Me.DsBusStops.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtXStreet1
        '
        Me.txtXStreet1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtXStreet1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblBusStopInformationBindingSource, "CROSS_STREET_1", True))
        Me.txtXStreet1.Location = New System.Drawing.Point(240, 117)
        Me.txtXStreet1.Name = "txtXStreet1"
        Me.txtXStreet1.Size = New System.Drawing.Size(193, 20)
        Me.txtXStreet1.TabIndex = 257
        '
        'txtXStreet
        '
        Me.txtXStreet.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtXStreet.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblBusStopInformationBindingSource, "CROSS_STREET", True))
        Me.txtXStreet.Location = New System.Drawing.Point(240, 92)
        Me.txtXStreet.Name = "txtXStreet"
        Me.txtXStreet.Size = New System.Drawing.Size(193, 20)
        Me.txtXStreet.TabIndex = 256
        '
        'txtTravelStreet
        '
        Me.txtTravelStreet.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtTravelStreet.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblBusStopInformationBindingSource, "STREET_OF_TRAVEL", True))
        Me.txtTravelStreet.Location = New System.Drawing.Point(240, 68)
        Me.txtTravelStreet.Name = "txtTravelStreet"
        Me.txtTravelStreet.Size = New System.Drawing.Size(193, 20)
        Me.txtTravelStreet.TabIndex = 255
        '
        'cboJurisd
        '
        Me.cboJurisd.BackColor = System.Drawing.SystemColors.Window
        Me.cboJurisd.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboJurisd.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblBusStopInformationBindingSource, "JURISDICTION_ID", True))
        Me.cboJurisd.DataSource = Me.CITYCODEBindingSource3
        Me.cboJurisd.DisplayMember = "JURISDICTION"
        Me.cboJurisd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboJurisd.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboJurisd.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboJurisd.Location = New System.Drawing.Point(335, 16)
        Me.cboJurisd.Name = "cboJurisd"
        Me.cboJurisd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboJurisd.Size = New System.Drawing.Size(98, 22)
        Me.cboJurisd.TabIndex = 254
        Me.cboJurisd.ValueMember = "ID"
        '
        'CITYCODEBindingSource3
        '
        Me.CITYCODEBindingSource3.DataMember = "CITY_CODE"
        Me.CITYCODEBindingSource3.DataSource = Me.DsJurisdiction
        '
        'DsJurisdiction
        '
        Me.DsJurisdiction.DataSetName = "dsJurisdiction"
        Me.DsJurisdiction.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboCity
        '
        Me.cboCity.BackColor = System.Drawing.SystemColors.Window
        Me.cboCity.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboCity.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblBusStopInformationBindingSource, "CITY_ID", True))
        Me.cboCity.DataSource = Me.CITYCODEBindingSource
        Me.cboCity.DisplayMember = "CITY"
        Me.cboCity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboCity.Location = New System.Drawing.Point(335, 42)
        Me.cboCity.Name = "cboCity"
        Me.cboCity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboCity.Size = New System.Drawing.Size(98, 22)
        Me.cboCity.TabIndex = 253
        Me.cboCity.ValueMember = "ID"
        '
        'CITYCODEBindingSource
        '
        Me.CITYCODEBindingSource.DataMember = "CITY_CODE"
        Me.CITYCODEBindingSource.DataSource = Me.DsCityCode
        '
        'DsCityCode
        '
        Me.DsCityCode.DataSetName = "dsCityCode"
        Me.DsCityCode.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboTravelDir
        '
        Me.cboTravelDir.BackColor = System.Drawing.SystemColors.Window
        Me.cboTravelDir.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboTravelDir.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblBusStopInformationBindingSource, "ST_DIR_ID", True))
        Me.cboTravelDir.DataSource = Me.STDIRCODEBindingSource
        Me.cboTravelDir.DisplayMember = "DIR"
        Me.cboTravelDir.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTravelDir.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboTravelDir.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboTravelDir.Location = New System.Drawing.Point(184, 68)
        Me.cboTravelDir.Name = "cboTravelDir"
        Me.cboTravelDir.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboTravelDir.Size = New System.Drawing.Size(49, 22)
        Me.cboTravelDir.TabIndex = 252
        Me.cboTravelDir.ValueMember = "ID"
        '
        'STDIRCODEBindingSource
        '
        Me.STDIRCODEBindingSource.DataMember = "ST_DIR_CODE"
        Me.STDIRCODEBindingSource.DataSource = Me.DsTravelDirectionCode
        '
        'DsTravelDirectionCode
        '
        Me.DsTravelDirectionCode.DataSetName = "dsTravelDirectionCode"
        Me.DsTravelDirectionCode.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'dtEffectDate
        '
        Me.dtEffectDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblBusStopInformationBindingSource, "EFFECTIVE_DATE", True))
        Me.dtEffectDate.Location = New System.Drawing.Point(718, 26)
        Me.dtEffectDate.Name = "dtEffectDate"
        Me.dtEffectDate.Size = New System.Drawing.Size(93, 20)
        Me.dtEffectDate.TabIndex = 250
        '
        'txtSANZID
        '
        Me.txtSANZID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblBusStopInformationBindingSource, "SANZ_ID", True))
        Me.txtSANZID.Location = New System.Drawing.Point(184, 16)
        Me.txtSANZID.Name = "txtSANZID"
        Me.txtSANZID.ReadOnly = True
        Me.txtSANZID.Size = New System.Drawing.Size(84, 20)
        Me.txtSANZID.TabIndex = 248
        '
        'txtOCTAID
        '
        Me.txtOCTAID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblBusStopInformationBindingSource, "OCTA_ID", True))
        Me.txtOCTAID.Location = New System.Drawing.Point(70, 16)
        Me.txtOCTAID.Name = "txtOCTAID"
        Me.txtOCTAID.ReadOnly = True
        Me.txtOCTAID.Size = New System.Drawing.Size(55, 20)
        Me.txtOCTAID.TabIndex = 247
        '
        'cmdChangeActiveStop
        '
        Me.cmdChangeActiveStop.BackColor = System.Drawing.SystemColors.Control
        Me.cmdChangeActiveStop.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdChangeActiveStop.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdChangeActiveStop.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdChangeActiveStop.Location = New System.Drawing.Point(716, 81)
        Me.cmdChangeActiveStop.Name = "cmdChangeActiveStop"
        Me.cmdChangeActiveStop.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdChangeActiveStop.Size = New System.Drawing.Size(94, 25)
        Me.cmdChangeActiveStop.TabIndex = 23
        Me.cmdChangeActiveStop.Text = "Change Active"
        Me.cmdChangeActiveStop.UseVisualStyleBackColor = False
        '
        'cboBSStatus
        '
        Me.cboBSStatus.BackColor = System.Drawing.SystemColors.Window
        Me.cboBSStatus.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboBSStatus.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblBusStopInformationBindingSource, "BS_STATUS_ID", True))
        Me.cboBSStatus.DataSource = Me.BSSTATUSCODEBindingSource
        Me.cboBSStatus.DisplayMember = "STATUS"
        Me.cboBSStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBSStatus.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBSStatus.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboBSStatus.Location = New System.Drawing.Point(557, 24)
        Me.cboBSStatus.Name = "cboBSStatus"
        Me.cboBSStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboBSStatus.Size = New System.Drawing.Size(112, 22)
        Me.cboBSStatus.TabIndex = 20
        Me.cboBSStatus.ValueMember = "ID"
        '
        'BSSTATUSCODEBindingSource
        '
        Me.BSSTATUSCODEBindingSource.DataMember = "BS_STATUS_CODE"
        Me.BSSTATUSCODEBindingSource.DataSource = Me.DsBusStopStatusCode
        '
        'DsBusStopStatusCode
        '
        Me.DsBusStopStatusCode.DataSetName = "dsBusStopStatusCode"
        Me.DsBusStopStatusCode.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboCounty
        '
        Me.cboCounty.BackColor = System.Drawing.SystemColors.Window
        Me.cboCounty.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboCounty.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblBusStopInformationBindingSource, "COUNTY_ID", True))
        Me.cboCounty.DataSource = Me.COUNTYCODEBindingSource
        Me.cboCounty.DisplayMember = "COUNTY"
        Me.cboCounty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCounty.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCounty.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboCounty.Location = New System.Drawing.Point(184, 42)
        Me.cboCounty.Name = "cboCounty"
        Me.cboCounty.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboCounty.Size = New System.Drawing.Size(84, 22)
        Me.cboCounty.TabIndex = 10
        Me.cboCounty.ValueMember = "ID"
        '
        'COUNTYCODEBindingSource
        '
        Me.COUNTYCODEBindingSource.DataMember = "COUNTY_CODE"
        Me.COUNTYCODEBindingSource.DataSource = Me.DsCountyCode
        '
        'DsCountyCode
        '
        Me.DsCountyCode.DataSetName = "dsCountyCode"
        Me.DsCountyCode.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtRouteServed
        '
        Me.txtRouteServed.AcceptsReturn = True
        Me.txtRouteServed.BackColor = System.Drawing.SystemColors.Window
        Me.txtRouteServed.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRouteServed.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRouteServed.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRouteServed.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRouteServed.Location = New System.Drawing.Point(557, 72)
        Me.txtRouteServed.MaxLength = 0
        Me.txtRouteServed.Multiline = True
        Me.txtRouteServed.Name = "txtRouteServed"
        Me.txtRouteServed.ReadOnly = True
        Me.txtRouteServed.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRouteServed.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtRouteServed.Size = New System.Drawing.Size(113, 65)
        Me.txtRouteServed.TabIndex = 34
        '
        'cboXLoc
        '
        Me.cboXLoc.BackColor = System.Drawing.SystemColors.Window
        Me.cboXLoc.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboXLoc.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblBusStopInformationBindingSource, "BS_LOC_ID", True))
        Me.cboXLoc.DataSource = Me.BSLOCCODEBindingSource
        Me.cboXLoc.DisplayMember = "LOC"
        Me.cboXLoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboXLoc.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboXLoc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboXLoc.Location = New System.Drawing.Point(184, 92)
        Me.cboXLoc.Name = "cboXLoc"
        Me.cboXLoc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboXLoc.Size = New System.Drawing.Size(49, 22)
        Me.cboXLoc.TabIndex = 16
        Me.cboXLoc.ValueMember = "ID"
        '
        'BSLOCCODEBindingSource
        '
        Me.BSLOCCODEBindingSource.DataMember = "BS_LOC_CODE"
        Me.BSLOCCODEBindingSource.DataSource = Me.DsBusStopLocation
        '
        'DsBusStopLocation
        '
        Me.DsBusStopLocation.DataSetName = "dsBusStopLocation"
        Me.DsBusStopLocation.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboXType
        '
        Me.cboXType.BackColor = System.Drawing.SystemColors.Window
        Me.cboXType.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboXType.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblBusStopInformationBindingSource, "ST_TYPE_ID_2", True))
        Me.cboXType.DataSource = Me.STTYPECODEBindingSource1
        Me.cboXType.DisplayMember = "TYPE"
        Me.cboXType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboXType.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboXType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboXType.Location = New System.Drawing.Point(440, 92)
        Me.cboXType.Name = "cboXType"
        Me.cboXType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboXType.Size = New System.Drawing.Size(65, 22)
        Me.cboXType.TabIndex = 18
        Me.cboXType.ValueMember = "ID"
        '
        'STTYPECODEBindingSource1
        '
        Me.STTYPECODEBindingSource1.DataMember = "ST_TYPE_CODE"
        Me.STTYPECODEBindingSource1.DataSource = Me.DsStreetType
        '
        'DsStreetType
        '
        Me.DsStreetType.DataSetName = "dsStreetType"
        Me.DsStreetType.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboTravelType
        '
        Me.cboTravelType.BackColor = System.Drawing.SystemColors.Window
        Me.cboTravelType.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboTravelType.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblBusStopInformationBindingSource, "ST_TYPE_ID_1", True))
        Me.cboTravelType.DataSource = Me.STTYPECODEBindingSource
        Me.cboTravelType.DisplayMember = "TYPE"
        Me.cboTravelType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTravelType.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboTravelType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboTravelType.Location = New System.Drawing.Point(440, 68)
        Me.cboTravelType.Name = "cboTravelType"
        Me.cboTravelType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboTravelType.Size = New System.Drawing.Size(65, 22)
        Me.cboTravelType.TabIndex = 15
        Me.cboTravelType.ValueMember = "ID"
        '
        'STTYPECODEBindingSource
        '
        Me.STTYPECODEBindingSource.DataMember = "ST_TYPE_CODE"
        Me.STTYPECODEBindingSource.DataSource = Me.DsStreetType
        '
        'cmdAddNewRecord
        '
        Me.cmdAddNewRecord.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddNewRecord.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddNewRecord.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddNewRecord.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddNewRecord.Location = New System.Drawing.Point(716, 112)
        Me.cmdAddNewRecord.Name = "cmdAddNewRecord"
        Me.cmdAddNewRecord.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAddNewRecord.Size = New System.Drawing.Size(94, 25)
        Me.cmdAddNewRecord.TabIndex = 24
        Me.cmdAddNewRecord.Text = "Add New Stop"
        Me.cmdAddNewRecord.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdAddNewRecord.UseVisualStyleBackColor = False
        '
        '_Label1_3
        '
        Me._Label1_3.AutoSize = True
        Me._Label1_3.BackColor = System.Drawing.Color.Transparent
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_3.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_3.Location = New System.Drawing.Point(553, 10)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(51, 14)
        Me._Label1_3.TabIndex = 245
        Me._Label1_3.Text = "STATUS:"
        '
        '_Label1_2
        '
        Me._Label1_2.AutoSize = True
        Me._Label1_2.BackColor = System.Drawing.Color.Transparent
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_2.ForeColor = System.Drawing.Color.CornflowerBlue
        Me._Label1_2.Location = New System.Drawing.Point(557, 56)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(118, 14)
        Me._Label1_2.TabIndex = 35
        Me._Label1_2.Text = "SERVED BY ROUTE(s)"
        '
        '_Label1_35
        '
        Me._Label1_35.AutoSize = True
        Me._Label1_35.BackColor = System.Drawing.Color.Transparent
        Me._Label1_35.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_35.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_35.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_35.Location = New System.Drawing.Point(130, 46)
        Me._Label1_35.Name = "_Label1_35"
        Me._Label1_35.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_35.Size = New System.Drawing.Size(53, 14)
        Me._Label1_35.TabIndex = 33
        Me._Label1_35.Text = "COUNTY:"
        '
        '_Label1_44
        '
        Me._Label1_44.AutoSize = True
        Me._Label1_44.BackColor = System.Drawing.Color.Transparent
        Me._Label1_44.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_44.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_44.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_44.Location = New System.Drawing.Point(298, 46)
        Me._Label1_44.Name = "_Label1_44"
        Me._Label1_44.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_44.Size = New System.Drawing.Size(34, 14)
        Me._Label1_44.TabIndex = 32
        Me._Label1_44.Text = "CITY:"
        '
        '_Label1_55
        '
        Me._Label1_55.AutoSize = True
        Me._Label1_55.BackColor = System.Drawing.Color.Transparent
        Me._Label1_55.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_55.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_55.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_55.Location = New System.Drawing.Point(287, 21)
        Me._Label1_55.Name = "_Label1_55"
        Me._Label1_55.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_55.Size = New System.Drawing.Size(47, 14)
        Me._Label1_55.TabIndex = 31
        Me._Label1_55.Text = "JURISD:"
        '
        '_Label1_77
        '
        Me._Label1_77.AutoSize = True
        Me._Label1_77.BackColor = System.Drawing.Color.Transparent
        Me._Label1_77.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_77.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_77.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_77.Location = New System.Drawing.Point(716, 11)
        Me._Label1_77.Name = "_Label1_77"
        Me._Label1_77.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_77.Size = New System.Drawing.Size(96, 14)
        Me._Label1_77.TabIndex = 30
        Me._Label1_77.Text = "EFFECTIVE DATE:"
        '
        '_Label1_1
        '
        Me._Label1_1.AutoSize = True
        Me._Label1_1.BackColor = System.Drawing.Color.Transparent
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_1.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_1.Location = New System.Drawing.Point(63, 95)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(121, 14)
        Me._Label1_1.TabIndex = 29
        Me._Label1_1.Text = "BUS STOP LOCATION:"
        '
        '_Label1_87
        '
        Me._Label1_87.AutoSize = True
        Me._Label1_87.BackColor = System.Drawing.Color.Transparent
        Me._Label1_87.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_87.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_87.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_87.Location = New System.Drawing.Point(16, 71)
        Me._Label1_87.Name = "_Label1_87"
        Me._Label1_87.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_87.Size = New System.Drawing.Size(168, 14)
        Me._Label1_87.TabIndex = 28
        Me._Label1_87.Text = "DIRECTION/STREET of TRAVEL:"
        '
        '_Label1_11
        '
        Me._Label1_11.AutoSize = True
        Me._Label1_11.BackColor = System.Drawing.Color.Transparent
        Me._Label1_11.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_11.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_11.Location = New System.Drawing.Point(132, 20)
        Me._Label1_11.Name = "_Label1_11"
        Me._Label1_11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_11.Size = New System.Drawing.Size(52, 14)
        Me._Label1_11.TabIndex = 27
        Me._Label1_11.Text = "SANZ ID:"
        '
        '_Label1_0
        '
        Me._Label1_0.AutoSize = True
        Me._Label1_0.BackColor = System.Drawing.Color.Transparent
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_0.Location = New System.Drawing.Point(14, 20)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(53, 14)
        Me._Label1_0.TabIndex = 26
        Me._Label1_0.Text = "OCTA ID:"
        '
        'CITYCODEBindingSource1
        '
        Me.CITYCODEBindingSource1.DataMember = "CITY_CODE"
        Me.CITYCODEBindingSource1.DataSource = Me.DsJurisdiction
        '
        'CITYCODEBindingSource2
        '
        Me.CITYCODEBindingSource2.DataMember = "CITY_CODE"
        Me.CITYCODEBindingSource2.DataSource = Me.DsJurisdiction
        '
        'DsBusStopStatusCode1
        '
        Me.DsBusStopStatusCode1.DataSetName = "dsBusStopStatusCode"
        Me.DsBusStopStatusCode1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cbxNiteOwl
        '
        Me.cbxNiteOwl.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.TblBusStopInformationBindingSource, "NITE_OWL", True))
        Me.cbxNiteOwl.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxNiteOwl.ForeColor = System.Drawing.Color.DimGray
        Me.cbxNiteOwl.Location = New System.Drawing.Point(89, 24)
        Me.cbxNiteOwl.Name = "cbxNiteOwl"
        Me.cbxNiteOwl.Size = New System.Drawing.Size(83, 24)
        Me.cbxNiteOwl.TabIndex = 260
        Me.cbxNiteOwl.Text = "CITY STOP"
        Me.cbxNiteOwl.UseVisualStyleBackColor = True
        '
        'cbxBRT
        '
        Me.cbxBRT.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.TblBusStopInformationBindingSource, "BRT_STOP", True))
        Me.cbxBRT.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxBRT.ForeColor = System.Drawing.Color.DimGray
        Me.cbxBRT.Location = New System.Drawing.Point(178, 24)
        Me.cbxBRT.Name = "cbxBRT"
        Me.cbxBRT.Size = New System.Drawing.Size(85, 24)
        Me.cbxBRT.TabIndex = 259
        Me.cbxBRT.Text = "BRT STOP"
        Me.cbxBRT.UseVisualStyleBackColor = True
        '
        'BusStopManagementDataSet4
        '
        Me.BusStopManagementDataSet4.DataSetName = "BusStopManagementDataSet4"
        Me.BusStopManagementDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Frame6
        '
        Me.Frame6.BackColor = System.Drawing.Color.Transparent
        Me.Frame6.Controls.Add(Me.cbxBRT)
        Me.Frame6.Controls.Add(Me.cbxNiteOwl)
        Me.Frame6.Controls.Add(Me.cbxExpress)
        Me.Frame6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame6.ForeColor = System.Drawing.Color.DimGray
        Me.Frame6.Location = New System.Drawing.Point(586, 38)
        Me.Frame6.Name = "Frame6"
        Me.Frame6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame6.Size = New System.Drawing.Size(269, 62)
        Me.Frame6.TabIndex = 305
        Me.Frame6.TabStop = False
        Me.Frame6.Text = "Stop Type"
        '
        'cbxExpress
        '
        Me.cbxExpress.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.TblBusStopInformationBindingSource, "EXPRESS_STOP", True))
        Me.cbxExpress.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxExpress.ForeColor = System.Drawing.Color.DimGray
        Me.cbxExpress.Location = New System.Drawing.Point(12, 24)
        Me.cbxExpress.Name = "cbxExpress"
        Me.cbxExpress.Size = New System.Drawing.Size(78, 24)
        Me.cbxExpress.TabIndex = 261
        Me.cbxExpress.Text = "EXPRESS"
        Me.cbxExpress.UseVisualStyleBackColor = True
        '
        'Frame7
        '
        Me.Frame7.BackColor = System.Drawing.Color.Transparent
        Me.Frame7.Controls.Add(Me.cmdSortOrder)
        Me.Frame7.Controls.Add(Me.Command1)
        Me.Frame7.Controls.Add(Me._Label1_5)
        Me.Frame7.Controls.Add(Me.cmdFindRecord)
        Me.Frame7.Controls.Add(Me.cmdClose)
        Me.Frame7.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame7.ForeColor = System.Drawing.Color.DimGray
        Me.Frame7.Location = New System.Drawing.Point(18, 38)
        Me.Frame7.Name = "Frame7"
        Me.Frame7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame7.Size = New System.Drawing.Size(562, 62)
        Me.Frame7.TabIndex = 306
        Me.Frame7.TabStop = False
        Me.Frame7.Text = "Navigation"
        '
        '_Label1_5
        '
        Me._Label1_5.AutoSize = True
        Me._Label1_5.BackColor = System.Drawing.Color.Transparent
        Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_5.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_5.Location = New System.Drawing.Point(20, 27)
        Me._Label1_5.Name = "_Label1_5"
        Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_5.Size = New System.Drawing.Size(55, 15)
        Me._Label1_5.TabIndex = 276
        Me._Label1_5.Text = "OCTA ID:"
        '
        'SSTab1
        '
        Me.SSTab1.Controls.Add(Me.TabPage1)
        Me.SSTab1.Controls.Add(Me.TabPage2)
        Me.SSTab1.Controls.Add(Me.TabPage3)
        Me.SSTab1.Controls.Add(Me.TabPage4)
        Me.SSTab1.Controls.Add(Me.TabPage5)
        Me.SSTab1.Controls.Add(Me.TabPage7)
        Me.SSTab1.Controls.Add(Me.TabPage8)
        Me.SSTab1.Controls.Add(Me.TabPage9)
        Me.SSTab1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SSTab1.HotTrack = True
        Me.SSTab1.Location = New System.Drawing.Point(18, 275)
        Me.SSTab1.Name = "SSTab1"
        Me.SSTab1.SelectedIndex = 0
        Me.SSTab1.Size = New System.Drawing.Size(966, 534)
        Me.SSTab1.TabIndex = 307
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage1.Controls.Add(Me.cmdSaveADARecord)
        Me.TabPage1.Controls.Add(Me.fraADA)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(958, 505)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "ADA"
        '
        'cmdSaveADARecord
        '
        Me.cmdSaveADARecord.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSaveADARecord.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSaveADARecord.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSaveADARecord.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSaveADARecord.Location = New System.Drawing.Point(797, 6)
        Me.cmdSaveADARecord.Name = "cmdSaveADARecord"
        Me.cmdSaveADARecord.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSaveADARecord.Size = New System.Drawing.Size(155, 33)
        Me.cmdSaveADARecord.TabIndex = 62
        Me.cmdSaveADARecord.Text = "Save ADA Record"
        Me.cmdSaveADARecord.UseVisualStyleBackColor = False
        '
        'fraADA
        '
        Me.fraADA.BackColor = System.Drawing.Color.Transparent
        Me.fraADA.Controls.Add(Me.cbxADASurveyed)
        Me.fraADA.Controls.Add(Me.txtADARemarks)
        Me.fraADA.Controls.Add(Me.dtADASurvey)
        Me.fraADA.Controls.Add(Me.dtADACompletion)
        Me.fraADA.Controls.Add(Me.btnADACreateHistory)
        Me.fraADA.Controls.Add(Me.cboADAStatus)
        Me.fraADA.Controls.Add(Me._Label1_84)
        Me.fraADA.Controls.Add(Me._Label1_7)
        Me.fraADA.Controls.Add(Me._Label1_6)
        Me.fraADA.Controls.Add(Me._Label1_83)
        Me.fraADA.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraADA.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraADA.Location = New System.Drawing.Point(105, 52)
        Me.fraADA.Name = "fraADA"
        Me.fraADA.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraADA.Size = New System.Drawing.Size(728, 398)
        Me.fraADA.TabIndex = 40
        Me.fraADA.TabStop = False
        '
        'cbxADASurveyed
        '
        Me.cbxADASurveyed.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.TblADAStatusBindingSource, "SURVEYED", True))
        Me.cbxADASurveyed.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxADASurveyed.ForeColor = System.Drawing.Color.DimGray
        Me.cbxADASurveyed.Location = New System.Drawing.Point(633, 19)
        Me.cbxADASurveyed.Name = "cbxADASurveyed"
        Me.cbxADASurveyed.Size = New System.Drawing.Size(89, 24)
        Me.cbxADASurveyed.TabIndex = 61
        Me.cbxADASurveyed.Text = "SURVEYED"
        Me.cbxADASurveyed.UseVisualStyleBackColor = True
        '
        'TblADAStatusBindingSource
        '
        Me.TblADAStatusBindingSource.DataMember = "tblADAStatus"
        Me.TblADAStatusBindingSource.DataSource = Me.DsADA
        '
        'DsADA
        '
        Me.DsADA.DataSetName = "dsADA"
        Me.DsADA.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtADARemarks
        '
        Me.txtADARemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtADARemarks.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblADAStatusBindingSource, "REMARKS", True))
        Me.txtADARemarks.Location = New System.Drawing.Point(43, 201)
        Me.txtADARemarks.Multiline = True
        Me.txtADARemarks.Name = "txtADARemarks"
        Me.txtADARemarks.Size = New System.Drawing.Size(582, 152)
        Me.txtADARemarks.TabIndex = 60
        '
        'dtADASurvey
        '
        Me.dtADASurvey.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblADAStatusBindingSource, "SURVEY_DATE", True))
        Me.dtADASurvey.Location = New System.Drawing.Point(192, 88)
        Me.dtADASurvey.Name = "dtADASurvey"
        Me.dtADASurvey.Size = New System.Drawing.Size(258, 20)
        Me.dtADASurvey.TabIndex = 59
        '
        'dtADACompletion
        '
        Me.dtADACompletion.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblADAStatusBindingSource, "COMPLETION_DATE", True))
        Me.dtADACompletion.Location = New System.Drawing.Point(192, 128)
        Me.dtADACompletion.Name = "dtADACompletion"
        Me.dtADACompletion.Size = New System.Drawing.Size(257, 20)
        Me.dtADACompletion.TabIndex = 58
        '
        'btnADACreateHistory
        '
        Me.btnADACreateHistory.BackColor = System.Drawing.SystemColors.Control
        Me.btnADACreateHistory.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnADACreateHistory.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnADACreateHistory.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnADACreateHistory.Location = New System.Drawing.Point(470, 119)
        Me.btnADACreateHistory.Name = "btnADACreateHistory"
        Me.btnADACreateHistory.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btnADACreateHistory.Size = New System.Drawing.Size(155, 33)
        Me.btnADACreateHistory.TabIndex = 46
        Me.btnADACreateHistory.Text = "Create History Record"
        Me.btnADACreateHistory.UseVisualStyleBackColor = False
        '
        'cboADAStatus
        '
        Me.cboADAStatus.BackColor = System.Drawing.SystemColors.Window
        Me.cboADAStatus.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboADAStatus.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblADAStatusBindingSource, "ADA_STATUS_ID1", True))
        Me.cboADAStatus.DataSource = Me.ADASTATUSCODEBindingSource1
        Me.cboADAStatus.DisplayMember = "DESCRIPTION"
        Me.cboADAStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboADAStatus.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboADAStatus.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboADAStatus.Location = New System.Drawing.Point(192, 48)
        Me.cboADAStatus.Name = "cboADAStatus"
        Me.cboADAStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboADAStatus.Size = New System.Drawing.Size(257, 22)
        Me.cboADAStatus.TabIndex = 43
        Me.cboADAStatus.ValueMember = "ID"
        '
        'ADASTATUSCODEBindingSource1
        '
        Me.ADASTATUSCODEBindingSource1.DataMember = "ADA_STATUS_CODE"
        Me.ADASTATUSCODEBindingSource1.DataSource = Me.DsADAStatusCode
        '
        'DsADAStatusCode
        '
        Me.DsADAStatusCode.DataSetName = "dsADAStatusCode"
        Me.DsADAStatusCode.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        '_Label1_84
        '
        Me._Label1_84.AutoSize = True
        Me._Label1_84.BackColor = System.Drawing.Color.Transparent
        Me._Label1_84.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_84.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_84.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_84.Location = New System.Drawing.Point(40, 184)
        Me._Label1_84.Name = "_Label1_84"
        Me._Label1_84.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_84.Size = New System.Drawing.Size(59, 15)
        Me._Label1_84.TabIndex = 55
        Me._Label1_84.Text = "REMARK:"
        '
        '_Label1_7
        '
        Me._Label1_7.AutoSize = True
        Me._Label1_7.BackColor = System.Drawing.Color.Transparent
        Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_7.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_7.Location = New System.Drawing.Point(40, 128)
        Me._Label1_7.Name = "_Label1_7"
        Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_7.Size = New System.Drawing.Size(142, 15)
        Me._Label1_7.TabIndex = 54
        Me._Label1_7.Text = "ADA COMPLETION DATE"
        '
        '_Label1_6
        '
        Me._Label1_6.AutoSize = True
        Me._Label1_6.BackColor = System.Drawing.Color.Transparent
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_6.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_6.Location = New System.Drawing.Point(96, 88)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(85, 15)
        Me._Label1_6.TabIndex = 53
        Me._Label1_6.Text = "SURVEY DATE"
        '
        '_Label1_83
        '
        Me._Label1_83.AutoSize = True
        Me._Label1_83.BackColor = System.Drawing.Color.Transparent
        Me._Label1_83.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_83.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_83.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_83.Location = New System.Drawing.Point(104, 48)
        Me._Label1_83.Name = "_Label1_83"
        Me._Label1_83.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_83.Size = New System.Drawing.Size(78, 15)
        Me._Label1_83.TabIndex = 52
        Me._Label1_83.Text = "ADA STATUS"
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage2.Controls.Add(Me.cmdSaveTransAmenities)
        Me.TabPage2.Controls.Add(Me.fraTransit)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(958, 505)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TRANSIT AMENITIES"
        '
        'cmdSaveTransAmenities
        '
        Me.cmdSaveTransAmenities.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSaveTransAmenities.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSaveTransAmenities.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSaveTransAmenities.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSaveTransAmenities.Location = New System.Drawing.Point(755, 6)
        Me.cmdSaveTransAmenities.Name = "cmdSaveTransAmenities"
        Me.cmdSaveTransAmenities.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSaveTransAmenities.Size = New System.Drawing.Size(197, 33)
        Me.cmdSaveTransAmenities.TabIndex = 63
        Me.cmdSaveTransAmenities.Text = "Save Transit Amenities Record"
        Me.cmdSaveTransAmenities.UseVisualStyleBackColor = False
        '
        'fraTransit
        '
        Me.fraTransit.BackColor = System.Drawing.Color.Transparent
        Me.fraTransit.Controls.Add(Me.OCTA_IDTextBox)
        Me.fraTransit.Controls.Add(Me.cboRstType)
        Me.fraTransit.Controls.Add(Me.cboTrnType)
        Me.fraTransit.Controls.Add(Me.cboBsPdType)
        Me.fraTransit.Controls.Add(Me.cbxTransSurvey)
        Me.fraTransit.Controls.Add(Me.txtTranAmenRmk)
        Me.fraTransit.Controls.Add(Me.txtRstLen)
        Me.fraTransit.Controls.Add(Me.txtTrnEgress)
        Me.fraTransit.Controls.Add(Me.txtTrnBsBay)
        Me.fraTransit.Controls.Add(Me.txtBsPdLen)
        Me.fraTransit.Controls.Add(Me.txtBsPdWdth)
        Me.fraTransit.Controls.Add(Me.txtTrnIngress)
        Me.fraTransit.Controls.Add(Me.cbxRstrcPrk)
        Me.fraTransit.Controls.Add(Me.cbxTurnout)
        Me.fraTransit.Controls.Add(Me.cbxBusPad)
        Me.fraTransit.Controls.Add(Me.txtTrnWidth)
        Me.fraTransit.Controls.Add(Me._Label1_26)
        Me.fraTransit.Controls.Add(Me._Label1_25)
        Me.fraTransit.Controls.Add(Me._Label1_14)
        Me.fraTransit.Controls.Add(Me._Label1_24)
        Me.fraTransit.Controls.Add(Me._Label1_16)
        Me.fraTransit.Controls.Add(Me._Label1_23)
        Me.fraTransit.Controls.Add(Me._Label1_20)
        Me.fraTransit.Controls.Add(Me._Label1_22)
        Me.fraTransit.Controls.Add(Me._Label1_13)
        Me.fraTransit.Controls.Add(Me._Label1_12)
        Me.fraTransit.Controls.Add(Me._Label1_10)
        Me.fraTransit.Controls.Add(Me._Label1_4)
        Me.fraTransit.Controls.Add(Me._Label1_27)
        Me.fraTransit.Controls.Add(Me._Label1_60)
        Me.fraTransit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraTransit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraTransit.Location = New System.Drawing.Point(62, 54)
        Me.fraTransit.Name = "fraTransit"
        Me.fraTransit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraTransit.Size = New System.Drawing.Size(861, 393)
        Me.fraTransit.TabIndex = 57
        Me.fraTransit.TabStop = False
        '
        'OCTA_IDTextBox
        '
        Me.OCTA_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopTransAmenitiesBindingSource, "OCTA_ID", True))
        Me.OCTA_IDTextBox.Location = New System.Drawing.Point(6, 19)
        Me.OCTA_IDTextBox.Name = "OCTA_IDTextBox"
        Me.OCTA_IDTextBox.Size = New System.Drawing.Size(31, 20)
        Me.OCTA_IDTextBox.TabIndex = 64
        Me.OCTA_IDTextBox.Visible = False
        '
        'TblStopTransAmenitiesBindingSource
        '
        Me.TblStopTransAmenitiesBindingSource.DataMember = "tblStopTransAmenities"
        Me.TblStopTransAmenitiesBindingSource.DataSource = Me.DsTransitAmenities
        '
        'DsTransitAmenities
        '
        Me.DsTransitAmenities.DataSetName = "dsTransitAmenities"
        Me.DsTransitAmenities.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboRstType
        '
        Me.cboRstType.BackColor = System.Drawing.SystemColors.Window
        Me.cboRstType.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboRstType.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblStopTransAmenitiesBindingSource, "RESTRICTIVE_PK_TYPE_ID", True))
        Me.cboRstType.DataSource = Me.RESTRICTIVEPKTYPECODEBindingSource
        Me.cboRstType.DisplayMember = "DESCRIPTION"
        Me.cboRstType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRstType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboRstType.Location = New System.Drawing.Point(152, 202)
        Me.cboRstType.Name = "cboRstType"
        Me.cboRstType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboRstType.Size = New System.Drawing.Size(159, 22)
        Me.cboRstType.TabIndex = 59
        Me.cboRstType.ValueMember = "ID"
        '
        'RESTRICTIVEPKTYPECODEBindingSource
        '
        Me.RESTRICTIVEPKTYPECODEBindingSource.DataMember = "RESTRICTIVE_PK_TYPE_CODE"
        Me.RESTRICTIVEPKTYPECODEBindingSource.DataSource = Me.DsRestrictiveParking
        '
        'DsRestrictiveParking
        '
        Me.DsRestrictiveParking.DataSetName = "dsRestrictiveParking"
        Me.DsRestrictiveParking.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboTrnType
        '
        Me.cboTrnType.BackColor = System.Drawing.SystemColors.Window
        Me.cboTrnType.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboTrnType.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblStopTransAmenitiesBindingSource, "TURNOUT_TYPE_ID", True))
        Me.cboTrnType.DataSource = Me.TURNOUTTYPECODEBindingSource
        Me.cboTrnType.DisplayMember = "DESCRIPTION"
        Me.cboTrnType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTrnType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboTrnType.Location = New System.Drawing.Point(152, 128)
        Me.cboTrnType.Name = "cboTrnType"
        Me.cboTrnType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboTrnType.Size = New System.Drawing.Size(159, 22)
        Me.cboTrnType.TabIndex = 60
        Me.cboTrnType.ValueMember = "ID"
        '
        'TURNOUTTYPECODEBindingSource
        '
        Me.TURNOUTTYPECODEBindingSource.DataMember = "TURNOUT_TYPE_CODE"
        Me.TURNOUTTYPECODEBindingSource.DataSource = Me.DsTurnOutType
        '
        'DsTurnOutType
        '
        Me.DsTurnOutType.DataSetName = "dsTurnOutType"
        Me.DsTurnOutType.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboBsPdType
        '
        Me.cboBsPdType.BackColor = System.Drawing.SystemColors.Window
        Me.cboBsPdType.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboBsPdType.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblStopTransAmenitiesBindingSource, "BUS_PAD_ID", True))
        Me.cboBsPdType.DataSource = Me.BUSPADCODEBindingSource
        Me.cboBsPdType.DisplayMember = "DESCRIPTION"
        Me.cboBsPdType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBsPdType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboBsPdType.Location = New System.Drawing.Point(152, 58)
        Me.cboBsPdType.Name = "cboBsPdType"
        Me.cboBsPdType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboBsPdType.Size = New System.Drawing.Size(146, 22)
        Me.cboBsPdType.TabIndex = 61
        Me.cboBsPdType.ValueMember = "ID"
        '
        'BUSPADCODEBindingSource
        '
        Me.BUSPADCODEBindingSource.DataMember = "BUS_PAD_CODE"
        Me.BUSPADCODEBindingSource.DataSource = Me.DsBusPadType
        '
        'DsBusPadType
        '
        Me.DsBusPadType.DataSetName = "dsBusPadType"
        Me.DsBusPadType.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cbxTransSurvey
        '
        Me.cbxTransSurvey.BackColor = System.Drawing.Color.Transparent
        Me.cbxTransSurvey.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxTransSurvey.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblStopTransAmenitiesBindingSource, "SURVEYED", True))
        Me.cbxTransSurvey.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxTransSurvey.ForeColor = System.Drawing.Color.DimGray
        Me.cbxTransSurvey.Location = New System.Drawing.Point(769, 19)
        Me.cbxTransSurvey.Name = "cbxTransSurvey"
        Me.cbxTransSurvey.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxTransSurvey.Size = New System.Drawing.Size(91, 25)
        Me.cbxTransSurvey.TabIndex = 75
        Me.cbxTransSurvey.Text = "SURVEYED"
        Me.cbxTransSurvey.UseVisualStyleBackColor = False
        '
        'txtTranAmenRmk
        '
        Me.txtTranAmenRmk.AcceptsReturn = True
        Me.txtTranAmenRmk.BackColor = System.Drawing.SystemColors.Window
        Me.txtTranAmenRmk.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtTranAmenRmk.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTranAmenRmk.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopTransAmenitiesBindingSource, "REMARKS", True))
        Me.txtTranAmenRmk.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTranAmenRmk.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTranAmenRmk.Location = New System.Drawing.Point(150, 249)
        Me.txtTranAmenRmk.MaxLength = 0
        Me.txtTranAmenRmk.Multiline = True
        Me.txtTranAmenRmk.Name = "txtTranAmenRmk"
        Me.txtTranAmenRmk.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTranAmenRmk.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtTranAmenRmk.Size = New System.Drawing.Size(673, 105)
        Me.txtTranAmenRmk.TabIndex = 74
        '
        'txtRstLen
        '
        Me.txtRstLen.AcceptsReturn = True
        Me.txtRstLen.BackColor = System.Drawing.SystemColors.Window
        Me.txtRstLen.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRstLen.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopTransAmenitiesBindingSource, "RESTRICTIVE_PK_LT", True))
        Me.txtRstLen.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRstLen.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRstLen.Location = New System.Drawing.Point(375, 200)
        Me.txtRstLen.MaxLength = 5
        Me.txtRstLen.Name = "txtRstLen"
        Me.txtRstLen.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRstLen.Size = New System.Drawing.Size(54, 20)
        Me.txtRstLen.TabIndex = 70
        '
        'txtTrnEgress
        '
        Me.txtTrnEgress.AcceptsReturn = True
        Me.txtTrnEgress.BackColor = System.Drawing.SystemColors.Window
        Me.txtTrnEgress.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTrnEgress.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopTransAmenitiesBindingSource, "EGRESS_LT", True))
        Me.txtTrnEgress.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrnEgress.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTrnEgress.Location = New System.Drawing.Point(644, 128)
        Me.txtTrnEgress.MaxLength = 5
        Me.txtTrnEgress.Name = "txtTrnEgress"
        Me.txtTrnEgress.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTrnEgress.Size = New System.Drawing.Size(54, 20)
        Me.txtTrnEgress.TabIndex = 69
        '
        'txtTrnBsBay
        '
        Me.txtTrnBsBay.AcceptsReturn = True
        Me.txtTrnBsBay.BackColor = System.Drawing.SystemColors.Window
        Me.txtTrnBsBay.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTrnBsBay.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopTransAmenitiesBindingSource, "BUS_BAY_LT", True))
        Me.txtTrnBsBay.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrnBsBay.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTrnBsBay.Location = New System.Drawing.Point(514, 128)
        Me.txtTrnBsBay.MaxLength = 5
        Me.txtTrnBsBay.Name = "txtTrnBsBay"
        Me.txtTrnBsBay.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTrnBsBay.Size = New System.Drawing.Size(54, 20)
        Me.txtTrnBsBay.TabIndex = 68
        '
        'txtBsPdLen
        '
        Me.txtBsPdLen.AcceptsReturn = True
        Me.txtBsPdLen.BackColor = System.Drawing.SystemColors.Window
        Me.txtBsPdLen.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBsPdLen.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopTransAmenitiesBindingSource, "PAD_LENGTH", True))
        Me.txtBsPdLen.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBsPdLen.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBsPdLen.Location = New System.Drawing.Point(514, 56)
        Me.txtBsPdLen.MaxLength = 5
        Me.txtBsPdLen.Name = "txtBsPdLen"
        Me.txtBsPdLen.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBsPdLen.Size = New System.Drawing.Size(54, 20)
        Me.txtBsPdLen.TabIndex = 67
        '
        'txtBsPdWdth
        '
        Me.txtBsPdWdth.AcceptsReturn = True
        Me.txtBsPdWdth.BackColor = System.Drawing.SystemColors.Window
        Me.txtBsPdWdth.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBsPdWdth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopTransAmenitiesBindingSource, "PAD_WIDTH", True))
        Me.txtBsPdWdth.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBsPdWdth.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBsPdWdth.Location = New System.Drawing.Point(375, 56)
        Me.txtBsPdWdth.MaxLength = 5
        Me.txtBsPdWdth.Name = "txtBsPdWdth"
        Me.txtBsPdWdth.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBsPdWdth.Size = New System.Drawing.Size(54, 20)
        Me.txtBsPdWdth.TabIndex = 66
        '
        'txtTrnIngress
        '
        Me.txtTrnIngress.AcceptsReturn = True
        Me.txtTrnIngress.BackColor = System.Drawing.SystemColors.Window
        Me.txtTrnIngress.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTrnIngress.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopTransAmenitiesBindingSource, "INGRESS_LT", True))
        Me.txtTrnIngress.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrnIngress.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTrnIngress.Location = New System.Drawing.Point(375, 128)
        Me.txtTrnIngress.MaxLength = 5
        Me.txtTrnIngress.Name = "txtTrnIngress"
        Me.txtTrnIngress.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTrnIngress.Size = New System.Drawing.Size(54, 20)
        Me.txtTrnIngress.TabIndex = 65
        '
        'cbxRstrcPrk
        '
        Me.cbxRstrcPrk.BackColor = System.Drawing.Color.Transparent
        Me.cbxRstrcPrk.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxRstrcPrk.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblStopTransAmenitiesBindingSource, "RESTRICTIVE_PK", True))
        Me.cbxRstrcPrk.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxRstrcPrk.ForeColor = System.Drawing.Color.DimGray
        Me.cbxRstrcPrk.Location = New System.Drawing.Point(150, 168)
        Me.cbxRstrcPrk.Name = "cbxRstrcPrk"
        Me.cbxRstrcPrk.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxRstrcPrk.Size = New System.Drawing.Size(17, 17)
        Me.cbxRstrcPrk.TabIndex = 64
        Me.cbxRstrcPrk.Text = "Check3"
        Me.cbxRstrcPrk.UseVisualStyleBackColor = False
        '
        'cbxTurnout
        '
        Me.cbxTurnout.BackColor = System.Drawing.Color.Transparent
        Me.cbxTurnout.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxTurnout.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblStopTransAmenitiesBindingSource, "TURNOUT", True))
        Me.cbxTurnout.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxTurnout.ForeColor = System.Drawing.Color.DimGray
        Me.cbxTurnout.Location = New System.Drawing.Point(151, 94)
        Me.cbxTurnout.Name = "cbxTurnout"
        Me.cbxTurnout.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxTurnout.Size = New System.Drawing.Size(17, 17)
        Me.cbxTurnout.TabIndex = 63
        Me.cbxTurnout.Text = "Check2"
        Me.cbxTurnout.UseVisualStyleBackColor = False
        '
        'cbxBusPad
        '
        Me.cbxBusPad.BackColor = System.Drawing.Color.Transparent
        Me.cbxBusPad.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxBusPad.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblStopTransAmenitiesBindingSource, "BUS_PAD", True))
        Me.cbxBusPad.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxBusPad.ForeColor = System.Drawing.Color.DimGray
        Me.cbxBusPad.Location = New System.Drawing.Point(152, 27)
        Me.cbxBusPad.Name = "cbxBusPad"
        Me.cbxBusPad.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxBusPad.Size = New System.Drawing.Size(17, 17)
        Me.cbxBusPad.TabIndex = 62
        Me.cbxBusPad.UseVisualStyleBackColor = False
        '
        'txtTrnWidth
        '
        Me.txtTrnWidth.AcceptsReturn = True
        Me.txtTrnWidth.BackColor = System.Drawing.SystemColors.Window
        Me.txtTrnWidth.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTrnWidth.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopTransAmenitiesBindingSource, "TURNOUT_WIDTH", True))
        Me.txtTrnWidth.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrnWidth.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTrnWidth.Location = New System.Drawing.Point(769, 128)
        Me.txtTrnWidth.MaxLength = 5
        Me.txtTrnWidth.Name = "txtTrnWidth"
        Me.txtTrnWidth.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTrnWidth.Size = New System.Drawing.Size(54, 20)
        Me.txtTrnWidth.TabIndex = 58
        '
        '_Label1_26
        '
        Me._Label1_26.AutoSize = True
        Me._Label1_26.BackColor = System.Drawing.Color.Transparent
        Me._Label1_26.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_26.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_26.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_26.Location = New System.Drawing.Point(70, 249)
        Me._Label1_26.Name = "_Label1_26"
        Me._Label1_26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_26.Size = New System.Drawing.Size(70, 15)
        Me._Label1_26.TabIndex = 89
        Me._Label1_26.Text = " REMARKS:"
        Me._Label1_26.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_25
        '
        Me._Label1_25.AutoSize = True
        Me._Label1_25.BackColor = System.Drawing.Color.Transparent
        Me._Label1_25.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_25.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_25.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_25.Location = New System.Drawing.Point(320, 203)
        Me._Label1_25.Name = "_Label1_25"
        Me._Label1_25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_25.Size = New System.Drawing.Size(52, 15)
        Me._Label1_25.TabIndex = 88
        Me._Label1_25.Text = "LENGTH"
        Me._Label1_25.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_14
        '
        Me._Label1_14.AutoSize = True
        Me._Label1_14.BackColor = System.Drawing.Color.Transparent
        Me._Label1_14.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_14.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_14.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_14.Location = New System.Drawing.Point(590, 131)
        Me._Label1_14.Name = "_Label1_14"
        Me._Label1_14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_14.Size = New System.Drawing.Size(53, 15)
        Me._Label1_14.TabIndex = 87
        Me._Label1_14.Text = "EGRESS"
        Me._Label1_14.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_24
        '
        Me._Label1_24.AutoSize = True
        Me._Label1_24.BackColor = System.Drawing.Color.Transparent
        Me._Label1_24.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_24.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_24.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_24.Location = New System.Drawing.Point(456, 130)
        Me._Label1_24.Name = "_Label1_24"
        Me._Label1_24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_24.Size = New System.Drawing.Size(56, 15)
        Me._Label1_24.TabIndex = 86
        Me._Label1_24.Text = "BUS BAY"
        Me._Label1_24.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_16
        '
        Me._Label1_16.AutoSize = True
        Me._Label1_16.BackColor = System.Drawing.Color.Transparent
        Me._Label1_16.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_16.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_16.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_16.Location = New System.Drawing.Point(317, 131)
        Me._Label1_16.Name = "_Label1_16"
        Me._Label1_16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_16.Size = New System.Drawing.Size(57, 15)
        Me._Label1_16.TabIndex = 85
        Me._Label1_16.Text = "INGRESS"
        Me._Label1_16.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_23
        '
        Me._Label1_23.AutoSize = True
        Me._Label1_23.BackColor = System.Drawing.Color.Transparent
        Me._Label1_23.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_23.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_23.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_23.Location = New System.Drawing.Point(435, 58)
        Me._Label1_23.Name = "_Label1_23"
        Me._Label1_23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_23.Size = New System.Drawing.Size(78, 15)
        Me._Label1_23.TabIndex = 84
        Me._Label1_23.Text = "PAD LENGTH"
        Me._Label1_23.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_20
        '
        Me._Label1_20.AutoSize = True
        Me._Label1_20.BackColor = System.Drawing.Color.Transparent
        Me._Label1_20.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_20.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_20.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_20.Location = New System.Drawing.Point(304, 59)
        Me._Label1_20.Name = "_Label1_20"
        Me._Label1_20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_20.Size = New System.Drawing.Size(71, 15)
        Me._Label1_20.TabIndex = 83
        Me._Label1_20.Text = "PAD WIDTH"
        Me._Label1_20.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_22
        '
        Me._Label1_22.AutoSize = True
        Me._Label1_22.BackColor = System.Drawing.Color.Transparent
        Me._Label1_22.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_22.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_22.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_22.Location = New System.Drawing.Point(109, 205)
        Me._Label1_22.Name = "_Label1_22"
        Me._Label1_22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_22.Size = New System.Drawing.Size(36, 15)
        Me._Label1_22.TabIndex = 82
        Me._Label1_22.Text = "TYPE"
        Me._Label1_22.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_13
        '
        Me._Label1_13.AutoSize = True
        Me._Label1_13.BackColor = System.Drawing.Color.Transparent
        Me._Label1_13.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_13.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_13.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_13.Location = New System.Drawing.Point(109, 133)
        Me._Label1_13.Name = "_Label1_13"
        Me._Label1_13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_13.Size = New System.Drawing.Size(36, 15)
        Me._Label1_13.TabIndex = 81
        Me._Label1_13.Text = "TYPE"
        Me._Label1_13.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_12
        '
        Me._Label1_12.AutoSize = True
        Me._Label1_12.BackColor = System.Drawing.Color.Transparent
        Me._Label1_12.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_12.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_12.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_12.Location = New System.Drawing.Point(109, 61)
        Me._Label1_12.Name = "_Label1_12"
        Me._Label1_12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_12.Size = New System.Drawing.Size(36, 15)
        Me._Label1_12.TabIndex = 80
        Me._Label1_12.Text = "TYPE"
        Me._Label1_12.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_10
        '
        Me._Label1_10.AutoSize = True
        Me._Label1_10.BackColor = System.Drawing.Color.Transparent
        Me._Label1_10.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_10.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_10.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_10.Location = New System.Drawing.Point(4, 168)
        Me._Label1_10.Name = "_Label1_10"
        Me._Label1_10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_10.Size = New System.Drawing.Size(140, 15)
        Me._Label1_10.TabIndex = 79
        Me._Label1_10.Text = " RESTRICTIVE PARKING:"
        Me._Label1_10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_4
        '
        Me._Label1_4.AutoSize = True
        Me._Label1_4.BackColor = System.Drawing.Color.Transparent
        Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_4.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_4.Location = New System.Drawing.Point(73, 94)
        Me._Label1_4.Name = "_Label1_4"
        Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_4.Size = New System.Drawing.Size(67, 15)
        Me._Label1_4.TabIndex = 78
        Me._Label1_4.Text = " TURNOUT:"
        Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_27
        '
        Me._Label1_27.AutoSize = True
        Me._Label1_27.BackColor = System.Drawing.Color.Transparent
        Me._Label1_27.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_27.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_27.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_27.Location = New System.Drawing.Point(79, 27)
        Me._Label1_27.Name = "_Label1_27"
        Me._Label1_27.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_27.Size = New System.Drawing.Size(63, 15)
        Me._Label1_27.TabIndex = 77
        Me._Label1_27.Text = " BUS PAD:"
        Me._Label1_27.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_60
        '
        Me._Label1_60.AutoSize = True
        Me._Label1_60.BackColor = System.Drawing.Color.Transparent
        Me._Label1_60.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_60.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_60.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_60.Location = New System.Drawing.Point(722, 131)
        Me._Label1_60.Name = "_Label1_60"
        Me._Label1_60.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_60.Size = New System.Drawing.Size(45, 15)
        Me._Label1_60.TabIndex = 76
        Me._Label1_60.Text = "WIDTH"
        Me._Label1_60.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'TabPage3
        '
        Me.TabPage3.AutoScroll = True
        Me.TabPage3.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage3.Controls.Add(Me.cmdSaveAmenity)
        Me.TabPage3.Controls.Add(Me.cbxPassSurvey)
        Me.TabPage3.Controls.Add(Me.txtPARemarks)
        Me.TabPage3.Controls.Add(Me.tdbPassAmen)
        Me.TabPage3.Controls.Add(Me.cmdRemAmen)
        Me.TabPage3.Controls.Add(Me.cmdAddAmen)
        Me.TabPage3.Controls.Add(Me._Label1_88)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(958, 505)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "PASSENGER AMENITIES"
        '
        'cmdSaveAmenity
        '
        Me.cmdSaveAmenity.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSaveAmenity.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSaveAmenity.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSaveAmenity.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSaveAmenity.Location = New System.Drawing.Point(758, 6)
        Me.cmdSaveAmenity.Name = "cmdSaveAmenity"
        Me.cmdSaveAmenity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSaveAmenity.Size = New System.Drawing.Size(197, 33)
        Me.cmdSaveAmenity.TabIndex = 107
        Me.cmdSaveAmenity.Text = "Save Passenger Amenities Rec"
        Me.cmdSaveAmenity.UseVisualStyleBackColor = False
        '
        'cbxPassSurvey
        '
        Me.cbxPassSurvey.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblBusStopInformationBindingSource, "PA_SURVEYED", True))
        Me.cbxPassSurvey.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxPassSurvey.ForeColor = System.Drawing.Color.DimGray
        Me.cbxPassSurvey.Location = New System.Drawing.Point(772, 99)
        Me.cbxPassSurvey.Name = "cbxPassSurvey"
        Me.cbxPassSurvey.Size = New System.Drawing.Size(92, 24)
        Me.cbxPassSurvey.TabIndex = 106
        Me.cbxPassSurvey.Text = "SURVYED"
        Me.cbxPassSurvey.UseVisualStyleBackColor = True
        '
        'txtPARemarks
        '
        Me.txtPARemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPARemarks.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblBusStopInformationBindingSource, "PA_REMARKS", True))
        Me.txtPARemarks.Location = New System.Drawing.Point(114, 334)
        Me.txtPARemarks.Multiline = True
        Me.txtPARemarks.Name = "txtPARemarks"
        Me.txtPARemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtPARemarks.Size = New System.Drawing.Size(634, 97)
        Me.txtPARemarks.TabIndex = 105
        '
        'tdbPassAmen
        '
        Me.tdbPassAmen.AllowUserToAddRows = False
        Me.tdbPassAmen.AllowUserToDeleteRows = False
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.Ivory
        Me.tdbPassAmen.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle10
        Me.tdbPassAmen.AutoGenerateColumns = False
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.tdbPassAmen.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.tdbPassAmen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.tdbPassAmen.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn2, Me.OCTAIDDataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.AMENITIESTYPEIDDataGridViewTextBoxColumn, Me.AMENITIESOWNERIDDataGridViewTextBoxColumn, Me.DataGridViewTextBoxColumn5, Me.TIMESURVDataGridViewTextBoxColumn, Me.DataGridViewCheckBoxColumn1})
        Me.tdbPassAmen.DataSource = Me.TblStopPsgrAmenitiesBindingSource
        Me.tdbPassAmen.Location = New System.Drawing.Point(46, 35)
        Me.tdbPassAmen.Name = "tdbPassAmen"
        Me.tdbPassAmen.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.tdbPassAmen.Size = New System.Drawing.Size(702, 275)
        Me.tdbPassAmen.TabIndex = 104
        '
        'IDDataGridViewTextBoxColumn2
        '
        Me.IDDataGridViewTextBoxColumn2.DataPropertyName = "ID"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.IDDataGridViewTextBoxColumn2.DefaultCellStyle = DataGridViewCellStyle12
        Me.IDDataGridViewTextBoxColumn2.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn2.Name = "IDDataGridViewTextBoxColumn2"
        Me.IDDataGridViewTextBoxColumn2.ReadOnly = True
        Me.IDDataGridViewTextBoxColumn2.Width = 50
        '
        'OCTAIDDataGridViewTextBoxColumn3
        '
        Me.OCTAIDDataGridViewTextBoxColumn3.DataPropertyName = "OCTA_ID"
        Me.OCTAIDDataGridViewTextBoxColumn3.HeaderText = "OCTA_ID"
        Me.OCTAIDDataGridViewTextBoxColumn3.Name = "OCTAIDDataGridViewTextBoxColumn3"
        Me.OCTAIDDataGridViewTextBoxColumn3.Visible = False
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "NUM"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn4.DefaultCellStyle = DataGridViewCellStyle13
        Me.DataGridViewTextBoxColumn4.HeaderText = "NUM"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 50
        '
        'AMENITIESTYPEIDDataGridViewTextBoxColumn
        '
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn.DataPropertyName = "AMENITIES_TYPE_ID"
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn.DataSource = Me.AMENITIESTYPECODEBindingSource
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn.DisplayMember = "DESCRIPTION"
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn.HeaderText = "TYPE"
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn.Name = "AMENITIESTYPEIDDataGridViewTextBoxColumn"
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn.ValueMember = "ID"
        Me.AMENITIESTYPEIDDataGridViewTextBoxColumn.Width = 125
        '
        'AMENITIESTYPECODEBindingSource
        '
        Me.AMENITIESTYPECODEBindingSource.DataMember = "AMENITIES_TYPE_CODE"
        Me.AMENITIESTYPECODEBindingSource.DataSource = Me.DsAmenityType
        '
        'DsAmenityType
        '
        Me.DsAmenityType.DataSetName = "dsAmenityType"
        Me.DsAmenityType.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'AMENITIESOWNERIDDataGridViewTextBoxColumn
        '
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn.DataPropertyName = "AMENITIES_OWNER_ID"
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn.DataSource = Me.AMENITIESOWNERCODEBindingSource
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn.DisplayMember = "DESCRIPTION"
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn.HeaderText = "OWNER"
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn.Name = "AMENITIESOWNERIDDataGridViewTextBoxColumn"
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn.ValueMember = "ID"
        Me.AMENITIESOWNERIDDataGridViewTextBoxColumn.Width = 225
        '
        'AMENITIESOWNERCODEBindingSource
        '
        Me.AMENITIESOWNERCODEBindingSource.DataMember = "AMENITIES_OWNER_CODE"
        Me.AMENITIESOWNERCODEBindingSource.DataSource = Me.DsAmentityOwner
        '
        'DsAmentityOwner
        '
        Me.DsAmentityOwner.DataSetName = "dsAmentityOwner"
        Me.DsAmentityOwner.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "DATE_SURV"
        DataGridViewCellStyle14.Format = "d"
        DataGridViewCellStyle14.NullValue = Nothing
        Me.DataGridViewTextBoxColumn5.DefaultCellStyle = DataGridViewCellStyle14
        Me.DataGridViewTextBoxColumn5.HeaderText = "DATE SURVEYED"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'TIMESURVDataGridViewTextBoxColumn
        '
        Me.TIMESURVDataGridViewTextBoxColumn.DataPropertyName = "TIME_SURV"
        DataGridViewCellStyle15.Format = "t"
        DataGridViewCellStyle15.NullValue = Nothing
        Me.TIMESURVDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle15
        Me.TIMESURVDataGridViewTextBoxColumn.HeaderText = "TIME SURVEYED"
        Me.TIMESURVDataGridViewTextBoxColumn.Name = "TIMESURVDataGridViewTextBoxColumn"
        '
        'DataGridViewCheckBoxColumn1
        '
        Me.DataGridViewCheckBoxColumn1.DataPropertyName = "SURVEYED"
        Me.DataGridViewCheckBoxColumn1.HeaderText = "SURVEYED"
        Me.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1"
        Me.DataGridViewCheckBoxColumn1.Visible = False
        '
        'TblStopPsgrAmenitiesBindingSource
        '
        Me.TblStopPsgrAmenitiesBindingSource.DataMember = "tblStopPsgrAmenities"
        Me.TblStopPsgrAmenitiesBindingSource.DataSource = Me.DsPassAmenities
        '
        'DsPassAmenities
        '
        Me.DsPassAmenities.DataSetName = "dsPassAmenities"
        Me.DsPassAmenities.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmdRemAmen
        '
        Me.cmdRemAmen.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemAmen.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRemAmen.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRemAmen.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRemAmen.Location = New System.Drawing.Point(772, 269)
        Me.cmdRemAmen.Name = "cmdRemAmen"
        Me.cmdRemAmen.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRemAmen.Size = New System.Drawing.Size(105, 40)
        Me.cmdRemAmen.TabIndex = 102
        Me.cmdRemAmen.Text = "Remove Amenity"
        Me.cmdRemAmen.UseVisualStyleBackColor = False
        '
        'cmdAddAmen
        '
        Me.cmdAddAmen.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddAmen.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddAmen.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddAmen.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddAmen.Location = New System.Drawing.Point(772, 223)
        Me.cmdAddAmen.Name = "cmdAddAmen"
        Me.cmdAddAmen.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAddAmen.Size = New System.Drawing.Size(105, 40)
        Me.cmdAddAmen.TabIndex = 101
        Me.cmdAddAmen.Text = "Add Amenity"
        Me.cmdAddAmen.UseVisualStyleBackColor = False
        '
        '_Label1_88
        '
        Me._Label1_88.AutoSize = True
        Me._Label1_88.BackColor = System.Drawing.Color.Transparent
        Me._Label1_88.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_88.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_88.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_88.Location = New System.Drawing.Point(43, 334)
        Me._Label1_88.Name = "_Label1_88"
        Me._Label1_88.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_88.Size = New System.Drawing.Size(70, 15)
        Me._Label1_88.TabIndex = 103
        Me._Label1_88.Text = " REMARKS "
        '
        'TabPage4
        '
        Me.TabPage4.AutoScroll = True
        Me.TabPage4.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage4.Controls.Add(Me.OCTA_IDTextBox1)
        Me.TabPage4.Controls.Add(Me.cmdSaveSignCassRecord)
        Me.TabPage4.Controls.Add(Me.fraCassetteSurvey)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(958, 505)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "HARDWARE"
        '
        'OCTA_IDTextBox1
        '
        Me.OCTA_IDTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblSignCassetteBindingSource, "OCTA_ID", True))
        Me.OCTA_IDTextBox1.Location = New System.Drawing.Point(111, 18)
        Me.OCTA_IDTextBox1.Name = "OCTA_IDTextBox1"
        Me.OCTA_IDTextBox1.Size = New System.Drawing.Size(100, 23)
        Me.OCTA_IDTextBox1.TabIndex = 102
        Me.OCTA_IDTextBox1.Visible = False
        '
        'TblSignCassetteBindingSource
        '
        Me.TblSignCassetteBindingSource.DataMember = "tblSignCassette"
        Me.TblSignCassetteBindingSource.DataSource = Me.DsSignCassetteHardware
        '
        'DsSignCassetteHardware
        '
        Me.DsSignCassetteHardware.DataSetName = "dsSignCassetteHardware"
        Me.DsSignCassetteHardware.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmdSaveSignCassRecord
        '
        Me.cmdSaveSignCassRecord.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSaveSignCassRecord.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSaveSignCassRecord.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSaveSignCassRecord.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSaveSignCassRecord.Location = New System.Drawing.Point(758, 3)
        Me.cmdSaveSignCassRecord.Name = "cmdSaveSignCassRecord"
        Me.cmdSaveSignCassRecord.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSaveSignCassRecord.Size = New System.Drawing.Size(197, 33)
        Me.cmdSaveSignCassRecord.TabIndex = 100
        Me.cmdSaveSignCassRecord.Text = "Save Sign/Cass Record"
        Me.cmdSaveSignCassRecord.UseVisualStyleBackColor = False
        '
        'fraCassetteSurvey
        '
        Me.fraCassetteSurvey.BackColor = System.Drawing.Color.Transparent
        Me.fraCassetteSurvey.Controls.Add(Me.Frame3)
        Me.fraCassetteSurvey.Controls.Add(Me.cbxReplacePermenent)
        Me.fraCassetteSurvey.Controls.Add(Me.cbxUpcomingChange)
        Me.fraCassetteSurvey.Controls.Add(Me.Frame2)
        Me.fraCassetteSurvey.Controls.Add(Me.Frame1)
        Me.fraCassetteSurvey.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraCassetteSurvey.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraCassetteSurvey.Location = New System.Drawing.Point(51, 52)
        Me.fraCassetteSurvey.Name = "fraCassetteSurvey"
        Me.fraCassetteSurvey.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraCassetteSurvey.Size = New System.Drawing.Size(857, 393)
        Me.fraCassetteSurvey.TabIndex = 99
        Me.fraCassetteSurvey.TabStop = False
        '
        'Frame3
        '
        Me.Frame3.BackColor = System.Drawing.Color.Transparent
        Me.Frame3.Controls.Add(Me.cbxPlaceSolar)
        Me.Frame3.Controls.Add(Me.cbxExistSolar)
        Me.Frame3.Controls.Add(Me.cbxSignSpecific)
        Me.Frame3.Controls.Add(Me.cbxCitySignage)
        Me.Frame3.Controls.Add(Me.txtCitySignage)
        Me.Frame3.Controls.Add(Me.txtSignSpecific)
        Me.Frame3.Controls.Add(Me.txtNumRouteDisplay)
        Me.Frame3.Controls.Add(Me.cboSPConfig)
        Me.Frame3.Controls.Add(Me.cboSCPostType)
        Me.Frame3.Controls.Add(Me.cboCasHardware)
        Me.Frame3.Controls.Add(Me.cboCasPosition)
        Me.Frame3.Controls.Add(Me._Label1_78)
        Me.Frame3.Controls.Add(Me._Label1_80)
        Me.Frame3.Controls.Add(Me._Label1_79)
        Me.Frame3.Controls.Add(Me._Label1_76)
        Me.Frame3.Controls.Add(Me._Label1_74)
        Me.Frame3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(16, 48)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(449, 329)
        Me.Frame3.TabIndex = 114
        Me.Frame3.TabStop = False
        '
        'cbxPlaceSolar
        '
        Me.cbxPlaceSolar.BackColor = System.Drawing.Color.Transparent
        Me.cbxPlaceSolar.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxPlaceSolar.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxPlaceSolar.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblSignCassetteBindingSource, "PLACE_LIGHT", True))
        Me.cbxPlaceSolar.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxPlaceSolar.ForeColor = System.Drawing.Color.DimGray
        Me.cbxPlaceSolar.Location = New System.Drawing.Point(88, 299)
        Me.cbxPlaceSolar.Name = "cbxPlaceSolar"
        Me.cbxPlaceSolar.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxPlaceSolar.Size = New System.Drawing.Size(138, 17)
        Me.cbxPlaceSolar.TabIndex = 128
        Me.cbxPlaceSolar.Text = "PLACE SOLAR LIGHT"
        Me.cbxPlaceSolar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxPlaceSolar.UseVisualStyleBackColor = False
        '
        'cbxExistSolar
        '
        Me.cbxExistSolar.BackColor = System.Drawing.Color.Transparent
        Me.cbxExistSolar.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxExistSolar.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxExistSolar.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblSignCassetteBindingSource, "SOLAR_LIGHT", True))
        Me.cbxExistSolar.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxExistSolar.ForeColor = System.Drawing.Color.DimGray
        Me.cbxExistSolar.Location = New System.Drawing.Point(74, 272)
        Me.cbxExistSolar.Name = "cbxExistSolar"
        Me.cbxExistSolar.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxExistSolar.Size = New System.Drawing.Size(152, 17)
        Me.cbxExistSolar.TabIndex = 127
        Me.cbxExistSolar.Text = "EXISTING SOLAR LIGHT"
        Me.cbxExistSolar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxExistSolar.UseVisualStyleBackColor = False
        '
        'cbxSignSpecific
        '
        Me.cbxSignSpecific.BackColor = System.Drawing.Color.Transparent
        Me.cbxSignSpecific.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxSignSpecific.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxSignSpecific.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblSignCassetteBindingSource, "LOC_SPECIFIC_SIGN", True))
        Me.cbxSignSpecific.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxSignSpecific.ForeColor = System.Drawing.Color.DimGray
        Me.cbxSignSpecific.Location = New System.Drawing.Point(65, 227)
        Me.cbxSignSpecific.Name = "cbxSignSpecific"
        Me.cbxSignSpecific.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxSignSpecific.Size = New System.Drawing.Size(161, 17)
        Me.cbxSignSpecific.TabIndex = 126
        Me.cbxSignSpecific.Text = "LOCATION SPECIFIC SIGN"
        Me.cbxSignSpecific.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxSignSpecific.UseVisualStyleBackColor = False
        '
        'cbxCitySignage
        '
        Me.cbxCitySignage.BackColor = System.Drawing.Color.Transparent
        Me.cbxCitySignage.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxCitySignage.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxCitySignage.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblSignCassetteBindingSource, "CITY_SIGNAGE", True))
        Me.cbxCitySignage.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxCitySignage.ForeColor = System.Drawing.Color.DimGray
        Me.cbxCitySignage.Location = New System.Drawing.Point(122, 195)
        Me.cbxCitySignage.Name = "cbxCitySignage"
        Me.cbxCitySignage.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxCitySignage.Size = New System.Drawing.Size(104, 17)
        Me.cbxCitySignage.TabIndex = 125
        Me.cbxCitySignage.Text = "CITY SIGNAGE"
        Me.cbxCitySignage.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxCitySignage.UseVisualStyleBackColor = False
        '
        'txtCitySignage
        '
        Me.txtCitySignage.AcceptsReturn = True
        Me.txtCitySignage.BackColor = System.Drawing.SystemColors.Window
        Me.txtCitySignage.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCitySignage.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblSignCassetteBindingSource, "CITY_SIGNAGE_DESC", True))
        Me.txtCitySignage.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCitySignage.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCitySignage.Location = New System.Drawing.Point(232, 192)
        Me.txtCitySignage.MaxLength = 50
        Me.txtCitySignage.Name = "txtCitySignage"
        Me.txtCitySignage.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCitySignage.Size = New System.Drawing.Size(209, 20)
        Me.txtCitySignage.TabIndex = 124
        '
        'txtSignSpecific
        '
        Me.txtSignSpecific.AcceptsReturn = True
        Me.txtSignSpecific.BackColor = System.Drawing.SystemColors.Window
        Me.txtSignSpecific.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSignSpecific.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSignSpecific.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblSignCassetteBindingSource, "LOC_SPECIFIC_SIGN_DESC", True))
        Me.txtSignSpecific.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSignSpecific.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSignSpecific.Location = New System.Drawing.Point(232, 224)
        Me.txtSignSpecific.MaxLength = 100
        Me.txtSignSpecific.Multiline = True
        Me.txtSignSpecific.Name = "txtSignSpecific"
        Me.txtSignSpecific.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSignSpecific.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtSignSpecific.Size = New System.Drawing.Size(209, 45)
        Me.txtSignSpecific.TabIndex = 123
        '
        'txtNumRouteDisplay
        '
        Me.txtNumRouteDisplay.AcceptsReturn = True
        Me.txtNumRouteDisplay.BackColor = System.Drawing.SystemColors.Window
        Me.txtNumRouteDisplay.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNumRouteDisplay.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblSignCassetteBindingSource, "NUM_ROUTE_DISPLAY", True))
        Me.txtNumRouteDisplay.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNumRouteDisplay.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNumRouteDisplay.Location = New System.Drawing.Point(232, 32)
        Me.txtNumRouteDisplay.MaxLength = 5
        Me.txtNumRouteDisplay.Name = "txtNumRouteDisplay"
        Me.txtNumRouteDisplay.ReadOnly = True
        Me.txtNumRouteDisplay.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNumRouteDisplay.Size = New System.Drawing.Size(57, 20)
        Me.txtNumRouteDisplay.TabIndex = 122
        '
        'cboSPConfig
        '
        Me.cboSPConfig.BackColor = System.Drawing.SystemColors.Window
        Me.cboSPConfig.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboSPConfig.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblSignCassetteBindingSource, "SIGN_POST_CONFIG_ID", True))
        Me.cboSPConfig.DataSource = Me.SIGNPOSTCONFIGCODEBindingSource
        Me.cboSPConfig.DisplayMember = "DESCRIPTION"
        Me.cboSPConfig.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSPConfig.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSPConfig.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboSPConfig.Location = New System.Drawing.Point(232, 64)
        Me.cboSPConfig.Name = "cboSPConfig"
        Me.cboSPConfig.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboSPConfig.Size = New System.Drawing.Size(209, 22)
        Me.cboSPConfig.TabIndex = 118
        Me.cboSPConfig.ValueMember = "ID"
        '
        'SIGNPOSTCONFIGCODEBindingSource
        '
        Me.SIGNPOSTCONFIGCODEBindingSource.DataMember = "SIGN_POST_CONFIG_CODE"
        Me.SIGNPOSTCONFIGCODEBindingSource.DataSource = Me.DsSignPostConfig
        '
        'DsSignPostConfig
        '
        Me.DsSignPostConfig.DataSetName = "dsSignPostConfig"
        Me.DsSignPostConfig.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboSCPostType
        '
        Me.cboSCPostType.BackColor = System.Drawing.SystemColors.Window
        Me.cboSCPostType.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboSCPostType.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblSignCassetteBindingSource, "SIGN_POST_TYPE_ID", True))
        Me.cboSCPostType.DataSource = Me.SIGNPOSTTYPECODEBindingSource
        Me.cboSCPostType.DisplayMember = "DESCRIPTION"
        Me.cboSCPostType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSCPostType.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSCPostType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboSCPostType.Location = New System.Drawing.Point(232, 96)
        Me.cboSCPostType.Name = "cboSCPostType"
        Me.cboSCPostType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboSCPostType.Size = New System.Drawing.Size(209, 22)
        Me.cboSCPostType.TabIndex = 117
        Me.cboSCPostType.ValueMember = "ID"
        '
        'SIGNPOSTTYPECODEBindingSource
        '
        Me.SIGNPOSTTYPECODEBindingSource.DataMember = "SIGN_POST_TYPE_CODE"
        Me.SIGNPOSTTYPECODEBindingSource.DataSource = Me.DsSignPostType
        '
        'DsSignPostType
        '
        Me.DsSignPostType.DataSetName = "dsSignPostType"
        Me.DsSignPostType.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboCasHardware
        '
        Me.cboCasHardware.BackColor = System.Drawing.SystemColors.Window
        Me.cboCasHardware.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboCasHardware.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblSignCassetteBindingSource, "CASS_HARDWARE_ID", True))
        Me.cboCasHardware.DataSource = Me.CASSETTETYPECODEBindingSource
        Me.cboCasHardware.DisplayMember = "DESCRIPTION"
        Me.cboCasHardware.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCasHardware.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCasHardware.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboCasHardware.Location = New System.Drawing.Point(232, 128)
        Me.cboCasHardware.Name = "cboCasHardware"
        Me.cboCasHardware.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboCasHardware.Size = New System.Drawing.Size(209, 22)
        Me.cboCasHardware.TabIndex = 116
        Me.cboCasHardware.ValueMember = "ID"
        '
        'CASSETTETYPECODEBindingSource
        '
        Me.CASSETTETYPECODEBindingSource.DataMember = "CASSETTE_TYPE_CODE"
        Me.CASSETTETYPECODEBindingSource.DataSource = Me.DsCassetteMountingHardware
        '
        'DsCassetteMountingHardware
        '
        Me.DsCassetteMountingHardware.DataSetName = "dsCassetteMountingHardware"
        Me.DsCassetteMountingHardware.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboCasPosition
        '
        Me.cboCasPosition.BackColor = System.Drawing.SystemColors.Window
        Me.cboCasPosition.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboCasPosition.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblSignCassetteBindingSource, "CASS_POSITION_ID", True))
        Me.cboCasPosition.DataSource = Me.CASSETTEPOSITIONCODEBindingSource
        Me.cboCasPosition.DisplayMember = "DESCRIPTION"
        Me.cboCasPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCasPosition.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCasPosition.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboCasPosition.Location = New System.Drawing.Point(232, 160)
        Me.cboCasPosition.Name = "cboCasPosition"
        Me.cboCasPosition.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboCasPosition.Size = New System.Drawing.Size(209, 22)
        Me.cboCasPosition.TabIndex = 115
        Me.cboCasPosition.ValueMember = "ID"
        '
        'CASSETTEPOSITIONCODEBindingSource
        '
        Me.CASSETTEPOSITIONCODEBindingSource.DataMember = "CASSETTE_POSITION_CODE"
        Me.CASSETTEPOSITIONCODEBindingSource.DataSource = Me.DsCassetteMountingPosition
        '
        'DsCassetteMountingPosition
        '
        Me.DsCassetteMountingPosition.DataSetName = "dsCassetteMountingPosition"
        Me.DsCassetteMountingPosition.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        '_Label1_78
        '
        Me._Label1_78.AutoSize = True
        Me._Label1_78.BackColor = System.Drawing.Color.Transparent
        Me._Label1_78.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_78.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_78.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_78.Location = New System.Drawing.Point(26, 130)
        Me._Label1_78.Name = "_Label1_78"
        Me._Label1_78.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_78.Size = New System.Drawing.Size(200, 15)
        Me._Label1_78.TabIndex = 134
        Me._Label1_78.Text = "CASSETTE MOUNTING HARDWARE"
        Me._Label1_78.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_80
        '
        Me._Label1_80.AutoSize = True
        Me._Label1_80.BackColor = System.Drawing.Color.Transparent
        Me._Label1_80.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_80.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_80.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_80.Location = New System.Drawing.Point(38, 66)
        Me._Label1_80.Name = "_Label1_80"
        Me._Label1_80.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_80.Size = New System.Drawing.Size(188, 15)
        Me._Label1_80.TabIndex = 133
        Me._Label1_80.Text = "SIGN and POST CONFIGURATION"
        Me._Label1_80.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_79
        '
        Me._Label1_79.AutoSize = True
        Me._Label1_79.BackColor = System.Drawing.Color.Transparent
        Me._Label1_79.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_79.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_79.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_79.Location = New System.Drawing.Point(155, 98)
        Me._Label1_79.Name = "_Label1_79"
        Me._Label1_79.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_79.Size = New System.Drawing.Size(71, 15)
        Me._Label1_79.TabIndex = 132
        Me._Label1_79.Text = "POST TYPE"
        Me._Label1_79.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_76
        '
        Me._Label1_76.AutoSize = True
        Me._Label1_76.BackColor = System.Drawing.Color.Transparent
        Me._Label1_76.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_76.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_76.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_76.Location = New System.Drawing.Point(37, 162)
        Me._Label1_76.Name = "_Label1_76"
        Me._Label1_76.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_76.Size = New System.Drawing.Size(189, 15)
        Me._Label1_76.TabIndex = 131
        Me._Label1_76.Text = "CASSETTE MOUNTING POSITION"
        Me._Label1_76.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_74
        '
        Me._Label1_74.AutoSize = True
        Me._Label1_74.BackColor = System.Drawing.Color.Transparent
        Me._Label1_74.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_74.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_74.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_74.Location = New System.Drawing.Point(137, 34)
        Me._Label1_74.Name = "_Label1_74"
        Me._Label1_74.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_74.Size = New System.Drawing.Size(89, 15)
        Me._Label1_74.TabIndex = 130
        Me._Label1_74.Text = "No. of ROUTES"
        Me._Label1_74.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cbxReplacePermenent
        '
        Me.cbxReplacePermenent.BackColor = System.Drawing.Color.Transparent
        Me.cbxReplacePermenent.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxReplacePermenent.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxReplacePermenent.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblSignCassetteBindingSource, "PERM_INSERT", True))
        Me.cbxReplacePermenent.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxReplacePermenent.ForeColor = System.Drawing.Color.DimGray
        Me.cbxReplacePermenent.Location = New System.Drawing.Point(280, 24)
        Me.cbxReplacePermenent.Name = "cbxReplacePermenent"
        Me.cbxReplacePermenent.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxReplacePermenent.Size = New System.Drawing.Size(185, 17)
        Me.cbxReplacePermenent.TabIndex = 113
        Me.cbxReplacePermenent.Text = "REPLACE PERMANENT INSERT"
        Me.cbxReplacePermenent.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxReplacePermenent.UseVisualStyleBackColor = False
        '
        'cbxUpcomingChange
        '
        Me.cbxUpcomingChange.BackColor = System.Drawing.Color.Transparent
        Me.cbxUpcomingChange.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxUpcomingChange.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxUpcomingChange.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblSignCassetteBindingSource, "UPCOMING_CHANGE", True))
        Me.cbxUpcomingChange.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxUpcomingChange.ForeColor = System.Drawing.Color.DimGray
        Me.cbxUpcomingChange.Location = New System.Drawing.Point(16, 24)
        Me.cbxUpcomingChange.Name = "cbxUpcomingChange"
        Me.cbxUpcomingChange.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxUpcomingChange.Size = New System.Drawing.Size(92, 17)
        Me.cbxUpcomingChange.TabIndex = 112
        Me.cbxUpcomingChange.Text = "UPCOMING CHANGE"
        Me.cbxUpcomingChange.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxUpcomingChange.UseVisualStyleBackColor = False
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.Color.Transparent
        Me.Frame2.Controls.Add(Me.txtDateIssued)
        Me.Frame2.Controls.Add(Me.txtIssuingAgency)
        Me.Frame2.Controls.Add(Me.txtPermitNo)
        Me.Frame2.Controls.Add(Me._Label1_82)
        Me.Frame2.Controls.Add(Me._Label1_72)
        Me.Frame2.Controls.Add(Me._Label1_53)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(480, 288)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(361, 99)
        Me.Frame2.TabIndex = 105
        Me.Frame2.TabStop = False
        '
        'txtDateIssued
        '
        Me.txtDateIssued.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblSignCassetteBindingSource, "ISSUED_DATE", True, System.Windows.Forms.DataSourceUpdateMode.OnValidation, Nothing, "d"))
        Me.txtDateIssued.Location = New System.Drawing.Point(272, 22)
        Me.txtDateIssued.Name = "txtDateIssued"
        Me.txtDateIssued.Size = New System.Drawing.Size(73, 20)
        Me.txtDateIssued.TabIndex = 112
        '
        'txtIssuingAgency
        '
        Me.txtIssuingAgency.AcceptsReturn = True
        Me.txtIssuingAgency.BackColor = System.Drawing.SystemColors.Window
        Me.txtIssuingAgency.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtIssuingAgency.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblSignCassetteBindingSource, "ISSUING_AGENCY", True))
        Me.txtIssuingAgency.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIssuingAgency.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtIssuingAgency.Location = New System.Drawing.Point(110, 59)
        Me.txtIssuingAgency.MaxLength = 25
        Me.txtIssuingAgency.Name = "txtIssuingAgency"
        Me.txtIssuingAgency.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtIssuingAgency.Size = New System.Drawing.Size(235, 20)
        Me.txtIssuingAgency.TabIndex = 107
        '
        'txtPermitNo
        '
        Me.txtPermitNo.AcceptsReturn = True
        Me.txtPermitNo.BackColor = System.Drawing.SystemColors.Window
        Me.txtPermitNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPermitNo.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblSignCassetteBindingSource, "PERMIT_NUM", True))
        Me.txtPermitNo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPermitNo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPermitNo.Location = New System.Drawing.Point(81, 24)
        Me.txtPermitNo.MaxLength = 50
        Me.txtPermitNo.Name = "txtPermitNo"
        Me.txtPermitNo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPermitNo.Size = New System.Drawing.Size(86, 20)
        Me.txtPermitNo.TabIndex = 106
        '
        '_Label1_82
        '
        Me._Label1_82.AutoSize = True
        Me._Label1_82.BackColor = System.Drawing.Color.Transparent
        Me._Label1_82.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_82.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_82.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_82.Location = New System.Drawing.Point(192, 24)
        Me._Label1_82.Name = "_Label1_82"
        Me._Label1_82.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_82.Size = New System.Drawing.Size(81, 15)
        Me._Label1_82.TabIndex = 111
        Me._Label1_82.Text = "DATE ISSUED"
        Me._Label1_82.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_72
        '
        Me._Label1_72.AutoSize = True
        Me._Label1_72.BackColor = System.Drawing.Color.Transparent
        Me._Label1_72.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_72.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_72.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_72.Location = New System.Drawing.Point(8, 62)
        Me._Label1_72.Name = "_Label1_72"
        Me._Label1_72.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_72.Size = New System.Drawing.Size(102, 15)
        Me._Label1_72.TabIndex = 110
        Me._Label1_72.Text = "ISSUING AGENCY"
        Me._Label1_72.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_53
        '
        Me._Label1_53.AutoSize = True
        Me._Label1_53.BackColor = System.Drawing.Color.Transparent
        Me._Label1_53.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_53.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_53.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_53.Location = New System.Drawing.Point(8, 27)
        Me._Label1_53.Name = "_Label1_53"
        Me._Label1_53.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_53.Size = New System.Drawing.Size(71, 15)
        Me._Label1_53.TabIndex = 109
        Me._Label1_53.Text = "PERMIT No."
        Me._Label1_53.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.txtRouteDisplay)
        Me.Frame1.Controls.Add(Me.txtCstRemarks)
        Me.Frame1.Controls.Add(Me._Label1_52)
        Me.Frame1.Controls.Add(Me._Label1_73)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(480, 48)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(361, 233)
        Me.Frame1.TabIndex = 100
        Me.Frame1.TabStop = False
        '
        'txtRouteDisplay
        '
        Me.txtRouteDisplay.AcceptsReturn = True
        Me.txtRouteDisplay.BackColor = System.Drawing.SystemColors.Window
        Me.txtRouteDisplay.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRouteDisplay.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRouteDisplay.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblSignCassetteBindingSource, "ROUTE_DISPLAY", True))
        Me.txtRouteDisplay.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRouteDisplay.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRouteDisplay.Location = New System.Drawing.Point(16, 40)
        Me.txtRouteDisplay.MaxLength = 0
        Me.txtRouteDisplay.Multiline = True
        Me.txtRouteDisplay.Name = "txtRouteDisplay"
        Me.txtRouteDisplay.ReadOnly = True
        Me.txtRouteDisplay.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRouteDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtRouteDisplay.Size = New System.Drawing.Size(329, 57)
        Me.txtRouteDisplay.TabIndex = 102
        '
        'txtCstRemarks
        '
        Me.txtCstRemarks.AcceptsReturn = True
        Me.txtCstRemarks.BackColor = System.Drawing.SystemColors.Window
        Me.txtCstRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCstRemarks.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCstRemarks.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblSignCassetteBindingSource, "REMARKS", True))
        Me.txtCstRemarks.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCstRemarks.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCstRemarks.Location = New System.Drawing.Point(16, 128)
        Me.txtCstRemarks.MaxLength = 255
        Me.txtCstRemarks.Multiline = True
        Me.txtCstRemarks.Name = "txtCstRemarks"
        Me.txtCstRemarks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCstRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtCstRemarks.Size = New System.Drawing.Size(329, 89)
        Me.txtCstRemarks.TabIndex = 101
        '
        '_Label1_52
        '
        Me._Label1_52.AutoSize = True
        Me._Label1_52.BackColor = System.Drawing.Color.Transparent
        Me._Label1_52.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_52.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_52.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_52.Location = New System.Drawing.Point(16, 24)
        Me._Label1_52.Name = "_Label1_52"
        Me._Label1_52.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_52.Size = New System.Drawing.Size(228, 15)
        Me._Label1_52.TabIndex = 104
        Me._Label1_52.Text = "ROUTES DISPLAYED AT THIS BUS STOP"
        '
        '_Label1_73
        '
        Me._Label1_73.AutoSize = True
        Me._Label1_73.BackColor = System.Drawing.Color.Transparent
        Me._Label1_73.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_73.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_73.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_73.Location = New System.Drawing.Point(16, 112)
        Me._Label1_73.Name = "_Label1_73"
        Me._Label1_73.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_73.Size = New System.Drawing.Size(64, 15)
        Me._Label1_73.TabIndex = 103
        Me._Label1_73.Text = "REMARKS"
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage5.Controls.Add(Me.cmdRemoveFilter)
        Me.TabPage5.Controls.Add(Me.cmdSearch)
        Me.TabPage5.Controls.Add(Me.lblStopHistoryCount)
        Me.TabPage5.Controls.Add(Me.tdbStopHist)
        Me.TabPage5.Controls.Add(Me.cmdEdit)
        Me.TabPage5.Controls.Add(Me.cmdRemoveHistory)
        Me.TabPage5.Controls.Add(Me.cmdAddHistory)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(958, 505)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "STOP HISTORY"
        '
        'cmdRemoveFilter
        '
        Me.cmdRemoveFilter.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemoveFilter.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRemoveFilter.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRemoveFilter.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRemoveFilter.Location = New System.Drawing.Point(784, 461)
        Me.cmdRemoveFilter.Name = "cmdRemoveFilter"
        Me.cmdRemoveFilter.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRemoveFilter.Size = New System.Drawing.Size(129, 33)
        Me.cmdRemoveFilter.TabIndex = 236
        Me.cmdRemoveFilter.Text = "REMOVE FILTER"
        Me.cmdRemoveFilter.UseVisualStyleBackColor = False
        '
        'cmdSearch
        '
        Me.cmdSearch.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSearch.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSearch.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSearch.Location = New System.Drawing.Point(635, 461)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSearch.Size = New System.Drawing.Size(129, 33)
        Me.cmdSearch.TabIndex = 235
        Me.cmdSearch.Text = "SEARCH"
        Me.cmdSearch.UseVisualStyleBackColor = False
        '
        'lblStopHistoryCount
        '
        Me.lblStopHistoryCount.AutoSize = True
        Me.lblStopHistoryCount.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStopHistoryCount.ForeColor = System.Drawing.Color.DimGray
        Me.lblStopHistoryCount.Location = New System.Drawing.Point(12, 470)
        Me.lblStopHistoryCount.Name = "lblStopHistoryCount"
        Me.lblStopHistoryCount.Size = New System.Drawing.Size(120, 14)
        Me.lblStopHistoryCount.TabIndex = 232
        Me.lblStopHistoryCount.Text = "Number of Records: "
        '
        'tdbStopHist
        '
        Me.tdbStopHist.AllowUserToAddRows = False
        Me.tdbStopHist.AllowUserToDeleteRows = False
        DataGridViewCellStyle16.BackColor = System.Drawing.Color.Ivory
        Me.tdbStopHist.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle16
        Me.tdbStopHist.AutoGenerateColumns = False
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.tdbStopHist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle17
        Me.tdbStopHist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.tdbStopHist.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.DATEDataGridViewTextBoxColumn, Me.NAMEDataGridViewTextBoxColumn, Me.TYPEDataGridViewTextBoxColumn, Me.REMARKSDataGridViewTextBoxColumn, Me.WONUMDataGridViewTextBoxColumn, Me.cmdAttachments, Me.OCTAIDDataGridViewTextBoxColumn1})
        Me.tdbStopHist.DataSource = Me.TblStopHistoryBindingSource
        Me.tdbStopHist.Location = New System.Drawing.Point(3, 3)
        Me.tdbStopHist.Name = "tdbStopHist"
        Me.tdbStopHist.ReadOnly = True
        Me.tdbStopHist.RowHeadersVisible = False
        Me.tdbStopHist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.tdbStopHist.Size = New System.Drawing.Size(952, 452)
        Me.tdbStopHist.TabIndex = 231
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        Me.IDDataGridViewTextBoxColumn.ReadOnly = True
        Me.IDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.IDDataGridViewTextBoxColumn.Width = 5
        '
        'DATEDataGridViewTextBoxColumn
        '
        Me.DATEDataGridViewTextBoxColumn.DataPropertyName = "DATE"
        Me.DATEDataGridViewTextBoxColumn.HeaderText = "DATE"
        Me.DATEDataGridViewTextBoxColumn.Name = "DATEDataGridViewTextBoxColumn"
        Me.DATEDataGridViewTextBoxColumn.ReadOnly = True
        Me.DATEDataGridViewTextBoxColumn.Width = 85
        '
        'NAMEDataGridViewTextBoxColumn
        '
        Me.NAMEDataGridViewTextBoxColumn.DataPropertyName = "NAME"
        Me.NAMEDataGridViewTextBoxColumn.HeaderText = "EMPLOYEE"
        Me.NAMEDataGridViewTextBoxColumn.Name = "NAMEDataGridViewTextBoxColumn"
        Me.NAMEDataGridViewTextBoxColumn.ReadOnly = True
        Me.NAMEDataGridViewTextBoxColumn.Width = 160
        '
        'TYPEDataGridViewTextBoxColumn
        '
        Me.TYPEDataGridViewTextBoxColumn.DataPropertyName = "TYPE"
        Me.TYPEDataGridViewTextBoxColumn.HeaderText = "TYPE"
        Me.TYPEDataGridViewTextBoxColumn.Name = "TYPEDataGridViewTextBoxColumn"
        Me.TYPEDataGridViewTextBoxColumn.ReadOnly = True
        Me.TYPEDataGridViewTextBoxColumn.Width = 90
        '
        'REMARKSDataGridViewTextBoxColumn
        '
        Me.REMARKSDataGridViewTextBoxColumn.DataPropertyName = "REMARKS"
        Me.REMARKSDataGridViewTextBoxColumn.HeaderText = "REMARKS"
        Me.REMARKSDataGridViewTextBoxColumn.Name = "REMARKSDataGridViewTextBoxColumn"
        Me.REMARKSDataGridViewTextBoxColumn.ReadOnly = True
        Me.REMARKSDataGridViewTextBoxColumn.Width = 404
        '
        'WONUMDataGridViewTextBoxColumn
        '
        Me.WONUMDataGridViewTextBoxColumn.DataPropertyName = "WO_NUM"
        Me.WONUMDataGridViewTextBoxColumn.HeaderText = "WO"
        Me.WONUMDataGridViewTextBoxColumn.Name = "WONUMDataGridViewTextBoxColumn"
        Me.WONUMDataGridViewTextBoxColumn.ReadOnly = True
        Me.WONUMDataGridViewTextBoxColumn.Width = 85
        '
        'cmdAttachments
        '
        Me.cmdAttachments.DataPropertyName = "ButtonText"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.Color.Gray
        Me.cmdAttachments.DefaultCellStyle = DataGridViewCellStyle18
        Me.cmdAttachments.HeaderText = "ATTACHMENTS"
        Me.cmdAttachments.Name = "cmdAttachments"
        Me.cmdAttachments.ReadOnly = True
        Me.cmdAttachments.Text = ""
        Me.cmdAttachments.Width = 115
        '
        'OCTAIDDataGridViewTextBoxColumn1
        '
        Me.OCTAIDDataGridViewTextBoxColumn1.DataPropertyName = "OCTA_ID"
        Me.OCTAIDDataGridViewTextBoxColumn1.HeaderText = "OCTA_ID"
        Me.OCTAIDDataGridViewTextBoxColumn1.Name = "OCTAIDDataGridViewTextBoxColumn1"
        Me.OCTAIDDataGridViewTextBoxColumn1.ReadOnly = True
        Me.OCTAIDDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.OCTAIDDataGridViewTextBoxColumn1.Width = 5
        '
        'TblStopHistoryBindingSource
        '
        Me.TblStopHistoryBindingSource.DataMember = "tblStopHistory"
        Me.TblStopHistoryBindingSource.DataSource = Me.DsStopHistory
        '
        'DsStopHistory
        '
        Me.DsStopHistory.DataSetName = "dsStopHistory"
        Me.DsStopHistory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdEdit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdEdit.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdEdit.Location = New System.Drawing.Point(337, 461)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdEdit.Size = New System.Drawing.Size(129, 33)
        Me.cmdEdit.TabIndex = 230
        Me.cmdEdit.Text = "EDIT RECORD"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'cmdRemoveHistory
        '
        Me.cmdRemoveHistory.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemoveHistory.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRemoveHistory.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRemoveHistory.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRemoveHistory.Location = New System.Drawing.Point(486, 461)
        Me.cmdRemoveHistory.Name = "cmdRemoveHistory"
        Me.cmdRemoveHistory.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRemoveHistory.Size = New System.Drawing.Size(129, 33)
        Me.cmdRemoveHistory.TabIndex = 229
        Me.cmdRemoveHistory.Text = "REMOVE  RECORD"
        Me.cmdRemoveHistory.UseVisualStyleBackColor = False
        '
        'cmdAddHistory
        '
        Me.cmdAddHistory.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddHistory.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddHistory.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddHistory.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddHistory.Location = New System.Drawing.Point(188, 461)
        Me.cmdAddHistory.Name = "cmdAddHistory"
        Me.cmdAddHistory.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAddHistory.Size = New System.Drawing.Size(129, 33)
        Me.cmdAddHistory.TabIndex = 228
        Me.cmdAddHistory.Text = "ADD RECORD"
        Me.cmdAddHistory.UseVisualStyleBackColor = False
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage7.Controls.Add(Me.fraWorkOrders)
        Me.TabPage7.Location = New System.Drawing.Point(4, 25)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(958, 505)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "WORK ORDERS"
        '
        'fraWorkOrders
        '
        Me.fraWorkOrders.BackColor = System.Drawing.Color.Transparent
        Me.fraWorkOrders.Controls.Add(Me.cmdWOEmailAll)
        Me.fraWorkOrders.Controls.Add(Me.cmdWOPrintAll)
        Me.fraWorkOrders.Controls.Add(Me.cmdWOEmailCurrent)
        Me.fraWorkOrders.Controls.Add(Me.cmWOPrintCurrent)
        Me.fraWorkOrders.Controls.Add(Me.txtWOItems)
        Me.fraWorkOrders.Controls.Add(Me.cmdSaveWORecord)
        Me.fraWorkOrders.Controls.Add(Me.WOGrid1)
        Me.fraWorkOrders.Controls.Add(Me.cmdPrintEmailAll)
        Me.fraWorkOrders.Controls.Add(Me.cbxWO_Dig_AlertWO)
        Me.fraWorkOrders.Controls.Add(Me.cmdClearAllWO)
        Me.fraWorkOrders.Controls.Add(Me.txtWorkOrdersWO)
        Me.fraWorkOrders.Controls.Add(Me.cmdPrvWorkWO)
        Me.fraWorkOrders.Controls.Add(Me.cboPriorityWO)
        Me.fraWorkOrders.Controls.Add(Me._Label1_32)
        Me.fraWorkOrders.Controls.Add(Me._Label1_29)
        Me.fraWorkOrders.Controls.Add(Me._Label1_28)
        Me.fraWorkOrders.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraWorkOrders.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraWorkOrders.Location = New System.Drawing.Point(52, 15)
        Me.fraWorkOrders.Name = "fraWorkOrders"
        Me.fraWorkOrders.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraWorkOrders.Size = New System.Drawing.Size(873, 479)
        Me.fraWorkOrders.TabIndex = 231
        Me.fraWorkOrders.TabStop = False
        '
        'cmdWOEmailAll
        '
        Me.cmdWOEmailAll.Location = New System.Drawing.Point(651, 53)
        Me.cmdWOEmailAll.Name = "cmdWOEmailAll"
        Me.cmdWOEmailAll.Size = New System.Drawing.Size(90, 26)
        Me.cmdWOEmailAll.TabIndex = 267
        Me.cmdWOEmailAll.Text = "Email All"
        Me.cmdWOEmailAll.UseVisualStyleBackColor = True
        '
        'cmdWOPrintAll
        '
        Me.cmdWOPrintAll.Location = New System.Drawing.Point(651, 17)
        Me.cmdWOPrintAll.Name = "cmdWOPrintAll"
        Me.cmdWOPrintAll.Size = New System.Drawing.Size(90, 26)
        Me.cmdWOPrintAll.TabIndex = 266
        Me.cmdWOPrintAll.Text = "Print All"
        Me.cmdWOPrintAll.UseVisualStyleBackColor = True
        '
        'cmdWOEmailCurrent
        '
        Me.cmdWOEmailCurrent.Location = New System.Drawing.Point(555, 53)
        Me.cmdWOEmailCurrent.Name = "cmdWOEmailCurrent"
        Me.cmdWOEmailCurrent.Size = New System.Drawing.Size(90, 26)
        Me.cmdWOEmailCurrent.TabIndex = 265
        Me.cmdWOEmailCurrent.Text = "Email Current"
        Me.cmdWOEmailCurrent.UseVisualStyleBackColor = True
        '
        'cmWOPrintCurrent
        '
        Me.cmWOPrintCurrent.Location = New System.Drawing.Point(555, 17)
        Me.cmWOPrintCurrent.Name = "cmWOPrintCurrent"
        Me.cmWOPrintCurrent.Size = New System.Drawing.Size(90, 26)
        Me.cmWOPrintCurrent.TabIndex = 264
        Me.cmWOPrintCurrent.Text = "Print Current"
        Me.cmWOPrintCurrent.UseVisualStyleBackColor = True
        '
        'txtWOItems
        '
        Me.txtWOItems.Location = New System.Drawing.Point(443, 413)
        Me.txtWOItems.Name = "txtWOItems"
        Me.txtWOItems.Size = New System.Drawing.Size(45, 20)
        Me.txtWOItems.TabIndex = 263
        Me.txtWOItems.Visible = False
        '
        'cmdSaveWORecord
        '
        Me.cmdSaveWORecord.Location = New System.Drawing.Point(445, 19)
        Me.cmdSaveWORecord.Name = "cmdSaveWORecord"
        Me.cmdSaveWORecord.Size = New System.Drawing.Size(90, 26)
        Me.cmdSaveWORecord.TabIndex = 262
        Me.cmdSaveWORecord.Text = "Save WO"
        Me.cmdSaveWORecord.UseVisualStyleBackColor = True
        '
        'WOGrid1
        '
        Me.WOGrid1.AllowUserToAddRows = False
        Me.WOGrid1.AllowUserToDeleteRows = False
        Me.WOGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.WOGrid1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.cboSelectedItem, Me.cboDESCRIPTION, Me.cboID})
        Me.WOGrid1.Location = New System.Drawing.Point(25, 19)
        Me.WOGrid1.Name = "WOGrid1"
        Me.WOGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.WOGrid1.Size = New System.Drawing.Size(393, 454)
        Me.WOGrid1.TabIndex = 261
        '
        'cboSelectedItem
        '
        Me.cboSelectedItem.HeaderText = ""
        Me.cboSelectedItem.Name = "cboSelectedItem"
        Me.cboSelectedItem.Width = 30
        '
        'cboDESCRIPTION
        '
        Me.cboDESCRIPTION.HeaderText = "ITEM DESCRIPTION"
        Me.cboDESCRIPTION.Name = "cboDESCRIPTION"
        Me.cboDESCRIPTION.Width = 300
        '
        'cboID
        '
        Me.cboID.HeaderText = "ID"
        Me.cboID.MinimumWidth = 2
        Me.cboID.Name = "cboID"
        Me.cboID.Visible = False
        Me.cboID.Width = 2
        '
        'cmdPrintEmailAll
        '
        Me.cmdPrintEmailAll.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPrintEmailAll.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPrintEmailAll.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPrintEmailAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPrintEmailAll.Location = New System.Drawing.Point(747, 53)
        Me.cmdPrintEmailAll.Name = "cmdPrintEmailAll"
        Me.cmdPrintEmailAll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPrintEmailAll.Size = New System.Drawing.Size(90, 26)
        Me.cmdPrintEmailAll.TabIndex = 260
        Me.cmdPrintEmailAll.Text = "Print && Email All"
        Me.cmdPrintEmailAll.UseVisualStyleBackColor = False
        '
        'cbxWO_Dig_AlertWO
        '
        Me.cbxWO_Dig_AlertWO.BackColor = System.Drawing.Color.Transparent
        Me.cbxWO_Dig_AlertWO.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxWO_Dig_AlertWO.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxWO_Dig_AlertWO.ForeColor = System.Drawing.Color.DimGray
        Me.cbxWO_Dig_AlertWO.Location = New System.Drawing.Point(847, 102)
        Me.cbxWO_Dig_AlertWO.Name = "cbxWO_Dig_AlertWO"
        Me.cbxWO_Dig_AlertWO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxWO_Dig_AlertWO.Size = New System.Drawing.Size(22, 14)
        Me.cbxWO_Dig_AlertWO.TabIndex = 239
        Me.cbxWO_Dig_AlertWO.UseVisualStyleBackColor = False
        '
        'cmdClearAllWO
        '
        Me.cmdClearAllWO.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClearAllWO.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClearAllWO.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClearAllWO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClearAllWO.Location = New System.Drawing.Point(445, 53)
        Me.cmdClearAllWO.Name = "cmdClearAllWO"
        Me.cmdClearAllWO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClearAllWO.Size = New System.Drawing.Size(90, 27)
        Me.cmdClearAllWO.TabIndex = 236
        Me.cmdClearAllWO.Text = "Clear Items"
        Me.cmdClearAllWO.UseVisualStyleBackColor = False
        '
        'txtWorkOrdersWO
        '
        Me.txtWorkOrdersWO.AcceptsReturn = True
        Me.txtWorkOrdersWO.BackColor = System.Drawing.SystemColors.Window
        Me.txtWorkOrdersWO.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtWorkOrdersWO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtWorkOrdersWO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWorkOrdersWO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWorkOrdersWO.Location = New System.Drawing.Point(443, 158)
        Me.txtWorkOrdersWO.MaxLength = 0
        Me.txtWorkOrdersWO.Multiline = True
        Me.txtWorkOrdersWO.Name = "txtWorkOrdersWO"
        Me.txtWorkOrdersWO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtWorkOrdersWO.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtWorkOrdersWO.Size = New System.Drawing.Size(415, 233)
        Me.txtWorkOrdersWO.TabIndex = 234
        '
        'cmdPrvWorkWO
        '
        Me.cmdPrvWorkWO.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPrvWorkWO.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPrvWorkWO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPrvWorkWO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPrvWorkWO.Location = New System.Drawing.Point(747, 17)
        Me.cmdPrvWorkWO.Name = "cmdPrvWorkWO"
        Me.cmdPrvWorkWO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPrvWorkWO.Size = New System.Drawing.Size(90, 26)
        Me.cmdPrvWorkWO.TabIndex = 233
        Me.cmdPrvWorkWO.Text = " Preview"
        Me.cmdPrvWorkWO.UseVisualStyleBackColor = False
        '
        'cboPriorityWO
        '
        Me.cboPriorityWO.BackColor = System.Drawing.SystemColors.Window
        Me.cboPriorityWO.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboPriorityWO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPriorityWO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboPriorityWO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboPriorityWO.Location = New System.Drawing.Point(504, 99)
        Me.cboPriorityWO.Name = "cboPriorityWO"
        Me.cboPriorityWO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboPriorityWO.Size = New System.Drawing.Size(271, 22)
        Me.cboPriorityWO.TabIndex = 231
        '
        '_Label1_32
        '
        Me._Label1_32.AutoSize = True
        Me._Label1_32.BackColor = System.Drawing.Color.Transparent
        Me._Label1_32.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_32.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_32.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_32.Location = New System.Drawing.Point(440, 141)
        Me._Label1_32.Name = "_Label1_32"
        Me._Label1_32.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_32.Size = New System.Drawing.Size(167, 15)
        Me._Label1_32.TabIndex = 241
        Me._Label1_32.Text = "ENTER WORK DESCRIPTION:"
        '
        '_Label1_29
        '
        Me._Label1_29.AutoSize = True
        Me._Label1_29.BackColor = System.Drawing.Color.Transparent
        Me._Label1_29.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_29.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_29.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_29.Location = New System.Drawing.Point(777, 102)
        Me._Label1_29.Name = "_Label1_29"
        Me._Label1_29.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_29.Size = New System.Drawing.Size(69, 15)
        Me._Label1_29.TabIndex = 240
        Me._Label1_29.Text = "DIG-ALERT:"
        '
        '_Label1_28
        '
        Me._Label1_28.AutoSize = True
        Me._Label1_28.BackColor = System.Drawing.Color.Transparent
        Me._Label1_28.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_28.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_28.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_28.Location = New System.Drawing.Point(442, 102)
        Me._Label1_28.Name = "_Label1_28"
        Me._Label1_28.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_28.Size = New System.Drawing.Size(62, 15)
        Me._Label1_28.TabIndex = 235
        Me._Label1_28.Text = "PRIORITY:"
        '
        'TabPage8
        '
        Me.TabPage8.AutoScroll = True
        Me.TabPage8.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage8.Controls.Add(Me.bnPictures)
        Me.TabPage8.Controls.Add(Me.imgStopPic)
        Me.TabPage8.Controls.Add(Me.fraStopPictures)
        Me.TabPage8.Location = New System.Drawing.Point(4, 25)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(958, 505)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "STOP PICTURES"
        '
        'bnPictures
        '
        Me.bnPictures.AddNewItem = Me.BindingNavigatorAddNewItem1
        Me.bnPictures.BindingSource = Me.TblStopImagesBindingSource
        Me.bnPictures.CountItem = Me.BindingNavigatorCountItem2
        Me.bnPictures.DeleteItem = Me.BindingNavigatorDeleteItem1
        Me.bnPictures.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem2, Me.BindingNavigatorMovePreviousItem2, Me.BindingNavigatorSeparator6, Me.BindingNavigatorPositionItem2, Me.BindingNavigatorCountItem2, Me.BindingNavigatorSeparator7, Me.BindingNavigatorMoveNextItem2, Me.BindingNavigatorMoveLastItem2, Me.BindingNavigatorSeparator8, Me.cmdZoom, Me.ToolStripSeparator3, Me.BindingNavigatorAddNewItem1, Me.toolStripSeparator, Me.BindingNavigatorDeleteItem1, Me.toolStripSeparator1, Me.SaveToolStripButton, Me.ToolStripSeparator2, Me.CancelToolStripButton})
        Me.bnPictures.Location = New System.Drawing.Point(0, 0)
        Me.bnPictures.MoveFirstItem = Me.BindingNavigatorMoveFirstItem2
        Me.bnPictures.MoveLastItem = Me.BindingNavigatorMoveLastItem2
        Me.bnPictures.MoveNextItem = Me.BindingNavigatorMoveNextItem2
        Me.bnPictures.MovePreviousItem = Me.BindingNavigatorMovePreviousItem2
        Me.bnPictures.Name = "bnPictures"
        Me.bnPictures.PositionItem = Me.BindingNavigatorPositionItem2
        Me.bnPictures.Size = New System.Drawing.Size(958, 25)
        Me.bnPictures.TabIndex = 263
        Me.bnPictures.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem1
        '
        Me.BindingNavigatorAddNewItem1.Image = CType(resources.GetObject("BindingNavigatorAddNewItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BindingNavigatorAddNewItem1.Name = "BindingNavigatorAddNewItem1"
        Me.BindingNavigatorAddNewItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem1.Size = New System.Drawing.Size(89, 22)
        Me.BindingNavigatorAddNewItem1.Text = "Add Picture"
        '
        'TblStopImagesBindingSource
        '
        Me.TblStopImagesBindingSource.DataMember = "tblStopImages"
        Me.TblStopImagesBindingSource.DataSource = Me.BusStopManagementDataSet2
        '
        'BusStopManagementDataSet2
        '
        Me.BusStopManagementDataSet2.DataSetName = "BusStopManagementDataSet2"
        Me.BusStopManagementDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem2
        '
        Me.BindingNavigatorCountItem2.Name = "BindingNavigatorCountItem2"
        Me.BindingNavigatorCountItem2.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem2.Text = "of {0}"
        Me.BindingNavigatorCountItem2.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem1
        '
        Me.BindingNavigatorDeleteItem1.Image = CType(resources.GetObject("BindingNavigatorDeleteItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BindingNavigatorDeleteItem1.Name = "BindingNavigatorDeleteItem1"
        Me.BindingNavigatorDeleteItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem1.Size = New System.Drawing.Size(100, 22)
        Me.BindingNavigatorDeleteItem1.Text = "Delete Picture"
        '
        'BindingNavigatorMoveFirstItem2
        '
        Me.BindingNavigatorMoveFirstItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem2.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem2.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem2.Name = "BindingNavigatorMoveFirstItem2"
        Me.BindingNavigatorMoveFirstItem2.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem2.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem2.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem2
        '
        Me.BindingNavigatorMovePreviousItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem2.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem2.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem2.Name = "BindingNavigatorMovePreviousItem2"
        Me.BindingNavigatorMovePreviousItem2.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem2.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem2.Text = "Move previous"
        '
        'BindingNavigatorSeparator6
        '
        Me.BindingNavigatorSeparator6.Name = "BindingNavigatorSeparator6"
        Me.BindingNavigatorSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem2
        '
        Me.BindingNavigatorPositionItem2.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem2.AutoSize = False
        Me.BindingNavigatorPositionItem2.Name = "BindingNavigatorPositionItem2"
        Me.BindingNavigatorPositionItem2.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem2.Text = "0"
        Me.BindingNavigatorPositionItem2.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator7
        '
        Me.BindingNavigatorSeparator7.Name = "BindingNavigatorSeparator7"
        Me.BindingNavigatorSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem2
        '
        Me.BindingNavigatorMoveNextItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem2.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem2.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem2.Name = "BindingNavigatorMoveNextItem2"
        Me.BindingNavigatorMoveNextItem2.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem2.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem2.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem2
        '
        Me.BindingNavigatorMoveLastItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem2.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem2.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem2.Name = "BindingNavigatorMoveLastItem2"
        Me.BindingNavigatorMoveLastItem2.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem2.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem2.Text = "Move last"
        '
        'BindingNavigatorSeparator8
        '
        Me.BindingNavigatorSeparator8.Name = "BindingNavigatorSeparator8"
        Me.BindingNavigatorSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'cmdZoom
        '
        Me.cmdZoom.Image = CType(resources.GetObject("cmdZoom.Image"), System.Drawing.Image)
        Me.cmdZoom.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdZoom.Name = "cmdZoom"
        Me.cmdZoom.Size = New System.Drawing.Size(59, 22)
        Me.cmdZoom.Text = "Zoom"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'toolStripSeparator
        '
        Me.toolStripSeparator.Name = "toolStripSeparator"
        Me.toolStripSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'SaveToolStripButton
        '
        Me.SaveToolStripButton.Image = CType(resources.GetObject("SaveToolStripButton.Image"), System.Drawing.Image)
        Me.SaveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton.Name = "SaveToolStripButton"
        Me.SaveToolStripButton.Size = New System.Drawing.Size(51, 22)
        Me.SaveToolStripButton.Text = "&Save"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'CancelToolStripButton
        '
        Me.CancelToolStripButton.Image = CType(resources.GetObject("CancelToolStripButton.Image"), System.Drawing.Image)
        Me.CancelToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CancelToolStripButton.Name = "CancelToolStripButton"
        Me.CancelToolStripButton.Size = New System.Drawing.Size(63, 22)
        Me.CancelToolStripButton.Text = "Cancel"
        '
        'imgStopPic
        '
        Me.imgStopPic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.imgStopPic.Cursor = System.Windows.Forms.Cursors.Default
        Me.imgStopPic.Location = New System.Drawing.Point(19, 51)
        Me.imgStopPic.Name = "imgStopPic"
        Me.imgStopPic.Size = New System.Drawing.Size(636, 440)
        Me.imgStopPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgStopPic.TabIndex = 188
        Me.imgStopPic.TabStop = False
        '
        'fraStopPictures
        '
        Me.fraStopPictures.BackColor = System.Drawing.Color.Transparent
        Me.fraStopPictures.Controls.Add(IDLabel)
        Me.fraStopPictures.Controls.Add(Me.IDTextBox)
        Me.fraStopPictures.Controls.Add(Me.Label1)
        Me.fraStopPictures.Controls.Add(Me.txtPictureOCTA_ID)
        Me.fraStopPictures.Controls.Add(Me.txtPicDate)
        Me.fraStopPictures.Controls.Add(SANZ_IDLabel)
        Me.fraStopPictures.Controls.Add(Me.SANZ_IDTextBox)
        Me.fraStopPictures.Controls.Add(Me.txtPicNotes)
        Me.fraStopPictures.Controls.Add(Me.txtPicPath)
        Me.fraStopPictures.Controls.Add(Me.cboTakenBy)
        Me.fraStopPictures.Controls.Add(Me.cmdPicsNeeded)
        Me.fraStopPictures.Controls.Add(Me.cmdPicBrowse)
        Me.fraStopPictures.Controls.Add(Me.cbxStopPhotoNeeded)
        Me.fraStopPictures.Controls.Add(Me._Label1_58)
        Me.fraStopPictures.Controls.Add(Me._Label1_56)
        Me.fraStopPictures.Controls.Add(Me._Label1_54)
        Me.fraStopPictures.Controls.Add(Me._Label1_47)
        Me.fraStopPictures.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraStopPictures.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraStopPictures.Location = New System.Drawing.Point(670, 42)
        Me.fraStopPictures.Name = "fraStopPictures"
        Me.fraStopPictures.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraStopPictures.Size = New System.Drawing.Size(266, 449)
        Me.fraStopPictures.TabIndex = 189
        Me.fraStopPictures.TabStop = False
        '
        'IDTextBox
        '
        Me.IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopImagesBindingSource, "ID", True))
        Me.IDTextBox.Enabled = False
        Me.IDTextBox.ForeColor = System.Drawing.Color.DimGray
        Me.IDTextBox.Location = New System.Drawing.Point(101, 129)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.ReadOnly = True
        Me.IDTextBox.Size = New System.Drawing.Size(137, 20)
        Me.IDTextBox.TabIndex = 267
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(18, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(83, 15)
        Me.Label1.TabIndex = 266
        Me.Label1.Text = "BUS STOP ID:"
        '
        'txtPictureOCTA_ID
        '
        Me.txtPictureOCTA_ID.BackColor = System.Drawing.SystemColors.Control
        Me.txtPictureOCTA_ID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopImagesBindingSource, "OCTA_ID", True))
        Me.txtPictureOCTA_ID.ForeColor = System.Drawing.Color.DimGray
        Me.txtPictureOCTA_ID.Location = New System.Drawing.Point(101, 19)
        Me.txtPictureOCTA_ID.Name = "txtPictureOCTA_ID"
        Me.txtPictureOCTA_ID.ReadOnly = True
        Me.txtPictureOCTA_ID.Size = New System.Drawing.Size(137, 20)
        Me.txtPictureOCTA_ID.TabIndex = 263
        '
        'txtPicDate
        '
        Me.txtPicDate.CustomFormat = ""
        Me.txtPicDate.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblStopImagesBindingSource, "IMAGE_DATE", True))
        Me.txtPicDate.Location = New System.Drawing.Point(101, 47)
        Me.txtPicDate.Name = "txtPicDate"
        Me.txtPicDate.Size = New System.Drawing.Size(137, 20)
        Me.txtPicDate.TabIndex = 264
        '
        'SANZ_IDTextBox
        '
        Me.SANZ_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopImagesBindingSource, "SANZ_ID", True))
        Me.SANZ_IDTextBox.ForeColor = System.Drawing.Color.DimGray
        Me.SANZ_IDTextBox.Location = New System.Drawing.Point(101, 103)
        Me.SANZ_IDTextBox.Name = "SANZ_IDTextBox"
        Me.SANZ_IDTextBox.ReadOnly = True
        Me.SANZ_IDTextBox.Size = New System.Drawing.Size(137, 20)
        Me.SANZ_IDTextBox.TabIndex = 262
        '
        'txtPicNotes
        '
        Me.txtPicNotes.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPicNotes.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopImagesBindingSource, "IMAGE_DESC", True))
        Me.txtPicNotes.ForeColor = System.Drawing.Color.DimGray
        Me.txtPicNotes.Location = New System.Drawing.Point(15, 315)
        Me.txtPicNotes.Multiline = True
        Me.txtPicNotes.Name = "txtPicNotes"
        Me.txtPicNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtPicNotes.Size = New System.Drawing.Size(223, 83)
        Me.txtPicNotes.TabIndex = 196
        '
        'txtPicPath
        '
        Me.txtPicPath.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtPicPath.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopImagesBindingSource, "IMAGE_PATH", True))
        Me.txtPicPath.ForeColor = System.Drawing.Color.DimGray
        Me.txtPicPath.Location = New System.Drawing.Point(15, 187)
        Me.txtPicPath.Multiline = True
        Me.txtPicPath.Name = "txtPicPath"
        Me.txtPicPath.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtPicPath.Size = New System.Drawing.Size(223, 56)
        Me.txtPicPath.TabIndex = 196
        '
        'cboTakenBy
        '
        Me.cboTakenBy.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopImagesBindingSource, "IMAGE_BY", True))
        Me.cboTakenBy.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblStopImagesBindingSource, "IMAGE_BY", True))
        Me.cboTakenBy.DataSource = Me.TblStaffBindingSource2
        Me.cboTakenBy.DisplayMember = "NAME"
        Me.cboTakenBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTakenBy.ForeColor = System.Drawing.Color.DimGray
        Me.cboTakenBy.FormattingEnabled = True
        Me.cboTakenBy.Location = New System.Drawing.Point(101, 75)
        Me.cboTakenBy.Name = "cboTakenBy"
        Me.cboTakenBy.Size = New System.Drawing.Size(137, 22)
        Me.cboTakenBy.TabIndex = 196
        Me.cboTakenBy.ValueMember = "NAME"
        '
        'TblStaffBindingSource2
        '
        Me.TblStaffBindingSource2.DataMember = "tblStaff"
        Me.TblStaffBindingSource2.DataSource = Me.BusStopManagementDataSet
        '
        'BusStopManagementDataSet
        '
        Me.BusStopManagementDataSet.DataSetName = "BusStopManagementDataSet"
        Me.BusStopManagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmdPicsNeeded
        '
        Me.cmdPicsNeeded.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPicsNeeded.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPicsNeeded.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPicsNeeded.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPicsNeeded.Location = New System.Drawing.Point(79, 404)
        Me.cmdPicsNeeded.Name = "cmdPicsNeeded"
        Me.cmdPicsNeeded.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPicsNeeded.Size = New System.Drawing.Size(121, 25)
        Me.cmdPicsNeeded.TabIndex = 261
        Me.cmdPicsNeeded.Text = "NEED PICTURE(S)"
        Me.cmdPicsNeeded.UseVisualStyleBackColor = False
        '
        'cmdPicBrowse
        '
        Me.cmdPicBrowse.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPicBrowse.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPicBrowse.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPicBrowse.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPicBrowse.Location = New System.Drawing.Point(15, 249)
        Me.cmdPicBrowse.Name = "cmdPicBrowse"
        Me.cmdPicBrowse.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPicBrowse.Size = New System.Drawing.Size(225, 28)
        Me.cmdPicBrowse.TabIndex = 176
        Me.cmdPicBrowse.Text = "Change Image Path for selected picture...."
        Me.cmdPicBrowse.UseVisualStyleBackColor = False
        '
        'cbxStopPhotoNeeded
        '
        Me.cbxStopPhotoNeeded.BackColor = System.Drawing.Color.Transparent
        Me.cbxStopPhotoNeeded.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxStopPhotoNeeded.Enabled = False
        Me.cbxStopPhotoNeeded.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxStopPhotoNeeded.ForeColor = System.Drawing.Color.DimGray
        Me.cbxStopPhotoNeeded.Location = New System.Drawing.Point(62, 404)
        Me.cbxStopPhotoNeeded.Name = "cbxStopPhotoNeeded"
        Me.cbxStopPhotoNeeded.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxStopPhotoNeeded.Size = New System.Drawing.Size(25, 25)
        Me.cbxStopPhotoNeeded.TabIndex = 175
        Me.cbxStopPhotoNeeded.UseVisualStyleBackColor = False
        '
        '_Label1_58
        '
        Me._Label1_58.AutoSize = True
        Me._Label1_58.BackColor = System.Drawing.Color.Transparent
        Me._Label1_58.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_58.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_58.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_58.Location = New System.Drawing.Point(12, 170)
        Me._Label1_58.Name = "_Label1_58"
        Me._Label1_58.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_58.Size = New System.Drawing.Size(78, 15)
        Me._Label1_58.TabIndex = 182
        Me._Label1_58.Text = "IMAGE PATH:"
        '
        '_Label1_56
        '
        Me._Label1_56.AutoSize = True
        Me._Label1_56.BackColor = System.Drawing.Color.Transparent
        Me._Label1_56.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_56.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_56.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_56.Location = New System.Drawing.Point(37, 78)
        Me._Label1_56.Name = "_Label1_56"
        Me._Label1_56.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_56.Size = New System.Drawing.Size(64, 15)
        Me._Label1_56.TabIndex = 180
        Me._Label1_56.Text = "TAKEN BY:"
        '
        '_Label1_54
        '
        Me._Label1_54.AutoSize = True
        Me._Label1_54.BackColor = System.Drawing.Color.Transparent
        Me._Label1_54.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_54.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_54.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_54.Location = New System.Drawing.Point(22, 50)
        Me._Label1_54.Name = "_Label1_54"
        Me._Label1_54.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_54.Size = New System.Drawing.Size(79, 15)
        Me._Label1_54.TabIndex = 179
        Me._Label1_54.Text = "DATE TAKEN:"
        '
        '_Label1_47
        '
        Me._Label1_47.AutoSize = True
        Me._Label1_47.BackColor = System.Drawing.Color.Transparent
        Me._Label1_47.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_47.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_47.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_47.Location = New System.Drawing.Point(14, 297)
        Me._Label1_47.Name = "_Label1_47"
        Me._Label1_47.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_47.Size = New System.Drawing.Size(49, 15)
        Me._Label1_47.TabIndex = 178
        Me._Label1_47.Text = "NOTES:"
        Me._Label1_47.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage9.Controls.Add(Me.cmdViewActiveList)
        Me.TabPage9.Controls.Add(Me.GroupBox1)
        Me.TabPage9.Controls.Add(Me.cmdSaveGPS)
        Me.TabPage9.Controls.Add(Me.cbxGPSRequired)
        Me.TabPage9.Controls.Add(Me.fraGPS2)
        Me.TabPage9.Location = New System.Drawing.Point(4, 25)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(958, 505)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "GPS/TIMEPOINT"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtTPRemovalDesc)
        Me.GroupBox1.Controls.Add(Me.lblTPRemoved)
        Me.GroupBox1.Controls.Add(Me.cmdDeleteTP)
        Me.GroupBox1.Controls.Add(Me.cmdUpdateRemoveTP)
        Me.GroupBox1.Controls.Add(Me.dtpEndDate)
        Me.GroupBox1.Controls.Add(Me.dtpStartDate)
        Me.GroupBox1.Controls.Add(Me.cmdAddTP)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtBusStopStatusID)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.DimGray
        Me.GroupBox1.Location = New System.Drawing.Point(131, 318)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(611, 139)
        Me.GroupBox1.TabIndex = 228
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "REMOVE TIME POINT"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(335, 68)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(87, 15)
        Me.Label4.TabIndex = 293
        Me.Label4.Text = "DESCRIPTION:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtTPRemovalDesc
        '
        Me.txtTPRemovalDesc.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.QryBusStopStatusBindingSource, "Description", True))
        Me.txtTPRemovalDesc.Enabled = False
        Me.txtTPRemovalDesc.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTPRemovalDesc.Location = New System.Drawing.Point(424, 64)
        Me.txtTPRemovalDesc.Multiline = True
        Me.txtTPRemovalDesc.Name = "txtTPRemovalDesc"
        Me.txtTPRemovalDesc.Size = New System.Drawing.Size(165, 55)
        Me.txtTPRemovalDesc.TabIndex = 292
        '
        'QryBusStopStatusBindingSource
        '
        Me.QryBusStopStatusBindingSource.DataMember = "qryBusStopStatus"
        Me.QryBusStopStatusBindingSource.DataSource = Me.DsBusStopStatus
        '
        'DsBusStopStatus
        '
        Me.DsBusStopStatus.DataSetName = "dsBusStopStatus"
        Me.DsBusStopStatus.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblTPRemoved
        '
        Me.lblTPRemoved.AutoSize = True
        Me.lblTPRemoved.ForeColor = System.Drawing.Color.Red
        Me.lblTPRemoved.Location = New System.Drawing.Point(6, 29)
        Me.lblTPRemoved.Name = "lblTPRemoved"
        Me.lblTPRemoved.Size = New System.Drawing.Size(241, 16)
        Me.lblTPRemoved.TabIndex = 291
        Me.lblTPRemoved.Text = "This Time Point has been removed from OTP."
        Me.lblTPRemoved.Visible = False
        '
        'cmdDeleteTP
        '
        Me.cmdDeleteTP.Enabled = False
        Me.cmdDeleteTP.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDeleteTP.ForeColor = System.Drawing.Color.Black
        Me.cmdDeleteTP.Location = New System.Drawing.Point(510, 29)
        Me.cmdDeleteTP.Name = "cmdDeleteTP"
        Me.cmdDeleteTP.Size = New System.Drawing.Size(80, 25)
        Me.cmdDeleteTP.TabIndex = 289
        Me.cmdDeleteTP.Text = "Delete"
        Me.cmdDeleteTP.UseVisualStyleBackColor = True
        '
        'cmdUpdateRemoveTP
        '
        Me.cmdUpdateRemoveTP.Enabled = False
        Me.cmdUpdateRemoveTP.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdUpdateRemoveTP.ForeColor = System.Drawing.Color.Black
        Me.cmdUpdateRemoveTP.Location = New System.Drawing.Point(338, 30)
        Me.cmdUpdateRemoveTP.Name = "cmdUpdateRemoveTP"
        Me.cmdUpdateRemoveTP.Size = New System.Drawing.Size(80, 25)
        Me.cmdUpdateRemoveTP.TabIndex = 229
        Me.cmdUpdateRemoveTP.Text = "Update Time Point Record"
        Me.cmdUpdateRemoveTP.UseVisualStyleBackColor = True
        '
        'dtpEndDate
        '
        Me.dtpEndDate.CalendarTrailingForeColor = System.Drawing.Color.DimGray
        Me.dtpEndDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.QryBusStopStatusBindingSource, "EndDate", True))
        Me.dtpEndDate.Enabled = False
        Me.dtpEndDate.Location = New System.Drawing.Point(98, 98)
        Me.dtpEndDate.MinDate = New Date(2020, 2, 13, 0, 0, 0, 0)
        Me.dtpEndDate.Name = "dtpEndDate"
        Me.dtpEndDate.Size = New System.Drawing.Size(200, 22)
        Me.dtpEndDate.TabIndex = 288
        '
        'dtpStartDate
        '
        Me.dtpStartDate.CalendarTrailingForeColor = System.Drawing.Color.DimGray
        Me.dtpStartDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.QryBusStopStatusBindingSource, "StartDate", True))
        Me.dtpStartDate.Enabled = False
        Me.dtpStartDate.Location = New System.Drawing.Point(98, 64)
        Me.dtpStartDate.Name = "dtpStartDate"
        Me.dtpStartDate.Size = New System.Drawing.Size(200, 22)
        Me.dtpStartDate.TabIndex = 287
        '
        'cmdAddTP
        '
        Me.cmdAddTP.Enabled = False
        Me.cmdAddTP.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddTP.ForeColor = System.Drawing.Color.Black
        Me.cmdAddTP.Location = New System.Drawing.Point(424, 29)
        Me.cmdAddTP.Name = "cmdAddTP"
        Me.cmdAddTP.Size = New System.Drawing.Size(80, 25)
        Me.cmdAddTP.TabIndex = 286
        Me.cmdAddTP.Text = "Add"
        Me.cmdAddTP.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(13, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(79, 15)
        Me.Label2.TabIndex = 285
        Me.Label2.Text = "START DATE:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(27, 100)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(65, 15)
        Me.Label3.TabIndex = 283
        Me.Label3.Text = "END DATE:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtBusStopStatusID
        '
        Me.txtBusStopStatusID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.QryBusStopStatusBindingSource, "ID", True))
        Me.txtBusStopStatusID.Location = New System.Drawing.Point(490, 32)
        Me.txtBusStopStatusID.Name = "txtBusStopStatusID"
        Me.txtBusStopStatusID.Size = New System.Drawing.Size(10, 22)
        Me.txtBusStopStatusID.TabIndex = 290
        '
        'cmdSaveGPS
        '
        Me.cmdSaveGPS.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSaveGPS.Location = New System.Drawing.Point(545, 29)
        Me.cmdSaveGPS.Name = "cmdSaveGPS"
        Me.cmdSaveGPS.Size = New System.Drawing.Size(197, 33)
        Me.cmdSaveGPS.TabIndex = 227
        Me.cmdSaveGPS.Text = "Save GPS Record"
        Me.cmdSaveGPS.UseVisualStyleBackColor = True
        '
        'cbxGPSRequired
        '
        Me.cbxGPSRequired.BackColor = System.Drawing.Color.Transparent
        Me.cbxGPSRequired.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxGPSRequired.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblStopCoordBindingSource, "GPS_REQUIRED", True))
        Me.cbxGPSRequired.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxGPSRequired.ForeColor = System.Drawing.Color.DimGray
        Me.cbxGPSRequired.Location = New System.Drawing.Point(131, 37)
        Me.cbxGPSRequired.Name = "cbxGPSRequired"
        Me.cbxGPSRequired.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxGPSRequired.Size = New System.Drawing.Size(130, 17)
        Me.cbxGPSRequired.TabIndex = 226
        Me.cbxGPSRequired.Text = "NEEDS GPS SURVEY"
        Me.cbxGPSRequired.UseVisualStyleBackColor = False
        '
        'TblStopCoordBindingSource
        '
        Me.TblStopCoordBindingSource.DataMember = "tblStopCoord"
        Me.TblStopCoordBindingSource.DataSource = Me.DsGPS
        '
        'DsGPS
        '
        Me.DsGPS.DataSetName = "dsGPS"
        Me.DsGPS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'fraGPS2
        '
        Me.fraGPS2.BackColor = System.Drawing.Color.Transparent
        Me.fraGPS2.Controls.Add(Me.dtGPSDate)
        Me.fraGPS2.Controls.Add(Me.txtLat)
        Me.fraGPS2.Controls.Add(Me.txtLon)
        Me.fraGPS2.Controls.Add(Me.txtGPS_OCTA_ID)
        Me.fraGPS2.Controls.Add(Me.txtElev)
        Me.fraGPS2.Controls.Add(Me.txtYCoord)
        Me.fraGPS2.Controls.Add(Me.txtXCoord)
        Me.fraGPS2.Controls.Add(Me._LATITUDE_9)
        Me.fraGPS2.Controls.Add(Me._Label1_8)
        Me.fraGPS2.Controls.Add(Me._Label1_59)
        Me.fraGPS2.Controls.Add(Me._Label1_46)
        Me.fraGPS2.Controls.Add(Me._Label1_45)
        Me.fraGPS2.Controls.Add(Me._Label1_43)
        Me.fraGPS2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraGPS2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraGPS2.Location = New System.Drawing.Point(131, 60)
        Me.fraGPS2.Name = "fraGPS2"
        Me.fraGPS2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraGPS2.Size = New System.Drawing.Size(610, 229)
        Me.fraGPS2.TabIndex = 225
        Me.fraGPS2.TabStop = False
        '
        'dtGPSDate
        '
        Me.dtGPSDate.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblStopCoordBindingSource, "DATE_GPS", True, System.Windows.Forms.DataSourceUpdateMode.OnValidation, Nothing, "d"))
        Me.dtGPSDate.Location = New System.Drawing.Point(410, 146)
        Me.dtGPSDate.Name = "dtGPSDate"
        Me.dtGPSDate.Size = New System.Drawing.Size(113, 20)
        Me.dtGPSDate.TabIndex = 281
        '
        'txtLat
        '
        Me.txtLat.AcceptsReturn = True
        Me.txtLat.BackColor = System.Drawing.SystemColors.Window
        Me.txtLat.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLat.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopCoordBindingSource, "LAT", True, System.Windows.Forms.DataSourceUpdateMode.OnValidation, "0"))
        Me.txtLat.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLat.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLat.Location = New System.Drawing.Point(410, 36)
        Me.txtLat.MaxLength = 0
        Me.txtLat.Name = "txtLat"
        Me.txtLat.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLat.Size = New System.Drawing.Size(113, 20)
        Me.txtLat.TabIndex = 278
        '
        'txtLon
        '
        Me.txtLon.AcceptsReturn = True
        Me.txtLon.BackColor = System.Drawing.SystemColors.Window
        Me.txtLon.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLon.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopCoordBindingSource, "LON", True, System.Windows.Forms.DataSourceUpdateMode.OnValidation, "0"))
        Me.txtLon.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLon.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLon.Location = New System.Drawing.Point(410, 92)
        Me.txtLon.MaxLength = 0
        Me.txtLon.Name = "txtLon"
        Me.txtLon.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLon.Size = New System.Drawing.Size(113, 20)
        Me.txtLon.TabIndex = 277
        '
        'txtGPS_OCTA_ID
        '
        Me.txtGPS_OCTA_ID.AcceptsReturn = True
        Me.txtGPS_OCTA_ID.BackColor = System.Drawing.SystemColors.Window
        Me.txtGPS_OCTA_ID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtGPS_OCTA_ID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopCoordBindingSource, "OCTA_ID", True))
        Me.txtGPS_OCTA_ID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGPS_OCTA_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtGPS_OCTA_ID.Location = New System.Drawing.Point(410, 172)
        Me.txtGPS_OCTA_ID.MaxLength = 0
        Me.txtGPS_OCTA_ID.Name = "txtGPS_OCTA_ID"
        Me.txtGPS_OCTA_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtGPS_OCTA_ID.Size = New System.Drawing.Size(113, 20)
        Me.txtGPS_OCTA_ID.TabIndex = 217
        Me.txtGPS_OCTA_ID.Visible = False
        '
        'txtElev
        '
        Me.txtElev.AcceptsReturn = True
        Me.txtElev.BackColor = System.Drawing.SystemColors.Window
        Me.txtElev.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtElev.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopCoordBindingSource, "ELEVATION", True, System.Windows.Forms.DataSourceUpdateMode.OnValidation, "0"))
        Me.txtElev.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtElev.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtElev.Location = New System.Drawing.Point(152, 148)
        Me.txtElev.MaxLength = 0
        Me.txtElev.Name = "txtElev"
        Me.txtElev.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtElev.Size = New System.Drawing.Size(113, 20)
        Me.txtElev.TabIndex = 216
        '
        'txtYCoord
        '
        Me.txtYCoord.AcceptsReturn = True
        Me.txtYCoord.BackColor = System.Drawing.SystemColors.Window
        Me.txtYCoord.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtYCoord.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopCoordBindingSource, "NORTHING", True, System.Windows.Forms.DataSourceUpdateMode.OnValidation, "0"))
        Me.txtYCoord.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYCoord.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtYCoord.Location = New System.Drawing.Point(152, 92)
        Me.txtYCoord.MaxLength = 0
        Me.txtYCoord.Name = "txtYCoord"
        Me.txtYCoord.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtYCoord.Size = New System.Drawing.Size(113, 20)
        Me.txtYCoord.TabIndex = 215
        '
        'txtXCoord
        '
        Me.txtXCoord.AcceptsReturn = True
        Me.txtXCoord.BackColor = System.Drawing.SystemColors.Window
        Me.txtXCoord.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtXCoord.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopCoordBindingSource, "EASTING", True, System.Windows.Forms.DataSourceUpdateMode.OnValidation, "0"))
        Me.txtXCoord.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtXCoord.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtXCoord.Location = New System.Drawing.Point(152, 36)
        Me.txtXCoord.MaxLength = 0
        Me.txtXCoord.Name = "txtXCoord"
        Me.txtXCoord.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtXCoord.Size = New System.Drawing.Size(113, 20)
        Me.txtXCoord.TabIndex = 214
        '
        '_LATITUDE_9
        '
        Me._LATITUDE_9.AutoSize = True
        Me._LATITUDE_9.BackColor = System.Drawing.Color.Transparent
        Me._LATITUDE_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._LATITUDE_9.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._LATITUDE_9.ForeColor = System.Drawing.Color.DimGray
        Me._LATITUDE_9.Location = New System.Drawing.Point(346, 39)
        Me._LATITUDE_9.Name = "_LATITUDE_9"
        Me._LATITUDE_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._LATITUDE_9.Size = New System.Drawing.Size(64, 15)
        Me._LATITUDE_9.TabIndex = 280
        Me._LATITUDE_9.Text = "LATITUDE:"
        Me._LATITUDE_9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_8
        '
        Me._Label1_8.AutoSize = True
        Me._Label1_8.BackColor = System.Drawing.Color.Transparent
        Me._Label1_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_8.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_8.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_8.Location = New System.Drawing.Point(337, 95)
        Me._Label1_8.Name = "_Label1_8"
        Me._Label1_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_8.Size = New System.Drawing.Size(75, 15)
        Me._Label1_8.TabIndex = 279
        Me._Label1_8.Text = "LONGITUDE:"
        Me._Label1_8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_59
        '
        Me._Label1_59.AutoSize = True
        Me._Label1_59.BackColor = System.Drawing.Color.Transparent
        Me._Label1_59.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_59.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_59.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_59.Location = New System.Drawing.Point(282, 151)
        Me._Label1_59.Name = "_Label1_59"
        Me._Label1_59.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_59.Size = New System.Drawing.Size(128, 15)
        Me._Label1_59.TabIndex = 223
        Me._Label1_59.Text = "DATE of GPS SURVEY:"
        Me._Label1_59.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_46
        '
        Me._Label1_46.AutoSize = True
        Me._Label1_46.BackColor = System.Drawing.Color.Transparent
        Me._Label1_46.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_46.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_46.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_46.Location = New System.Drawing.Point(81, 151)
        Me._Label1_46.Name = "_Label1_46"
        Me._Label1_46.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_46.Size = New System.Drawing.Size(72, 15)
        Me._Label1_46.TabIndex = 222
        Me._Label1_46.Text = "ELEVATION:"
        Me._Label1_46.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_45
        '
        Me._Label1_45.AutoSize = True
        Me._Label1_45.BackColor = System.Drawing.Color.Transparent
        Me._Label1_45.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_45.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_45.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_45.Location = New System.Drawing.Point(44, 95)
        Me._Label1_45.Name = "_Label1_45"
        Me._Label1_45.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_45.Size = New System.Drawing.Size(109, 15)
        Me._Label1_45.TabIndex = 221
        Me._Label1_45.Text = "Y - COORDINATES:"
        Me._Label1_45.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        '_Label1_43
        '
        Me._Label1_43.AutoSize = True
        Me._Label1_43.BackColor = System.Drawing.Color.Transparent
        Me._Label1_43.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_43.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_43.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_43.Location = New System.Drawing.Point(43, 39)
        Me._Label1_43.Name = "_Label1_43"
        Me._Label1_43.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_43.Size = New System.Drawing.Size(110, 15)
        Me._Label1_43.TabIndex = 220
        Me._Label1_43.Text = "X - COORDINATES:"
        Me._Label1_43.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'HISTORYTYPECODEBindingSource
        '
        Me.HISTORYTYPECODEBindingSource.DataMember = "HISTORY_TYPE_CODE"
        Me.HISTORYTYPECODEBindingSource.DataSource = Me.DsStopHistoryType
        '
        'DsStopHistoryType
        '
        Me.DsStopHistoryType.DataSetName = "dsStopHistoryType"
        Me.DsStopHistoryType.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ADASTATUSCODEBindingSource
        '
        Me.ADASTATUSCODEBindingSource.DataMember = "ADA_STATUS_CODE"
        Me.ADASTATUSCODEBindingSource.DataSource = Me.BusStopManagementDataSet5
        '
        'BusStopManagementDataSet5
        '
        Me.BusStopManagementDataSet5.DataSetName = "BusStopManagementDataSet5"
        Me.BusStopManagementDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblStaffBindingSource1
        '
        Me.TblStaffBindingSource1.DataMember = "tblStaff"
        Me.TblStaffBindingSource1.DataSource = Me.BusStopManagementDataSet
        '
        'bsPictures
        '
        Me.bsPictures.DataSource = Me.BusStopManagementDataSet2
        Me.bsPictures.Position = 0
        '
        'TblStopImagesTableAdapter
        '
        Me.TblStopImagesTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.tblStopImagesTableAdapter = Me.TblStopImagesTableAdapter
        Me.TableAdapterManager.UpdateOrder = BusStopManagement.BusStopManagementDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'bnBusStop
        '
        Me.bnBusStop.AddNewItem = Nothing
        Me.bnBusStop.BindingSource = Me.TblBusStopInformationBindingSource
        Me.bnBusStop.CountItem = Me.BindingNavigatorCountItem1
        Me.bnBusStop.DeleteItem = Nothing
        Me.bnBusStop.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem1, Me.BindingNavigatorMovePreviousItem1, Me.BindingNavigatorSeparator3, Me.BindingNavigatorPositionItem1, Me.BindingNavigatorCountItem1, Me.BindingNavigatorSeparator4, Me.BindingNavigatorMoveNextItem1, Me.BindingNavigatorMoveLastItem1, Me.BindingNavigatorSeparator5, Me.tsbSaveBusStop})
        Me.bnBusStop.Location = New System.Drawing.Point(0, 0)
        Me.bnBusStop.MoveFirstItem = Me.BindingNavigatorMoveFirstItem1
        Me.bnBusStop.MoveLastItem = Me.BindingNavigatorMoveLastItem1
        Me.bnBusStop.MoveNextItem = Me.BindingNavigatorMoveNextItem1
        Me.bnBusStop.MovePreviousItem = Me.BindingNavigatorMovePreviousItem1
        Me.bnBusStop.Name = "bnBusStop"
        Me.bnBusStop.PositionItem = Me.BindingNavigatorPositionItem1
        Me.bnBusStop.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.bnBusStop.Size = New System.Drawing.Size(1004, 25)
        Me.bnBusStop.TabIndex = 308
        Me.bnBusStop.Text = "BindingNavigator1"
        '
        'BindingNavigatorCountItem1
        '
        Me.BindingNavigatorCountItem1.Name = "BindingNavigatorCountItem1"
        Me.BindingNavigatorCountItem1.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem1.Text = "of {0}"
        Me.BindingNavigatorCountItem1.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem1
        '
        Me.BindingNavigatorMoveFirstItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem1.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem1.Name = "BindingNavigatorMoveFirstItem1"
        Me.BindingNavigatorMoveFirstItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem1.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem1.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem1
        '
        Me.BindingNavigatorMovePreviousItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem1.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem1.Name = "BindingNavigatorMovePreviousItem1"
        Me.BindingNavigatorMovePreviousItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem1.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem1.Text = "Move previous"
        '
        'BindingNavigatorSeparator3
        '
        Me.BindingNavigatorSeparator3.Name = "BindingNavigatorSeparator3"
        Me.BindingNavigatorSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem1
        '
        Me.BindingNavigatorPositionItem1.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem1.AutoSize = False
        Me.BindingNavigatorPositionItem1.Name = "BindingNavigatorPositionItem1"
        Me.BindingNavigatorPositionItem1.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem1.Text = "0"
        Me.BindingNavigatorPositionItem1.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator4
        '
        Me.BindingNavigatorSeparator4.Name = "BindingNavigatorSeparator4"
        Me.BindingNavigatorSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem1
        '
        Me.BindingNavigatorMoveNextItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem1.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem1.Name = "BindingNavigatorMoveNextItem1"
        Me.BindingNavigatorMoveNextItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem1.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem1.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem1
        '
        Me.BindingNavigatorMoveLastItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem1.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem1.Name = "BindingNavigatorMoveLastItem1"
        Me.BindingNavigatorMoveLastItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem1.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem1.Text = "Move last"
        '
        'BindingNavigatorSeparator5
        '
        Me.BindingNavigatorSeparator5.Name = "BindingNavigatorSeparator5"
        Me.BindingNavigatorSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'tsbSaveBusStop
        '
        Me.tsbSaveBusStop.Image = CType(resources.GetObject("tsbSaveBusStop.Image"), System.Drawing.Image)
        Me.tsbSaveBusStop.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.tsbSaveBusStop.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSaveBusStop.Name = "tsbSaveBusStop"
        Me.tsbSaveBusStop.Size = New System.Drawing.Size(100, 22)
        Me.tsbSaveBusStop.Text = "Save Bus Stop"
        Me.tsbSaveBusStop.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TblStaffTableAdapter
        '
        Me.TblStaffTableAdapter.ClearBeforeFill = True
        '
        'TblADAStatusTableAdapter
        '
        Me.TblADAStatusTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager2
        '
        Me.TableAdapterManager2.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager2.Connection = Nothing
        Me.TableAdapterManager2.UpdateOrder = BusStopManagement.dsADATableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'ADA_STATUS_CODETableAdapter
        '
        Me.ADA_STATUS_CODETableAdapter.ClearBeforeFill = True
        '
        'ADA_STATUS_CODETableAdapter1
        '
        Me.ADA_STATUS_CODETableAdapter1.ClearBeforeFill = True
        '
        'TblStopTransAmenitiesTableAdapter
        '
        Me.TblStopTransAmenitiesTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager3
        '
        Me.TableAdapterManager3.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager3.tblStopTransAmenitiesTableAdapter = Me.TblStopTransAmenitiesTableAdapter
        Me.TableAdapterManager3.UpdateOrder = BusStopManagement.dsTransitAmenitiesTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'BS_STATUS_CODETableAdapter
        '
        Me.BS_STATUS_CODETableAdapter.ClearBeforeFill = True
        '
        'COUNTY_CODETableAdapter
        '
        Me.COUNTY_CODETableAdapter.ClearBeforeFill = True
        '
        'CITY_CODETableAdapter
        '
        Me.CITY_CODETableAdapter.ClearBeforeFill = True
        '
        'ST_DIR_CODETableAdapter
        '
        Me.ST_DIR_CODETableAdapter.ClearBeforeFill = True
        '
        'BS_LOC_CODETableAdapter
        '
        Me.BS_LOC_CODETableAdapter.ClearBeforeFill = True
        '
        'ST_TYPE_CODETableAdapter
        '
        Me.ST_TYPE_CODETableAdapter.ClearBeforeFill = True
        '
        'TblBusStopInformationTableAdapter
        '
        Me.TblBusStopInformationTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager4
        '
        Me.TableAdapterManager4.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager4.tblBusStopInformationTableAdapter = Me.TblBusStopInformationTableAdapter
        Me.TableAdapterManager4.UpdateOrder = BusStopManagement.dsBusStopsTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CITY_CODETableAdapter1
        '
        Me.CITY_CODETableAdapter1.ClearBeforeFill = True
        '
        'TblStopHistoryTableAdapter
        '
        Me.TblStopHistoryTableAdapter.ClearBeforeFill = True
        '
        'HISTORY_TYPE_CODETableAdapter
        '
        Me.HISTORY_TYPE_CODETableAdapter.ClearBeforeFill = True
        '
        'OCTAIDDataGridViewTextBoxColumn
        '
        Me.OCTAIDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.OCTAIDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.OCTAIDDataGridViewTextBoxColumn.Name = "OCTAIDDataGridViewTextBoxColumn"
        Me.OCTAIDDataGridViewTextBoxColumn.Visible = False
        Me.OCTAIDDataGridViewTextBoxColumn.Width = 80
        '
        'OCTA_ID
        '
        Me.OCTA_ID.DataPropertyName = "OCTA_ID"
        Me.OCTA_ID.HeaderText = "OCTA ID"
        Me.OCTA_ID.Name = "OCTA_ID"
        Me.OCTA_ID.Visible = False
        '
        'ID
        '
        Me.ID.DataPropertyName = "ID"
        Me.ID.HeaderText = "ID"
        Me.ID.Name = "ID"
        Me.ID.Visible = False
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "OCTA_ID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "OCTA_ID"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Visible = False
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "ID"
        Me.DataGridViewTextBoxColumn2.HeaderText = "ID"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Visible = False
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "OCTA_ID"
        Me.DataGridViewTextBoxColumn3.HeaderText = "OCTA_ID"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Visible = False
        '
        'TblStopPsgrAmenitiesTableAdapter
        '
        Me.TblStopPsgrAmenitiesTableAdapter.ClearBeforeFill = True
        '
        'AMENITIES_TYPE_CODETableAdapter
        '
        Me.AMENITIES_TYPE_CODETableAdapter.ClearBeforeFill = True
        '
        'AMENITIES_OWNER_CODETableAdapter
        '
        Me.AMENITIES_OWNER_CODETableAdapter.ClearBeforeFill = True
        '
        'TblBusStopInformationBindingSource1
        '
        Me.TblBusStopInformationBindingSource1.DataMember = "tblBusStopInformation"
        Me.TblBusStopInformationBindingSource1.DataSource = Me.DsBusStops
        '
        'TblStopCoordTableAdapter
        '
        Me.TblStopCoordTableAdapter.ClearBeforeFill = True
        '
        'BUS_PAD_CODETableAdapter
        '
        Me.BUS_PAD_CODETableAdapter.ClearBeforeFill = True
        '
        'TURNOUT_TYPE_CODETableAdapter
        '
        Me.TURNOUT_TYPE_CODETableAdapter.ClearBeforeFill = True
        '
        'RESTRICTIVE_PK_TYPE_CODETableAdapter
        '
        Me.RESTRICTIVE_PK_TYPE_CODETableAdapter.ClearBeforeFill = True
        '
        'TblSignCassetteTableAdapter
        '
        Me.TblSignCassetteTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager1
        '
        Me.TableAdapterManager1.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager1.tblSignCassetteTableAdapter = Me.TblSignCassetteTableAdapter
        Me.TableAdapterManager1.UpdateOrder = BusStopManagement.dsSignCassetteHardwareTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'SIGN_POST_CONFIG_CODETableAdapter
        '
        Me.SIGN_POST_CONFIG_CODETableAdapter.ClearBeforeFill = True
        '
        'SIGN_POST_TYPE_CODETableAdapter
        '
        Me.SIGN_POST_TYPE_CODETableAdapter.ClearBeforeFill = True
        '
        'CASSETTE_TYPE_CODETableAdapter
        '
        Me.CASSETTE_TYPE_CODETableAdapter.ClearBeforeFill = True
        '
        'CASSETTE_POSITION_CODETableAdapter
        '
        Me.CASSETTE_POSITION_CODETableAdapter.ClearBeforeFill = True
        '
        'DsWorkOrderItemCodes
        '
        Me.DsWorkOrderItemCodes.DataSetName = "dsWorkOrderItemCodes"
        Me.DsWorkOrderItemCodes.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'WOITEMCODEBindingSource
        '
        Me.WOITEMCODEBindingSource.DataMember = "WO_ITEM_CODE"
        Me.WOITEMCODEBindingSource.DataSource = Me.DsWorkOrderItemCodes
        '
        'WO_ITEM_CODETableAdapter
        '
        Me.WO_ITEM_CODETableAdapter.ClearBeforeFill = True
        '
        'WOITEMCODEBindingSource1
        '
        Me.WOITEMCODEBindingSource1.DataMember = "WO_ITEM_CODE"
        Me.WOITEMCODEBindingSource1.DataSource = Me.DsWorkOrderItemCodes
        '
        'VwTimePointsTableAdapter
        '
        Me.VwTimePointsTableAdapter.ClearBeforeFill = True
        '
        'QryBusStopStatusTableAdapter
        '
        Me.QryBusStopStatusTableAdapter.ClearBeforeFill = True
        '
        'cmdViewActiveList
        '
        Me.cmdViewActiveList.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdViewActiveList.Location = New System.Drawing.Point(642, 295)
        Me.cmdViewActiveList.Name = "cmdViewActiveList"
        Me.cmdViewActiveList.Size = New System.Drawing.Size(99, 28)
        Me.cmdViewActiveList.TabIndex = 229
        Me.cmdViewActiveList.Text = "View Active List"
        Me.cmdViewActiveList.UseVisualStyleBackColor = True
        '
        'frmUpdateStop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(1004, 812)
        Me.Controls.Add(Me.bnBusStop)
        Me.Controls.Add(Me.SSTab1)
        Me.Controls.Add(Me.txtStopID)
        Me.Controls.Add(Me.txtCBOTravelDir)
        Me.Controls.Add(Me.txtCBOXLoc)
        Me.Controls.Add(Me.txtCBOXType)
        Me.Controls.Add(Me.txtCBOJurisd)
        Me.Controls.Add(Me.txtCBOTravelType)
        Me.Controls.Add(Me.Text1)
        Me.Controls.Add(Me.txtCBOCity)
        Me.Controls.Add(Me.txtCBOCounty)
        Me.Controls.Add(Me.txtCBOBSStatus)
        Me.Controls.Add(Me.txtTBM)
        Me.Controls.Add(Me.cbxFieldWork)
        Me.Controls.Add(Me.fraTop)
        Me.Controls.Add(Me.Frame6)
        Me.Controls.Add(Me.Frame7)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximumSize = New System.Drawing.Size(1020, 851)
        Me.MinimumSize = New System.Drawing.Size(1020, 851)
        Me.Name = "frmUpdateStop"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "OCTA Stops"
        Me.fraTop.ResumeLayout(False)
        Me.fraTop.PerformLayout()
        CType(Me.VwTimePointsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsTimePoints, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblBusStopInformationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsBusStops, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CITYCODEBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsJurisdiction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CITYCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsCityCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.STDIRCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsTravelDirectionCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BSSTATUSCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsBusStopStatusCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.COUNTYCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsCountyCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BSLOCCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsBusStopLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.STTYPECODEBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsStreetType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.STTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CITYCODEBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CITYCODEBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsBusStopStatusCode1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusStopManagementDataSet4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame6.ResumeLayout(False)
        Me.Frame7.ResumeLayout(False)
        Me.Frame7.PerformLayout()
        Me.SSTab1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.fraADA.ResumeLayout(False)
        Me.fraADA.PerformLayout()
        CType(Me.TblADAStatusBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsADA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ADASTATUSCODEBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsADAStatusCode, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.fraTransit.ResumeLayout(False)
        Me.fraTransit.PerformLayout()
        CType(Me.TblStopTransAmenitiesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsTransitAmenities, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RESTRICTIVEPKTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsRestrictiveParking, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TURNOUTTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsTurnOutType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BUSPADCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsBusPadType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.tdbPassAmen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AMENITIESTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsAmenityType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AMENITIESOWNERCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsAmentityOwner, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblStopPsgrAmenitiesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsPassAmenities, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.TblSignCassetteBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsSignCassetteHardware, System.ComponentModel.ISupportInitialize).EndInit()
        Me.fraCassetteSurvey.ResumeLayout(False)
        Me.Frame3.ResumeLayout(False)
        Me.Frame3.PerformLayout()
        CType(Me.SIGNPOSTCONFIGCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsSignPostConfig, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SIGNPOSTTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsSignPostType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CASSETTETYPECODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsCassetteMountingHardware, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CASSETTEPOSITIONCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsCassetteMountingPosition, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame2.ResumeLayout(False)
        Me.Frame2.PerformLayout()
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        CType(Me.tdbStopHist, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblStopHistoryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsStopHistory, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.fraWorkOrders.ResumeLayout(False)
        Me.fraWorkOrders.PerformLayout()
        CType(Me.WOGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        CType(Me.bnPictures, System.ComponentModel.ISupportInitialize).EndInit()
        Me.bnPictures.ResumeLayout(False)
        Me.bnPictures.PerformLayout()
        CType(Me.TblStopImagesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusStopManagementDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgStopPic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.fraStopPictures.ResumeLayout(False)
        Me.fraStopPictures.PerformLayout()
        CType(Me.TblStaffBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusStopManagementDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage9.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.QryBusStopStatusBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsBusStopStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblStopCoordBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsGPS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.fraGPS2.ResumeLayout(False)
        Me.fraGPS2.PerformLayout()
        CType(Me.HISTORYTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsStopHistoryType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ADASTATUSCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusStopManagementDataSet5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblStaffBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsPictures, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bnBusStop, System.ComponentModel.ISupportInitialize).EndInit()
        Me.bnBusStop.ResumeLayout(False)
        Me.bnBusStop.PerformLayout()
        CType(Me.TblBusStopInformationBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsWorkOrderItemCodes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WOITEMCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WOITEMCODEBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblStaffBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents cmdSortOrder As Button
    Public WithEvents txtStopID As TextBox
    Public WithEvents Command1 As Button
    Public WithEvents txtCBOTravelDir As TextBox
    Public WithEvents txtCBOXLoc As TextBox
    Public WithEvents txtCBOXType As TextBox
    Public WithEvents txtCBOJurisd As TextBox
    Public WithEvents txtCBOTravelType As TextBox
    Public WithEvents Text1 As TextBox
    Public WithEvents txtCBOCity As TextBox
    Public WithEvents txtCBOCounty As TextBox
    Public WithEvents txtCBOBSStatus As TextBox
    Public WithEvents txtTBM As TextBox
    Public WithEvents cbxFieldWork As CheckBox
    Public WithEvents cmdFindRecord As Button
    Public WithEvents cmdClose As Button
    Public WithEvents fraTop As GroupBox
    Public WithEvents cmdChangeActiveStop As Button
    Public WithEvents cboBSStatus As ComboBox
    Public WithEvents cboCounty As ComboBox
    Public WithEvents txtRouteServed As TextBox
    Public WithEvents cboXLoc As ComboBox
    Public WithEvents cboXType As ComboBox
    Public WithEvents cboTravelType As ComboBox
    Public WithEvents cmdAddNewRecord As Button
    Public WithEvents _Label1_3 As Label
    Public WithEvents _Label1_2 As Label
    Public WithEvents _Label1_35 As Label
    Public WithEvents _Label1_44 As Label
    Public WithEvents _Label1_55 As Label
    Public WithEvents _Label1_77 As Label
    Public WithEvents _Label1_1 As Label
    Public WithEvents _Label1_87 As Label
    Public WithEvents _Label1_11 As Label
    Public WithEvents _Label1_0 As Label
    Public WithEvents Frame6 As GroupBox
    Public WithEvents Frame7 As GroupBox
    Public WithEvents _Label1_5 As Label
    Friend WithEvents SSTab1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Public WithEvents fraADA As GroupBox
    Public WithEvents btnADACreateHistory As Button
    Public WithEvents cboADAStatus As ComboBox
    Public WithEvents _Label1_84 As Label
    Public WithEvents _Label1_7 As Label
    Public WithEvents _Label1_6 As Label
    Public WithEvents _Label1_83 As Label
    Friend WithEvents TabPage2 As TabPage
    Public WithEvents fraTransit As GroupBox
    Public WithEvents cboRstType As ComboBox
    Public WithEvents cboTrnType As ComboBox
    Public WithEvents cboBsPdType As ComboBox
    Public WithEvents cbxTransSurvey As CheckBox
    Public WithEvents txtTranAmenRmk As TextBox
    Public WithEvents txtRstLen As TextBox
    Public WithEvents txtTrnEgress As TextBox
    Public WithEvents txtTrnBsBay As TextBox
    Public WithEvents txtBsPdLen As TextBox
    Public WithEvents txtBsPdWdth As TextBox
    Public WithEvents txtTrnIngress As TextBox
    Public WithEvents cbxRstrcPrk As CheckBox
    Public WithEvents cbxTurnout As CheckBox
    Public WithEvents cbxBusPad As CheckBox
    Public WithEvents txtTrnWidth As TextBox
    Public WithEvents _Label1_26 As Label
    Public WithEvents _Label1_25 As Label
    Public WithEvents _Label1_14 As Label
    Public WithEvents _Label1_24 As Label
    Public WithEvents _Label1_16 As Label
    Public WithEvents _Label1_23 As Label
    Public WithEvents _Label1_20 As Label
    Public WithEvents _Label1_22 As Label
    Public WithEvents _Label1_13 As Label
    Public WithEvents _Label1_12 As Label
    Public WithEvents _Label1_10 As Label
    Public WithEvents _Label1_4 As Label
    Public WithEvents _Label1_27 As Label
    Public WithEvents _Label1_60 As Label
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents tdbPassAmen As DataGridView
    Public WithEvents cmdRemAmen As Button
    Public WithEvents cmdAddAmen As Button
    Public WithEvents _Label1_88 As Label
    Friend WithEvents TabPage4 As TabPage
    Public WithEvents fraCassetteSurvey As GroupBox
    Public WithEvents Frame3 As GroupBox
    Public WithEvents cbxPlaceSolar As CheckBox
    Public WithEvents cbxExistSolar As CheckBox
    Public WithEvents cbxSignSpecific As CheckBox
    Public WithEvents cbxCitySignage As CheckBox
    Public WithEvents txtCitySignage As TextBox
    Public WithEvents txtSignSpecific As TextBox
    Public WithEvents txtNumRouteDisplay As TextBox
    Public WithEvents cboSPConfig As ComboBox
    Public WithEvents cboSCPostType As ComboBox
    Public WithEvents cboCasHardware As ComboBox
    Public WithEvents cboCasPosition As ComboBox
    Public WithEvents _Label1_78 As Label
    Public WithEvents _Label1_80 As Label
    Public WithEvents _Label1_79 As Label
    Public WithEvents _Label1_76 As Label
    Public WithEvents _Label1_74 As Label
    Public WithEvents cbxReplacePermenent As CheckBox
    Public WithEvents cbxUpcomingChange As CheckBox
    Public WithEvents Frame2 As GroupBox
    Public WithEvents txtIssuingAgency As TextBox
    Public WithEvents txtPermitNo As TextBox
    Public WithEvents _Label1_82 As Label
    Public WithEvents _Label1_72 As Label
    Public WithEvents _Label1_53 As Label
    Public WithEvents Frame1 As GroupBox
    Public WithEvents txtRouteDisplay As TextBox
    Public WithEvents txtCstRemarks As TextBox
    Public WithEvents _Label1_52 As Label
    Public WithEvents _Label1_73 As Label
    Friend WithEvents TabPage5 As TabPage
    Public WithEvents cmdEdit As Button
    Public WithEvents cmdRemoveHistory As Button
    Public WithEvents cmdAddHistory As Button
    Friend WithEvents TabPage7 As TabPage
    Public WithEvents fraWorkOrders As GroupBox
    Friend WithEvents WOGrid1 As DataGridView
    Public WithEvents cmdPrintEmailAll As Button
    Public WithEvents cbxWO_Dig_AlertWO As CheckBox
    Public WithEvents cmdClearAllWO As Button
    Public WithEvents txtWorkOrdersWO As TextBox
    Public WithEvents cmdPrvWorkWO As Button
    Public WithEvents cboPriorityWO As ComboBox
    Public WithEvents _Label1_32 As Label
    Public WithEvents _Label1_29 As Label
    Public WithEvents _Label1_28 As Label
    Friend WithEvents TabPage8 As TabPage
    Public WithEvents imgStopPic As PictureBox
    Public WithEvents fraStopPictures As GroupBox
    Public WithEvents cmdPicsNeeded As Button
    Public WithEvents cmdPicBrowse As Button
    Public WithEvents cbxStopPhotoNeeded As CheckBox
    Public WithEvents _Label1_58 As Label
    Public WithEvents _Label1_56 As Label
    Public WithEvents _Label1_54 As Label
    Public WithEvents _Label1_47 As Label
    Friend WithEvents TabPage9 As TabPage
    Public WithEvents cbxGPSRequired As CheckBox
    Public WithEvents fraGPS2 As GroupBox
    Public WithEvents txtLat As TextBox
    Public WithEvents txtLon As TextBox
    Public WithEvents txtGPS_OCTA_ID As TextBox
    Public WithEvents txtElev As TextBox
    Public WithEvents txtYCoord As TextBox
    Public WithEvents txtXCoord As TextBox
    Public WithEvents _LATITUDE_9 As Label
    Public WithEvents _Label1_8 As Label
    Public WithEvents _Label1_59 As Label
    Public WithEvents _Label1_46 As Label
    Public WithEvents _Label1_45 As Label
    Public WithEvents _Label1_43 As Label
    Friend WithEvents dtGPSDate As DateTimePicker
    Friend WithEvents bsPictures As BindingSource
    Friend WithEvents BusStopManagementDataSet2 As BusStopManagementDataSet2
    Friend WithEvents TblStopImagesBindingSource As BindingSource
    Friend WithEvents TblStopImagesTableAdapter As BusStopManagementDataSet2TableAdapters.tblStopImagesTableAdapter
    Friend WithEvents TableAdapterManager As BusStopManagementDataSet2TableAdapters.TableAdapterManager
    Friend WithEvents SANZ_IDTextBox As TextBox
    Friend WithEvents txtPicNotes As TextBox
    Friend WithEvents txtPicPath As TextBox
    Friend WithEvents cboTakenBy As ComboBox
    Friend WithEvents bnBusStop As BindingNavigator
    Friend WithEvents BindingNavigatorCountItem1 As ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator3 As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem1 As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator4 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator5 As ToolStripSeparator
    Friend WithEvents txtPictureOCTA_ID As TextBox
    Friend WithEvents bnPictures As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem2 As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem2 As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem2 As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator6 As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem2 As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator7 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem2 As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem2 As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator8 As ToolStripSeparator
    Friend WithEvents toolStripSeparator As ToolStripSeparator
    Friend WithEvents toolStripSeparator1 As ToolStripSeparator
    Friend WithEvents SaveToolStripButton As ToolStripButton
    Friend WithEvents txtPicDate As DateTimePicker
    Friend WithEvents TblStaffBindingSource As BindingSource
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents CancelToolStripButton As ToolStripButton
    Friend WithEvents cmdZoom As ToolStripButton
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents BusStopManagementDataSet As BusStopManagementDataSet
    Friend WithEvents TblStaffBindingSource1 As BindingSource
    Friend WithEvents TblStaffTableAdapter As BusStopManagementDataSetTableAdapters.tblStaffTableAdapter
    Friend WithEvents TblStaffBindingSource2 As BindingSource
    Public WithEvents Label1 As Label
    Friend WithEvents IDTextBox As TextBox
    Friend WithEvents txtSANZID As TextBox
    Friend WithEvents txtOCTAID As TextBox
    Friend WithEvents BusStopManagementDataSet4 As BusStopManagementDataSet4
    Friend WithEvents DsADA As dsADA
    Friend WithEvents TblADAStatusBindingSource As BindingSource
    Friend WithEvents TblADAStatusTableAdapter As dsADATableAdapters.tblADAStatusTableAdapter
    Friend WithEvents TableAdapterManager2 As dsADATableAdapters.TableAdapterManager
    Friend WithEvents cbxADASurveyed As CheckBox
    Friend WithEvents txtADARemarks As TextBox
    Friend WithEvents dtADASurvey As DateTimePicker
    Friend WithEvents dtADACompletion As DateTimePicker
    Friend WithEvents BusStopManagementDataSet5 As BusStopManagementDataSet5
    Friend WithEvents ADASTATUSCODEBindingSource As BindingSource
    Friend WithEvents ADA_STATUS_CODETableAdapter As BusStopManagementDataSet5TableAdapters.ADA_STATUS_CODETableAdapter
    Friend WithEvents DsADAStatusCode As dsADAStatusCode
    Friend WithEvents ADA_STATUS_CODETableAdapter1 As dsADAStatusCodeTableAdapters.ADA_STATUS_CODETableAdapter
    Public WithEvents cmdSaveADARecord As Button
    Public WithEvents cmdSaveTransAmenities As Button
    Friend WithEvents DsTransitAmenities As dsTransitAmenities
    Friend WithEvents TblStopTransAmenitiesBindingSource As BindingSource
    Friend WithEvents TblStopTransAmenitiesTableAdapter As dsTransitAmenitiesTableAdapters.tblStopTransAmenitiesTableAdapter
    Friend WithEvents TableAdapterManager3 As dsTransitAmenitiesTableAdapters.TableAdapterManager
    Friend WithEvents OCTA_IDTextBox As TextBox
    Friend WithEvents DsJurisdiction As dsJurisdiction
    Friend WithEvents DsBusStopStatusCode As dsBusStopStatusCode
    Friend WithEvents BSSTATUSCODEBindingSource As BindingSource
    Friend WithEvents BS_STATUS_CODETableAdapter As dsBusStopStatusCodeTableAdapters.BS_STATUS_CODETableAdapter
    Friend WithEvents DsBusStopStatusCode1 As dsBusStopStatusCode
    Friend WithEvents CITYCODEBindingSource2 As BindingSource
    Friend WithEvents DsCountyCode As dsCountyCode
    Friend WithEvents COUNTYCODEBindingSource As BindingSource
    Friend WithEvents COUNTY_CODETableAdapter As dsCountyCodeTableAdapters.COUNTY_CODETableAdapter
    Friend WithEvents DsCityCode As dsCityCode
    Friend WithEvents CITYCODEBindingSource As BindingSource
    Friend WithEvents CITY_CODETableAdapter As dsCityCodeTableAdapters.CITY_CODETableAdapter
    Friend WithEvents dtEffectDate As DateTimePicker
    Friend WithEvents DsTravelDirectionCode As dsTravelDirectionCode
    Friend WithEvents STDIRCODEBindingSource As BindingSource
    Friend WithEvents ST_DIR_CODETableAdapter As dsTravelDirectionCodeTableAdapters.ST_DIR_CODETableAdapter
    Friend WithEvents DsBusStopLocation As dsBusStopLocation
    Friend WithEvents BSLOCCODEBindingSource As BindingSource
    Friend WithEvents BS_LOC_CODETableAdapter As dsBusStopLocationTableAdapters.BS_LOC_CODETableAdapter
    Public WithEvents cboTravelDir As ComboBox
    Public WithEvents cboCity As ComboBox
    Friend WithEvents DsStreetType As dsStreetType
    Friend WithEvents STTYPECODEBindingSource As BindingSource
    Friend WithEvents ST_TYPE_CODETableAdapter As dsStreetTypeTableAdapters.ST_TYPE_CODETableAdapter
    Friend WithEvents STTYPECODEBindingSource1 As BindingSource
    Public WithEvents cboJurisd As ComboBox
    Friend WithEvents txtXStreet As TextBox
    Friend WithEvents txtTravelStreet As TextBox
    Friend WithEvents txtXStreet1 As TextBox
    Friend WithEvents cbxCurrentStop As CheckBox
    Friend WithEvents cbxNiteOwl As CheckBox
    Friend WithEvents cbxBRT As CheckBox
    Friend WithEvents cbxExpress As CheckBox
    'Friend WithEvents QryBusStopInfoTableAdapter As BusStopManagement.BusStopManagementDataSet3TableAdapters.tblBusStopInformationTableAdapter
    Friend WithEvents DsBusStops As dsBusStops
    Friend WithEvents TblBusStopInformationBindingSource As BindingSource
    Friend WithEvents TblBusStopInformationTableAdapter As dsBusStopsTableAdapters.tblBusStopInformationTableAdapter
    Friend WithEvents TableAdapterManager4 As dsBusStopsTableAdapters.TableAdapterManager
    Friend WithEvents ADASTATUSCODEBindingSource1 As BindingSource
    Friend WithEvents CITYCODEBindingSource1 As BindingSource
    Friend WithEvents CITY_CODETableAdapter1 As dsJurisdictionTableAdapters.CITY_CODETableAdapter
    Friend WithEvents CITYCODEBindingSource3 As BindingSource
    Friend WithEvents DsStopHistory As dsStopHistory
    Friend WithEvents TblStopHistoryBindingSource As BindingSource
    Friend WithEvents TblStopHistoryTableAdapter As dsStopHistoryTableAdapters.tblStopHistoryTableAdapter
    Friend WithEvents DsStopHistoryType As dsStopHistoryType
    Friend WithEvents HISTORYTYPECODEBindingSource As BindingSource
    Friend WithEvents HISTORY_TYPE_CODETableAdapter As dsStopHistoryTypeTableAdapters.HISTORY_TYPE_CODETableAdapter
    Friend WithEvents lblStopHistoryCount As Label
    Friend WithEvents tsbSaveBusStop As ToolStripButton
    Friend WithEvents tdbStopHist As DataGridView
    Friend WithEvents OCTAIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents OCTA_ID As DataGridViewTextBoxColumn
    Friend WithEvents ID As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents IDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents OCTAIDDataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents SANZIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NUMDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DESCRIPTIONDataGridViewTextBoxColumn As DataGridViewComboBoxColumn
    Friend WithEvents OWNERDataGridViewTextBoxColumn As DataGridViewComboBoxColumn
    Friend WithEvents DATESURVDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SURVEYEDDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents DsPassAmenities As dsPassAmenities
    Friend WithEvents TblStopPsgrAmenitiesBindingSource As BindingSource
    Friend WithEvents TblStopPsgrAmenitiesTableAdapter As dsPassAmenitiesTableAdapters.tblStopPsgrAmenitiesTableAdapter
    Friend WithEvents DsAmenityType As dsAmenityType
    Friend WithEvents AMENITIESTYPECODEBindingSource As BindingSource
    Friend WithEvents AMENITIES_TYPE_CODETableAdapter As dsAmenityTypeTableAdapters.AMENITIES_TYPE_CODETableAdapter
    Friend WithEvents DsAmentityOwner As dsAmentityOwner
    Friend WithEvents AMENITIESOWNERCODEBindingSource As BindingSource
    Friend WithEvents AMENITIES_OWNER_CODETableAdapter As dsAmentityOwnerTableAdapters.AMENITIES_OWNER_CODETableAdapter
    Friend WithEvents TblBusStopInformationBindingSource1 As BindingSource
    Friend WithEvents txtPARemarks As TextBox
    Friend WithEvents cbxPassSurvey As CheckBox
    Friend WithEvents IDDataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents OCTAIDDataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents AMENITIESTYPEIDDataGridViewTextBoxColumn As DataGridViewComboBoxColumn
    Friend WithEvents AMENITIESOWNERIDDataGridViewTextBoxColumn As DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents TIMESURVDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn1 As DataGridViewCheckBoxColumn
    Public WithEvents cmdSaveAmenity As Button
    Friend WithEvents DsGPS As dsGPS
    Friend WithEvents TblStopCoordBindingSource As BindingSource
    Friend WithEvents TblStopCoordTableAdapter As dsGPSTableAdapters.tblStopCoordTableAdapter
    Friend WithEvents cmdSaveGPS As Button
    Friend WithEvents DsBusPadType As dsBusPadType
    Friend WithEvents BUSPADCODEBindingSource As BindingSource
    Friend WithEvents BUS_PAD_CODETableAdapter As dsBusPadTypeTableAdapters.BUS_PAD_CODETableAdapter
    Friend WithEvents DsTurnOutType As dsTurnOutType
    Friend WithEvents TURNOUTTYPECODEBindingSource As BindingSource
    Friend WithEvents TURNOUT_TYPE_CODETableAdapter As dsTurnOutTypeTableAdapters.TURNOUT_TYPE_CODETableAdapter
    Friend WithEvents DsRestrictiveParking As dsRestrictiveParking
    Friend WithEvents RESTRICTIVEPKTYPECODEBindingSource As BindingSource
    Friend WithEvents RESTRICTIVE_PK_TYPE_CODETableAdapter As dsRestrictiveParkingTableAdapters.RESTRICTIVE_PK_TYPE_CODETableAdapter
    Public WithEvents cmdSaveSignCassRecord As Button
    Friend WithEvents DsSignCassetteHardware As dsSignCassetteHardware
    Friend WithEvents TblSignCassetteBindingSource As BindingSource
    Friend WithEvents TblSignCassetteTableAdapter As dsSignCassetteHardwareTableAdapters.tblSignCassetteTableAdapter
    Friend WithEvents TableAdapterManager1 As dsSignCassetteHardwareTableAdapters.TableAdapterManager
    Friend WithEvents OCTA_IDTextBox1 As TextBox
    Friend WithEvents DsSignPostConfig As dsSignPostConfig
    Friend WithEvents SIGNPOSTCONFIGCODEBindingSource As BindingSource
    Friend WithEvents SIGN_POST_CONFIG_CODETableAdapter As dsSignPostConfigTableAdapters.SIGN_POST_CONFIG_CODETableAdapter
    Friend WithEvents DsSignPostType As dsSignPostType
    Friend WithEvents SIGNPOSTTYPECODEBindingSource As BindingSource
    Friend WithEvents SIGN_POST_TYPE_CODETableAdapter As dsSignPostTypeTableAdapters.SIGN_POST_TYPE_CODETableAdapter
    Friend WithEvents DsCassetteMountingHardware As dsCassetteMountingHardware
    Friend WithEvents CASSETTETYPECODEBindingSource As BindingSource
    Friend WithEvents CASSETTE_TYPE_CODETableAdapter As dsCassetteMountingHardwareTableAdapters.CASSETTE_TYPE_CODETableAdapter
    Friend WithEvents DsCassetteMountingPosition As dsCassetteMountingPosition
    Friend WithEvents CASSETTEPOSITIONCODEBindingSource As BindingSource
    Friend WithEvents CASSETTE_POSITION_CODETableAdapter As dsCassetteMountingPositionTableAdapters.CASSETTE_POSITION_CODETableAdapter
    Friend WithEvents txtDateIssued As DateTimePicker
    Friend WithEvents DsWorkOrderItemCodes As dsWorkOrderItemCodes
    Friend WithEvents WOITEMCODEBindingSource As BindingSource
    Friend WithEvents WO_ITEM_CODETableAdapter As dsWorkOrderItemCodesTableAdapters.WO_ITEM_CODETableAdapter
    Friend WithEvents WOITEMCODEBindingSource1 As BindingSource
    Friend WithEvents cboSelectedItem As DataGridViewCheckBoxColumn
    Friend WithEvents cboDESCRIPTION As DataGridViewTextBoxColumn
    Friend WithEvents cboID As DataGridViewTextBoxColumn
    Friend WithEvents cmdSaveWORecord As Button
    Friend WithEvents txtWOItems As TextBox
    Friend WithEvents DsWOPriority As dsWOPriority
    Friend WithEvents WO_PRIORITY_CODETableAdapter As dsWOPriorityTableAdapters.WO_PRIORITY_CODETableAdapter
    Friend WithEvents cmdWOEmailAll As Button
    Friend WithEvents cmdWOPrintAll As Button
    Friend WithEvents cmdWOEmailCurrent As Button
    Friend WithEvents cmWOPrintCurrent As Button
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DATEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NAMEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TYPEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents REMARKSDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents WONUMDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents cmdAttachments As DataGridViewButtonColumn
    Friend WithEvents OCTAIDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Public WithEvents cmdRemoveFilter As Button
    Public WithEvents cmdSearch As Button
    Friend WithEvents lnkArchivedDocs As LinkLabel
    Friend WithEvents GroupBox1 As GroupBox
    Public WithEvents Label2 As Label
    Public WithEvents Label3 As Label
    Friend WithEvents txtTPName As TextBox
    Public WithEvents lblTPName As Label
    Friend WithEvents DsTimePoints As dsTimePoints
    Friend WithEvents VwTimePointsBindingSource As BindingSource
    Friend WithEvents VwTimePointsTableAdapter As dsTimePointsTableAdapters.vwTimePointsTableAdapter
    Friend WithEvents cmdUpdateRemoveTP As Button
    Friend WithEvents dtpEndDate As DateTimePicker
    Friend WithEvents dtpStartDate As DateTimePicker
    Friend WithEvents cmdAddTP As Button
    Friend WithEvents DsBusStopStatus As dsBusStopStatus
    Friend WithEvents QryBusStopStatusBindingSource As BindingSource
    Friend WithEvents QryBusStopStatusTableAdapter As dsBusStopStatusTableAdapters.qryBusStopStatusTableAdapter
    Friend WithEvents cmdDeleteTP As Button
    Friend WithEvents txtBusStopStatusID As TextBox
    Friend WithEvents lblTPRemoved As Label
    Public WithEvents Label4 As Label
    Friend WithEvents txtTPRemovalDesc As TextBox
    Friend WithEvents cmdViewActiveList As Button
End Class
