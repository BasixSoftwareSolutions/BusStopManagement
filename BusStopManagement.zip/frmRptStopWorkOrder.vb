﻿Public Class frmRptStopWorkOrder
    Private optWorkOrderReport() As RadioButton
    Private optWOTR() As RadioButton

    Public Sub New()
        InitializeComponent()
        optWorkOrderReport = New RadioButton() {optWorkOrderReport0, optWorkOrderReport1, optWorkOrderReport2, optWorkOrderReport3, optWorkOrderReport4, optWorkOrderReport5, optWorkOrderReport6}
        optWOTR = New RadioButton() {optWOTR0, optWOTR1, optWOTR2}
    End Sub
    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdOpenReport_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOpenReport.Click
        On Error GoTo errHandler

        Dim strSQL As String = ""
        Dim rsData As New ADODB.Recordset
        Dim blnShowReport As Boolean
        Dim rs As New ADODB.Recordset
        Dim rs2 As New ADODB.Recordset
        Dim ytdCompleted, ytdTotal, ytdPending, ytdCost As Short
        Dim mCompleted, mTotal, mPending, mCost As Short
        Dim dtStart, dtEnd As String
        Dim i As Short
        Dim dt2, dt3 As String
        Dim mCodes As String
        Dim nCInt As Short
        Dim pos As Short
        Dim newCode As String
        Dim ct As Short
        Dim oldCt As Short
        Dim mn As String
        Dim sReportName As String = ""
        Dim sReportTitle As String = ""

        If optWorkOrderReport(0).Checked = True Or optWorkOrderReport(1).Checked = True Or optWorkOrderReport(2).Checked = True Or optWorkOrderReport(3).Checked = True Or optWorkOrderReport(4).Checked = True Then

            If optWorkOrderReport(3).Checked = True Then
                If Trim(txtWorkOrderNum.Text) = "" Or Not IsNumeric(txtWorkOrderNum.Text) Then
                    MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
                    txtWorkOrderNum.SelectionStart = 0
                    txtWorkOrderNum.SelectionLength = Len(txtWorkOrderNum.Text)
                    txtWorkOrderNum.Focus()
                    Exit Sub
                End If
            End If

            Me.Enabled = False
            Me.Cursor = System.Windows.Forms.Cursors.WaitCursor

            If optWorkOrderReport(0).Checked = True Then
                ' initialize the report
                sReportName = "IssuedWOReports.rpt"
                ' clean up old report data
                strSQL = "DELETE  FROM tblIssuedWOReports"
                dbRep.Execute(strSQL)

                ' Change the header
                sReportTitle = "All Work Orders"

                strSQL = "SELECT wo.WO_ID, wo.OCTA_ID, wo.WO_DATE_ISSUED, wo.WO_PRIORITY_ID, " _
                        & "wo.WO_COMPLETE_DATE, wo.WO_COMPLETED_BY, wo.WO_ISSUED_BY, wo.WO_COST, " _
                        & "dir.DIR, info.STREET_OF_TRAVEL, type1.TYPE as type1_type, loc.LOC, info.CROSS_STREET, " _
                        & "info.CROSS_STREET_1, type2.TYPE as type2_type, wo.WO_DESCRIPTION, wo.WO_REMARKS " _
                        & "FROM tblWorkOrders as [wo], (((tblBusStopInformation as [info] " _
                        & "INNER JOIN ST_DIR_CODE as [dir] ON info.ST_DIR_ID = dir.ID) " _
                        & "INNER JOIN ST_TYPE_CODE as [type1] ON (info.ST_TYPE_ID_1 = type1.ID " _
                        & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                        & "INNER JOIN BS_LOC_CODE as [loc] ON info.BS_LOC_ID = loc.ID) " _
                        & "INNER JOIN ST_TYPE_CODE AS [type2] ON (info.ST_TYPE_ID_2 = type2.ID " _
                        & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0)) " _
                        & "WHERE wo.OCTA_ID=info.OCTA_ID " _
                        & "ORDER by wo.WO_ID DESC"

            ElseIf optWorkOrderReport(1).Checked = True Then
                ' initialize the report
                sReportName = "OpenWOReports.rpt"
                ' clean up old report data
                strSQL = "DELETE  FROM tblIssuedWOReports"
                dbRep.Execute(strSQL)

                ' initialize the report header
                sReportTitle = "Open Work Orders"

                strSQL = "SELECT wo.WO_ID, wo.OCTA_ID, wo.WO_DATE_ISSUED, wo.WO_PRIORITY_ID, " _
                    & "wo.WO_COMPLETE_DATE, wo.WO_COMPLETED_BY, wo.WO_ISSUED_BY, wo.WO_COST, " _
                    & "dir.DIR, info.STREET_OF_TRAVEL, type1.TYPE as type1_type, loc.LOC, info.CROSS_STREET, " _
                    & "info.CROSS_STREET_1, type2.TYPE as type2_type, wo.WO_DESCRIPTION, wo.WO_REMARKS " _
                    & "FROM tblWorkOrders as [wo], (((tblBusStopInformation as [info] " _
                    & "INNER JOIN ST_DIR_CODE as [dir] ON info.ST_DIR_ID = dir.ID) " _
                    & "INNER JOIN ST_TYPE_CODE as [type1] ON (info.ST_TYPE_ID_1 = type1.ID " _
                    & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                    & "INNER JOIN BS_LOC_CODE as [loc] ON info.BS_LOC_ID = loc.ID) " _
                    & "INNER JOIN ST_TYPE_CODE AS [type2] ON (info.ST_TYPE_ID_2 = type2.ID " _
                    & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0)) " _
                    & "WHERE wo.OCTA_ID=info.OCTA_ID AND wo.WO_COMPLETE_DATE IS NULL " _
                    & "ORDER by wo.WO_ID DESC"

            ElseIf optWorkOrderReport(2).Checked = True Then
                ' initialize the report
                sReportName = "IssuedWOReports.rpt"

                ' clean up old report data
                strSQL = "DELETE  FROM tblIssuedWOReports"
                dbRep.Execute(strSQL)

                ' initialize the report header
                sReportTitle = "Completed Work Orders"

                strSQL = "SELECT wo.WO_ID, wo.OCTA_ID, wo.WO_DATE_ISSUED, wo.WO_PRIORITY_ID, " _
                    & "wo.WO_COMPLETE_DATE, wo.WO_COMPLETED_BY, wo.WO_ISSUED_BY, wo.WO_COST, " _
                    & "dir.DIR, info.STREET_OF_TRAVEL, type1.TYPE as type1_type, loc.LOC, info.CROSS_STREET, " _
                    & "info.CROSS_STREET_1, type2.TYPE as type2_type, wo.WO_DESCRIPTION, wo.WO_REMARKS " _
                    & "FROM tblWorkOrders as [wo], (((tblBusStopInformation as [info] " _
                    & "INNER JOIN ST_DIR_CODE as [dir] ON info.ST_DIR_ID = dir.ID) " _
                    & "INNER JOIN ST_TYPE_CODE as [type1] ON (info.ST_TYPE_ID_1 = type1.ID " _
                    & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                    & "INNER JOIN BS_LOC_CODE as [loc] ON info.BS_LOC_ID = loc.ID) " _
                    & "INNER JOIN ST_TYPE_CODE AS [type2] ON (info.ST_TYPE_ID_2 = type2.ID " _
                    & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0)) " _
                    & "WHERE wo.OCTA_ID=info.OCTA_ID  AND wo.WO_COMPLETE_DATE IS NOT NULL " _
                    & "ORDER by wo.WO_ID DESC"

            ElseIf optWorkOrderReport(3).Checked = True Then

                ' initialize the report
                sReportName = "IssuedWOReports.rpt"

                ' clean up old report data
                strSQL = "DELETE  FROM tblIssuedWOReports"
                dbRep.Execute(strSQL)

                ' initialize the report header
                sReportTitle = "Work Order #" & txtWorkOrderNum.Text

                strSQL = "SELECT wo.WO_ID, wo.OCTA_ID, wo.WO_DATE_ISSUED, wo.WO_PRIORITY_ID, " _
                    & "wo.WO_COMPLETE_DATE, wo.WO_COMPLETED_BY, wo.WO_ISSUED_BY, wo.WO_COST, " _
                    & "dir.DIR, info.STREET_OF_TRAVEL, type1.TYPE as type1_type, loc.LOC, info.CROSS_STREET, " _
                    & "info.CROSS_STREET_1, type2.TYPE as type2_type, wo.WO_DESCRIPTION, wo.WO_REMARKS " _
                    & "FROM tblWorkOrders as [wo], (((tblBusStopInformation as [info] " _
                    & "INNER JOIN ST_DIR_CODE as [dir] ON info.ST_DIR_ID = dir.ID) " _
                    & "INNER JOIN ST_TYPE_CODE as [type1] ON (info.ST_TYPE_ID_1 = type1.ID " _
                    & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                    & "INNER JOIN BS_LOC_CODE as [loc] ON info.BS_LOC_ID = loc.ID) " _
                    & "INNER JOIN ST_TYPE_CODE AS [type2] ON (info.ST_TYPE_ID_2 = type2.ID " _
                    & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0)) " _
                    & "WHERE wo.OCTA_ID=info.OCTA_ID  AND wo.WO_ID = " & txtWorkOrderNum.Text & " ORDER by wo.WO_ID DESC"

            ElseIf optWorkOrderReport(4).Checked = True Then

                If dtpDateFrom.Value > dtpDateTo.Value Then
                    MsgBox("Invalid Date Range")
                    Me.Enabled = True
                    Me.Cursor = System.Windows.Forms.Cursors.Default
                    Exit Sub
                End If

                ' initialize the report
                sReportName = "IssuedWOReports.rpt"

                ' clean up old report data
                strSQL = "DELETE  FROM tblIssuedWOReports"
                dbRep.Execute(strSQL)

                If CDate(dtpDateFrom.Value) > CDate(dtpDateTo.Value) Then
                    MsgBox("Please enter a valid date range.")
                    Exit Sub
                End If
                sReportTitle = "Completed Work Orders from " & dtpDateFrom.Value.ToShortDateString & " to " & dtpDateTo.Value.ToShortDateString

                strSQL = "SELECT wo.WO_ID, wo.OCTA_ID, wo.WO_DATE_ISSUED, wo.WO_PRIORITY_ID, " _
                    & "wo.WO_COMPLETE_DATE, wo.WO_COMPLETED_BY, wo.WO_ISSUED_BY, wo.WO_COST, " _
                    & "dir.DIR, info.STREET_OF_TRAVEL, type1.TYPE as type1_type, loc.LOC, info.CROSS_STREET, " _
                    & "info.CROSS_STREET_1, type2.TYPE as type2_type, wo.WO_DESCRIPTION, wo.WO_REMARKS " _
                    & "FROM tblWorkOrders as [wo], (((tblBusStopInformation as [info] " _
                    & "INNER JOIN ST_DIR_CODE as [dir] ON info.ST_DIR_ID = dir.ID) " _
                    & "INNER JOIN ST_TYPE_CODE as [type1] ON (info.ST_TYPE_ID_1 = type1.ID " _
                    & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                    & "INNER JOIN BS_LOC_CODE as [loc] ON info.BS_LOC_ID = loc.ID) " _
                    & "INNER JOIN ST_TYPE_CODE AS [type2] ON (info.ST_TYPE_ID_2 = type2.ID " _
                    & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0)) " _
                    & "WHERE wo.OCTA_ID=info.OCTA_ID AND wo.WO_COMPLETE_DATE >= '" & dtpDateFrom.Value & "' AND wo.WO_COMPLETE_DATE <= '" & dtpDateTo.Value & "' " _
                    & "ORDER by wo.WO_ID DESC"
            End If

            rsData.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset)

            If Not (rsData.EOF And rsData.BOF) Then
                CopyADOtoAccessNoPause2(rsData, dbRep, "tblIssuedWOReports")
                blnShowReport = True
            Else
                MsgBox("No Work Order Found. Re-Check Your Criteria And Try Again.", MsgBoxStyle.Information)
                blnShowReport = False
            End If

            rsData.Close()
            rsData = Nothing
            dbRep.Close()
            dbRep.Open()

            Me.Enabled = True
            Me.Cursor = System.Windows.Forms.Cursors.Default

            If blnShowReport Then frmCrystalReportsWP.LoadReport(sReportName, sReportTitle, "", "")
        Else

            If optWorkOrderReport(5).Checked = True Then
                If DTPicker2.Value > DTPicker3.Value Then
                    MsgBox("Invalid Date Range")
                    Exit Sub
                End If

                strSQL = "DELETE  FROM tblWOTaskReport"
                dbRep.Execute(strSQL)

                strSQL = "SELECT * FROM WO_ITEM_CODE"
                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                For i = 0 To rs.RecordCount - 1
                    strSQL = "INSERT INTO tblWOTaskReport (ITEM_NO, DESCRIPTION) VALUES (" & rs.Fields("ID").Value & ", " & cV2Q_String((rs.Fields("DESCRIPTION").Value)) & ")"
                    dbRep.Execute(strSQL)
                    rs.MoveNext()
                Next i

                rs.Close()

                dt2 = DTPicker2.Value

                dt3 = DTPicker3.Value

                If optWOTR(0).Checked Then
                    strSQL = "SELECT * FROM tblWorkOrders WHERE WO_DATE_ISSUED >= '" & dt2 & "' AND WO_DATE_ISSUED <= '" & dt3 & "'"
                ElseIf optWOTR(1).Checked Then '
                    strSQL = "SELECT * FROM tblWorkOrders WHERE WO_DATE_ISSUED >= '" & dt2 & "' AND WO_DATE_ISSUED <= '" & dt3 & "' AND WO_COMPLETE_DATE is null"
                ElseIf optWOTR(2).Checked Then
                    strSQL = "SELECT * FROM tblWorkOrders WHERE WO_DATE_ISSUED >= '" & dt2 & "' AND WO_DATE_ISSUED <= '" & dt3 & "' AND WO_COMPLETE_DATE is not null"
                End If

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                For i = 0 To rs.RecordCount - 1
                    If Not IsDBNull(rs.Fields("WO_ITEMS").Value) And rs.Fields("WO_ITEMS").Value <> "" Then
                        mCodes = rs.Fields("WO_ITEMS").Value

                        pos = -1

                        Do While (pos <> 0)
                            pos = InStr(mCodes, ",")

                            If pos = 0 Then
                                pos = Len(mCodes)
                                newCode = Mid(mCodes, 1, pos)
                                pos = 0
                            Else
                                newCode = Mid(mCodes, 1, pos - 1)
                                mCodes = Mid(mCodes, pos + 1, Len(mCodes) - pos)
                            End If

                            nCInt = CShort(newCode)

                            strSQL = "SELECT * FROM tblWOTaskReport WHERE ITEM_NO = " & nCInt
                            rs2.Open(strSQL, dbRep, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                            oldCt = rs2.Fields("COUNT_COMPLETED").Value

                            rs2.Update("COUNT_COMPLETED", oldCt + 1)
                            rs2.Close()
                        Loop
                    End If

                    rs.MoveNext()

                Next i

                rs.Close()

                If optWOTR(0).Checked Then
                    sReportName = "WOTaskReport_a.rpt"
                ElseIf optWOTR(1).Checked Then
                    sReportName = "WOTaskReport_b.rpt"
                ElseIf optWOTR(2).Checked Then
                    sReportName = "WOTaskReport.rpt"
                End If

                sReportTitle = "Work Order Task Report " & DTPicker2.Value.ToShortDateString & " to " & DTPicker3.Value.ToShortDateString

                frmCrystalReportsWP.LoadReport(sReportName, sReportTitle, "", "")

            ElseIf optWorkOrderReport(6).Checked = True Then

                dtStart = "'01/01/" & Combo2.Text & "'"
                dtEnd = "'12/31/" & Combo2.Text & "'"

                strSQL = "SELECT * FROM tblWorkOrders WHERE WO_DATE_ISSUED >= " & dtStart & " AND WO_DATE_ISSUED <= " & dtEnd

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                ytdTotal = rs.RecordCount

                rs.Close()

                strSQL = "SELECT * FROM tblWorkOrders WHERE WO_COMPLETE_DATE is null AND WO_DATE_ISSUED >= " & dtStart & " AND WO_DATE_ISSUED <= " & dtEnd

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                ytdPending = rs.RecordCount
                rs.Close()

                strSQL = "SELECT * FROM tblWorkOrders WHERE WO_COMPLETE_DATE is not null AND WO_DATE_ISSUED >= " & dtStart & " AND WO_DATE_ISSUED <= " & dtEnd

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                ytdCompleted = rs.RecordCount
                rs.Close()

                strSQL = "SELECT SUM(WO_COST) FROM tblWorkOrders WHERE WO_DATE_ISSUED >= " & dtStart & " AND WO_DATE_ISSUED <= " & dtEnd

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                If Not IsDBNull(rs.Fields(0).Value) Then
                    ytdCost = rs.Fields(0).Value
                Else
                    ytdCost = 0
                End If
                rs.Close()

                dtStart = "'" & Combo1.Text & "/01/" & Combo2.Text & "'"

                If Combo1.Text = "01" Or Combo1.Text = "03" Or Combo1.Text = "05" Or Combo1.Text = "07" Or Combo1.Text = "08" Or Combo1.Text = "10" Or Combo1.Text = "12" Then
                    dtEnd = "'" & Combo1.Text & "/31/" & Combo2.Text & "'"
                ElseIf Combo1.Text = "04" Or Combo1.Text = "06" Or Combo1.Text = "09" Or Combo1.Text = "11" Then
                    dtEnd = "'" & Combo1.Text & "/30/" & Combo2.Text & "'"
                ElseIf Combo1.Text = "02" Then
                    If Combo2.Text = "2004" Or Combo2.Text = "2008" Or Combo2.Text = "2112" Then
                        dtEnd = "'" & Combo1.Text & "/29/" & Combo2.Text & "'"
                    Else
                        dtEnd = "'" & Combo1.Text & "/28/" & Combo2.Text & "'"
                    End If
                End If

                strSQL = "SELECT * FROM tblWorkOrders WHERE WO_DATE_ISSUED >= " & dtStart & " AND WO_DATE_ISSUED <= " & dtEnd

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                mTotal = rs.RecordCount
                rs.Close()

                strSQL = "SELECT * FROM tblWorkOrders WHERE WO_DATE_ISSUED >= " & dtStart & " AND WO_DATE_ISSUED <= " & dtEnd & " AND WO_COMPLETE_DATE is null"

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                mPending = rs.RecordCount
                rs.Close()

                strSQL = "SELECT * FROM tblWorkOrders WHERE WO_DATE_ISSUED >= " & dtStart & " AND WO_DATE_ISSUED <= " & dtEnd & " AND WO_COMPLETE_DATE is not null"

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                mCompleted = rs.RecordCount
                rs.Close()

                strSQL = "SELECT SUM(WO_COST) FROM tblWorkOrders WHERE WO_DATE_ISSUED >= " & dtStart & " AND WO_DATE_ISSUED <= " & dtEnd

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                If Not IsDBNull(rs.Fields(0).Value) Then
                    mCost = rs.Fields(0).Value
                Else
                    mCost = 0
                End If
                rs.Close()

                strSQL = "DELETE  FROM tblWOSummary"
                dbRep.Execute(strSQL)

                strSQL = "INSERT INTO tblWOSummary (YTD_TOTAL, YTD_PENDING, YTD_COMPLETED, YTD_COST, " & "M_TOTAL, M_PENDING, M_COMPLETED, M_COST) " & "VALUES (" & ytdTotal & "," & ytdPending & "," & ytdCompleted & "," & ytdCost & "," & mTotal & "," & mPending & "," & mCompleted & "," & mCost & ")"
                dbRep.Execute(strSQL)

                sReportName = "WOSummaryReport.rpt"

                mn = Combo1.Text

                Select Case Combo1.Text
                    Case "01"
                        mn = "January"
                    Case "02"
                        mn = "February"
                    Case "03"
                        mn = "March"
                    Case "04"
                        mn = "April"
                    Case "05"
                        mn = "May"
                    Case "06"
                        mn = "June"
                    Case "07"
                        mn = "July"
                    Case "08"
                        mn = "August"
                    Case "09"
                        mn = "September"
                    Case "10"
                        mn = "October"
                    Case "11"
                        mn = "November"
                    Case "12"
                        mn = "December"
                End Select

                sReportTitle = "Work Order Summary For The Month of " & mn & ", " & Combo2.Text

                frmCrystalReportsWP.LoadReport(sReportName, sReportTitle, "", "")

            End If

        End If

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub dtpDateFrom_ValueChanged(sender As Object, e As EventArgs) Handles dtpDateFrom.ValueChanged
        If dtpDateTo.Value < dtpDateFrom.Value Then
            dtpDateTo.Value = dtpDateFrom.Value.AddDays(1)
        End If
    End Sub

    Private Sub frmRptStopWorkOrder_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        dtpDateFrom.Format = DateTimePickerFormat.Custom
        dtpDateFrom.CustomFormat = "MM/dd/yyyy"
        dtpDateTo.Format = DateTimePickerFormat.Custom
        dtpDateTo.CustomFormat = "MM/dd/yyyy"
        DTPicker2.Format = DateTimePickerFormat.Custom
        DTPicker2.CustomFormat = "MM/dd/yyyy"
        DTPicker3.Format = DateTimePickerFormat.Custom
        DTPicker3.CustomFormat = "MM/dd/yyyy"

        dtpDateFrom.Value = GetToken(CStr(Now), 1, " ")
        dtpDateTo.Value = GetToken(CStr(Now), 1, " ")

        AddHandler optWorkOrderReport(0).CheckedChanged, AddressOf optWorkOrderReport_CheckedChanged
        AddHandler optWorkOrderReport(1).CheckedChanged, AddressOf optWorkOrderReport_CheckedChanged
        AddHandler optWorkOrderReport(2).CheckedChanged, AddressOf optWorkOrderReport_CheckedChanged
        AddHandler optWorkOrderReport(3).CheckedChanged, AddressOf optWorkOrderReport_CheckedChanged
        AddHandler optWorkOrderReport(4).CheckedChanged, AddressOf optWorkOrderReport_CheckedChanged
        AddHandler optWorkOrderReport(5).CheckedChanged, AddressOf optWorkOrderReport_CheckedChanged
        AddHandler optWorkOrderReport(6).CheckedChanged, AddressOf optWorkOrderReport_CheckedChanged

        Dim i As Short
        For i = 1 To 12
            If i < 10 Then
                Combo1.Items.Add(0 & i)
            Else
                Combo1.Items.Add(CStr(i))
            End If
        Next i

        Combo1.SelectedIndex = 0

        Combo2.Items.Add(DateAdd(DateInterval.Year, -2, Date.Now).Year)
        Combo2.Items.Add(DateAdd(DateInterval.Year, -1, Date.Now).Year)
        Combo2.Items.Add(Date.Now.Year)
        Combo2.SelectedIndex = 2

        DTPicker2.Value = Now
        DTPicker3.Value = Now

    End Sub

    Private Sub optWorkOrderReport_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        If eventSender.Checked Then
            Dim Index As Integer = CInt(eventSender.tag)
            If Index <> 3 Then
                TxtEnabled(txtWorkOrderNum, False)
                txtWorkOrderNum.BackColor = System.Drawing.ColorTranslator.FromOle(&H8000000F)
            Else
                TxtEnabled(txtWorkOrderNum, True)
                txtWorkOrderNum.BackColor = System.Drawing.Color.White
            End If
            If Index <> 4 Then
                dtpDateFrom.Enabled = False
                dtpDateTo.Enabled = False
            Else
                dtpDateFrom.Enabled = True
                dtpDateTo.Enabled = True
            End If
            If Index = 5 Then
                DTPicker2.Enabled = True
                DTPicker3.Enabled = True
                optWOTR(0).Enabled = True
                optWOTR(1).Enabled = True
                optWOTR(2).Enabled = True
            Else
                DTPicker2.Enabled = False
                DTPicker3.Enabled = False
                optWOTR(0).Enabled = False
                optWOTR(1).Enabled = False
                optWOTR(2).Enabled = False
            End If
            If Index = 6 Then
                Combo1.Enabled = True
                Combo2.Enabled = True
                Combo1.BackColor = System.Drawing.Color.White
                Combo2.BackColor = System.Drawing.Color.White
            Else
                Combo1.Enabled = False
                Combo2.Enabled = False
                Combo1.BackColor = System.Drawing.ColorTranslator.FromOle(&H8000000F)
                Combo2.BackColor = System.Drawing.ColorTranslator.FromOle(&H8000000F)
            End If
        End If
    End Sub
End Class