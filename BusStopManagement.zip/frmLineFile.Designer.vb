﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLineFile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLineFile))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.cmdEditRoute = New System.Windows.Forms.Button()
        Me.txtRouteDes = New System.Windows.Forms.TextBox()
        Me.cmdCopyRoute = New System.Windows.Forms.Button()
        Me.cmdDeleteRoute = New System.Windows.Forms.Button()
        Me.cmdCreateRoute = New System.Windows.Forms.Button()
        Me.cboRouteDir = New System.Windows.Forms.ComboBox()
        Me.cboRouteNo = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.optInactive = New System.Windows.Forms.RadioButton()
        Me.optActive = New System.Windows.Forms.RadioButton()
        Me.cmdStopDetails = New System.Windows.Forms.Button()
        Me.cmdEditStop = New System.Windows.Forms.Button()
        Me.cmdDeleteStop = New System.Windows.Forms.Button()
        Me.cmdReSeqStop = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdAddStop = New System.Windows.Forms.Button()
        Me.RouteGrid = New System.Windows.Forms.DataGridView()
        CType(Me.RouteGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdEditRoute
        '
        resources.ApplyResources(Me.cmdEditRoute, "cmdEditRoute")
        Me.cmdEditRoute.BackColor = System.Drawing.SystemColors.Control
        Me.cmdEditRoute.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdEditRoute.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdEditRoute.Name = "cmdEditRoute"
        Me.cmdEditRoute.UseVisualStyleBackColor = False
        '
        'txtRouteDes
        '
        Me.txtRouteDes.AcceptsReturn = True
        Me.txtRouteDes.BackColor = System.Drawing.SystemColors.Window
        Me.txtRouteDes.Cursor = System.Windows.Forms.Cursors.IBeam
        resources.ApplyResources(Me.txtRouteDes, "txtRouteDes")
        Me.txtRouteDes.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRouteDes.Name = "txtRouteDes"
        '
        'cmdCopyRoute
        '
        resources.ApplyResources(Me.cmdCopyRoute, "cmdCopyRoute")
        Me.cmdCopyRoute.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCopyRoute.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCopyRoute.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCopyRoute.Name = "cmdCopyRoute"
        Me.cmdCopyRoute.UseVisualStyleBackColor = False
        '
        'cmdDeleteRoute
        '
        resources.ApplyResources(Me.cmdDeleteRoute, "cmdDeleteRoute")
        Me.cmdDeleteRoute.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDeleteRoute.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDeleteRoute.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDeleteRoute.Name = "cmdDeleteRoute"
        Me.cmdDeleteRoute.UseVisualStyleBackColor = False
        '
        'cmdCreateRoute
        '
        resources.ApplyResources(Me.cmdCreateRoute, "cmdCreateRoute")
        Me.cmdCreateRoute.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCreateRoute.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCreateRoute.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCreateRoute.Name = "cmdCreateRoute"
        Me.cmdCreateRoute.UseVisualStyleBackColor = False
        '
        'cboRouteDir
        '
        Me.cboRouteDir.BackColor = System.Drawing.SystemColors.Window
        Me.cboRouteDir.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboRouteDir.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        resources.ApplyResources(Me.cboRouteDir, "cboRouteDir")
        Me.cboRouteDir.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboRouteDir.Name = "cboRouteDir"
        '
        'cboRouteNo
        '
        Me.cboRouteNo.BackColor = System.Drawing.SystemColors.Window
        Me.cboRouteNo.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboRouteNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        resources.ApplyResources(Me.cboRouteNo, "cboRouteNo")
        Me.cboRouteNo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboRouteNo.Name = "cboRouteNo"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Name = "Label3"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Name = "Label2"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Name = "Label1"
        '
        'optInactive
        '
        resources.ApplyResources(Me.optInactive, "optInactive")
        Me.optInactive.BackColor = System.Drawing.Color.Transparent
        Me.optInactive.Cursor = System.Windows.Forms.Cursors.Default
        Me.optInactive.ForeColor = System.Drawing.Color.DimGray
        Me.optInactive.Name = "optInactive"
        Me.optInactive.TabStop = True
        Me.optInactive.UseVisualStyleBackColor = False
        '
        'optActive
        '
        resources.ApplyResources(Me.optActive, "optActive")
        Me.optActive.BackColor = System.Drawing.Color.Transparent
        Me.optActive.Checked = True
        Me.optActive.Cursor = System.Windows.Forms.Cursors.Default
        Me.optActive.ForeColor = System.Drawing.Color.DimGray
        Me.optActive.Name = "optActive"
        Me.optActive.TabStop = True
        Me.optActive.UseVisualStyleBackColor = False
        '
        'cmdStopDetails
        '
        resources.ApplyResources(Me.cmdStopDetails, "cmdStopDetails")
        Me.cmdStopDetails.BackColor = System.Drawing.SystemColors.Control
        Me.cmdStopDetails.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdStopDetails.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdStopDetails.Name = "cmdStopDetails"
        Me.cmdStopDetails.UseVisualStyleBackColor = False
        '
        'cmdEditStop
        '
        resources.ApplyResources(Me.cmdEditStop, "cmdEditStop")
        Me.cmdEditStop.BackColor = System.Drawing.SystemColors.Control
        Me.cmdEditStop.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdEditStop.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdEditStop.Name = "cmdEditStop"
        Me.cmdEditStop.UseVisualStyleBackColor = False
        '
        'cmdDeleteStop
        '
        resources.ApplyResources(Me.cmdDeleteStop, "cmdDeleteStop")
        Me.cmdDeleteStop.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDeleteStop.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDeleteStop.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDeleteStop.Name = "cmdDeleteStop"
        Me.cmdDeleteStop.UseVisualStyleBackColor = False
        '
        'cmdReSeqStop
        '
        resources.ApplyResources(Me.cmdReSeqStop, "cmdReSeqStop")
        Me.cmdReSeqStop.BackColor = System.Drawing.SystemColors.Control
        Me.cmdReSeqStop.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdReSeqStop.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdReSeqStop.Name = "cmdReSeqStop"
        Me.cmdReSeqStop.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        resources.ApplyResources(Me.cmdCancel, "cmdCancel")
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdAddStop
        '
        resources.ApplyResources(Me.cmdAddStop, "cmdAddStop")
        Me.cmdAddStop.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddStop.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAddStop.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAddStop.Name = "cmdAddStop"
        Me.cmdAddStop.UseVisualStyleBackColor = False
        '
        'RouteGrid
        '
        Me.RouteGrid.AllowUserToAddRows = False
        Me.RouteGrid.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        Me.RouteGrid.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.RouteGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        resources.ApplyResources(Me.RouteGrid, "RouteGrid")
        Me.RouteGrid.Name = "RouteGrid"
        Me.RouteGrid.ReadOnly = True
        Me.RouteGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        '
        'frmLineFile
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.Controls.Add(Me.RouteGrid)
        Me.Controls.Add(Me.optInactive)
        Me.Controls.Add(Me.optActive)
        Me.Controls.Add(Me.cmdStopDetails)
        Me.Controls.Add(Me.cmdEditStop)
        Me.Controls.Add(Me.cmdDeleteStop)
        Me.Controls.Add(Me.cmdReSeqStop)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdAddStop)
        Me.Controls.Add(Me.cmdEditRoute)
        Me.Controls.Add(Me.txtRouteDes)
        Me.Controls.Add(Me.cmdCopyRoute)
        Me.Controls.Add(Me.cmdDeleteRoute)
        Me.Controls.Add(Me.cmdCreateRoute)
        Me.Controls.Add(Me.cboRouteDir)
        Me.Controls.Add(Me.cboRouteNo)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmLineFile"
        CType(Me.RouteGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents cmdEditRoute As Button
    Public WithEvents txtRouteDes As TextBox
    Public WithEvents cmdCopyRoute As Button
    Public WithEvents cmdDeleteRoute As Button
    Public WithEvents cmdCreateRoute As Button
    Public WithEvents cboRouteDir As ComboBox
    Public WithEvents cboRouteNo As ComboBox
    Public WithEvents Label3 As Label
    Public WithEvents Label2 As Label
    Public WithEvents Label1 As Label
    Public WithEvents optInactive As RadioButton
    Public WithEvents optActive As RadioButton
    Public WithEvents cmdStopDetails As Button
    Public WithEvents cmdEditStop As Button
    Public WithEvents cmdDeleteStop As Button
    Public WithEvents cmdReSeqStop As Button
    Public WithEvents cmdCancel As Button
    Public WithEvents cmdAddStop As Button
    Friend WithEvents RouteGrid As DataGridView
End Class
