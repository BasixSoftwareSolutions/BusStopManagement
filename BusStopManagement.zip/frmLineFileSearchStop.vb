﻿Public Class frmLineFileSearchStop
    Private Shared m_vb6FormDefInstance As frmLineFileSearchStop
    Private Shared m_InitializingDefInstance As Boolean
    Public rptIndex As Short

    Public Shared Property DefInstance() As frmLineFileSearchStop
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmLineFileSearchStop()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
    Private Sub cboSearchDir_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles cboSearchDir.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii = 13 Then
            cmdSearch_Click(cmdSearch, New System.EventArgs())
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub cboSearchLoc_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles cboSearchLoc.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii = 13 Then
            cmdSearch_Click(cmdSearch, New System.EventArgs())
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdClear_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClear.Click
        txtSearchOCTAID.Text = ""
        txtSearchSANZID.Text = ""
        cboSearchDir.SelectedIndex = -1
        cboSearchLoc.SelectedIndex = -1
        txtSearchStreet.Text = ""
        txtSearchXStreet.Text = ""
        lstResults.Items.Clear()
    End Sub

    Private Sub cmdSearch_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSearch.Click
        Dim rs As New ADODB.Recordset
        Dim strSQL As String
        Dim result As String
        Dim resultID As Short
        lstResults.DataSource = Nothing

        lstResults.DisplayMember = "result"
        lstResults.ValueMember = "resultID"

        Dim tb As New DataTable
        tb.Columns.Add("result", GetType(String))
        tb.Columns.Add("resultID", GetType(Integer))

        If optSearchBy0.Checked = True Then
            If txtSearchOCTAID.Text <> "" Then
                If IsNumeric(txtSearchOCTAID.Text) Then
                    strSQL = "SELECT info.OCTA_ID, dir.DIR, info.STREET_OF_TRAVEL, type1.TYPE AS stType, " _
                                & "loc.LOC, info.CROSS_STREET, type2.TYPE AS xStType, " _
                                & "info.CROSS_STREET_1, city.JURISDICTION, info.ACTIVE_STOP " _
                                & "FROM (((((tblBusStopInformation as [info] " _
                                & "INNER JOIN ST_DIR_CODE as [dir] ON info.ST_DIR_ID = dir.ID) " _
                                & "INNER JOIN BS_LOC_CODE as [loc] ON info.BS_LOC_ID = loc.ID) " _
                                & "INNER JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " _
                                & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                                & "INNER JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " _
                                & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " _
                                & "INNER JOIN CITY_CODE as [city] ON info.JURISDICTION_ID = city.ID) "

                    strSQL = strSQL & "WHERE info.OCTA_ID = " & txtSearchOCTAID.Text & " ORDER BY info.OCTA_ID"

                    rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)

                    If rs.RecordCount <> 0 Then
                        result = rs.Fields("OCTA_ID").Value & " -- " & rs.Fields("DIR").Value & " " & rs.Fields("STREET_OF_TRAVEL").Value
                        result = result & " " & rs.Fields("stType").Value
                        result = result & "/" & rs.Fields("LOC").Value & " " & rs.Fields("CROSS_STREET").Value
                        result = result & " " & rs.Fields("xStType").Value
                        result = result & IIf(IsDBNull(rs.Fields("CROSS_STREET_1").Value), "", " " & rs.Fields("CROSS_STREET_1").Value)
                        result = result & "; " & rs.Fields("JURISDICTION").Value

                        If IsDBNull(rs.Fields("ACTIVE_STOP").Value) Then
                            result = result & " (Inactive)"
                        Else
                            If Not rs.Fields("ACTIVE_STOP").Value Then
                                result = result & " (Inactive)"
                            End If
                        End If

                        resultID = CShort(rs.Fields("OCTA_ID").Value)
                        tb.Rows.Add(result, resultID)
                    Else
                        MsgBox("No records found.  Please try again.")
                    End If
                Else
                    MsgBox("OCTA ID is invalid.  Please try again.")
                End If
            Else
                MsgBox("Please enter an OCTA ID to search for.")
            End If
        ElseIf optSearchBy1.Checked = True Then
            If txtSearchSANZID.Text <> "" Then
                strSQL = "SELECT info.OCTA_ID, dir.DIR, info.STREET_OF_TRAVEL, type1.TYPE AS stType, " _
                        & "loc.LOC, info.CROSS_STREET, type2.TYPE AS xStType, " _
                        & "info.CROSS_STREET_1, city.JURISDICTION, info.ACTIVE_STOP " _
                        & "FROM (((((tblBusStopInformation as [info] " _
                        & "INNER JOIN ST_DIR_CODE as [dir] ON info.ST_DIR_ID = dir.ID) " _
                        & "INNER JOIN BS_LOC_CODE as [loc] ON info.BS_LOC_ID = loc.ID) " _
                        & "INNER JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " _
                        & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                        & "INNER JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " _
                        & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " _
                        & "INNER JOIN CITY_CODE as [city] ON info.JURISDICTION_ID = city.ID) "

                strSQL = strSQL & "WHERE info.SANZ_ID = " & addQuotes(txtSearchSANZID.Text) & " ORDER BY info.OCTA_ID"

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)

                If rs.RecordCount <> 0 Then
                    result = rs.Fields("OCTA_ID").Value & " -- " & rs.Fields("DIR").Value & " " & rs.Fields("STREET_OF_TRAVEL").Value
                    result = result & " " & rs.Fields("stType").Value
                    result = result & "/" & rs.Fields("LOC").Value & " " & rs.Fields("CROSS_STREET").Value
                    result = result & " " & rs.Fields("xStType").Value
                    result = result & IIf(IsDBNull(rs.Fields("CROSS_STREET_1").Value), "", " " & rs.Fields("CROSS_STREET_1").Value)
                    result = result & "; " & rs.Fields("JURISDICTION").Value

                    If IsDBNull(rs.Fields("ACTIVE_STOP").Value) Then
                        result = result & " (Inactive)"
                    Else
                        If Not rs.Fields("ACTIVE_STOP").Value Then
                            result = result & " (Inactive)"
                        End If
                    End If

                    resultID = CShort(rs.Fields("OCTA_ID").Value)
                    tb.Rows.Add(result, resultID)
                Else
                    MsgBox("No records found.  Please try again")
                End If
            Else
                MsgBox("Please enter a SANZ ID to search for.")
            End If
        ElseIf optSearchBy2.Checked = True Then
            If cboSearchDir.Text <> "" Or cboSearchLoc.Text <> "" Or txtSearchStreet.Text <> "" Or txtSearchXStreet.Text <> "" Then
                strSQL = "SELECT bus.OCTA_ID, dir.DIR, bus.STREET_OF_TRAVEL, type1.TYPE AS stType, " _
                    & "loc.LOC, bus.CROSS_STREET, type2.TYPE AS xStType, " _
                    & "bus.CROSS_STREET_1, city.JURISDICTION, bus.ACTIVE_STOP " _
                    & "FROM ((((tblBusStopInformation AS [bus] " _
                    & "LEFT JOIN ST_DIR_CODE AS [dir] on dir.id = bus.ST_DIR_ID) " _
                    & "LEFT JOIN BS_LOC_CODE AS [loc] on loc.id = bus.BS_LOC_ID) " _
                    & "LEFT JOIN ST_TYPE_CODE as [type1] ON ((bus.ST_TYPE_ID_1 = type1.ID) " _
                    & "OR (bus.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                    & "LEFT JOIN ST_TYPE_CODE as [type2] ON ((bus.ST_TYPE_ID_2 = type2.ID) " _
                    & "OR (bus.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " _
                    & "LEFT JOIN CITY_CODE AS [city] on city.ID = bus.JURISDICTION_ID WHERE "

                If cboSearchDir.Text <> "" Then
                    strSQL = strSQL & "st_dir_id = " & cboSearchDir.SelectedValue & " and "
                End If
                If cboSearchLoc.Text <> "" Then
                    strSQL = strSQL & "bs_loc_id = " & cboSearchLoc.SelectedValue & " and "
                End If
                If txtSearchStreet.Text <> "" Then
                    strSQL = strSQL & "Street_of_Travel = '" & Replace(txtSearchStreet.Text, "'", "''") & "' and "
                End If
                If txtSearchXStreet.Text <> "" Then
                    strSQL = strSQL & "Cross_Street = '" & Replace(txtSearchXStreet.Text, "'", "''") & "' and "
                End If

                strSQL = strSQL.Substring(0, Len(strSQL) - 4)
                strSQL = strSQL & " ORDER BY bus.OCTA_ID"
                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)

                If rs.RecordCount <> 0 Then
                    If rs.EOF = True Then
                        MsgBox("No records found.  Please try again")
                        Exit Sub
                    End If

                    Do While Not rs.EOF
                        result = rs.Fields("OCTA_ID").Value & " -- " & rs.Fields("DIR").Value & " " & rs.Fields("STREET_OF_TRAVEL").Value
                        result = result & " " & rs.Fields("stType").Value
                        result = result & "/" & rs.Fields("LOC").Value & " " & rs.Fields("CROSS_STREET").Value
                        result = result & " " & rs.Fields("xStType").Value
                        result = result & IIf(IsDBNull(rs.Fields("CROSS_STREET_1").Value), "", " " & rs.Fields("CROSS_STREET_1").Value)
                        result = result & "; " & rs.Fields("JURISDICTION").Value

                        If IsDBNull(rs.Fields("ACTIVE_STOP").Value) Then
                            result = result & " (Inactive)"
                        Else
                            If Not rs.Fields("ACTIVE_STOP").Value Then
                                result = result & " (Inactive)"
                            End If
                        End If
                        resultID = CShort(rs.Fields("OCTA_ID").Value)
                        tb.Rows.Add(result, resultID)
                        rs.MoveNext()
                    Loop
                Else
                    MsgBox("No records found.  Please try again")
                End If

            Else
                MsgBox("Please enter search criteria.")
            End If
        Else
            MsgBox("Try again!")
        End If

        tb.Rows.Add("", -1)
        lstResults.DataSource = tb
        lstResults.Enabled = True

        If lstResults.Items.Count <> 0 Then lstResults.SelectedIndex = 0

    End Sub


    Private Sub cmdSelect_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSelect.Click
        On Error GoTo errHandler

        Dim temp As String
        If lstResults.SelectedIndex <> -1 Then

            If rptIndex = 1 Then
                temp = CStr(lstResults.SelectedValue)

                If temp <> "" Then
                    frmRptStopModificationNotice.srchFlag = True
                    frmRptStopModificationNotice.OID = CShort(temp)
                Else
                    frmRptStopModificationNotice.srchFlag = False
                End If
            ElseIf rptIndex = 2 Then
                temp = CStr(lstResults.SelectedValue)
                If temp <> "" Then
                    frmRptDamageStopCostEstimate.srchFlag = True
                    frmRptDamageStopCostEstimate.OID = CShort(temp)
                Else
                    frmRptDamageStopCostEstimate.srchFlag = False
                End If
            ElseIf rptIndex = 3 Then
                temp = CStr(lstResults.SelectedValue)
                If temp <> "" Then
                    frmUpdateStop.OID = CShort(temp)
                End If
            End If

            Me.Close()
        Else
            MsgBox("Please select a stop.")
            Exit Sub
        End If

        OCTA_ID = CStr(lstResults.SelectedValue)

        Me.Close()

        frmLineFileAddStop.ShowDialog()
        Exit Sub

errHandler:
        frmUpdateStop.FindCheck = True
        Me.Close()
    End Sub

    Private Sub frmLineFileSearchStop_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Dim strSQL As String
        Dim rsCombo As New ADODB.Recordset

        strSQL = "SELECT DIR, ID FROM ST_DIR_CODE WHERE ACTIVE =1"

        cboSearchDir.DisplayMember = "DIR"
        cboSearchDir.ValueMember = "ID"
        Dim tb As New DataTable
        tb.Columns.Add("DIR", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rsCombo.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)

        If Not (rsCombo.EOF And rsCombo.BOF) Then
            rsCombo.MoveFirst()
            Do While rsCombo.EOF = False
                tb.Rows.Add(rsCombo.Fields("DIR").Value, rsCombo.Fields("ID").Value)
                rsCombo.MoveNext()
            Loop
        End If

        cboSearchDir.DataSource = tb
        cboSearchDir.SelectedIndex = -1
        rsCombo.Close()

        strSQL = "SELECT LOC, ID FROM BS_LOC_CODE WHERE ACTIVE =1"

        cboSearchLoc.DisplayMember = "LOC"
        cboSearchLoc.ValueMember = "ID"
        Dim tb2 As New DataTable
        tb2.Columns.Add("LOC", GetType(String))
        tb2.Columns.Add("ID", GetType(Integer))

        rsCombo.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)

        If Not (rsCombo.EOF And rsCombo.BOF) Then
            rsCombo.MoveFirst()
            Do While rsCombo.EOF = False
                tb2.Rows.Add(rsCombo.Fields("LOC").Value, rsCombo.Fields("ID").Value)
                rsCombo.MoveNext()
            Loop
        End If

        cboSearchLoc.DataSource = tb2
        cboSearchLoc.SelectedIndex = -1
        rsCombo.Close()

        rsCombo = Nothing

    End Sub

    Private Sub lstResults_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        Call cmdSelect_Click(cmdSelect, New System.EventArgs())
    End Sub

    Private Sub optSearchBy0_CheckedChanged(sender As Object, e As EventArgs) Handles optSearchBy0.CheckedChanged

        Call optSearchByCheckedChanged(0)

    End Sub
    Private Sub optSearchBy1_CheckedChanged(sender As Object, e As EventArgs) Handles optSearchBy1.CheckedChanged

        Call optSearchByCheckedChanged(1)

    End Sub
    Private Sub optSearchBy2_CheckedChanged(sender As Object, e As EventArgs) Handles optSearchBy2.CheckedChanged

        Call optSearchByCheckedChanged(2)

    End Sub

    Private Sub optSearchByCheckedChanged(iIndex As Integer)

        Select Case iIndex
            Case 0
                TxtEnabled(txtSearchOCTAID, True)
                txtSearchOCTAID.Focus()
                TxtEnabled(txtSearchSANZID, False)
                CboEnabled(cboSearchDir, False)
                CboEnabled(cboSearchLoc, False)
                TxtEnabled(txtSearchStreet, False)
                TxtEnabled(txtSearchXStreet, False)
                txtSearchSANZID.Text = ""
                cboSearchDir.SelectedIndex = -1
                cboSearchLoc.SelectedIndex = -1
                txtSearchStreet.Text = ""
                txtSearchXStreet.Text = ""

            Case 1
                TxtEnabled(txtSearchOCTAID, False)
                TxtEnabled(txtSearchSANZID, True)
                txtSearchSANZID.Focus()
                CboEnabled(cboSearchDir, False)
                CboEnabled(cboSearchLoc, False)
                TxtEnabled(txtSearchStreet, False)
                TxtEnabled(txtSearchXStreet, False)
                txtSearchOCTAID.Text = ""
                cboSearchDir.SelectedIndex = -1
                cboSearchLoc.SelectedIndex = -1
                txtSearchStreet.Text = ""
                txtSearchXStreet.Text = ""

            Case 2
                TxtEnabled(txtSearchOCTAID, False)
                TxtEnabled(txtSearchSANZID, False)
                CboEnabled(cboSearchDir, True)
                CboEnabled(cboSearchLoc, True)
                TxtEnabled(txtSearchStreet, True)
                cboSearchDir.Focus()
                TxtEnabled(txtSearchXStreet, True)
                txtSearchSANZID.Text = ""
                txtSearchOCTAID.Text = ""
        End Select

    End Sub

    Private Sub txtSearchOCTAID_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtSearchOCTAID.KeyPress

        If Asc(eventArgs.KeyChar) = 13 Then
            cmdSearch_Click(cmdSearch, New System.EventArgs())
        End If

    End Sub

    Private Sub txtSearchSANZID_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtSearchSANZID.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii = 13 Then
            cmdSearch_Click(cmdSearch, New System.EventArgs())
        Else
            If KeyAscii >= 97 And KeyAscii <= 122 Then
                KeyAscii = KeyAscii - 32
            End If
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If

    End Sub

    Private Sub txtSearchStreet_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtSearchStreet.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii = 13 Then
            cmdSearch_Click(cmdSearch, New System.EventArgs())
        Else
            If KeyAscii >= 97 And KeyAscii <= 122 Then
                KeyAscii = KeyAscii - 32
            End If
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtSearchXStreet_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtSearchXStreet.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii = 13 Then
            cmdSearch_Click(cmdSearch, New System.EventArgs())
        Else
            If KeyAscii >= 97 And KeyAscii <= 122 Then
                KeyAscii = KeyAscii - 32
            End If
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub lstResults_Click(sender As Object, e As EventArgs) Handles lstResults.Click

        If lstResults.SelectedItems.Count > 0 Then
            OCTA_ID = CStr(lstResults.SelectedValue)
            Me.Close()
            frmLineFileAddStop.DefInstance.ShowDialog()
        End If

    End Sub
End Class