﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWorkOrderCompletion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmWorkOrderCompletion))
        Me.cmdSubmit = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.Frame5 = New System.Windows.Forms.GroupBox()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Frame4 = New System.Windows.Forms.GroupBox()
        Me.cboCompletedBy = New System.Windows.Forms.ComboBox()
        Me.dtpCompDate = New System.Windows.Forms.DateTimePicker()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.txtCost = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Frame3 = New System.Windows.Forms.GroupBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtOCTAID = New System.Windows.Forms.TextBox()
        Me.txtLocation1 = New System.Windows.Forms.TextBox()
        Me.txtIssBy = New System.Windows.Forms.TextBox()
        Me.txtIssDate = New System.Windows.Forms.TextBox()
        Me.txtLocation3 = New System.Windows.Forms.TextBox()
        Me.txtLocation2 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.cbxNeedIns = New System.Windows.Forms.CheckBox()
        Me.cbxNeedGPS = New System.Windows.Forms.CheckBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmdSearch = New System.Windows.Forms.Button()
        Me.txtWONum = New System.Windows.Forms.TextBox()
        Me.cmdFindWO = New System.Windows.Forms.Button()
        Me.cmdClear = New System.Windows.Forms.Button()
        Me.frm = New System.Windows.Forms.Label()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.Frame5.SuspendLayout()
        Me.Frame4.SuspendLayout()
        Me.Frame3.SuspendLayout()
        Me.Frame2.SuspendLayout()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdSubmit
        '
        Me.cmdSubmit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSubmit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSubmit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSubmit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSubmit.Location = New System.Drawing.Point(419, 371)
        Me.cmdSubmit.Name = "cmdSubmit"
        Me.cmdSubmit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSubmit.Size = New System.Drawing.Size(65, 25)
        Me.cmdSubmit.TabIndex = 21
        Me.cmdSubmit.Text = "&Submit"
        Me.cmdSubmit.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(419, 397)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(65, 25)
        Me.cmdCancel.TabIndex = 22
        Me.cmdCancel.Text = "&Close"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'Frame5
        '
        Me.Frame5.BackColor = System.Drawing.Color.Transparent
        Me.Frame5.Controls.Add(Me.txtRemarks)
        Me.Frame5.Controls.Add(Me.Label7)
        Me.Frame5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame5.Location = New System.Drawing.Point(12, 276)
        Me.Frame5.Name = "Frame5"
        Me.Frame5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame5.Size = New System.Drawing.Size(489, 73)
        Me.Frame5.TabIndex = 27
        Me.Frame5.TabStop = False
        '
        'txtRemarks
        '
        Me.txtRemarks.AcceptsReturn = True
        Me.txtRemarks.BackColor = System.Drawing.SystemColors.Window
        Me.txtRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRemarks.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRemarks.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRemarks.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRemarks.Location = New System.Drawing.Point(80, 16)
        Me.txtRemarks.MaxLength = 255
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRemarks.Size = New System.Drawing.Size(401, 51)
        Me.txtRemarks.TabIndex = 10
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DimGray
        Me.Label7.Location = New System.Drawing.Point(8, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(62, 14)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "REMARKS:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Frame4
        '
        Me.Frame4.BackColor = System.Drawing.Color.Transparent
        Me.Frame4.Controls.Add(Me.cboCompletedBy)
        Me.Frame4.Controls.Add(Me.dtpCompDate)
        Me.Frame4.Controls.Add(Me.cmdAdd)
        Me.Frame4.Controls.Add(Me.txtCost)
        Me.Frame4.Controls.Add(Me.Label12)
        Me.Frame4.Controls.Add(Me.Label11)
        Me.Frame4.Controls.Add(Me.Label6)
        Me.Frame4.Controls.Add(Me.Label5)
        Me.Frame4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame4.Location = New System.Drawing.Point(13, 204)
        Me.Frame4.Name = "Frame4"
        Me.Frame4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame4.Size = New System.Drawing.Size(489, 65)
        Me.Frame4.TabIndex = 26
        Me.Frame4.TabStop = False
        '
        'cboCompletedBy
        '
        Me.cboCompletedBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCompletedBy.FormattingEnabled = True
        Me.cboCompletedBy.Location = New System.Drawing.Point(207, 29)
        Me.cboCompletedBy.Name = "cboCompletedBy"
        Me.cboCompletedBy.Size = New System.Drawing.Size(140, 22)
        Me.cboCompletedBy.TabIndex = 37
        '
        'dtpCompDate
        '
        Me.dtpCompDate.Location = New System.Drawing.Point(10, 31)
        Me.dtpCompDate.Name = "dtpCompDate"
        Me.dtpCompDate.Size = New System.Drawing.Size(187, 20)
        Me.dtpCompDate.TabIndex = 36
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAdd.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAdd.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAdd.Image = CType(resources.GetObject("cmdAdd.Image"), System.Drawing.Image)
        Me.cmdAdd.Location = New System.Drawing.Point(350, 29)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAdd.Size = New System.Drawing.Size(25, 22)
        Me.cmdAdd.TabIndex = 34
        Me.cmdAdd.Text = "+"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'txtCost
        '
        Me.txtCost.AcceptsReturn = True
        Me.txtCost.BackColor = System.Drawing.SystemColors.Window
        Me.txtCost.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCost.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCost.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCost.Location = New System.Drawing.Point(402, 31)
        Me.txtCost.MaxLength = 10
        Me.txtCost.Name = "txtCost"
        Me.txtCost.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCost.Size = New System.Drawing.Size(81, 20)
        Me.txtCost.TabIndex = 33
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label12.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(385, 31)
        Me.Label12.Name = "Label12"
        Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label12.Size = New System.Drawing.Size(18, 19)
        Me.Label12.TabIndex = 32
        Me.Label12.Text = "$"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.DimGray
        Me.Label11.Location = New System.Drawing.Point(399, 11)
        Me.Label11.Name = "Label11"
        Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label11.Size = New System.Drawing.Size(39, 14)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "COST:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DimGray
        Me.Label6.Location = New System.Drawing.Point(7, 11)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(111, 14)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "COMPLETION DATE:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DimGray
        Me.Label5.Location = New System.Drawing.Point(204, 11)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(92, 14)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "COMPLETED BY:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Frame3
        '
        Me.Frame3.BackColor = System.Drawing.Color.Transparent
        Me.Frame3.Controls.Add(Me.txtCity)
        Me.Frame3.Controls.Add(Me.txtOCTAID)
        Me.Frame3.Controls.Add(Me.txtLocation1)
        Me.Frame3.Controls.Add(Me.txtIssBy)
        Me.Frame3.Controls.Add(Me.txtIssDate)
        Me.Frame3.Controls.Add(Me.txtLocation3)
        Me.Frame3.Controls.Add(Me.txtLocation2)
        Me.Frame3.Controls.Add(Me.Label10)
        Me.Frame3.Controls.Add(Me.Label9)
        Me.Frame3.Controls.Add(Me.Label3)
        Me.Frame3.Controls.Add(Me.Label4)
        Me.Frame3.Controls.Add(Me.Label2)
        Me.Frame3.Controls.Add(Me.Label1)
        Me.Frame3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame3.Location = New System.Drawing.Point(12, 68)
        Me.Frame3.Name = "Frame3"
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Size = New System.Drawing.Size(489, 129)
        Me.Frame3.TabIndex = 25
        Me.Frame3.TabStop = False
        '
        'txtCity
        '
        Me.txtCity.AcceptsReturn = True
        Me.txtCity.BackColor = System.Drawing.SystemColors.Window
        Me.txtCity.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCity.Location = New System.Drawing.Point(432, 80)
        Me.txtCity.MaxLength = 0
        Me.txtCity.Name = "txtCity"
        Me.txtCity.ReadOnly = True
        Me.txtCity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCity.Size = New System.Drawing.Size(41, 20)
        Me.txtCity.TabIndex = 8
        '
        'txtOCTAID
        '
        Me.txtOCTAID.AcceptsReturn = True
        Me.txtOCTAID.BackColor = System.Drawing.SystemColors.Window
        Me.txtOCTAID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtOCTAID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOCTAID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOCTAID.Location = New System.Drawing.Point(72, 16)
        Me.txtOCTAID.MaxLength = 0
        Me.txtOCTAID.Name = "txtOCTAID"
        Me.txtOCTAID.ReadOnly = True
        Me.txtOCTAID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtOCTAID.Size = New System.Drawing.Size(41, 20)
        Me.txtOCTAID.TabIndex = 3
        '
        'txtLocation1
        '
        Me.txtLocation1.AcceptsReturn = True
        Me.txtLocation1.BackColor = System.Drawing.SystemColors.Window
        Me.txtLocation1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLocation1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLocation1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLocation1.Location = New System.Drawing.Point(144, 56)
        Me.txtLocation1.MaxLength = 0
        Me.txtLocation1.Name = "txtLocation1"
        Me.txtLocation1.ReadOnly = True
        Me.txtLocation1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLocation1.Size = New System.Drawing.Size(265, 20)
        Me.txtLocation1.TabIndex = 6
        '
        'txtIssBy
        '
        Me.txtIssBy.AcceptsReturn = True
        Me.txtIssBy.BackColor = System.Drawing.SystemColors.Window
        Me.txtIssBy.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtIssBy.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIssBy.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtIssBy.Location = New System.Drawing.Point(360, 16)
        Me.txtIssBy.MaxLength = 0
        Me.txtIssBy.Name = "txtIssBy"
        Me.txtIssBy.ReadOnly = True
        Me.txtIssBy.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtIssBy.Size = New System.Drawing.Size(121, 20)
        Me.txtIssBy.TabIndex = 5
        '
        'txtIssDate
        '
        Me.txtIssDate.AcceptsReturn = True
        Me.txtIssDate.BackColor = System.Drawing.SystemColors.Window
        Me.txtIssDate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtIssDate.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIssDate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtIssDate.Location = New System.Drawing.Point(208, 16)
        Me.txtIssDate.MaxLength = 0
        Me.txtIssDate.Name = "txtIssDate"
        Me.txtIssDate.ReadOnly = True
        Me.txtIssDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtIssDate.Size = New System.Drawing.Size(65, 20)
        Me.txtIssDate.TabIndex = 4
        '
        'txtLocation3
        '
        Me.txtLocation3.AcceptsReturn = True
        Me.txtLocation3.BackColor = System.Drawing.SystemColors.Window
        Me.txtLocation3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLocation3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLocation3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLocation3.Location = New System.Drawing.Point(144, 104)
        Me.txtLocation3.MaxLength = 0
        Me.txtLocation3.Name = "txtLocation3"
        Me.txtLocation3.ReadOnly = True
        Me.txtLocation3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLocation3.Size = New System.Drawing.Size(265, 20)
        Me.txtLocation3.TabIndex = 9
        '
        'txtLocation2
        '
        Me.txtLocation2.AcceptsReturn = True
        Me.txtLocation2.BackColor = System.Drawing.SystemColors.Window
        Me.txtLocation2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLocation2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLocation2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLocation2.Location = New System.Drawing.Point(144, 80)
        Me.txtLocation2.MaxLength = 0
        Me.txtLocation2.Name = "txtLocation2"
        Me.txtLocation2.ReadOnly = True
        Me.txtLocation2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLocation2.Size = New System.Drawing.Size(265, 20)
        Me.txtLocation2.TabIndex = 7
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DimGray
        Me.Label10.Location = New System.Drawing.Point(429, 59)
        Me.Label10.Name = "Label10"
        Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label10.Size = New System.Drawing.Size(34, 14)
        Me.Label10.TabIndex = 30
        Me.Label10.Text = "CITY:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.DimGray
        Me.Label9.Location = New System.Drawing.Point(40, 80)
        Me.Label9.Name = "Label9"
        Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label9.Size = New System.Drawing.Size(89, 14)
        Me.Label9.TabIndex = 29
        Me.Label9.Text = "CROSS STREET:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(288, 19)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(63, 14)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "ISSUED BY:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(128, 19)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(70, 14)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "ISSUE DATE:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(20, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(109, 14)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "STREET of TRAVEL:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(16, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(53, 14)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "OCTA ID:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.Color.Transparent
        Me.Frame2.Controls.Add(Me.cbxNeedIns)
        Me.Frame2.Controls.Add(Me.cbxNeedGPS)
        Me.Frame2.Controls.Add(Me.Label8)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(12, 356)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(376, 73)
        Me.Frame2.TabIndex = 24
        Me.Frame2.TabStop = False
        '
        'cbxNeedIns
        '
        Me.cbxNeedIns.BackColor = System.Drawing.Color.Transparent
        Me.cbxNeedIns.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxNeedIns.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxNeedIns.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxNeedIns.ForeColor = System.Drawing.Color.DimGray
        Me.cbxNeedIns.Location = New System.Drawing.Point(194, 40)
        Me.cbxNeedIns.Name = "cbxNeedIns"
        Me.cbxNeedIns.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxNeedIns.Size = New System.Drawing.Size(164, 17)
        Me.cbxNeedIns.TabIndex = 12
        Me.cbxNeedIns.Text = "NEED PERMANENT INSERT"
        Me.cbxNeedIns.UseVisualStyleBackColor = False
        '
        'cbxNeedGPS
        '
        Me.cbxNeedGPS.BackColor = System.Drawing.Color.Transparent
        Me.cbxNeedGPS.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbxNeedGPS.Cursor = System.Windows.Forms.Cursors.Default
        Me.cbxNeedGPS.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxNeedGPS.ForeColor = System.Drawing.Color.DimGray
        Me.cbxNeedGPS.Location = New System.Drawing.Point(7, 40)
        Me.cbxNeedGPS.Name = "cbxNeedGPS"
        Me.cbxNeedGPS.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cbxNeedGPS.Size = New System.Drawing.Size(125, 17)
        Me.cbxNeedGPS.TabIndex = 11
        Me.cbxNeedGPS.Text = "NEED GPS SURVEY"
        Me.cbxNeedGPS.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DimGray
        Me.Label8.Location = New System.Drawing.Point(8, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(178, 16)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "FOLLOW-UP WORK REQUIRED:"
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.cmdSearch)
        Me.Frame1.Controls.Add(Me.txtWONum)
        Me.Frame1.Controls.Add(Me.cmdFindWO)
        Me.Frame1.Controls.Add(Me.cmdClear)
        Me.Frame1.Controls.Add(Me.frm)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(12, 12)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(489, 49)
        Me.Frame1.TabIndex = 23
        Me.Frame1.TabStop = False
        '
        'cmdSearch
        '
        Me.cmdSearch.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSearch.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSearch.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSearch.Location = New System.Drawing.Point(297, 14)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSearch.Size = New System.Drawing.Size(129, 25)
        Me.cmdSearch.TabIndex = 37
        Me.cmdSearch.Text = "Search &Open WO"
        Me.cmdSearch.UseVisualStyleBackColor = False
        '
        'txtWONum
        '
        Me.txtWONum.AcceptsReturn = True
        Me.txtWONum.BackColor = System.Drawing.SystemColors.Window
        Me.txtWONum.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtWONum.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWONum.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWONum.Location = New System.Drawing.Point(96, 16)
        Me.txtWONum.MaxLength = 9
        Me.txtWONum.Name = "txtWONum"
        Me.txtWONum.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtWONum.Size = New System.Drawing.Size(57, 20)
        Me.txtWONum.TabIndex = 0
        '
        'cmdFindWO
        '
        Me.cmdFindWO.BackColor = System.Drawing.SystemColors.Control
        Me.cmdFindWO.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdFindWO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdFindWO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdFindWO.Location = New System.Drawing.Point(161, 14)
        Me.cmdFindWO.Name = "cmdFindWO"
        Me.cmdFindWO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdFindWO.Size = New System.Drawing.Size(129, 25)
        Me.cmdFindWO.TabIndex = 1
        Me.cmdFindWO.Text = "&Get Work Order"
        Me.cmdFindWO.UseVisualStyleBackColor = False
        '
        'cmdClear
        '
        Me.cmdClear.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClear.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClear.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClear.Location = New System.Drawing.Point(432, 14)
        Me.cmdClear.Name = "cmdClear"
        Me.cmdClear.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClear.Size = New System.Drawing.Size(49, 25)
        Me.cmdClear.TabIndex = 2
        Me.cmdClear.Text = "C&lear"
        Me.cmdClear.UseVisualStyleBackColor = False
        '
        'frm
        '
        Me.frm.BackColor = System.Drawing.Color.Transparent
        Me.frm.Cursor = System.Windows.Forms.Cursors.Default
        Me.frm.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frm.ForeColor = System.Drawing.Color.DimGray
        Me.frm.Location = New System.Drawing.Point(8, 17)
        Me.frm.Name = "frm"
        Me.frm.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frm.Size = New System.Drawing.Size(89, 17)
        Me.frm.TabIndex = 20
        Me.frm.Text = "ENTER W.O.#"
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(402, 364)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(99, 65)
        Me.Shape1.TabIndex = 28
        '
        'frmWorkOrderCompletion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(517, 446)
        Me.Controls.Add(Me.cmdSubmit)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.Frame5)
        Me.Controls.Add(Me.Frame4)
        Me.Controls.Add(Me.Frame3)
        Me.Controls.Add(Me.Frame2)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Shape1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmWorkOrderCompletion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Work Order Completion"
        Me.Frame5.ResumeLayout(False)
        Me.Frame5.PerformLayout()
        Me.Frame4.ResumeLayout(False)
        Me.Frame4.PerformLayout()
        Me.Frame3.ResumeLayout(False)
        Me.Frame3.PerformLayout()
        Me.Frame2.ResumeLayout(False)
        Me.Frame2.PerformLayout()
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents cmdSubmit As Button
    Public WithEvents cmdCancel As Button
    Public WithEvents Frame5 As GroupBox
    Public WithEvents txtRemarks As TextBox
    Public WithEvents Label7 As Label
    Public WithEvents Frame4 As GroupBox
    Public WithEvents cmdAdd As Button
    Public WithEvents txtCost As TextBox
    Public WithEvents Label12 As Label
    Public WithEvents Label11 As Label
    Public WithEvents Label6 As Label
    Public WithEvents Label5 As Label
    Public WithEvents Frame3 As GroupBox
    Public WithEvents txtCity As TextBox
    Public WithEvents txtOCTAID As TextBox
    Public WithEvents txtLocation1 As TextBox
    Public WithEvents txtIssBy As TextBox
    Public WithEvents txtIssDate As TextBox
    Public WithEvents txtLocation3 As TextBox
    Public WithEvents txtLocation2 As TextBox
    Public WithEvents Label10 As Label
    Public WithEvents Label9 As Label
    Public WithEvents Label3 As Label
    Public WithEvents Label4 As Label
    Public WithEvents Label2 As Label
    Public WithEvents Label1 As Label
    Public WithEvents Frame2 As GroupBox
    Public WithEvents cbxNeedIns As CheckBox
    Public WithEvents cbxNeedGPS As CheckBox
    Public WithEvents Label8 As Label
    Public WithEvents Frame1 As GroupBox
    Public WithEvents cmdSearch As Button
    Public WithEvents txtWONum As TextBox
    Public WithEvents cmdFindWO As Button
    Public WithEvents cmdClear As Button
    Public WithEvents frm As Label
    Public WithEvents Shape1 As Label
    Friend WithEvents dtpCompDate As DateTimePicker
    Friend WithEvents cboCompletedBy As ComboBox
End Class
