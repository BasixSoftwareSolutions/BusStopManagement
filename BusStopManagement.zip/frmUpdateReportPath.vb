﻿Public Class frmUpdateReportPath
    Private Sub cmdExit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExit.Click
        Me.Close()
    End Sub

    Private Sub frmUpdateReportPath_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        txtWO.Text = GetAppValue("WorkOrderReportPath")
        txtDSCE.Text = GetAppValue("DamageStopCostEstReportPath")
        txtSMO.Text = GetAppValue("StopModNoticeReportPath")

    End Sub

    Private Sub cmdWO_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdWO.Click
        On Error GoTo errHandler

        Dim str_Renamed As String
        Dim strSQL As String

        str_Renamed = frmPathUpdate.FolderOnly(Me.Handle.ToInt32)

        If str_Renamed <> "" Then
            str_Renamed = str_Renamed & "\"
            txtWO.Text = str_Renamed
            strSQL = "UPDATE dbo.tblAppValues SET Value = '" & str_Renamed & "' WHERE Name = 'WorkOrderReportPath'"
            db.Execute(strSQL)
            MsgBox("The Report Path has been updated to " & vbCrLf & str_Renamed & "", MsgBoxStyle.Information, "Path Updated")
        End If

        Exit Sub

errHandler:
        MsgBox(Err.Description)
    End Sub

    Private Sub cmdSMO_Click(sender As Object, e As EventArgs) Handles cmdSMO.Click
        On Error GoTo errHandler

        Dim str_Renamed As String
        Dim strSQL As String

        str_Renamed = frmPathUpdate.FolderOnly(Me.Handle.ToInt32)

        If str_Renamed <> "" Then
            str_Renamed = str_Renamed & "\"
            txtSMO.Text = str_Renamed
            strSQL = "UPDATE dbo.tblAppValues SET Value = '" & str_Renamed & "' WHERE Name = 'StopModNoticeReportPath'"
            db.Execute(strSQL)
            MsgBox("The Report Path has been updated to " & vbCrLf & str_Renamed & "", MsgBoxStyle.Information, "Path Updated")
        End If

        Exit Sub

errHandler:
        MsgBox(Err.Description)
    End Sub

    Private Sub cmdDSCE_Click(sender As Object, e As EventArgs) Handles cmdDSCE.Click
        On Error GoTo errHandler

        Dim str_Renamed As String
        Dim strSQL As String

        str_Renamed = frmPathUpdate.FolderOnly(Me.Handle.ToInt32)

        If str_Renamed <> "" Then
            str_Renamed = str_Renamed & "\"
            txtDSCE.Text = str_Renamed
            strSQL = "UPDATE dbo.tblAppValues SET Value = '" & str_Renamed & "' WHERE Name = 'DamageStopCostEstReportPath'"
            db.Execute(strSQL)
            MsgBox("The Report Path has been updated to " & vbCrLf & str_Renamed & "", MsgBoxStyle.Information, "Path Updated")
        End If

        Exit Sub

errHandler:
        MsgBox(Err.Description)
    End Sub
End Class