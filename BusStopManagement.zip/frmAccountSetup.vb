﻿Imports System.Data.SqlClient
Public Class frmAccountSetup

    'Private dataAdapter As New SqlDataAdapter()

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click

        Me.Close()

    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click

        Try

            Me.Validate()
            Me.TblStaffBindingSource.EndEdit()
            Me.TblStaffTableAdapter.Update(Me.DsStaff.tblStaff)
            'CreateObject("WScript.Shell").Popup("Update successful", 1, "Saved")
            MsgBox("Update successful", vbInformation, "Saved")

        Catch ex As Exception
            MsgBox(Err.Description)
        End Try

    End Sub

    Private Sub frmAccountSetup_Load(sender As Object, e As EventArgs) Handles Me.Load

        Me.TblStaffTableAdapter.Fill(Me.DsStaff.tblStaff)

    End Sub

    Private Sub tdgAccount_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles tdgAccount.CellEndEdit

        If tdgAccount.CurrentCell.Value Is DBNull.Value Then
            Exit Sub
        End If

        Dim strUpperValue As String

        strUpperValue = tdgAccount.CurrentCell.Value
        tdgAccount.CurrentCell.Value = strUpperValue.ToUpper

    End Sub

End Class