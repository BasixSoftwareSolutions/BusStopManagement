﻿Partial Class dsStopHistory
End Class
