﻿Public Class frmLineFileAddStop
    Private Shared m_vb6FormDefInstance As frmLineFileAddStop
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmLineFileAddStop
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmLineFileAddStop()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property

    Private Sub SetStopInfo()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT bsi.SANZ_ID, sdc.DIR, (bsi.STREET_OF_TRAVEL " &
             "+ ' ' + stc1.TYPE) AS FULL_STREET, blc.LOC, (bsi.CROSS_STREET " &
             "+ ' ' + stc2.TYPE) AS FULL_XSTREET, bsi.CROSS_STREET_1 " &
             "FROM (((tblBusStopInformation AS bsi " &
             "LEFT JOIN ST_DIR_CODE AS sdc ON bsi.ST_DIR_ID = sdc.ID) " &
             "LEFT JOIN ST_TYPE_CODE AS stc1 ON ((bsi.ST_TYPE_ID_1 = stc1.ID) OR " &
             "(bsi.ST_TYPE_ID_1 IS NULL AND stc1.ID = 0))) " &
             "LEFT JOIN BS_LOC_CODE AS blc ON bsi.BS_LOC_ID = blc.ID) " &
             "LEFT JOIN ST_TYPE_CODE AS stc2 ON ((bsi.ST_TYPE_ID_2 = stc2.ID) OR " &
             "(bsi.ST_TYPE_ID_2 IS NULL AND stc2.ID = 0)) " &
             " WHERE bsi.OCTA_ID = " & OCTA_ID

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not rs.EOF Then
            txtOCTA_ID.Text = CStr(OCTA_ID)
            txtSANZ_ID.Text = rs.Fields("SANZ_ID").Value
            txtDIR.Text = rs.Fields("DIR").Value
            txtStreet.Text = Replace(rs.Fields("FULL_STREET").Value, "_", "")
            txtLOC.Text = rs.Fields("LOC").Value
            txtXStreet.Text = Replace(rs.Fields("FULL_XSTREET").Value, "_", "") & IIf(IsDBNull(rs.Fields("CROSS_STREET_1").Value), "", " " & rs.Fields("CROSS_STREET_1").Value)
        Else
            MsgBox("Unable to find stop information for stop: " & OCTA_ID & "")
        End If

        rs.Close()
        rs = Nothing

    End Sub

    Private Sub cboSequenceNo_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles cboSequenceNo.KeyPress

        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If

        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If

    End Sub

    Private Sub cmdAddStop_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAddStop.Click

        If optTimePoint0.Checked Then
            If cboTPID.SelectedIndex = -1 Then
                MsgBox("Please select a value for Time Point ID.")
                cboTPID.Focus()
                Exit Sub
            End If

            If Trim(txtTPDesc.Text) = "" Then
                MsgBox("Please enter a value for Time Point Description.")
                'txtTPDesc.SetFocus
                Exit Sub
            End If
        End If

        If Not SeqNoOK() Then
            Exit Sub
        End If


        If cboHardware.SelectedIndex = -1 Then
            MsgBox("Please select a hardware type from the list.")
            Exit Sub
        End If

        ' now ready to add stop to route...
        AddStop2Route()

        Me.Close()

    End Sub

    Private Function SeqNoOK() As Boolean
        Dim bln As Boolean
        Dim intSN As Short

        If Not IsNumeric(cboSequenceNo.Text) Then
            MsgBox("Please enter a numeric value for sequence number.", MsgBoxStyle.Exclamation)
            SeqNoOK = False
            Exit Function
        Else
            On Error GoTo errHandler
            intSN = CShort(cboSequenceNo.Text)
        End If

        bln = True
        If SeqLowerBound <> 0 And SeqUpperBound <> 0 Then
            On Error GoTo errHandler
            If intSN <= SeqLowerBound Or intSN >= SeqUpperBound Then
                If frmLineFile.RouteGrid.CurrentRow.Index = 0 And intSN < SeqLowerBound And intSN <> 0 Then
                    'do nothing, condition is relaxed, stop can be added in 1st position
                Else
                    MsgBox("Please select a valid sequence number from the list.", MsgBoxStyle.Exclamation)
                    bln = False
                End If
            End If

        ElseIf SeqLowerBound = 0 And SeqUpperBound = 0 Then
            ' do nothing...
        ElseIf SeqUpperBound = 0 Then
            On Error GoTo errHandler
            If intSN <= SeqLowerBound Then
                MsgBox("Please enter a value bigger than " & SeqLowerBound & ".", MsgBoxStyle.Exclamation)
                bln = False
            End If
        End If

        SeqNoOK = bln

        Exit Function
errHandler:
        MsgBox("Invalid Value")

        Exit Function

    End Function

    Private Sub AddStop2Route()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim bIsTimePoint As Integer = 0

        bIsTimePoint = IIf(optTimePoint0.Checked, 1, 0)

        If optTimePoint0.Checked Then
            If cboComment.SelectedIndex <> -1 Then
                strSQL = "INSERT INTO tblBusStopSequences(RTE, RTE_DIR_ID, SEQ, OCTA_ID, SANZ_ID, " _
                     & "PLACE_ID, PLACE_DESCRIPTION, " _
                     & "TIMEPOINT, STOPTYPE, HARDWARE, TRANSFERS, [COMMENTS]) VALUES (" _
                     & frmLineFile.cboRouteNo.Text & ", " _
                     & frmLineFile.cboRouteDir.SelectedValue & ", " _
                     & cboSequenceNo.Text & ", " & txtOCTA_ID.Text & ", '" & txtSANZ_ID.Text & "', " _
                     & cV2Q_String(cboTPID.Text) & ", " & cV2Q_String(txtTPDesc.Text) & ", " _
                     & bIsTimePoint & ", 0, " & cboHardware.Text & ", " _
                     & cV2Q_String(txtTransferInfo.Text) & ", " _
                     & cV2Q_String(cboComment.SelectedText) & ")"
            Else
                strSQL = "INSERT INTO tblBusStopSequences(RTE, RTE_DIR_ID, SEQ, OCTA_ID, SANZ_ID, " _
                     & "PLACE_ID, PLACE_DESCRIPTION, " _
                     & "TIMEPOINT, STOPTYPE, HARDWARE, TRANSFERS) VALUES (" _
                     & frmLineFile.cboRouteNo.Text & ", " _
                     & frmLineFile.cboRouteDir.SelectedValue & ", " _
                     & cboSequenceNo.Text & ", " & txtOCTA_ID.Text & ", '" & txtSANZ_ID.Text & "', " _
                     & cV2Q_String(cboTPID.Text) & ", " & cV2Q_String(txtTPDesc.Text) & ", " _
                     & bIsTimePoint & ", 0, " & cboHardware.Text & ", " _
                     & cV2Q_String(txtTransferInfo.Text) & ")"
            End If
        Else
            If cboComment.SelectedIndex <> -1 Then
                strSQL = "INSERT INTO tblBusStopSequences(RTE, RTE_DIR_ID, SEQ, OCTA_ID, SANZ_ID, " _
                     & "TIMEPOINT, STOPTYPE, HARDWARE, TRANSFERS, [COMMENTS]) VALUES (" _
                     & frmLineFile.cboRouteNo.Text & ", " _
                     & frmLineFile.cboRouteDir.SelectedValue & ", " _
                     & cboSequenceNo.Text & ", " & txtOCTA_ID.Text & ", '" & txtSANZ_ID.Text & "', " _
                     & bIsTimePoint & ", 0, " & cboHardware.Text & ", " _
                     & cV2Q_String(txtTransferInfo.Text) & ", " _
                     & cV2Q_String(cboComment.SelectedText) & ")"
            Else
                strSQL = "INSERT INTO tblBusStopSequences(RTE, RTE_DIR_ID, SEQ, OCTA_ID, SANZ_ID, " _
                     & "TIMEPOINT, STOPTYPE, HARDWARE, TRANSFERS) VALUES (" _
                     & frmLineFile.cboRouteNo.Text & ", " _
                     & frmLineFile.cboRouteDir.SelectedValue & ", " _
                     & cboSequenceNo.Text & ", " & txtOCTA_ID.Text & ", '" & txtSANZ_ID.Text & "', " _
                     & bIsTimePoint & ", 0, " & cboHardware.Text & ", " _
                     & cV2Q_String(txtTransferInfo.Text) & ")"
            End If
        End If

        db.Execute(strSQL)

        ' Set Stop status to active...
        strSQL = "SELECT ACTIVE_STOP FROM tblBusStopInformation " & "WHERE OCTA_ID = " & txtOCTA_ID.Text
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
        Dim myDate As Date
        If Not rs.EOF Then
            myDate = Today
            If rs.Fields(0).Value = 0 Then
                strSQL = "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " _
                        & "HISTORY_TYPE_ID, REMARKS) VALUES (" & txtOCTA_ID.Text & ",'" & txtSANZ_ID.Text & "','" _
                        & myDate & "','" & CurrentLoginUserID & "'," & "26,'" & "BUS STOP STATUS HAS CHANGED " _
                        & "AND IS NOW AN ACTIVE STOP" & "');"

                db.Execute(strSQL)
            End If
        End If
        rs.Close()


        strSQL = "UPDATE tblBusStopInformation SET ACTIVE_STOP = 1 " & "WHERE OCTA_ID = " & txtOCTA_ID.Text
        db.Execute(strSQL)

        strSQL = "UPDATE tblSignCassette SET PERM_INSERT = " & 1 & ", UPCOMING_CHANGE = " & 1 & " WHERE OCTA_ID = " & txtOCTA_ID.Text
        db.Execute(strSQL)

        ' Check if stop added has GPS information...
        strSQL = "SELECT * FROM tblStopCoord WHERE OCTA_ID = " & txtOCTA_ID.Text & " AND EASTING <> 0 AND NORTHING <> 0"

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
        If rs.EOF Then
            MsgBox("Stop: " & txtOCTA_ID.Text & " has no GPS information!", MsgBoxStyle.Exclamation, "WARNING!!!")
            ' Added by Anuket 8/23/04
            strSQL = "UPDATE tblStopCoord " & "SET GPS_REQUIRED = 1 WHERE OCTA_ID = " & txtOCTA_ID.Text
            db.Execute(strSQL)
        End If
        rs.Close()


        ' Stop History entry
        Dim remarks As String
        Dim rteDir As String

        strSQL = "SELECT DIR FROM ROUTE_DIR_CODE WHERE DESCRIPTION = '" & frmLineFile.cboRouteDir.Text & "'"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
        rs.MoveFirst()

        rteDir = rs.Fields(0).Value

        rs.Close()

        remarks = "BUS STOP WAS ADDED TO ROUTE " & frmLineFile.cboRouteNo.Text & " " & rteDir

        strSQL = "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " &
            "HISTORY_TYPE_ID, REMARKS) VALUES (" & txtOCTA_ID.Text & ",'" & txtSANZ_ID.Text & "','" &
            myDate & "','" & CurrentLoginUserID & "'," & "26,'" & remarks & "')"

        db.Execute(strSQL)

        rs = Nothing

        Call frmLineFile.LoadStops4Route(CShort(frmLineFile.cboRouteNo.Text), frmLineFile.cboRouteDir.SelectedValue)
    End Sub


    Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
        Me.Close()
    End Sub

    Private Sub frmLineFileAddStop_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Dim i As Short

        ' Route
        lblRouteInfo.Text = "Route Information: " & ROUTE_ID & " - " & DIR_DESC & " - " & ROUTE_DESC

        ' new stop information
        SetStopInfo()

        ' Time Point
        optTimePoint1.Checked = True

        ' Sequence Number
        For i = SeqLowerBound + 1 To SeqUpperBound - 1
            cboSequenceNo.Items.Add(CStr(i))
        Next

        ' Hardware
        LoadHardware()

        ' Comments
        LoadComment()

    End Sub

    Private Sub LoadHardware()

        cboHardware.Items.Clear()
        cboHardware.Items.Add(CStr(0))
        cboHardware.Items.Add(CStr(9))

    End Sub

    Private Sub LoadLandmarks()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT lmc.DESCRIPTION FROM tblBusStopLandmarks AS bsl " &
             "LEFT JOIN BS_LANDMARK_CODE AS lmc ON bsl.LANDMARK_ID = lmc.ID " &
             "WHERE bsl.OCTA_ID = " & txtOCTA_ID.Text & " AND " &
             "bsl.RTE = " & frmLineFile.cboRouteNo.Text & " AND " &
             "bsl.DIRECTION = '" & frmLineFile.cboRouteDir.Text &
             "' ORDER BY lmc.DESCRIPTION"

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount < 1 Then
            lstLandmarks.Items.Clear()
        End If

        Do While Not rs.EOF
            lstLandmarks.Items.Add(rs.Fields("DESCRIPTION").Value)
            rs.MoveNext()
        Loop

        rs.Close()
        rs = Nothing

    End Sub

    Private Sub LoadComment()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT * FROM ROUTE_COMMENT_CODE WHERE ACTIVE =1 ORDER BY ID"
        cboComment.DisplayMember = "DESCRIPTION"
        cboComment.ValueMember = "ID"

        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))
        tb.Rows.Add("", -1)

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If

        cboComment.DataSource = tb
        cboComment.Enabled = True

        rs.Close()
        rs = Nothing

    End Sub

    Private Sub txtTPDesc_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtTPDesc.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtTPID_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtTPID.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtTransferInfo_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtTransferInfo.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub cmdAddLandmark_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAddLandmark.Click
        frmBSLandmarks.ShowDialog()
        LoadLandmarks()
    End Sub

    Private Sub optTimePoint_CheckedChanged(ByVal iIndex As Integer)

        If iIndex = 0 Then
            cboTPID.Enabled = True
            LoadTimePt()
        Else
            txtTPDesc.Text = ""
            cboTPID.Items.Clear()
            cboTPID.Enabled = False
        End If

    End Sub

    Private Sub LoadTimePt()
        Dim rs As New ADODB.Recordset
        Dim strSQL As String
        strSQL = "SELECT * FROM TIME_POINT_DESC"
        Dim i As Short

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

        If Not rs.EOF Then
            txtTPDesc.Text = ""
            cboTPID.Items.Clear()
            cboTPID.Enabled = True
            rs.MoveFirst()

            For i = 0 To rs.RecordCount - 1
                If Not IsDBNull(rs.Fields("PlaceName").Value) Then
                    cboTPID.Items.Add(rs.Fields("PlaceName").Value)
                End If
                rs.MoveNext()
            Next i
        End If
        rs.Close()
    End Sub

    Private Sub cboTPID_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboTPID.SelectedIndexChanged

        If cboTPID.SelectedIndex < 0 Then
            txtTPDesc.Text = ""
            Exit Sub
        End If

        Dim rs As New ADODB.Recordset
        Dim strSQL As String
        strSQL = "SELECT * FROM TIME_POINT_DESC"
        Dim i As Short

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

        If Not rs.EOF Then

            rs.MoveFirst()

            For i = 0 To rs.RecordCount - 1
                If rs.Fields("PlaceName").Value = cboTPID.Text Then
                    txtTPDesc.Text = rs.Fields("Description").Value
                End If
                rs.MoveNext()
            Next i
        End If
        rs.Close()


    End Sub

    Private Sub optTimePoint1_CheckedChanged(sender As Object, e As EventArgs) Handles optTimePoint1.CheckedChanged

        Call optTimePoint_CheckedChanged(1)

    End Sub

    Private Sub optTimePoint0_CheckedChanged(sender As Object, e As EventArgs) Handles optTimePoint0.CheckedChanged

        Call optTimePoint_CheckedChanged(0)

    End Sub
End Class