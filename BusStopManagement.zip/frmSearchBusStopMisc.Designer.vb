﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmSearchBusStopMisc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSearchBusStopMisc))
        Me.txtSearchXStreet = New System.Windows.Forms.ComboBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdClear = New System.Windows.Forms.Button()
        Me.cmdSelect = New System.Windows.Forms.Button()
        Me.cmdSearch = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.txtSearchTPName = New System.Windows.Forms.TextBox()
        Me.optSearchBy4 = New System.Windows.Forms.RadioButton()
        Me.txtSeqSearch = New System.Windows.Forms.TextBox()
        Me.optSearchBy3 = New System.Windows.Forms.RadioButton()
        Me.cmdSwap = New System.Windows.Forms.Button()
        Me.txtSearchStreet = New System.Windows.Forms.ComboBox()
        Me.cboSearchLoc = New System.Windows.Forms.ComboBox()
        Me.BSLOCCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsBusStopLocation = New BusStopManagement.dsBusStopLocation()
        Me.cboSearchDir = New System.Windows.Forms.ComboBox()
        Me.STDIRCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsTravelDirectionCode = New BusStopManagement.dsTravelDirectionCode()
        Me.txtSearchSANZID = New System.Windows.Forms.TextBox()
        Me.txtSearchOCTAID = New System.Windows.Forms.TextBox()
        Me.optSearchBy1 = New System.Windows.Forms.RadioButton()
        Me.optSearchBy2 = New System.Windows.Forms.RadioButton()
        Me.optSearchBy0 = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ST_DIR_CODETableAdapter = New BusStopManagement.dsTravelDirectionCodeTableAdapters.ST_DIR_CODETableAdapter()
        Me.BS_LOC_CODETableAdapter = New BusStopManagement.dsBusStopLocationTableAdapters.BS_LOC_CODETableAdapter()
        Me.lstResults = New System.Windows.Forms.ListBox()
        Me.Frame1.SuspendLayout()
        CType(Me.BSLOCCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsBusStopLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.STDIRCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsTravelDirectionCode, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtSearchXStreet
        '
        Me.txtSearchXStreet.BackColor = System.Drawing.SystemColors.Window
        Me.txtSearchXStreet.Cursor = System.Windows.Forms.Cursors.Default
        Me.txtSearchXStreet.Enabled = False
        Me.txtSearchXStreet.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchXStreet.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchXStreet.Location = New System.Drawing.Point(185, 192)
        Me.txtSearchXStreet.Name = "txtSearchXStreet"
        Me.txtSearchXStreet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSearchXStreet.Size = New System.Drawing.Size(185, 22)
        Me.txtSearchXStreet.TabIndex = 30
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(324, 249)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(81, 25)
        Me.cmdCancel.TabIndex = 25
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdClear
        '
        Me.cmdClear.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClear.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClear.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClear.Location = New System.Drawing.Point(223, 249)
        Me.cmdClear.Name = "cmdClear"
        Me.cmdClear.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClear.Size = New System.Drawing.Size(81, 25)
        Me.cmdClear.TabIndex = 24
        Me.cmdClear.Text = "Clear &Fields"
        Me.cmdClear.UseVisualStyleBackColor = False
        '
        'cmdSelect
        '
        Me.cmdSelect.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSelect.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSelect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSelect.Location = New System.Drawing.Point(122, 249)
        Me.cmdSelect.Name = "cmdSelect"
        Me.cmdSelect.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSelect.Size = New System.Drawing.Size(81, 25)
        Me.cmdSelect.TabIndex = 23
        Me.cmdSelect.Text = "Select S&top"
        Me.cmdSelect.UseVisualStyleBackColor = False
        '
        'cmdSearch
        '
        Me.cmdSearch.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSearch.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSearch.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSearch.Location = New System.Drawing.Point(20, 249)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSearch.Size = New System.Drawing.Size(81, 25)
        Me.cmdSearch.TabIndex = 22
        Me.cmdSearch.Text = "&Search"
        Me.cmdSearch.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.txtSearchTPName)
        Me.Frame1.Controls.Add(Me.optSearchBy4)
        Me.Frame1.Controls.Add(Me.txtSeqSearch)
        Me.Frame1.Controls.Add(Me.optSearchBy3)
        Me.Frame1.Controls.Add(Me.cmdSwap)
        Me.Frame1.Controls.Add(Me.txtSearchStreet)
        Me.Frame1.Controls.Add(Me.cboSearchLoc)
        Me.Frame1.Controls.Add(Me.cboSearchDir)
        Me.Frame1.Controls.Add(Me.txtSearchSANZID)
        Me.Frame1.Controls.Add(Me.txtSearchOCTAID)
        Me.Frame1.Controls.Add(Me.optSearchBy1)
        Me.Frame1.Controls.Add(Me.optSearchBy2)
        Me.Frame1.Controls.Add(Me.optSearchBy0)
        Me.Frame1.Controls.Add(Me.Label1)
        Me.Frame1.Controls.Add(Me.Label5)
        Me.Frame1.Controls.Add(Me.Label4)
        Me.Frame1.Controls.Add(Me.Label3)
        Me.Frame1.Controls.Add(Me.Label2)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.Color.DimGray
        Me.Frame1.Location = New System.Drawing.Point(12, 28)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(401, 207)
        Me.Frame1.TabIndex = 28
        Me.Frame1.TabStop = False
        '
        'txtSearchTPName
        '
        Me.txtSearchTPName.AcceptsReturn = True
        Me.txtSearchTPName.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtSearchTPName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearchTPName.Enabled = False
        Me.txtSearchTPName.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchTPName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchTPName.Location = New System.Drawing.Point(296, 64)
        Me.txtSearchTPName.MaxLength = 0
        Me.txtSearchTPName.Name = "txtSearchTPName"
        Me.txtSearchTPName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSearchTPName.Size = New System.Drawing.Size(97, 20)
        Me.txtSearchTPName.TabIndex = 31
        '
        'optSearchBy4
        '
        Me.optSearchBy4.BackColor = System.Drawing.Color.Transparent
        Me.optSearchBy4.Cursor = System.Windows.Forms.Cursors.Default
        Me.optSearchBy4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSearchBy4.ForeColor = System.Drawing.Color.DimGray
        Me.optSearchBy4.Location = New System.Drawing.Point(236, 64)
        Me.optSearchBy4.Name = "optSearchBy4"
        Me.optSearchBy4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optSearchBy4.Size = New System.Drawing.Size(53, 17)
        Me.optSearchBy4.TabIndex = 30
        Me.optSearchBy4.TabStop = True
        Me.optSearchBy4.Tag = "4"
        Me.optSearchBy4.Text = "TP ID:"
        Me.optSearchBy4.UseVisualStyleBackColor = False
        '
        'txtSeqSearch
        '
        Me.txtSeqSearch.AcceptsReturn = True
        Me.txtSeqSearch.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtSeqSearch.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSeqSearch.Enabled = False
        Me.txtSeqSearch.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSeqSearch.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSeqSearch.Location = New System.Drawing.Point(296, 24)
        Me.txtSeqSearch.MaxLength = 0
        Me.txtSeqSearch.Name = "txtSeqSearch"
        Me.txtSeqSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSeqSearch.Size = New System.Drawing.Size(97, 20)
        Me.txtSeqSearch.TabIndex = 29
        '
        'optSearchBy3
        '
        Me.optSearchBy3.BackColor = System.Drawing.Color.Transparent
        Me.optSearchBy3.Cursor = System.Windows.Forms.Cursors.Default
        Me.optSearchBy3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSearchBy3.ForeColor = System.Drawing.Color.DimGray
        Me.optSearchBy3.Location = New System.Drawing.Point(236, 24)
        Me.optSearchBy3.Name = "optSearchBy3"
        Me.optSearchBy3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optSearchBy3.Size = New System.Drawing.Size(53, 17)
        Me.optSearchBy3.TabIndex = 28
        Me.optSearchBy3.TabStop = True
        Me.optSearchBy3.Tag = "3"
        Me.optSearchBy3.Text = "SEQ:"
        Me.optSearchBy3.UseVisualStyleBackColor = False
        '
        'cmdSwap
        '
        Me.cmdSwap.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSwap.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSwap.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSwap.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSwap.Image = CType(resources.GetObject("cmdSwap.Image"), System.Drawing.Image)
        Me.cmdSwap.Location = New System.Drawing.Point(363, 146)
        Me.cmdSwap.Name = "cmdSwap"
        Me.cmdSwap.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSwap.Size = New System.Drawing.Size(31, 29)
        Me.cmdSwap.TabIndex = 21
        Me.cmdSwap.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdSwap.UseVisualStyleBackColor = False
        '
        'txtSearchStreet
        '
        Me.txtSearchStreet.BackColor = System.Drawing.SystemColors.Window
        Me.txtSearchStreet.Cursor = System.Windows.Forms.Cursors.Default
        Me.txtSearchStreet.Enabled = False
        Me.txtSearchStreet.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchStreet.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchStreet.Location = New System.Drawing.Point(173, 135)
        Me.txtSearchStreet.Name = "txtSearchStreet"
        Me.txtSearchStreet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSearchStreet.Size = New System.Drawing.Size(185, 22)
        Me.txtSearchStreet.TabIndex = 19
        '
        'cboSearchLoc
        '
        Me.cboSearchLoc.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.cboSearchLoc.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboSearchLoc.DataSource = Me.BSLOCCODEBindingSource
        Me.cboSearchLoc.DisplayMember = "LOC"
        Me.cboSearchLoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSearchLoc.Enabled = False
        Me.cboSearchLoc.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSearchLoc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboSearchLoc.Location = New System.Drawing.Point(68, 164)
        Me.cboSearchLoc.Name = "cboSearchLoc"
        Me.cboSearchLoc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboSearchLoc.Size = New System.Drawing.Size(49, 22)
        Me.cboSearchLoc.TabIndex = 6
        Me.cboSearchLoc.ValueMember = "ID"
        '
        'BSLOCCODEBindingSource
        '
        Me.BSLOCCODEBindingSource.DataMember = "BS_LOC_CODE"
        Me.BSLOCCODEBindingSource.DataSource = Me.DsBusStopLocation
        '
        'DsBusStopLocation
        '
        Me.DsBusStopLocation.DataSetName = "dsBusStopLocation"
        Me.DsBusStopLocation.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboSearchDir
        '
        Me.cboSearchDir.BackColor = System.Drawing.SystemColors.Menu
        Me.cboSearchDir.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboSearchDir.DataSource = Me.STDIRCODEBindingSource
        Me.cboSearchDir.DisplayMember = "DIR"
        Me.cboSearchDir.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSearchDir.Enabled = False
        Me.cboSearchDir.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSearchDir.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboSearchDir.Location = New System.Drawing.Point(68, 133)
        Me.cboSearchDir.Name = "cboSearchDir"
        Me.cboSearchDir.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboSearchDir.Size = New System.Drawing.Size(49, 22)
        Me.cboSearchDir.TabIndex = 5
        Me.cboSearchDir.ValueMember = "ID"
        '
        'STDIRCODEBindingSource
        '
        Me.STDIRCODEBindingSource.DataMember = "ST_DIR_CODE"
        Me.STDIRCODEBindingSource.DataSource = Me.DsTravelDirectionCode
        '
        'DsTravelDirectionCode
        '
        Me.DsTravelDirectionCode.DataSetName = "dsTravelDirectionCode"
        Me.DsTravelDirectionCode.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtSearchSANZID
        '
        Me.txtSearchSANZID.AcceptsReturn = True
        Me.txtSearchSANZID.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtSearchSANZID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearchSANZID.Enabled = False
        Me.txtSearchSANZID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchSANZID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchSANZID.Location = New System.Drawing.Point(104, 64)
        Me.txtSearchSANZID.MaxLength = 0
        Me.txtSearchSANZID.Name = "txtSearchSANZID"
        Me.txtSearchSANZID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSearchSANZID.Size = New System.Drawing.Size(97, 20)
        Me.txtSearchSANZID.TabIndex = 3
        '
        'txtSearchOCTAID
        '
        Me.txtSearchOCTAID.AcceptsReturn = True
        Me.txtSearchOCTAID.BackColor = System.Drawing.SystemColors.Window
        Me.txtSearchOCTAID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearchOCTAID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearchOCTAID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSearchOCTAID.Location = New System.Drawing.Point(104, 24)
        Me.txtSearchOCTAID.MaxLength = 0
        Me.txtSearchOCTAID.Name = "txtSearchOCTAID"
        Me.txtSearchOCTAID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSearchOCTAID.Size = New System.Drawing.Size(97, 20)
        Me.txtSearchOCTAID.TabIndex = 0
        '
        'optSearchBy1
        '
        Me.optSearchBy1.BackColor = System.Drawing.Color.Transparent
        Me.optSearchBy1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optSearchBy1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSearchBy1.ForeColor = System.Drawing.Color.DimGray
        Me.optSearchBy1.Location = New System.Drawing.Point(24, 64)
        Me.optSearchBy1.Name = "optSearchBy1"
        Me.optSearchBy1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optSearchBy1.Size = New System.Drawing.Size(73, 17)
        Me.optSearchBy1.TabIndex = 2
        Me.optSearchBy1.TabStop = True
        Me.optSearchBy1.Tag = "1"
        Me.optSearchBy1.Text = "SANZ ID:"
        Me.optSearchBy1.UseVisualStyleBackColor = False
        '
        'optSearchBy2
        '
        Me.optSearchBy2.BackColor = System.Drawing.Color.Transparent
        Me.optSearchBy2.Cursor = System.Windows.Forms.Cursors.Default
        Me.optSearchBy2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSearchBy2.ForeColor = System.Drawing.Color.DimGray
        Me.optSearchBy2.Location = New System.Drawing.Point(24, 104)
        Me.optSearchBy2.Name = "optSearchBy2"
        Me.optSearchBy2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optSearchBy2.Size = New System.Drawing.Size(121, 17)
        Me.optSearchBy2.TabIndex = 4
        Me.optSearchBy2.TabStop = True
        Me.optSearchBy2.Tag = "2"
        Me.optSearchBy2.Text = "Street/Cross Street:"
        Me.optSearchBy2.UseVisualStyleBackColor = False
        '
        'optSearchBy0
        '
        Me.optSearchBy0.BackColor = System.Drawing.Color.Transparent
        Me.optSearchBy0.Checked = True
        Me.optSearchBy0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optSearchBy0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optSearchBy0.ForeColor = System.Drawing.Color.DimGray
        Me.optSearchBy0.Location = New System.Drawing.Point(24, 24)
        Me.optSearchBy0.Name = "optSearchBy0"
        Me.optSearchBy0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optSearchBy0.Size = New System.Drawing.Size(73, 17)
        Me.optSearchBy0.TabIndex = 1
        Me.optSearchBy0.TabStop = True
        Me.optSearchBy0.Tag = "0"
        Me.optSearchBy0.Text = "OCTA ID:"
        Me.optSearchBy0.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Ivory
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(15, -3)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(77, 16)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Search By:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DimGray
        Me.Label5.Location = New System.Drawing.Point(128, 168)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(50, 14)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "X-Street:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(138, 136)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(39, 14)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Street:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(15, 168)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(51, 14)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Location:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(14, 136)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(52, 14)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Direction:"
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(12, 241)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(401, 41)
        Me.Shape1.TabIndex = 31
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DimGray
        Me.Label6.Location = New System.Drawing.Point(12, 289)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(106, 16)
        Me.Label6.TabIndex = 29
        Me.Label6.Text = "Search Results:"
        '
        'ST_DIR_CODETableAdapter
        '
        Me.ST_DIR_CODETableAdapter.ClearBeforeFill = True
        '
        'BS_LOC_CODETableAdapter
        '
        Me.BS_LOC_CODETableAdapter.ClearBeforeFill = True
        '
        'lstResults
        '
        Me.lstResults.FormattingEnabled = True
        Me.lstResults.Location = New System.Drawing.Point(15, 309)
        Me.lstResults.Name = "lstResults"
        Me.lstResults.Size = New System.Drawing.Size(397, 134)
        Me.lstResults.TabIndex = 32
        '
        'frmSearchBusStopMisc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(430, 461)
        Me.Controls.Add(Me.lstResults)
        Me.Controls.Add(Me.txtSearchXStreet)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdClear)
        Me.Controls.Add(Me.cmdSelect)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Shape1)
        Me.Controls.Add(Me.Label6)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmSearchBusStopMisc"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Locate Stop"
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        CType(Me.BSLOCCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsBusStopLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.STDIRCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsTravelDirectionCode, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents txtSearchXStreet As ComboBox
    Public WithEvents cmdCancel As Button
    Public WithEvents cmdClear As Button
    Public WithEvents cmdSelect As Button
    Public WithEvents cmdSearch As Button
    Public WithEvents Frame1 As GroupBox
    Public WithEvents cmdSwap As Button
    Public WithEvents txtSearchStreet As ComboBox
    Public WithEvents cboSearchLoc As ComboBox
    Public WithEvents cboSearchDir As ComboBox
    Public WithEvents txtSearchSANZID As TextBox
    Public WithEvents txtSearchOCTAID As TextBox
    Public WithEvents optSearchBy1 As RadioButton
    Public WithEvents optSearchBy2 As RadioButton
    Public WithEvents optSearchBy0 As RadioButton
    Public WithEvents Label5 As Label
    Public WithEvents Label4 As Label
    Public WithEvents Label3 As Label
    Public WithEvents Label2 As Label
    Public WithEvents Shape1 As Label
    Public WithEvents Label6 As Label
    Public WithEvents Label1 As Label
    Friend WithEvents DsTravelDirectionCode As dsTravelDirectionCode
    Friend WithEvents STDIRCODEBindingSource As BindingSource
    Friend WithEvents ST_DIR_CODETableAdapter As dsTravelDirectionCodeTableAdapters.ST_DIR_CODETableAdapter
    Friend WithEvents DsBusStopLocation As dsBusStopLocation
    Friend WithEvents BSLOCCODEBindingSource As BindingSource
    Friend WithEvents BS_LOC_CODETableAdapter As dsBusStopLocationTableAdapters.BS_LOC_CODETableAdapter
    Friend WithEvents lstResults As ListBox
    Public WithEvents txtSeqSearch As TextBox
    Public WithEvents optSearchBy3 As RadioButton
    Public WithEvents txtSearchTPName As TextBox
    Public WithEvents optSearchBy4 As RadioButton
End Class
