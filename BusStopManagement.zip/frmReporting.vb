﻿Public Class frmReporting
    Private Sub cmdFollowUpReports_Click(sender As Object, e As EventArgs) Handles cmdFollowUpReports.Click

        frmRptFollowUp.Show()

    End Sub

    Private Sub cmdBusStopReports_Click(sender As Object, e As EventArgs) Handles cmdBusStopReports.Click

        frmRptBusStop.Show()

    End Sub

    'Used for windows 7 machines
    'Private Sub cmdadhocreports_click(sender As Object, e As EventArgs) Handles cmdAdhocReports.Click

    '    Dim sapppath As String
    '    Dim x As Object

    '    sapppath = GetAppValue("msaccesspath")
    '    x = Shell(sapppath, AppWinStyle.MaximizedFocus)

    'End Sub

    'Used for windows 10 machines
    'Private Sub cmdAdhocReports_Click(sender As Object, e As EventArgs) Handles cmdAdhocReports.Click

    '    Dim sAppPath As String
    '    Dim sFilePath As String
    '    Dim x As Object

    '    sAppPath = GetAppValue("MSAccessPath")
    '    sFilePath = GetAppValue("FilterReportPath")

    '    x = Shell(sAppPath & " " & Chr(34) & sFilePath & Chr(34), AppWinStyle.MaximizedFocus)

    'End Sub


    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click

        Me.Close()

    End Sub

    Private Sub cmdRouteStopLists_Click(sender As Object, e As EventArgs) Handles cmdRouteStopLists.Click

        frmRptRouteStop.Show()

    End Sub

    Private Sub cmdWOReports_Click(sender As Object, e As EventArgs) Handles cmdWOReports.Click

        frmRptStopWorkOrder.Show()

    End Sub

    Private Sub cmdSMC_Click(sender As Object, e As EventArgs) Handles cmdSMC.Click

        frmRptStopModificationNotice.Show()

    End Sub

    Private Sub cmdDSCE_Click(sender As Object, e As EventArgs) Handles cmdDSCE.Click

        frmRptDamageStopCostEstimate.Show()

    End Sub
End Class