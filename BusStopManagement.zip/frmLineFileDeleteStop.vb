﻿Imports System.Data.SqlClient
Public Class frmLineFileDeleteStop
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmLineFileDeleteStop
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmLineFileDeleteStop
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmLineFileDeleteStop()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region

    Dim rs As New ADODB.Recordset
    Dim rowIndex As Short

    Private Sub frmLineFileDeleteStop_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Dim strSQL As String
        strSQL = "SELECT RTE, DIR, OCTA_ID, SANZ_ID, RTE_DIR_ID FROM tblBusStopSequences seq, " & "ROUTE_DIR_CODE rdc WHERE seq.OCTA_ID = " & OCTA_ID & "AND rdc.ID = seq.RTE_DIR_ID"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount < 2 Then
            MsgBox("Stop does not exist in aditional routes")
        End If

        Call LoadData()

    End Sub

    Private Sub LoadData()
        On Error GoTo errHandler

        Dim strSQL As String

        strSQL = "SELECT RTE, DIR, OCTA_ID, SANZ_ID, RTE_DIR_ID FROM tblBusStopSequences seq, " & "ROUTE_DIR_CODE rdc WHERE seq.OCTA_ID = " & OCTA_ID & "AND rdc.ID = seq.RTE_DIR_ID"

        Dim oConn As New SqlConnection(sConn)
        Dim dataadapter As New SqlDataAdapter(strSQL, oConn)
        Dim ds As New DataSet()
        oConn.Open()
        dataadapter.Fill(ds, "LoadGrid")
        oConn.Close()

        TDBGrid1.DataSource = ds
        TDBGrid1.DataMember = "LoadGrid"

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub frmLineFileDeleteStop_Closed(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Closed
        rs.Close()
    End Sub

    Private Sub cmdDeleteAll_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdDeleteAll.Click

        Dim strSQL As String
        Dim i As Short
        Dim AllRoutes As String

        AllRoutes = ""

        If MsgBox("This will delete all bus stops listed. Do you want to continue?", MsgBoxStyle.YesNo, "Delete Stops") = MsgBoxResult.No Then Exit Sub

        For i = 0 To TDBGrid1.RowCount - 1
            If i = TDBGrid1.RowCount - 1 Then
                AllRoutes = AllRoutes & TDBGrid1.Item(0, i).Value & " " & TDBGrid1.Item(1, i).Value
            Else
                AllRoutes = AllRoutes & TDBGrid1.Item(0, i).Value & " " & TDBGrid1.Item(1, i).Value & ", "
            End If
        Next i

        strSQL = "DELETE FROM tblBusStopSequences WHERE OCTA_ID = " & OCTA_ID
        db.Execute(strSQL)

        ' LandMarks
        strSQL = "DELETE FROM tblBusStopLandmarks WHERE OCTA_ID = " & OCTA_ID
        db.Execute(strSQL)

        Call LoadData()

        Dim myDate As Date
        myDate = Today

        cmdDelete.Enabled = False
        cmdDeleteAll.Enabled = False

        Dim remarks As String
        Dim typeID As Short

        remarks = "'BUS STOP WAS REMOVED FROM ALL ROUTE(s) " & AllRoutes & "'"
        typeID = 26

        strSQL = "" & "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) VALUES (" & OCTA_ID & ",'" & SANZ_ID & "','" & myDate & "'," & CurrentLoginUserID & "," & typeID & "," & remarks & ");"

        db.Execute(strSQL)

        remarks = "'BUS STOP WAS REMOVED FROM ALL ROUTES AND IS NOW INACTIVE'"

        typeID = 4

        strSQL = "" & "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) VALUES (" & OCTA_ID & ",'" & SANZ_ID & "','" & myDate & "'," & CurrentLoginUserID & "," & typeID & "," & remarks & ");"

        db.Execute(strSQL)

        strSQL = "UPDATE tblBusStopInformation SET ACTIVE_STOP = 0 " & "WHERE OCTA_ID = " & OCTA_ID
        db.Execute(strSQL)

    End Sub

    Private Sub cmdDelete_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdDelete.Click

        Dim route, routeDir As Short

        Dim i As Integer
        i = TDBGrid1.CurrentRow.Index
        route = TDBGrid1.Item(0, i).Value
        routeDir = TDBGrid1.Item(4, i).Value

        strSQL = "DELETE FROM tblBusStopSequences WHERE OCTA_ID = " & OCTA_ID & " AND RTE = " & route & " AND RTE_DIR_ID = " & routeDir

        db.Execute(strSQL)

        ' LandMarks
        strSQL = "SELECT DESCRIPTION FROM ROUTE_DIR_CODE WHERE ID = " & routeDir

        Dim trs As New ADODB.Recordset
        trs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)
        trs.MoveFirst()

        Dim rd As String
        rd = trs.Fields(0).Value
        trs.Close()

        strSQL = "DELETE FROM tblBusStopLandmarks WHERE OCTA_ID = " & OCTA_ID & " AND RTE = " & route & " AND DIRECTION = '" & rd & "'"

        db.Execute(strSQL)

        Call LoadData()

        strSQL = "SELECT * FROM tblBusStopSequences WHERE OCTA_ID = " & OCTA_ID
        trs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        Dim myDate As Date
        myDate = Today
        Dim remarks As String
        Dim typeID As Short

        Dim rsDir As New ADODB.Recordset
        Dim rteDir As String

        'Stop History, deleted from single route may be all but 2 entries needed
        strSQL = "SELECT DIR FROM ROUTE_DIR_CODE WHERE ID = '" & DIR_ID & "'"
        rsDir.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
        rsDir.MoveFirst()

        rteDir = rsDir.Fields(0).Value

        rsDir.Close()

        remarks = "'BUS STOP WAS REMOVED FROM ROUTE " & route & " " & rteDir & "'"
        typeID = 26

        strSQL = "" & "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) VALUES (" & OCTA_ID & ",'" & SANZ_ID & "','" & myDate & "'," & CurrentLoginUserID & "," & typeID & "," & remarks & ");"

        db.Execute(strSQL)

        If trs.RecordCount < 1 Then
            cmdDelete.Enabled = False
            cmdDeleteAll.Enabled = False

            remarks = "'BUS STOP WAS REMOVED FROM ALL ROUTES AND IS NOW INACTIVE'"
            typeID = 4

            strSQL = "" & "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) VALUES (" & OCTA_ID & ",'" & SANZ_ID & "','" & myDate & "'," & CurrentLoginUserID & "," & typeID & "," & remarks & ");"

            db.Execute(strSQL)

            strSQL = "UPDATE tblBusStopInformation SET ACTIVE_STOP = 0 " & "WHERE OCTA_ID = " & OCTA_ID
            db.Execute(strSQL)

        End If

        trs.Close()
    End Sub

End Class