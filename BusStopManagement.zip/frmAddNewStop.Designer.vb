﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAddNewStop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAddNewStop))
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cboAgencyDesc = New System.Windows.Forms.ComboBox()
        Me.CITYCODEBindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsAgencyDesc = New BusStopManagement.dsAgencyDesc()
        Me.cboJurisd = New System.Windows.Forms.ComboBox()
        Me.CITYCODEBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsAgencyCode = New BusStopManagement.dsAgencyCode()
        Me.cboCity = New System.Windows.Forms.ComboBox()
        Me.CITYCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsListOfCitiesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsListOfCities = New BusStopManagement.dsListOfCities()
        Me._Label1_3 = New System.Windows.Forms.Label()
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me.DsCityCode = New BusStopManagement.dsCityCode()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdInsertStop = New System.Windows.Forms.Button()
        Me.txtSANZID = New System.Windows.Forms.TextBox()
        Me._Label1_2 = New System.Windows.Forms.Label()
        Me.TDBGrid1 = New System.Windows.Forms.DataGridView()
        Me.SANZIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StreetDirDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StreetDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StreetTypeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BusLocDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CrossStreetDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StreetType2DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CrossStreet2DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblBusStopInformationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsAddNewStop = New BusStopManagement.dsAddNewStop()
        Me.CITY_CODETableAdapter = New BusStopManagement.dsListOfCitiesTableAdapters.CITY_CODETableAdapter()
        Me.CITYCODEBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CITY_CODETableAdapter1 = New BusStopManagement.dsCityCodeTableAdapters.CITY_CODETableAdapter()
        Me.CITY_CODETableAdapter2 = New BusStopManagement.dsAgencyCodeTableAdapters.CITY_CODETableAdapter()
        Me.BusStopManagementDataSet4 = New BusStopManagement.BusStopManagementDataSet4()
        Me.CITYCODEBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CITY_CODETableAdapter3 = New BusStopManagement.dsAgencyDescTableAdapters.CITY_CODETableAdapter()
        Me.TblBusStopInformationTableAdapter = New BusStopManagement.dsAddNewStopTableAdapters.tblBusStopInformationTableAdapter()
        Me.lblNumberOfRecords = New System.Windows.Forms.Label()
        Me.Frame1.SuspendLayout()
        CType(Me.CITYCODEBindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsAgencyDesc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CITYCODEBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsAgencyCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CITYCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsListOfCitiesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsListOfCities, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsCityCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TDBGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblBusStopInformationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsAddNewStop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CITYCODEBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusStopManagementDataSet4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CITYCODEBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.cboAgencyDesc)
        Me.Frame1.Controls.Add(Me.cboJurisd)
        Me.Frame1.Controls.Add(Me.cboCity)
        Me.Frame1.Controls.Add(Me._Label1_3)
        Me.Frame1.Controls.Add(Me._Label1_1)
        Me.Frame1.Controls.Add(Me._Label1_0)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.Color.DimGray
        Me.Frame1.Location = New System.Drawing.Point(12, 12)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(609, 79)
        Me.Frame1.TabIndex = 14
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Agency Information"
        '
        'cboAgencyDesc
        '
        Me.cboAgencyDesc.BackColor = System.Drawing.SystemColors.Window
        Me.cboAgencyDesc.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboAgencyDesc.DataSource = Me.CITYCODEBindingSource4
        Me.cboAgencyDesc.DisplayMember = "DESCRIPTION"
        Me.cboAgencyDesc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAgencyDesc.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboAgencyDesc.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboAgencyDesc.Location = New System.Drawing.Point(320, 42)
        Me.cboAgencyDesc.Name = "cboAgencyDesc"
        Me.cboAgencyDesc.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboAgencyDesc.Size = New System.Drawing.Size(265, 22)
        Me.cboAgencyDesc.TabIndex = 2
        Me.cboAgencyDesc.ValueMember = "JURISDICTION"
        '
        'CITYCODEBindingSource4
        '
        Me.CITYCODEBindingSource4.DataMember = "CITY_CODE"
        Me.CITYCODEBindingSource4.DataSource = Me.DsAgencyDesc
        '
        'DsAgencyDesc
        '
        Me.DsAgencyDesc.DataSetName = "dsAgencyDesc"
        Me.DsAgencyDesc.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboJurisd
        '
        Me.cboJurisd.BackColor = System.Drawing.SystemColors.Window
        Me.cboJurisd.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboJurisd.DataSource = Me.CITYCODEBindingSource2
        Me.cboJurisd.DisplayMember = "JURISDICTION"
        Me.cboJurisd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboJurisd.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboJurisd.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboJurisd.Location = New System.Drawing.Point(176, 42)
        Me.cboJurisd.Name = "cboJurisd"
        Me.cboJurisd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboJurisd.Size = New System.Drawing.Size(97, 22)
        Me.cboJurisd.TabIndex = 1
        Me.cboJurisd.ValueMember = "CITY"
        '
        'CITYCODEBindingSource2
        '
        Me.CITYCODEBindingSource2.DataMember = "CITY_CODE"
        Me.CITYCODEBindingSource2.DataSource = Me.DsAgencyCode
        '
        'DsAgencyCode
        '
        Me.DsAgencyCode.DataSetName = "dsAgencyCode"
        Me.DsAgencyCode.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboCity
        '
        Me.cboCity.BackColor = System.Drawing.SystemColors.Window
        Me.cboCity.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboCity.DataSource = Me.CITYCODEBindingSource
        Me.cboCity.DisplayMember = "CITY"
        Me.cboCity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboCity.Location = New System.Drawing.Point(32, 42)
        Me.cboCity.Name = "cboCity"
        Me.cboCity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboCity.Size = New System.Drawing.Size(89, 22)
        Me.cboCity.TabIndex = 0
        '
        'CITYCODEBindingSource
        '
        Me.CITYCODEBindingSource.DataMember = "CITY_CODE"
        Me.CITYCODEBindingSource.DataSource = Me.DsListOfCitiesBindingSource
        '
        'DsListOfCitiesBindingSource
        '
        Me.DsListOfCitiesBindingSource.DataSource = Me.DsListOfCities
        Me.DsListOfCitiesBindingSource.Position = 0
        '
        'DsListOfCities
        '
        Me.DsListOfCities.DataSetName = "dsListOfCities"
        Me.DsListOfCities.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        '_Label1_3
        '
        Me._Label1_3.AutoSize = True
        Me._Label1_3.BackColor = System.Drawing.Color.Transparent
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_3.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_3.Location = New System.Drawing.Point(317, 25)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(124, 14)
        Me._Label1_3.TabIndex = 11
        Me._Label1_3.Text = "AGENCY DESCRIPTION"
        '
        '_Label1_1
        '
        Me._Label1_1.AutoSize = True
        Me._Label1_1.BackColor = System.Drawing.Color.Transparent
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_1.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_1.Location = New System.Drawing.Point(173, 25)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(83, 14)
        Me._Label1_1.TabIndex = 9
        Me._Label1_1.Text = "AGENCY CODE"
        '
        '_Label1_0
        '
        Me._Label1_0.AutoSize = True
        Me._Label1_0.BackColor = System.Drawing.Color.Transparent
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_0.Location = New System.Drawing.Point(29, 25)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(32, 14)
        Me._Label1_0.TabIndex = 8
        Me._Label1_0.Text = "CITY"
        '
        'DsCityCode
        '
        Me.DsCityCode.DataSetName = "dsCityCode"
        Me.DsCityCode.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(536, 289)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(81, 25)
        Me.cmdCancel.TabIndex = 13
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdInsertStop
        '
        Me.cmdInsertStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdInsertStop.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInsertStop.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdInsertStop.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdInsertStop.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdInsertStop.Location = New System.Drawing.Point(440, 289)
        Me.cmdInsertStop.Name = "cmdInsertStop"
        Me.cmdInsertStop.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdInsertStop.Size = New System.Drawing.Size(81, 25)
        Me.cmdInsertStop.TabIndex = 12
        Me.cmdInsertStop.Text = "&Insert Stop"
        Me.cmdInsertStop.UseVisualStyleBackColor = False
        '
        'txtSANZID
        '
        Me.txtSANZID.AcceptsReturn = True
        Me.txtSANZID.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtSANZID.BackColor = System.Drawing.SystemColors.Window
        Me.txtSANZID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSANZID.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSANZID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSANZID.Location = New System.Drawing.Point(288, 289)
        Me.txtSANZID.MaxLength = 10
        Me.txtSANZID.Name = "txtSANZID"
        Me.txtSANZID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSANZID.Size = New System.Drawing.Size(137, 22)
        Me.txtSANZID.TabIndex = 11
        '
        '_Label1_2
        '
        Me._Label1_2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me._Label1_2.AutoSize = True
        Me._Label1_2.BackColor = System.Drawing.Color.Transparent
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_2.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_2.Location = New System.Drawing.Point(205, 294)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(78, 14)
        Me._Label1_2.TabIndex = 15
        Me._Label1_2.Text = "NEW SANZ ID:"
        '
        'TDBGrid1
        '
        Me.TDBGrid1.AllowUserToAddRows = False
        Me.TDBGrid1.AllowUserToDeleteRows = False
        Me.TDBGrid1.AllowUserToOrderColumns = True
        Me.TDBGrid1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TDBGrid1.AutoGenerateColumns = False
        Me.TDBGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TDBGrid1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SANZIDDataGridViewTextBoxColumn, Me.StreetDirDataGridViewTextBoxColumn, Me.StreetDataGridViewTextBoxColumn, Me.StreetTypeDataGridViewTextBoxColumn, Me.BusLocDataGridViewTextBoxColumn, Me.CrossStreetDataGridViewTextBoxColumn, Me.StreetType2DataGridViewTextBoxColumn, Me.CrossStreet2DataGridViewTextBoxColumn})
        Me.TDBGrid1.DataSource = Me.TblBusStopInformationBindingSource
        Me.TDBGrid1.Location = New System.Drawing.Point(12, 106)
        Me.TDBGrid1.Name = "TDBGrid1"
        Me.TDBGrid1.ReadOnly = True
        Me.TDBGrid1.Size = New System.Drawing.Size(609, 174)
        Me.TDBGrid1.TabIndex = 16
        '
        'SANZIDDataGridViewTextBoxColumn
        '
        Me.SANZIDDataGridViewTextBoxColumn.DataPropertyName = "SANZ_ID"
        Me.SANZIDDataGridViewTextBoxColumn.HeaderText = "SANZ ID"
        Me.SANZIDDataGridViewTextBoxColumn.Name = "SANZIDDataGridViewTextBoxColumn"
        Me.SANZIDDataGridViewTextBoxColumn.ReadOnly = True
        Me.SANZIDDataGridViewTextBoxColumn.Width = 75
        '
        'StreetDirDataGridViewTextBoxColumn
        '
        Me.StreetDirDataGridViewTextBoxColumn.DataPropertyName = "Street_Dir"
        Me.StreetDirDataGridViewTextBoxColumn.HeaderText = "ST DIR"
        Me.StreetDirDataGridViewTextBoxColumn.Name = "StreetDirDataGridViewTextBoxColumn"
        Me.StreetDirDataGridViewTextBoxColumn.ReadOnly = True
        Me.StreetDirDataGridViewTextBoxColumn.Width = 50
        '
        'StreetDataGridViewTextBoxColumn
        '
        Me.StreetDataGridViewTextBoxColumn.DataPropertyName = "Street"
        Me.StreetDataGridViewTextBoxColumn.HeaderText = "STREET"
        Me.StreetDataGridViewTextBoxColumn.Name = "StreetDataGridViewTextBoxColumn"
        Me.StreetDataGridViewTextBoxColumn.ReadOnly = True
        Me.StreetDataGridViewTextBoxColumn.Width = 125
        '
        'StreetTypeDataGridViewTextBoxColumn
        '
        Me.StreetTypeDataGridViewTextBoxColumn.DataPropertyName = "Street_Type"
        Me.StreetTypeDataGridViewTextBoxColumn.HeaderText = "ST TYPE"
        Me.StreetTypeDataGridViewTextBoxColumn.Name = "StreetTypeDataGridViewTextBoxColumn"
        Me.StreetTypeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BusLocDataGridViewTextBoxColumn
        '
        Me.BusLocDataGridViewTextBoxColumn.DataPropertyName = "Bus_Loc"
        Me.BusLocDataGridViewTextBoxColumn.HeaderText = "BUS LOC"
        Me.BusLocDataGridViewTextBoxColumn.Name = "BusLocDataGridViewTextBoxColumn"
        Me.BusLocDataGridViewTextBoxColumn.ReadOnly = True
        '
        'CrossStreetDataGridViewTextBoxColumn
        '
        Me.CrossStreetDataGridViewTextBoxColumn.DataPropertyName = "Cross_Street"
        Me.CrossStreetDataGridViewTextBoxColumn.HeaderText = "CROSS STREET"
        Me.CrossStreetDataGridViewTextBoxColumn.Name = "CrossStreetDataGridViewTextBoxColumn"
        Me.CrossStreetDataGridViewTextBoxColumn.ReadOnly = True
        Me.CrossStreetDataGridViewTextBoxColumn.Width = 125
        '
        'StreetType2DataGridViewTextBoxColumn
        '
        Me.StreetType2DataGridViewTextBoxColumn.DataPropertyName = "Street_Type2"
        Me.StreetType2DataGridViewTextBoxColumn.HeaderText = "ST TYPE 2"
        Me.StreetType2DataGridViewTextBoxColumn.Name = "StreetType2DataGridViewTextBoxColumn"
        Me.StreetType2DataGridViewTextBoxColumn.ReadOnly = True
        '
        'CrossStreet2DataGridViewTextBoxColumn
        '
        Me.CrossStreet2DataGridViewTextBoxColumn.DataPropertyName = "Cross_Street_2"
        Me.CrossStreet2DataGridViewTextBoxColumn.HeaderText = "CROSS STREET 2"
        Me.CrossStreet2DataGridViewTextBoxColumn.Name = "CrossStreet2DataGridViewTextBoxColumn"
        Me.CrossStreet2DataGridViewTextBoxColumn.ReadOnly = True
        '
        'TblBusStopInformationBindingSource
        '
        Me.TblBusStopInformationBindingSource.DataMember = "tblBusStopInformation"
        Me.TblBusStopInformationBindingSource.DataSource = Me.DsAddNewStop
        '
        'DsAddNewStop
        '
        Me.DsAddNewStop.DataSetName = "dsAddNewStop"
        Me.DsAddNewStop.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CITY_CODETableAdapter
        '
        Me.CITY_CODETableAdapter.ClearBeforeFill = True
        '
        'CITYCODEBindingSource1
        '
        Me.CITYCODEBindingSource1.DataMember = "CITY_CODE"
        Me.CITYCODEBindingSource1.DataSource = Me.DsCityCode
        '
        'CITY_CODETableAdapter1
        '
        Me.CITY_CODETableAdapter1.ClearBeforeFill = True
        '
        'CITY_CODETableAdapter2
        '
        Me.CITY_CODETableAdapter2.ClearBeforeFill = True
        '
        'BusStopManagementDataSet4
        '
        Me.BusStopManagementDataSet4.DataSetName = "BusStopManagementDataSet4"
        Me.BusStopManagementDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CITYCODEBindingSource3
        '
        Me.CITYCODEBindingSource3.DataMember = "CITY_CODE"
        Me.CITYCODEBindingSource3.DataSource = Me.DsAgencyDesc
        '
        'CITY_CODETableAdapter3
        '
        Me.CITY_CODETableAdapter3.ClearBeforeFill = True
        '
        'TblBusStopInformationTableAdapter
        '
        Me.TblBusStopInformationTableAdapter.ClearBeforeFill = True
        '
        'lblNumberOfRecords
        '
        Me.lblNumberOfRecords.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblNumberOfRecords.AutoSize = True
        Me.lblNumberOfRecords.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNumberOfRecords.ForeColor = System.Drawing.Color.DimGray
        Me.lblNumberOfRecords.Location = New System.Drawing.Point(12, 287)
        Me.lblNumberOfRecords.Name = "lblNumberOfRecords"
        Me.lblNumberOfRecords.Size = New System.Drawing.Size(117, 14)
        Me.lblNumberOfRecords.TabIndex = 17
        Me.lblNumberOfRecords.Text = "Number of Records:"
        '
        'frmAddNewStop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(636, 330)
        Me.Controls.Add(Me.lblNumberOfRecords)
        Me.Controls.Add(Me.TDBGrid1)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdInsertStop)
        Me.Controls.Add(Me.txtSANZID)
        Me.Controls.Add(Me._Label1_2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(652, 368)
        Me.Name = "frmAddNewStop"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add New Stop"
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        CType(Me.CITYCODEBindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsAgencyDesc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CITYCODEBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsAgencyCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CITYCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsListOfCitiesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsListOfCities, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsCityCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TDBGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblBusStopInformationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsAddNewStop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CITYCODEBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusStopManagementDataSet4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CITYCODEBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents Frame1 As GroupBox
    Public WithEvents cboAgencyDesc As ComboBox
    Public WithEvents cboJurisd As ComboBox
    Public WithEvents cboCity As ComboBox
    Public WithEvents _Label1_3 As Label
    Public WithEvents _Label1_1 As Label
    Public WithEvents _Label1_0 As Label
    Public WithEvents cmdCancel As Button
    Public WithEvents cmdInsertStop As Button
    Public WithEvents txtSANZID As TextBox
    Public WithEvents _Label1_2 As Label
    Friend WithEvents TDBGrid1 As DataGridView
    Friend WithEvents DsListOfCitiesBindingSource As BindingSource
    Friend WithEvents DsListOfCities As dsListOfCities
    Friend WithEvents CITYCODEBindingSource As BindingSource
    Friend WithEvents CITY_CODETableAdapter As dsListOfCitiesTableAdapters.CITY_CODETableAdapter
    Friend WithEvents DsCityCode As dsCityCode
    Friend WithEvents CITYCODEBindingSource1 As BindingSource
    Friend WithEvents CITY_CODETableAdapter1 As dsCityCodeTableAdapters.CITY_CODETableAdapter
    Friend WithEvents DsAgencyCode As dsAgencyCode
    Friend WithEvents CITYCODEBindingSource2 As BindingSource
    Friend WithEvents CITY_CODETableAdapter2 As dsAgencyCodeTableAdapters.CITY_CODETableAdapter
    Friend WithEvents BusStopManagementDataSet4 As BusStopManagementDataSet4
    Friend WithEvents DsAgencyDesc As dsAgencyDesc
    Friend WithEvents CITYCODEBindingSource3 As BindingSource
    Friend WithEvents CITY_CODETableAdapter3 As dsAgencyDescTableAdapters.CITY_CODETableAdapter
    Friend WithEvents CITYCODEBindingSource4 As BindingSource
    Friend WithEvents DsAddNewStop As dsAddNewStop
    Friend WithEvents TblBusStopInformationBindingSource As BindingSource
    Friend WithEvents TblBusStopInformationTableAdapter As dsAddNewStopTableAdapters.tblBusStopInformationTableAdapter
    Friend WithEvents lblNumberOfRecords As Label
    Friend WithEvents SANZIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StreetDirDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StreetDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StreetTypeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BusLocDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CrossStreetDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StreetType2DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CrossStreet2DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
