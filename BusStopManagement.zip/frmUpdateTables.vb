﻿Imports System.Data.SqlClient
Imports System.Data
Public Class frmUpdateTables
    Public TABLE_NAME As String
    Dim rowIndex As Short
    Dim dataadapter As SqlDataAdapter
    Dim ds As DataSet()

    Private Sub cmdExit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExit.Click
        Me.Close()
    End Sub

    Private Sub frmUpdateTables_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Try
            Me.BSMTableAdapter.Fill(Me.BusStopManagementDataSet1.ADA_STATUS_CODE)

            LoadTableList()
            lstTables.SelectedIndex = 0

        Catch ex As SqlException
            MsgBox(Err.Description)
        End Try

    End Sub

    Private Sub LoadTableList()
        Try
            lstTables.Items.Clear()
            lstTables.Items.Add("tblAppValues")
            lstTables.Items.Add("ADA_STATUS_CODE")
            lstTables.Items.Add("AMENITIES_OWNER_CODE")
            lstTables.Items.Add("AMENITIES_TYPE_CODE")
            lstTables.Items.Add("BENCH_MAINTENANCE_CODE")
            lstTables.Items.Add("BS_LANDMARK_CODE")
            lstTables.Items.Add("BS_LOC_CODE")
            lstTables.Items.Add("BS_STATUS_CODE")
            lstTables.Items.Add("BS_TYPE_CODE")
            lstTables.Items.Add("BUS_PAD_CODE")
            lstTables.Items.Add("CASSETTE_POSITION_CODE")
            lstTables.Items.Add("CASSETTE_TYPE_CODE")
            lstTables.Items.Add("CITY_CODE")
            lstTables.Items.Add("CITY_GROUP_CODE")
            lstTables.Items.Add("CITY_SIGN_CODE")
            lstTables.Items.Add("CONTACT_TYPE_CODE")
            lstTables.Items.Add("COUNTY_CODE")
            lstTables.Items.Add("DAY_OF_WEEK_CODE")
            lstTables.Items.Add("HARDWARE_GROUP_CODE")
            lstTables.Items.Add("HARDWARE_ITEM_CODE")
            lstTables.Items.Add("HISTORY_TYPE_CODE")
            lstTables.Items.Add("MAINTENANCE_ITEM_CODE")
            lstTables.Items.Add("POST_LOC_CODE")
            lstTables.Items.Add("tblMaintenanceEmployees")
            'lstTables.Items.Add("tblFaxContacts")
            lstTables.Items.Add("PRE_SUFFIX_TYPE_CODE")
            lstTables.Items.Add("RESPONSE_TYPE_CODE")
            lstTables.Items.Add("RESTRICTIVE_PK_TYPE_CODE")
            lstTables.Items.Add("ROUTE_COMMENT_CODE")
            lstTables.Items.Add("ROUTE_DESIGNATION_CODE")
            lstTables.Items.Add("ROUTE_DIR_CODE")
            lstTables.Items.Add("SC_ROUTE_CODE")
            lstTables.Items.Add("SHELTER_MAINTENANCE_CODE")
            lstTables.Items.Add("SIGN_AGENCY_CODE")
            lstTables.Items.Add("SIGN_POST_CONFIG_CODE")
            lstTables.Items.Add("SIGN_POST_TYPE_CODE")
            lstTables.Items.Add("ST_DIR_CODE")
            lstTables.Items.Add("ST_TYPE_CODE")
            lstTables.Items.Add("THS_ROUTE_CODE")
            lstTables.Items.Add("TIME_POINT_DESC")
            lstTables.Items.Add("TRAFFIC_CONTROL_CODE")
            lstTables.Items.Add("TRANSIT_AGENCY_CODE")
            lstTables.Items.Add("TURNOUT_TYPE_CODE")
            lstTables.Items.Add("WO_GROUP_CODE")
            lstTables.Items.Add("WO_ITEM_CODE")
            lstTables.Items.Add("WO_ITEM_COST")
            lstTables.Items.Add("WO_PRIORITY_CODE")

        Catch ex As SqlException
            MsgBox(Err.Description)
        End Try

    End Sub

    Private Sub lstTables_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstTables.SelectedIndexChanged
        Try
            Call LoadTable()
        Catch ex As SqlException
            MsgBox(Err.Description)
        End Try
    End Sub
    Private Sub GetData(ByVal selectCommand As String)

        Try
            Me.dataadapter = New SqlDataAdapter(selectCommand, sConn)
            Dim commandBuilder As New SqlCommandBuilder(Me.dataadapter)

            Dim dt As New DataTable()
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture
            Me.dataadapter.Fill(dt)
            Me.BSMTableBindingSource.DataSource = dt
            lblTotalRecords.Text = "Total Records: " & Me.TdbGrid1.RowCount
        Catch ex As SqlException
            MsgBox(Err.Description)
        End Try

    End Sub

    Private Sub LoadTable()
        Try
            TABLE_NAME = lstTables.Text
            Dim strSQL As String
            strSQL = "SELECT * FROM " & TABLE_NAME

            Me.TdbGrid1.DataSource = Me.BSMTableBindingSource
            GetData(strSQL)

        Catch ex As Exception
            MsgBox(Err.Description)
        End Try
    End Sub

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        Dim ds As New DataSet

        Try
            Me.dataadapter.Update(CType(Me.BSMTableBindingSource.DataSource, DataTable))
            MsgBox("Record saved.", vbInformation, "Saved")
        Catch ex As Exception
            MsgBox(Err.Description)
        End Try

    End Sub
End Class