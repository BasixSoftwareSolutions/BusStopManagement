﻿Imports System.ComponentModel

Public Class frmUpdateStop

    'Variables for WO collection listTblStopHistoryBindingSource
    Dim WOList As Collection
    Dim iKey As Short
    Dim sValue As String
    Dim sWOList(2) As Object

    Dim qryBusStopInfo As String
    Dim pos As Short
    Public currentTab As Short

    'Recordsets to be bound
    Public rs As New ADODB.Recordset
    Public rsWo As New ADODB.Recordset
    Public rsImage As New ADODB.Recordset
    Dim rsEmail As New ADODB.Recordset

    '///////////////////
    ' New Work Order implementation...
    Private myWOHD As clsWorkOrderHandler

    Public FindCheck As Boolean
    Public FindOCTAID As Short
    Public OID As Short

    '////////////////////////

    Dim sFormat As String = "MM/dd/yyyy"

    'Enumeration for the different tabs
    Private Enum tabEnum
        sstADA = 0
        sstTransitAmen = 1
        sstPassengerAmen = 2
        sstSignCassette = 3
        sstStopHistory = 4
        sstSafetySurvey = 5
        sstWorkOrder = 6
        sstFax = 7
        sstStopPic = 8
        sstTrash = 9
        sstGPS = 10
    End Enum

    Dim blnGPSDateChange As Boolean
    Dim blnPicDateChange As Boolean
    Dim blnADASurDateChange As Boolean
    Dim blnADAComDateChange As Boolean
    Dim blnIssuedDateChange As Boolean
    Dim cSngCharge As Single
    Private Const CHECK_BOX_COUNT As Short = 9
    Dim Current_SANZ_ID As String

    Dim startChkFlag As Boolean
    Dim strFiles As Object

    Private Sub cbxStopPhotoNeeded_CheckStateChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cbxStopPhotoNeeded.CheckStateChanged
        'UpdateImageTab
    End Sub

    Private Sub cmdChangeActiveStop_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdChangeActiveStop.Click

        Dim strSQL As String
        Dim response As Object

        Dim intHistoryType As Short
        Dim strRemarks As String
        Dim strDate As String

        intHistoryType = 26
        strDate = Date.Now.ToString(sFormat)

        If cbxCurrentStop.CheckState = 1 Then ' If its active then ask
            response = MsgBox("Deactivating this stop will remove it from all routes, are you sure you want to continue?", MsgBoxStyle.YesNo, "Inactivate Stop")
            If response = MsgBoxResult.Yes Then
                cbxCurrentStop.CheckState = System.Windows.Forms.CheckState.Unchecked
                strSQL = "DELETE  FROM tblBusStopSequences WHERE OCTA_ID = " & txtOCTAID.Text
                db.Execute(strSQL)
                txtRouteServed.Text = ""
                strRemarks = "'STOP DEACTIVATED AND REMOVED FROM ALL ROUTES'"
                strSQL = "INSERT INTO tblStopHistory (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, HISTORY_TYPE_ID, " & "REMARKS) VALUES (" & txtOCTAID.Text & ", '" & txtSANZID.Text & "', '" & strDate & "', " & CurrentLoginUserID & ", " & intHistoryType & ", " & strRemarks & ")"
                db.Execute(strSQL)
            End If

        Else
            cbxCurrentStop.CheckState = System.Windows.Forms.CheckState.Checked
            strRemarks = "'STOP ACTIVATED'"
            strSQL = "INSERT INTO tblStopHistory (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, HISTORY_TYPE_ID, " & "REMARKS) VALUES (" & txtOCTAID.Text & ", '" & txtSANZID.Text & "', '" & strDate & "', " & CurrentLoginUserID & ", " & intHistoryType & ", " & strRemarks & ")"
            db.Execute(strSQL)
        End If

        Call tsbSaveBusStop_Click(cmdFindRecord, New System.EventArgs())

    End Sub

    Private Sub cmdSortOrder_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSortOrder.Click
        On Error GoTo errHandler

        Dim strOCTA_ID As String
        Dim sSort As String

        If cmdSortOrder.Text = "Sort By SANZ ID" Then
            cmdSortOrder.Text = "Sort By OCTA ID"
            sSort = "SANZ_ID"
        Else cmdSortOrder.Text = "Sort By OCTA ID"
            cmdSortOrder.Text = "Sort By SANZ ID"
            sSort = "OCTA_ID"
        End If

        'bnBusStop
        strOCTA_ID = Me.txtOCTAID.Text
        bnBusStop.BindingSource = Nothing
        bnBusStop.BindingSource = TblBusStopInformationBindingSource
        TblBusStopInformationBindingSource.Sort = sSort
        bnBusStop.Refresh()
        Me.TblBusStopInformationBindingSource.Position = Me.TblBusStopInformationBindingSource.Find("OCTA_ID", strOCTA_ID)

        Exit Sub
errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub Command1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command1.Click
        On Error GoTo errHandler

        Dim rs As New ADODB.Recordset
        Dim strSQL As String

        strSQL = "SELECT MapURL FROM qryBusStopLatLon WHERE OCTA_ID = " & Me.txtOCTAID.Text
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not rs.EOF Then
            ShellExecute(Me.Handle.ToInt32, "open", rs.Fields("MapURL").Value, vbNullString, "", 0)
        Else
            MsgBox("Bus Stop location data could not be found", MsgBoxStyle.Information, "Lat/Lon Data missing")
        End If

        rs.Close()
        rs = Nothing

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub


    Private Sub txtElev_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtElev.Leave
        If Not IsNumeric(txtElev.Text) Then
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            txtElev.SelectionStart = 0
            txtElev.SelectionLength = Len(txtElev.Text)
            txtElev.Focus()
        End If
    End Sub

    Private Sub txtGPSDate_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtGPS_OCTA_ID.Leave
        If Trim(txtGPS_OCTA_ID.Text) <> "" Then
            If Not IsDate(txtGPS_OCTA_ID.Text) Then
                MsgBox("Not a date!")
                txtGPS_OCTA_ID.Focus()
            End If
        Else
            blnGPSDateChange = True
        End If
    End Sub

    Private Sub NullifyDateControlValues(ByRef id As Short)
        Dim strSQL As String

        Me.txtStopID.Text = ""

        If blnGPSDateChange Then
            strSQL = "UPDATE tblStopCoord SET DATE_GPS = NULL WHERE OCTA_ID = " & id
            db.Execute(strSQL)
            blnGPSDateChange = False
        End If

        If blnADASurDateChange Then
            strSQL = "UPDATE tblADAStatus SET SURVEY_DATE = NULL WHERE OCTA_ID = " & id
            db.Execute(strSQL)
            blnADASurDateChange = False
        End If

        If blnADAComDateChange Then
            strSQL = "UPDATE tblADAStatus SET COMPLETION_DATE = NULL WHERE OCTA_ID = " & id
            db.Execute(strSQL)
            blnADAComDateChange = False
        End If

        If blnIssuedDateChange Then
            strSQL = "UPDATE tblSignCassette SET ISSUED_DATE = NULL WHERE OCTA_ID = " & id
            db.Execute(strSQL)
            blnIssuedDateChange = False
        End If
    End Sub

    Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
        Me.Close()
    End Sub


    '***************** GENERAL FUNCTIONALITY *****************/
    '==========================================================
    Private Sub frmUpdateStop_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        On Error GoTo errHandler

        Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
        Me.Refresh()
        Call FormatWOGridColumns()
        'Me.WO_PRIORITY_CODETableAdapter.Fill(Me.DsWOPriority.WO_PRIORITY_CODE)
        Me.WO_ITEM_CODETableAdapter.Fill(Me.DsWorkOrderItemCodes.WO_ITEM_CODE)
        Me.CASSETTE_POSITION_CODETableAdapter.Fill(Me.DsCassetteMountingPosition.CASSETTE_POSITION_CODE)
        Me.CASSETTE_TYPE_CODETableAdapter.Fill(Me.DsCassetteMountingHardware.CASSETTE_TYPE_CODE)
        Me.SIGN_POST_TYPE_CODETableAdapter.Fill(Me.DsSignPostType.SIGN_POST_TYPE_CODE)
        Me.SIGN_POST_CONFIG_CODETableAdapter.Fill(Me.DsSignPostConfig.SIGN_POST_CONFIG_CODE)
        Me.TblSignCassetteTableAdapter.Fill(Me.DsSignCassetteHardware.tblSignCassette)
        Me.RESTRICTIVE_PK_TYPE_CODETableAdapter.Fill(Me.DsRestrictiveParking.RESTRICTIVE_PK_TYPE_CODE)
        Me.TURNOUT_TYPE_CODETableAdapter.Fill(Me.DsTurnOutType.TURNOUT_TYPE_CODE)
        Me.BUS_PAD_CODETableAdapter.Fill(Me.DsBusPadType.BUS_PAD_CODE)
        Me.TblStopCoordTableAdapter.Fill(Me.DsGPS.tblStopCoord)
        Me.VwTimePointsTableAdapter.Fill(Me.DsTimePoints.vwTimePoints)
        Me.QryBusStopStatusTableAdapter.Fill(Me.DsBusStopStatus.qryBusStopStatus)
        Me.AMENITIES_OWNER_CODETableAdapter.Fill(Me.DsAmentityOwner.AMENITIES_OWNER_CODE)
        Me.AMENITIES_TYPE_CODETableAdapter.Fill(Me.DsAmenityType.AMENITIES_TYPE_CODE)
        Me.TblStopPsgrAmenitiesTableAdapter.Fill(Me.DsPassAmenities.tblStopPsgrAmenities)
        Me.HISTORY_TYPE_CODETableAdapter.Fill(Me.DsStopHistoryType.HISTORY_TYPE_CODE)
        Me.TblStopHistoryTableAdapter.Fill(Me.DsStopHistory.tblStopHistory)
        Me.CITY_CODETableAdapter1.Fill(Me.DsJurisdiction.CITY_CODE)
        Me.TblBusStopInformationTableAdapter.Fill(Me.DsBusStops.tblBusStopInformation)
        Me.ST_TYPE_CODETableAdapter.Fill(Me.DsStreetType.ST_TYPE_CODE)
        Me.BS_LOC_CODETableAdapter.Fill(Me.DsBusStopLocation.BS_LOC_CODE)
        Me.ST_DIR_CODETableAdapter.Fill(Me.DsTravelDirectionCode.ST_DIR_CODE)
        Me.CITY_CODETableAdapter.Fill(Me.DsCityCode.CITY_CODE)
        Me.COUNTY_CODETableAdapter.Fill(Me.DsCountyCode.COUNTY_CODE)
        Me.BS_STATUS_CODETableAdapter.Fill(Me.DsBusStopStatusCode1.BS_STATUS_CODE)
        Me.BS_STATUS_CODETableAdapter.Fill(Me.DsBusStopStatusCode.BS_STATUS_CODE)
        Me.TblStopTransAmenitiesTableAdapter.Fill(Me.DsTransitAmenities.tblStopTransAmenities)
        Me.ADA_STATUS_CODETableAdapter1.Fill(Me.DsADAStatusCode.ADA_STATUS_CODE)
        Me.ADA_STATUS_CODETableAdapter.Fill(Me.BusStopManagementDataSet5.ADA_STATUS_CODE)
        Me.TblADAStatusTableAdapter.Fill(Me.DsADA.tblADAStatus)
        Me.TblStaffTableAdapter.Fill(Me.BusStopManagementDataSet.tblStaff)
        Me.TblStopImagesTableAdapter.Fill(Me.BusStopManagementDataSet2.tblStopImages)
        Me.QryBusStopStatusTableAdapter.Fill(Me.DsBusStopStatus.qryBusStopStatus)

        TblStopImagesBindingSource.Filter = "OCTA_ID = 1"
        TblStopHistoryBindingSource.Filter = "OCTA_ID = 1"
        TblStopPsgrAmenitiesBindingSource.Filter = "OCTA_ID = 1"
        TblStopCoordBindingSource.Filter = "OCTA_ID = 1"
        TblStopTransAmenitiesBindingSource.Filter = "OCTA_ID = 1"
        TblSignCassetteBindingSource.Filter = "OCTA_ID = 1"
        VwTimePointsBindingSource.Filter = "OCTA_ID = 1"
        QryBusStopStatusBindingSource.Filter = "OCTA_ID = 1"
        Call LoadWOPriorityCode()

        txtPicDate.Format = DateTimePickerFormat.Custom
        txtPicDate.CustomFormat = "MM/dd/yyyy"
        dtEffectDate.Format = DateTimePickerFormat.Custom
        dtEffectDate.CustomFormat = "MM/dd/yyyy"
        dtGPSDate.Format = DateTimePickerFormat.Custom
        dtGPSDate.CustomFormat = "MM/dd/yyyy"
        txtDateIssued.Format = DateTimePickerFormat.Custom
        txtDateIssued.CustomFormat = "MM/dd/yyyy"

        If basUtilities.CurrentUserRight < basUtilities.UserRight.PowerUser Then
            LockFromViewer()
        Else
            If basUtilities.CurrentUserRight < basUtilities.UserRight.SystemAdmin Then
                LockFromPowerUser()
            End If
        End If

        SSTab1.SelectedIndex = tabEnum.sstStopHistory

        Me.Cursor = System.Windows.Forms.Cursors.Default

        Exit Sub

errHandler:
        MsgBox(Err.Description)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Resume Next
    End Sub

    Private Sub LockFromViewer()

        fraTop.Enabled = False
        fraWorkOrders.Enabled = False

        cbxNiteOwl.Enabled = False
        cbxBRT.Enabled = False

        cmdAddHistory.Visible = False
        cmdRemoveHistory.Visible = False
        cmdEdit.Visible = False

        fraStopPictures.Enabled = False
        fraADA.Enabled = False
        fraTransit.Enabled = False
        cbxPassSurvey.Enabled = False
        cmdAddAmen.Visible = False
        cmdRemAmen.Visible = False
        txtPARemarks.Enabled = False

        fraCassetteSurvey.Enabled = False
        BindingNavigatorAddNewItem1.Enabled = False
        BindingNavigatorDeleteItem1.Enabled = False
        SaveToolStripButton.Enabled = False
        bnBusStop.BindingSource.AllowNew = False

    End Sub
    Private Sub LockFromPowerUser()
        fraTop.Enabled = False
    End Sub

    Private Sub txtADARemarks_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        If txtADARemarks.Text = "" Then txtADARemarks.Text = " "
    End Sub

    Private Sub txtADARemarks_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs)
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtBsPdLen_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtBsPdLen.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtBsPdLen_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtBsPdLen.Leave
        If txtBsPdLen.Text = "" Then
            txtBsPdLen.Text = "0"
        ElseIf CInt(txtBsPdLen.Text) > 32767 Then
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            txtBsPdLen.SelectionStart = 0
            txtBsPdLen.SelectionLength = Len(txtBsPdLen.Text)
            txtBsPdLen.Focus()
        End If
    End Sub
    Private Sub txtBsPdWdth_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtBsPdWdth.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtBsPdWdth_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtBsPdWdth.Leave
        If txtBsPdWdth.Text = "" Then
            txtBsPdWdth.Text = "0"
        ElseIf CInt(txtBsPdWdth.Text) > 32767 Then
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            txtBsPdWdth.SelectionStart = 0
            txtBsPdWdth.SelectionLength = Len(txtBsPdWdth.Text)
            txtBsPdWdth.Focus()
        End If
    End Sub
    Private Sub txtCstRemarks_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCstRemarks.TextChanged
        If txtCstRemarks.Text = "" Then txtCstRemarks.Text = " "
    End Sub
    Private Sub txtCstRemarks_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtCstRemarks.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If

        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub txtElev_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtElev.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 And KeyAscii <> 46 Then
                KeyAscii = 0
            End If
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub txtFax_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs)
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub txtNoCst_KeyPress(ByRef KeyAscii As Short)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If
    End Sub
    Private Sub txtOCTAID_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        'Update corresponding tabs when the record changes
        If txtOCTAID.Text <> "" Then
            If SSTab1.SelectedIndex = tabEnum.sstWorkOrder Then
                'UpdateWOTab()
            ElseIf SSTab1.SelectedIndex = tabEnum.sstStopPic Then
                'UpdateImageTab()
            ElseIf SSTab1.SelectedIndex = tabEnum.sstStopHistory Then
                'UpdateStopHistoryTab()
            ElseIf SSTab1.SelectedIndex = tabEnum.sstPassengerAmen Then
                'UpdatePassAmenTab()
            End If
            ' Make sure rs("EFFECTIVE_DATE") has a value.
            If IsDBNull(rs.Fields("EFFECTIVE_DATE").Value) Then dtEffectDate.Value = Today.ToShortDateString

            'update route information
            UpdateRouteInfo()

            'Check Fax/Update
            'LockFaxUpdateControl()
        End If

        Current_SANZ_ID = txtSANZID.Text
    End Sub
    Private Sub UpdateRouteInfo()
        Dim strSQL As String
        Dim strRouteServed As String
        Dim strRouteDisplay As String
        Dim i As Integer

        strSQL = "SELECT DIR, RTE, HARDWARE FROM tblBusStopSequences AS A " _
                & "LEFT OUTER JOIN ROUTE_DIR_CODE AS B ON " _
                & "A.RTE_DIR_ID = B.ID " _
                & " WHERE A.OCTA_ID = " & txtOCTAID.Text & " AND A.SANZ_ID = '" & txtSANZID.Text & "'"

        rsRouteInfo.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        i = 0
        strRouteServed = ""
        strRouteDisplay = ""
        If Not rsRouteInfo.EOF Then
            Do While Not rsRouteInfo.EOF
                If rsRouteInfo.Fields("hardware").Value <> 8 And rsRouteInfo.Fields("hardware").Value <> 9 Then
                    strRouteDisplay = strRouteDisplay & rsRouteInfo.Fields("RTE").Value & rsRouteInfo.Fields("DIR").Value & Chr(44) & Chr(32)
                    i = i + 1
                End If
                strRouteServed = strRouteServed & rsRouteInfo.Fields("RTE").Value & rsRouteInfo.Fields("DIR").Value & Chr(44) & Chr(32)

                rsRouteInfo.MoveNext()
            Loop

            If strRouteDisplay <> "" Then strRouteDisplay = strRouteDisplay.Substring(0, Len(strRouteDisplay) - 2)
            If strRouteServed <> "" Then strRouteServed = strRouteServed.Substring(0, Len(strRouteServed) - 2)
        End If

        txtRouteServed.Text = strRouteServed
        txtRouteDisplay.Text = strRouteDisplay
        txtNumRouteDisplay.Text = CStr(i)

        rsRouteInfo.Close()
    End Sub
    Private Sub txtCBOCounty_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCBOCounty.TextChanged

        If txtCBOCounty.Text <> "" Then
            cboCounty.SelectedIndex = CShort(txtCBOCounty.Text) - 1
        Else
            cboCounty.Text = ""
        End If


    End Sub
    Private Sub cboCounty_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboCounty.SelectedIndexChanged
        txtCBOCounty.Text = CStr(cboCounty.SelectedIndex + 1)
    End Sub
    Private Sub cboCounty_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboCounty.Leave
        If Trim(cboCounty.Text) = "" Then
            MsgBox("Invalid entry! Value will be reset.", MsgBoxStyle.Exclamation)
            cboCounty.SelectedIndex = 0
            cboCounty.Focus()
        End If
    End Sub
    Private Sub txtCBOTravelType_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCBOTravelType.TextChanged
        If txtCBOTravelType.Text <> "" Then
            cboTravelType.SelectedIndex = CShort(txtCBOTravelType.Text) + 1
        Else
            cboTravelType.Text = ""
        End If
    End Sub
    Private Sub cboTravelType_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboTravelType.SelectedIndexChanged
        txtCBOTravelType.Text = CStr(cboTravelType.SelectedIndex - 1)
    End Sub
    Private Sub cboTravelType_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) 'Handles cboTravelType.KeyPress - ALEX
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        Dim cb As Integer
        Dim FindString As String

        If KeyAscii < 32 Or KeyAscii > 127 Then GoTo EventExitSub

        If cboTravelType.SelectionLength = 0 Then
            FindString = cboTravelType.Text & Chr(KeyAscii)
        Else
            FindString = cboTravelType.Text.Substring(0, cboTravelType.SelectionStart) & Chr(KeyAscii)
        End If

        cb = SendMessage(cboTravelType.Handle.ToInt32, CB_FINDSTRING, -1, FindString)

        If cb <> CB_ERR Then
            cboTravelType.SelectedIndex = cb
            cboTravelType.SelectionStart = Len(FindString)
            cboTravelType.SelectionLength = Len(cboTravelType.Text) - cboTravelType.SelectionStart
        End If
        KeyAscii = 0

EventExitSub:
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub cboTravelType_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboTravelType.Leave
        If Trim(cboTravelType.Text) = "" Then
            MsgBox("Invalid entry! Value will be reset.", MsgBoxStyle.Exclamation)
            cboTravelType.SelectedIndex = 0
            cboTravelType.Focus()
        End If
    End Sub
    Private Sub txtCBOXType_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCBOXType.TextChanged
        If txtCBOXType.Text <> "" Then
            cboXType.SelectedIndex = CShort(txtCBOXType.Text) + 1
        Else
            cboXType.Text = ""
        End If
    End Sub
    Private Sub cboXType_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboXType.SelectedIndexChanged
        txtCBOXType.Text = CStr(cboXType.SelectedIndex - 1)
    End Sub
    Private Sub cboXType_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboXType.Leave
        If Trim(cboXType.Text) = "" Then
            MsgBox("Invalid entry! Value will be reset.", MsgBoxStyle.Exclamation)
            cboXType.SelectedIndex = 0
            cboXType.Focus()
        End If
    End Sub
    Private Sub txtCBOBSStatus_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCBOBSStatus.TextChanged
        'by Anuket
        If txtCBOBSStatus.Text <> "" Then
            cboBSStatus.SelectedIndex = CShort(txtCBOBSStatus.Text) - 1
        Else
            cboBSStatus.Text = ""
        End If
    End Sub
    Private Sub cboBSStatus_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboBSStatus.SelectedIndexChanged
        'by Anuket
        txtCBOBSStatus.Text = CStr(cboBSStatus.SelectedIndex + 1)
    End Sub
    Private Sub cboBSStatus_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboBSStatus.Leave
        If Trim(cboBSStatus.Text) = "" Then
            MsgBox("Invalid entry! Value will be reset.", MsgBoxStyle.Exclamation)
            cboBSStatus.SelectedIndex = 0
            cboBSStatus.Focus()
        End If
    End Sub
    Private Sub txtCBOXLoc_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCBOXLoc.TextChanged
        If txtCBOXLoc.Text <> "" Then
            cboXLoc.SelectedIndex = CShort(txtCBOXLoc.Text) - 1
        Else
            cboXLoc.Text = ""
        End If
    End Sub
    Private Sub cboXLoc_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboXLoc.SelectedIndexChanged
        txtCBOXLoc.Text = CStr(cboXLoc.SelectedIndex + 1)
    End Sub
    Private Sub cboXLoc_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboXLoc.Leave
        If Trim(cboXLoc.Text) = "" Then
            MsgBox("Invalid entry! Value will be reset.", MsgBoxStyle.Exclamation)
            cboXLoc.SelectedIndex = 0
            cboXLoc.Focus()
        End If
    End Sub
    Private Sub txtCBOCity_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtCBOCity.TextChanged

        If txtCBOCity.Text <> "" Then
            cboCity.SelectedIndex = GetItemIndex(cboCity, CShort(txtCBOCity.Text))
        Else
            cboCity.Text = ""
        End If
    End Sub
    Private Sub cboCity_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        If cboCity.SelectedIndex <> -1 Then txtCBOCity.Text = CStr(cboCity.SelectedIndex)
    End Sub
    Private Sub cboCity_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs)
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        Dim cb As Integer
        Dim FindString As String

        If KeyAscii < 32 Or KeyAscii > 127 Then GoTo EventExitSub

        If cboCity.SelectionLength = 0 Then
            FindString = cboCity.Text & Chr(KeyAscii)
        Else
            FindString = cboCity.Text.Substring(0, cboCity.SelectionStart) & Chr(KeyAscii)
        End If

        cb = SendMessage(cboCity.Handle.ToInt32, CB_FINDSTRING, -1, FindString)

        If cb <> CB_ERR Then
            cboCity.SelectedIndex = cb
            cboCity.SelectionStart = Len(FindString)
            cboCity.SelectionLength = Len(cboCity.Text) - cboCity.SelectionStart
        End If
        KeyAscii = 0
EventExitSub:
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub cboCity_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        If Trim(cboCity.Text) = "" Then
            MsgBox("Invalid entry! Value will be reset.", MsgBoxStyle.Exclamation)
            cboCity.SelectedIndex = 0
            cboCity.Focus()
        End If
    End Sub
    Public Sub GoToStopID(iStopID As Integer)

        Me.TblBusStopInformationBindingSource.Position = Me.TblBusStopInformationBindingSource.Find("OCTA_ID", iStopID)
        OID = iStopID

    End Sub
    Private Sub cmdFindRecord_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdFindRecord.Click

        frmSearchBusStopMisc.rptIndex = 3
        frmSearchBusStopMisc.ShowDialog()

        If IsNumeric(OID) Then
            Me.TblBusStopInformationBindingSource.Position = Me.TblBusStopInformationBindingSource.Find("OCTA_ID", OID)
        End If

    End Sub
    Private Sub cmdAddNewRecord_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAddNewRecord.Click
        frmAddNewStop.ShowDialog()
    End Sub
    '################# END GENERAL FUNCTIONALITY #################

    '******************* STOP HISTORY TAB *******************/
    '=========================================================
    Private Function HasHistoryDoc(ByRef aID As Integer) As Boolean
        Dim rsDoc As New ADODB.Recordset
        Dim strSQL As String
        Dim bln As Boolean

        strSQL = "SELECT TOP 1 DOC_ID FROM tblHistoryDoc WHERE HISTORY_ID = " & aID
        rsDoc.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        bln = False
        If Not rsDoc.EOF Then bln = True

        rsDoc.Close()
        rsDoc = Nothing
        HasHistoryDoc = bln
    End Function

    Private Sub cmdAddHistory_Click(sender As Object, e As EventArgs) Handles cmdAddHistory.Click

        frmAddHistory.ShowDialog()

        TblStopHistoryBindingSource.DataSource = TblStopHistoryTableAdapter.GetData()
        TblStopHistoryBindingSource.ResetBindings(False)
        Me.tdbStopHist.Refresh()

    End Sub

    Private Sub cmdRemoveHistory_Click(sender As Object, e As EventArgs) Handles cmdRemoveHistory.Click
        On Error GoTo errHandler

        Dim lngRow As Integer
        Dim lngID As Integer
        Dim strSQL As String
        Dim vRow As VariantType

        If basUtilities.CurrentUserRight < basUtilities.UserRight.SystemAdmin Then
            MsgBox(DENY_MESSAGE, MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If MsgBox("Remove selected history record?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Sub
        Else
            If tdbStopHist.CurrentRow.Index < 0 Then
                Exit Sub
            End If
            vRow = tdbStopHist.CurrentRow.Index
            lngID = tdbStopHist.Item(0, vRow).Value

            If lngID <= 0 Then
                Exit Sub
            End If

            ' Delete based on currently selected record
            strSQL = "DELETE FROM tblStopHistory WHERE HISTORY_ID = " & lngID
            db.Execute(strSQL)
            TblStopHistoryBindingSource.DataSource = TblStopHistoryTableAdapter.GetData()
            TblStopHistoryBindingSource.ResetBindings(False)
            Me.tdbStopHist.Refresh()

            CreateObject("WScript.Shell").Popup("Record has been deleted", 1, "Deleted")
            MsgBox("Record has been deleted.", vbInformation, "Deleted")
        End If

        Exit Sub
errHandler:
        MsgBox(Err.Description)

    End Sub
    Private Sub tdbStopHist_SelectionChanged(sender As Object, e As EventArgs) Handles tdbStopHist.SelectionChanged
        Dim lngID As Integer
        Dim vRow As VariantType

        On Error GoTo errHandler

        'If tdbStopHist.CurrentRow.Index < 1 Then Exit Sub
        vRow = tdbStopHist.CurrentRow.Index
        lngID = tdbStopHist.Item(0, vRow).Value

        If lngID <= 0 Then Exit Sub
        gEditHistoryID = lngID

        Exit Sub

errHandler:

    End Sub
    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        Dim lngID As Integer
        Dim vRow As VariantType

        vRow = tdbStopHist.CurrentRow.Index
        lngID = tdbStopHist.Item(0, vRow).Value

        If lngID <= 0 Then Exit Sub
        gEditHistoryID = lngID

        frmEditHistory.ShowDialog()

        TblStopHistoryBindingSource.DataSource = TblStopHistoryTableAdapter.GetData()
        TblStopHistoryBindingSource.ResetBindings(False)
        Me.tdbStopHist.Refresh()

    End Sub

    '################# END STOP HISTORY TAB #################

    '************************ GPS TAB ************************/
    '==========================================================
    Private Sub cmdSaveGPS_Click(sender As Object, e As EventArgs) Handles cmdSaveGPS.Click

        Me.Validate()
        Me.TblStopCoordBindingSource.EndEdit()
        Me.TblStopCoordTableAdapter.Update(Me.DsGPS)
        MessageBox.Show("Record has been saved.")

    End Sub

    '###################### END GPS TAB ######################

    '******************* STOP PICTURES TAB *******************/
    '==========================================================
    Private Sub txtPicDate_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs)
        If Not IsDate(txtPicDate.Text) Then
            MsgBox("Not a date")
            txtPicDate.Focus()
        End If

    End Sub
    Private Sub cmdZoom_Click(sender As Object, e As EventArgs) Handles cmdZoom.Click

        frmBusStopPicDetail.ShowDialog()

    End Sub
    Private Sub cmdPicsNeeded_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPicsNeeded.Click
        Dim strSQL As String

        Try
            If cbxStopPhotoNeeded.CheckState = 0 Then
                cbxStopPhotoNeeded.CheckState = System.Windows.Forms.CheckState.Checked
                strSQL = "UPDATE tblBusStopInformation SET NEW_IMAGE_REQUIRED = 1 WHERE OCTA_ID = " & Me.txtOCTAID.Text.ToString
            Else
                cbxStopPhotoNeeded.CheckState = System.Windows.Forms.CheckState.Unchecked
                strSQL = "UPDATE tblBusStopInformation SET NEW_IMAGE_REQUIRED = 0 WHERE OCTA_ID = " & Me.txtOCTAID.Text.ToString
            End If
            db.Execute(strSQL)
        Catch ex As Exception
            MsgBox("Your request contains missing information", vbInformation)
        End Try

    End Sub
    Private Sub CancelToolStripButton_Click(sender As Object, e As EventArgs) Handles CancelToolStripButton.Click

        TblStopImagesBindingSource.CancelEdit()
        Me.TblStopImagesBindingSource.MoveFirst()

    End Sub
    Private Sub BindingNavigatorDeleteItem1_MouseDown(sender As Object, e As MouseEventArgs) Handles BindingNavigatorDeleteItem1.MouseDown
        Try
            If MessageBox.Show("Are you sure you want to delete the current record?",
                               "Confirm Delete",
                               MessageBoxButtons.OKCancel,
                               MessageBoxIcon.Question,
            MessageBoxDefaultButton.Button2) = DialogResult.OK Then
                Me.bnPictures.BindingSource.RemoveCurrent()
            End If

            Me.Validate()
            Me.TblStopImagesBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.BusStopManagementDataSet2)
            Me.TblStopImagesBindingSource.MoveNext()
            MsgBox("Picture has been deleted.", vbInformation, "Deleted")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub BindingNavigatorAddNewItem1_MouseUp(sender As Object, e As MouseEventArgs) Handles BindingNavigatorAddNewItem1.MouseUp

        txtPictureOCTA_ID.Text = txtOCTAID.Text
        SANZ_IDTextBox.Text = txtSANZID.Text
        cboTakenBy.Text = basUtilities.GetUserName
        txtPicDate.Value = Date.Today.ToShortDateString

    End Sub
    Private Sub SaveToolStripButton_Click(sender As Object, e As EventArgs) Handles SaveToolStripButton.Click

        Me.Validate()
        Me.TblStopImagesBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.BusStopManagementDataSet2)
        MessageBox.Show("Record has been added to the database")

    End Sub
    Private Sub AddPicture()
        On Error GoTo errHandler

        Dim datTaken As Date
        Dim i, X As Short
        Dim fName As String
        Dim tempPath As String
        Dim objFS As Scripting.FileSystemObject
        Dim information As System.IO.FileInfo
        Dim tempPicDir As String
        tempPicDir = GetSetting(System.Reflection.Assembly.GetExecutingAssembly.GetName.Name, "Directories", "PicDir")

        If tempPicDir <> "" Then
            tempPicDir = tempPicDir
        Else
            tempPicDir = "K:\SANZ\"
        End If

        Dim fd As OpenFileDialog = New OpenFileDialog()

        With fd
            .Title = "Add image to Stop..."
            .InitialDirectory = tempPicDir
            .Filter = "Picture Files (*.bmp;*.jpg;*.gif)|*.bmp;*.jpg;*.gif"
            .FilterIndex = 2
            .Multiselect = True
            .RestoreDirectory = True
        End With

        If fd.ShowDialog() = DialogResult.OK Then
            txtPicPath.Text = fd.FileName
        End If

        If fd.FileName <> "" Then
            strFiles = Split(fd.FileName, Chr(0))
            If UBound(strFiles) < 1 Then
                fName = strFiles(0)
                If My.Computer.FileSystem.FileExists(fName) Then
                    information = My.Computer.FileSystem.GetFileInfo(fName)
                    datTaken = information.CreationTime
                    AddNewPicRecord(fName, datTaken)
                End If
            End If

        End If

        Exit Sub
errHandler:
        MsgBox(Err.Description)

    End Sub
    Private Sub AddNewPicRecord(ByRef fName As String, ByRef dDateTaken As Date)

        txtPictureOCTA_ID.Text = txtOCTAID.Text
        SANZ_IDTextBox.Text = txtSANZID.Text
        txtPicPath.Text = fName
        cboTakenBy.SelectedIndex = basUtilities.CurrentUserRight
        txtPicDate.Value = dDateTaken

    End Sub
    Private Sub cmdPicBrowse_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPicBrowse.Click

        Dim fd As OpenFileDialog = New OpenFileDialog()

        With fd
            .Title = "Change image path to..."
            .InitialDirectory = "K:\SANZ\"
            .Filter = "Picture Files (*.bmp;*.jpg;*.gif)|*.bmp;*.jpg;*.gif"
            .FilterIndex = 2
            .RestoreDirectory = True
        End With

        If fd.ShowDialog() = DialogResult.OK Then
            txtPicPath.Text = fd.FileName
        End If

        UpdatePicture()

ErrHand:
        Err.Clear()
        Exit Sub
    End Sub
    Private Sub bsPictures_CurrentChanged(sender As Object, e As EventArgs) Handles bsPictures.CurrentChanged

        Call UpdatePicture()

    End Sub
    Private Sub TblStopImagesBindingSource_CurrentChanged(sender As Object, e As EventArgs) Handles TblStopImagesBindingSource.CurrentChanged

        Call UpdatePicture()

    End Sub
    Private Sub UpdatePicture()

        On Error GoTo errHandler

        Dim ratio As Double
        Dim newHeight As Double
        Dim newWidth As Double

        'If there is a picture to be displayed, then resize it to
        ' fit on the form, keeping aspect ratio
        If txtPicPath.Text <> "" Then
            If My.Computer.FileSystem.FileExists(txtPicPath.Text) Then
                imgStopPic.Image = System.Drawing.Image.FromFile(txtPicPath.Text)
                imgStopPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage

                'make sure the width stays on the form.
                newWidth = 640
                ratio = imgStopPic.Image.Height / imgStopPic.Image.Width
                newHeight = ratio * newWidth

                'make sure the height doesnt exceed its boundary
                If newHeight > 425 Then
                    newHeight = 425
                    ratio = imgStopPic.Image.Width / imgStopPic.Image.Height
                    newWidth = ratio * newHeight
                End If

                imgStopPic.Width = newWidth
                imgStopPic.Height = newHeight
            Else
                imgStopPic.Image = Nothing
            End If
        Else
            imgStopPic.Image = Nothing
        End If

        Exit Sub
errHandler:
        MsgBox(Err.Description)

    End Sub
    '################# END STOP PICTURES TAB #################

    '************************ ADA TAB ************************/
    '==========================================================
    Private Sub cboADAStatus_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboADAStatus.Leave
        If Trim(cboADAStatus.Text) = "" Then
            SSTab1.SelectedIndex = tabEnum.sstADA
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            cboADAStatus.Focus()
        End If
    End Sub
    Private Function ADAStatusMatch(ByRef aIndex As Short, ByRef fromCombo As Boolean) As Short
        Dim retIndex As Short

        If Not fromCombo Then
            Select Case aIndex
                Case 1
                    retIndex = 0
                Case 2
                    retIndex = 2
                Case 3
                    retIndex = 3
                Case 4
                    retIndex = 4
                Case 5
                    retIndex = 1
                Case Else
                    retIndex = -1
            End Select
        Else
            Select Case aIndex
                Case 0
                    retIndex = 1
                Case 1
                    retIndex = 5
                Case 2
                    retIndex = 2
                Case 3
                    retIndex = 3
                Case 4
                    retIndex = 4
                Case Else
                    retIndex = -1
            End Select
        End If

        ADAStatusMatch = retIndex
    End Function
    Private Sub btnADACreateHistory_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles btnADACreateHistory.Click

        If MsgBox("Create History record?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Sub
        End If

        Dim strSQL As String
        Dim intHistoryType As Short
        Dim strRemarks As String
        Dim strDate As String

        intHistoryType = 1 'Edit database
        strRemarks = "'EDIT ADA STATUS INFORMATION'"
        strDate = Date.Today.ToShortDateString()
        strSQL = "INSERT INTO tblStopHistory (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, HISTORY_TYPE_ID, " _
                & "REMARKS) VALUES (" & txtOCTAID.Text & ", '" & txtSANZID.Text & "', '" & strDate & "', " & CurrentLoginUserID & ", " & intHistoryType & ", " & strRemarks & ")"

        db.Execute(strSQL)

        MsgBox("Record created!", MsgBoxStyle.Information)
    End Sub

    '###################### END ADA TAB ######################

    '***************** TRANSIT AMENITIES TAB *****************/
    '==========================================================
    Private Sub cmdSaveTransAmenities_Click(sender As Object, e As EventArgs) Handles cmdSaveTransAmenities.Click
        On Error GoTo errHandler

        Me.Validate()
        Me.TblStopTransAmenitiesBindingSource.EndEdit()
        Me.TblStopTransAmenitiesTableAdapter.Update(Me.DsTransitAmenities)
        MessageBox.Show("Record has been saved.")

        Exit Sub
errHandler:
        MsgBox(Err.Description)

    End Sub

    '############### END TRANSIT AMENITIES TAB ###############

    '**************** PASSENGER AMENITIES TAB ****************/
    '==========================================================
    Private Sub cmdRemAmen_Click(sender As Object, e As EventArgs) Handles cmdRemAmen.Click
        On Error GoTo errHandler

        Dim lngRow As Integer
        Dim lngID As Integer
        Dim strSQL As String
        Dim vRow As VariantType

        If basUtilities.CurrentUserRight < basUtilities.UserRight.SystemAdmin Then
            MsgBox(DENY_MESSAGE, MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If MsgBox("Delete selected amenity record?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Sub
        End If

        If tdbPassAmen.CurrentRow.Index < 0 Then Exit Sub
        vRow = tdbPassAmen.CurrentRow.Index
        lngID = tdbPassAmen.Item(0, vRow).Value

        If lngID <= 0 Then Exit Sub

        ' Get the ID from invisible column in array
        strSQL = "DELETE FROM tblStopPsgrAmenities WHERE ID = " & lngID
        db.Execute(strSQL)

        TblStopPsgrAmenitiesBindingSource.DataSource = TblStopPsgrAmenitiesTableAdapter.GetData()
        TblStopPsgrAmenitiesBindingSource.ResetBindings(False)
        Me.tdbPassAmen.Refresh()

        MsgBox("Record has been deleted.", vbInformation, "Deleted")

        Exit Sub
errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdAddAmen_Click(sender As Object, e As EventArgs) Handles cmdAddAmen.Click

        frmAddAmenity.ShowDialog()

        TblStopPsgrAmenitiesBindingSource.DataSource = TblStopPsgrAmenitiesTableAdapter.GetData()
        TblStopPsgrAmenitiesBindingSource.ResetBindings(False)
        Me.tdbPassAmen.Refresh()

        MsgBox("Record has been Added.", vbInformation, "Added")
    End Sub
    Private Sub cmdSaveAmenity_Click(sender As Object, e As EventArgs) Handles cmdSaveAmenity.Click
        On Error GoTo errHandler

        Me.Validate()
        Me.TblStopPsgrAmenitiesBindingSource.EndEdit()
        Me.TblStopPsgrAmenitiesTableAdapter.Update(Me.DsPassAmenities)
        Me.tdbPassAmen.Refresh()

        MsgBox("Record has been Saved.", vbInformation, "Saved")

        Exit Sub
errHandler:
        MsgBox(Err.Description)

    End Sub

    '############### END PASSENGER AMENITIES TAB ###############


    '******************* SIGN/CASSETTE HARDWARE TAB *******************/
    '==========================================================

    Private Sub cmdSaveSignCassRecord_Click(sender As Object, e As EventArgs) Handles cmdSaveSignCassRecord.Click
        On Error GoTo errHandler

        Me.Validate()
        Me.TblSignCassetteBindingSource.EndEdit()
        Me.TblSignCassetteTableAdapter.Update(Me.DsSignCassetteHardware)
        MessageBox.Show("Record has been saved.")

        Exit Sub
errHandler:
        MsgBox(Err.Description)

    End Sub

    '################# END SIGN/CASSETTE HARDWARE TAB #################
    Private Sub txtTravelStreet_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs)
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub txtTrnBsBay_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtTrnBsBay.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub txtTrnBsBay_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTrnBsBay.Leave
        If txtTrnBsBay.Text = "" Then
            txtTrnBsBay.Text = "0"
        ElseIf CInt(txtTrnBsBay.Text) > 32767 Then
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            txtTrnBsBay.SelectionStart = 0
            txtTrnBsBay.SelectionLength = Len(txtTrnBsBay.Text)
            txtTrnBsBay.Focus()
        End If
    End Sub
    Private Sub txtTrnWidth_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtTrnWidth.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub txtTrnWidth_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTrnWidth.Leave
        If txtTrnWidth.Text = "" Then
            txtTrnWidth.Text = "0"
        ElseIf CInt(txtTrnWidth.Text) > 32767 Then
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            txtTrnWidth.SelectionStart = 0
            txtTrnWidth.SelectionLength = Len(txtTrnWidth.Text)
            txtTrnWidth.Focus()
        End If
    End Sub
    Private Sub txtTrnEgress_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtTrnEgress.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub txtTrnEgress_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTrnEgress.Leave
        If txtTrnEgress.Text = "" Then
            txtTrnEgress.Text = "0"
        ElseIf CInt(txtTrnEgress.Text) > 32767 Then
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            txtTrnEgress.SelectionStart = 0
            txtTrnEgress.SelectionLength = Len(txtTrnEgress.Text)
            txtTrnEgress.Focus()
        End If
    End Sub
    Private Sub txtTrnIngress_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtTrnIngress.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub txtTrnIngress_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTrnIngress.Leave
        If txtTrnIngress.Text = "" Then
            txtTrnIngress.Text = "0"
        ElseIf CInt(txtTrnIngress.Text) > 32767 Then
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            txtTrnIngress.SelectionStart = 0
            txtTrnIngress.SelectionLength = Len(txtTrnIngress.Text)
            txtTrnIngress.Focus()
        End If
    End Sub
    Private Sub txtTrshRemarks_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs)
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
    Private Sub RemoveEmptyWO()
        Dim strSQL As String

        strSQL = "DELETE  FROM tblWorkOrderReports WHERE WO_DESCRIPTION = ' ' OR WO_DESCRIPTION = '' OR " _
                & "WO_DESCRIPTION IS NULL"
        dbRep.Execute(strSQL)
    End Sub
    Private Sub txtYCoord_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtYCoord.Leave
        If Not IsNumeric(txtYCoord.Text) Then
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            txtYCoord.SelectionStart = 0
            txtYCoord.SelectionLength = Len(txtYCoord.Text)
            txtYCoord.Focus()
        End If
    End Sub
    Private Sub cmdSaveADARecord_Click(sender As Object, e As EventArgs) Handles cmdSaveADARecord.Click

        Me.Validate()
        Me.TblADAStatusBindingSource.EndEdit()
        Me.TableAdapterManager2.UpdateAll(Me.DsADA)
        MessageBox.Show("Record has been updated.")

    End Sub
    Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs)
        Try
            Me.BS_STATUS_CODETableAdapter.FillBy(Me.DsBusStopStatusCode.BS_STATUS_CODE)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub
    Private Sub SaveAll()
        Try

            'Save ADA
            Me.Validate()
            Me.TblADAStatusBindingSource.EndEdit()
            Me.TableAdapterManager2.UpdateAll(Me.DsADA)

            'Save Transit Amenities
            Me.Validate()
            Me.TblStopTransAmenitiesBindingSource.EndEdit()
            Me.TblStopTransAmenitiesTableAdapter.Update(Me.DsTransitAmenities)

            'Save Passenger Amenities
            Me.Validate()
            Me.TblStopPsgrAmenitiesBindingSource.EndEdit()
            Me.TblStopPsgrAmenitiesTableAdapter.Update(Me.DsPassAmenities)
            Me.tdbPassAmen.Refresh()

            'Save Sign Cassette
            Me.Validate()
            Me.TblSignCassetteBindingSource.EndEdit()
            Me.TblSignCassetteTableAdapter.Update(Me.DsSignCassetteHardware)

            'Save GPS
            Me.Validate()
            Me.TblStopCoordBindingSource.EndEdit()
            Me.TblStopCoordTableAdapter.Update(Me.DsGPS)

        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub
    Private Sub tsbSaveBusStop_Click(sender As Object, e As EventArgs) Handles tsbSaveBusStop.Click

        Me.Validate()
        Me.TblBusStopInformationBindingSource.EndEdit()
        Me.TblBusStopInformationTableAdapter.Update(Me.DsBusStops)
        SaveAll()

        MessageBox.Show("Record has been saved.")

    End Sub
    Private Sub txtStopID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStopID.KeyPress

        If Asc(e.KeyChar) = 13 Then
            'Call cmdFindRecord_Click(cmdFindRecord, New System.EventArgs())
            If IsNumeric(txtStopID.Text) Then
                Me.TblBusStopInformationBindingSource.Position = Me.TblBusStopInformationBindingSource.Find("OCTA_ID", txtStopID.Text)
            End If
        End If

    End Sub
    Private Sub FormatWOGridColumns()

        Dim rs As New ADODB.Recordset
        strSQL = "SELECT ITEM_NO, WO_GROUP_ID, DESCRIPTION FROM dbo.WO_ITEM_CODE WHERE DELETED = 0 ORDER BY WO_GROUP_ID, ID"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        Dim i As Integer
        i = 0

        Do While Not rs.EOF
            WOGrid1.Rows.Add(0, rs.Fields("DESCRIPTION").Value, IIf(IsDBNull(rs.Fields("ITEM_NO").Value), "99", rs.Fields("ITEM_NO").Value))
            rs.MoveNext()
            i = i + 1
        Loop

        rs.Close()
        rs = Nothing

        WOGrid1.Rows.Insert(0, 0, "SIGN MAINTENANCE", "")
        WOGrid1.Rows(0).Cells(0).ReadOnly = True
        WOGrid1.Rows(0).Cells(0).Style.BackColor = Color.DarkGray
        WOGrid1.Rows(0).Cells(1).Style.BackColor = Color.DarkGray
        WOGrid1.Rows(0).Cells(0).Style.ForeColor = Color.White
        WOGrid1.Rows(0).Cells(1).Style.ForeColor = Color.White
        WOGrid1.Rows.Insert(13, 0, "SIGN AND POST MAINTENANCE", "")
        WOGrid1.Rows(13).Cells(0).ReadOnly = True
        WOGrid1.Rows(13).Cells(0).Style.BackColor = Color.DarkGray
        WOGrid1.Rows(13).Cells(1).Style.BackColor = Color.DarkGray
        WOGrid1.Rows(13).Cells(0).Style.ForeColor = Color.White
        WOGrid1.Rows(13).Cells(1).Style.ForeColor = Color.White
        WOGrid1.Rows.Insert(26, 0, "GENERAL MAINTENANCE", "")
        WOGrid1.Rows(26).Cells(0).ReadOnly = True
        WOGrid1.Rows(26).Cells(0).Style.BackColor = Color.DarkGray
        WOGrid1.Rows(26).Cells(1).Style.BackColor = Color.DarkGray
        WOGrid1.Rows(26).Cells(0).Style.ForeColor = Color.White
        WOGrid1.Rows(26).Cells(1).Style.ForeColor = Color.White
        WOGrid1.Rows.Insert(37, 0, "STOP AMENITIES", "")
        WOGrid1.Rows(37).Cells(0).ReadOnly = True
        WOGrid1.Rows(37).Cells(0).Style.BackColor = Color.DarkGray
        WOGrid1.Rows(37).Cells(1).Style.BackColor = Color.DarkGray
        WOGrid1.Rows(37).Cells(0).Style.ForeColor = Color.White
        WOGrid1.Rows(37).Cells(1).Style.ForeColor = Color.White

    End Sub

    '//////////////////////////////////////////////////////////////////////////////////////////////////
    '////////////////////////////////New Work Order Implementation/////////////////////////////////////
    '//////////////////////////////////////////////////////////////////////////////////////////////////

    Private Sub TblBusStopInformationBindingSource_CurrentChanged(sender As Object, e As EventArgs) Handles TblBusStopInformationBindingSource.CurrentChanged

        If Me.txtOCTAID.Text <> "" Then
            txtStopID.Text = ""
            TblStopImagesBindingSource.Filter = "OCTA_ID = " & Me.txtOCTAID.Text & ""
            TblStopImagesBindingSource.MoveFirst()
            Call UpdatePicture()
            TblADAStatusBindingSource.Filter = "OCTA_ID = " & Me.txtOCTAID.Text & ""
            TblStopHistoryBindingSource.Filter = "OCTA_ID = " & Me.txtOCTAID.Text & ""
            lblStopHistoryCount.Text = "Number of Records: " & tdbStopHist.RowCount & ""
            TblStopPsgrAmenitiesBindingSource.Filter = "OCTA_ID = " & Me.txtOCTAID.Text & ""
            TblStopCoordBindingSource.Filter = "OCTA_ID = " & Me.txtOCTAID.Text & ""
            TblStopTransAmenitiesBindingSource.Filter = "OCTA_ID = " & Me.txtOCTAID.Text & ""
            TblSignCassetteBindingSource.Filter = "OCTA_ID = " & Me.txtOCTAID.Text & ""
            VwTimePointsBindingSource.Filter = "OCTA_ID = " & Me.txtOCTAID.Text & ""
            QryBusStopStatusBindingSource.Filter = "OCTA_ID = " & Me.txtOCTAID.Text & ""
            Call UpdateRouteInfo()

            'Check to see if this is a Time Point
            txtTPName.Visible = False
            lblTPName.Visible = False
            lblTPName.ForeColor = Color.DimGray
            cmdAddTP.Enabled = False
            cmdDeleteTP.Enabled = False
            dtpStartDate.Enabled = False
            dtpEndDate.Enabled = False
            dtpStartDate.Enabled = False
            dtpEndDate.Enabled = False
            lblTPRemoved.Visible = False
            cmdUpdateRemoveTP.Enabled = False
            txtTPRemovalDesc.Enabled = False

            If txtTPName.Text <> "" Then
                txtTPName.Visible = True
                lblTPName.Visible = True
                cmdAddTP.Enabled = True
                dtpStartDate.Enabled = True
                dtpEndDate.Enabled = True
                txtTPRemovalDesc.Enabled = True
            End If

            'Check the status of the Time Point
            Dim rs As New ADODB.Recordset
            Dim iCount As Integer

            strSQL = "SELECT Count(ID) As rsCount From dbo.qryBusStopStatus WHERE OCTA_ID = " & Me.txtOCTAID.Text & ""
            rs.Open(strSQL, dbRep, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)
            If Not (rs.BOF And rs.EOF) Then
                iCount = rs.Fields("rsCount").Value
            End If

            rs.Close()
            rs = Nothing

            If iCount > 0 Then 'This TP has been removed
                dtpStartDate.Enabled = True
                dtpEndDate.Enabled = True
                lblTPRemoved.Visible = True
                lblTPName.ForeColor = Color.Red
                cmdUpdateRemoveTP.Enabled = True
                cmdDeleteTP.Enabled = True
                cmdAddTP.Enabled = False
                txtTPRemovalDesc.Enabled = True
            End If

        End If

    End Sub

    Private Sub tdbStopHist_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles tdbStopHist.CellClick

        If tdbStopHist.Columns(e.ColumnIndex).Name = "cmdAttachments" Then
            If tdbStopHist.Rows(e.RowIndex).Cells(0).Value > 0 Then
                gEditHistoryID = tdbStopHist.Rows(e.RowIndex).Cells(0).Value
                frmMiscDocs.Show()
            End If
        End If

    End Sub

    Private Sub cmdSaveWORecord_Click(sender As Object, e As EventArgs) Handles cmdSaveWORecord.Click
        On Error GoTo errHandler

        strSQL = "INSERT INTO dbo.tblTmpWOReports(OCTA_ID, " _
                & "SANZ_ID, " _
                & "WO_DATE_ISSUED, " _
                & "WO_PRIORITY_ID, " _
                & "WO_DESCRIPTION, " _
                & "WO_ITEMS, " _
                & "WO_DIG_ALERT, " _
                & "STREET_OF_TRAVEL, " _
                & "CROSS_STREET, " _
                & "CROSS_STREET_1, " _
                & "WO_ISSUED_BY, " _
                & "type1_TYPE, " _
                & "type2_TYPE, " _
                & "DIR, " _
                & "LOC, " _
                & "CITY, " _
                & "ROUTE_DISPLAY) " _
                & "VALUES(" _
                & Me.txtOCTAID.Text & ", '" _
                & Me.txtSANZID.Text & "', '" _
                & Date.Now.ToString(sFormat) & "', " _
                & Me.cboPriorityWO.SelectedValue & " , '" _
                & Me.txtWorkOrdersWO.Text & "', '" _
                & Me.txtWOItems.Text & "', " _
                & Me.cbxWO_Dig_AlertWO.CheckState & ", '" _
                & Me.txtTravelStreet.Text & "', '" _
                & Me.txtXStreet.Text & "', '" _
                & Me.txtXStreet1.Text & "', '" _
                & GetUserName() & "', '" _
                & Me.cboTravelType.Text & "', '" _
                & Me.cboXType.Text & "', '" _
                & Me.cboTravelDir.Text & "', '" _
                & Me.cboXLoc.Text & "', '" _
                & Me.cboCity.Text & "', '" _
                & Me.txtRouteDisplay.Text & "')"

        db.Execute(strSQL)

        CreateObject("WScript.Shell").Popup("Record has been saved", 1, "Saved")

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub
    Private Sub cmdClearAllWO_Click(sender As Object, e As EventArgs) Handles cmdClearAllWO.Click

        For i = 0 To WOGrid1.RowCount - 1
            WOGrid1.Rows(i).Cells(0).Value = 0
        Next

        txtWorkOrdersWO.Text = ""
        txtWOItems.Text = ""

    End Sub
    Private Sub cmdPrvWorkWO_Click(sender As Object, e As EventArgs) Handles cmdPrvWorkWO.Click
        Dim strSQL As String
        Dim rsData As New ADODB.Recordset
        Dim rsCheck As New ADODB.Recordset
        Dim sReportName As String = ""

        strSQL = "DELETE FROM tblWorkOrderReports"
        dbRep.Execute(strSQL)

        strSQL = "INSERT INTO tblWorkOrderReports " _
                & "SELECT * FROM tblTmpWOReports WHERE WO_DESCRIPTION <> ' ' AND " _
                & "WO_DESCRIPTION <> '' AND WO_DESCRIPTION IS NOT NULL AND OCTA_ID = " & txtOCTAID.Text
        dbRep.Execute(strSQL)

        strSQL = "SELECT * FROM tblWorkOrderReports"
        rsData.Open(strSQL, dbRep, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)

        If rsData.EOF Then
            MsgBox("SELECT MAINTENANCE DESCRIPTION(S) BEFORE PREVIEWING OR PRINTING WORK ORDER", MsgBoxStyle.Information)
            rsData.Close()
            rsData = Nothing
            Exit Sub
        End If

        rsData.Close()
        rsData = Nothing

        'Trim Description
        Call TrimDescription()

        If cbxWO_Dig_AlertWO.CheckState = 1 Then
            sReportName = "WorkOrderReport.rpt"
        Else
            sReportName = "WorkOrderReport_No_DigAlert.rpt"
        End If

        frmCrystalReportsWP.LoadReport(sReportName, "", "", "")

    End Sub
    Private Sub TrimDescription()
        Dim rsTrim As New ADODB.Recordset

        rsTrim.Open("tblWorkOrderReports", dbRep, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdTableDirect)

        Do While Not rsTrim.EOF
            rsTrim.Fields("WO_DESCRIPTION").Value = Trim(rsTrim.Fields("WO_DESCRIPTION").Value)
            rsTrim.Update()
            rsTrim.MoveNext()
        Loop

        rsTrim.Close()
        rsTrim = Nothing

    End Sub
    Private Sub IssueWO(ByVal sMode As String)
        On Error GoTo errHandler

        Dim cText As CRAXDRT.TextObject
        Dim cSec As CRAXDRT.Section
        Dim sReportName As String = ""
        Dim intHistoryType As Short
        Dim strDate As String
        Dim sMsgbox As String
        Dim strSQL As String = ""
        Dim rsCheck As New ADODB.Recordset
        Dim rsCost As New ADODB.Recordset
        Dim strFieldsList As String = ""
        Dim strValuesList As String = ""
        Dim i As Short
        Dim j As Short
        Dim r As Short
        Dim sngTotalCost As Single
        Dim filePath As String = ""
        Dim strFPath As String = ""
        Dim objFile As New Scripting.FileSystemObject
        Dim directoryExists As Boolean
        Dim rsHDoc As New ADODB.Recordset
        Dim histId As Integer
        Dim sWONumber As String = ""

        Dim EmailList As New ArrayList
        Dim WOList As New ArrayList

        If sMode = "PrintAll" Or sMode = "EmailAll" Then
            sMsgbox = "This action will issue work order(s) and save record(s) to history table. You will NOT be " _
                  & "able to cancel the action after you click yes. Continue?"
        ElseIf sMode = "PrintCurrent" Or sMode = "EmailCurrent" Or sMode = "PrintEmailAll" Then
            sMsgbox = "This action will issue the current work order and save the record to the history table. You will NOT be " _
                  & "able to cancel the action after you click yes. Continue?"
        Else
            Exit Sub
        End If

        If MsgBox(sMsgbox, MsgBoxStyle.YesNo + MsgBoxStyle.Exclamation) = MsgBoxResult.No Then
            Exit Sub
        End If

        strSQL = "DELETE FROM tblTmpWOReports WHERE WO_DESCRIPTION = ' ' OR " _
                & "WO_DESCRIPTION = '' OR WO_DESCRIPTION IS NULL"

        dbRep.Execute(strSQL)

        Dim rsAll As New ADODB.Recordset

        If sMode = "PrintCurrent" Or sMode = "EmailCurrent" Then
            strSQL = "SELECT * FROM tblTmpWOReports WHERE OCTA_ID = " & Me.txtOCTAID.Text & ""
        ElseIf sMode = "PrintAll" Or sMode = "EmailAll" Or sMode = "PrintEmailAll" Then
            strSQL = "SELECT * FROM tblTmpWOReports"
        Else
            Exit Sub
        End If

        rsAll.Open(strSQL, dbRep, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)

        If rsAll.RecordCount < 1 Then
            MsgBox("No Current Work Orders")
            Exit Sub
        End If

        strSQL = "DELETE FROM tblWorkOrderReports"
        dbRep.Execute(strSQL)

        rsAll.MoveFirst()
        Do Until rsAll.EOF
            Dim rsWO As New ADODB.Recordset

            strSQL = "INSERT INTO tblWorkOrderReports " _
                    & "SELECT * FROM tblTmpWOReports WHERE WO_DESCRIPTION <> ' ' AND " _
                    & "WO_DESCRIPTION <> '' AND WO_DESCRIPTION IS NOT NULL And OCTA_ID = " & rsAll.Fields("OCTA_ID").Value

            dbRep.Execute(strSQL)

            ' Get the list of Work Orders from temporary database
            strSQL = "SELECT * FROM tblWorkOrderReports WHERE OCTA_ID = " & rsAll.Fields("OCTA_ID").Value & ""
            rsWO.Open(strSQL, dbRep, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)

            If rsWO.EOF Then
                MsgBox("No active work order to issue.", MsgBoxStyle.Information)
                rsWO.Close()
                rsWO = Nothing
                Exit Sub
            End If
            ' copy them to the permanent database and assign new WO_ID
            CopyADOtoAccess(rsWO, db, "tblWorkOrders", "WO_ID")

            rsWO.MoveFirst()
            'Trim Description
            Call TrimDescription()

            'Show Report
            If rsWO.Fields("wo_dig_alert").Value = True Then
                sReportName = "workorderreport.rpt"
            Else
                sReportName = "workorderreport_no_digalert.rpt"
            End If

            'save record(s) to history table
            intHistoryType = 23 'work order
            strDate = Date.Now.ToString(sFormat)

            strFPath = GetAppValue("WorkOrderReportPath")

            If strFPath = "" Or strFPath = "Not Found" Then
                MsgBox("Problem creating work order file, please check the path in the Administrator's Utilities")
                GoTo errHandler
            Else
                directoryExists = objFile.FolderExists(strFPath)
                If directoryExists = False Then
                    MsgBox("Problem creating work order file, please check the path in the Administrator's Utilities")
                    GoTo errHandler
                Else
                    filePath = strFPath & "WO_" & rsWO.Fields("OCTA_ID").Value & "_" & rsWO.Fields("WO_ID").Value & ".doc"
                    EmailList.Add(filePath)
                    WOList.Add(rsWO.Fields("WO_ID").Value)
                    If sMode = "PrintCurrent" Or sMode = "PrintEmailAll" Or sMode = "PrintAll" Then
                        frmCrystalReportsWP.LoadExportOnly(sReportName, filePath, True)
                    ElseIf sMode = "EmailAll" Or sMode = "EmailCurrent" Then
                        frmCrystalReportsWP.LoadExportOnly(sReportName, filePath, False)
                    Else
                        frmCrystalReportsWP.LoadExportOnly(sReportName, filePath, True)
                    End If
                End If
            End If

            sWONumber = rsWO.Fields("WO_ID").Value
            ' Save a record into History table...
            strSQL = "insert into tblstophistory (octa_id, sanz_id, [date], staff_id, history_type_id, wo_num, " _
                        & "remarks) values (" & rsWO.Fields("octa_id").Value & ", '" & rsWO.Fields("sanz_id").Value & "', '" _
                        & strDate & "', " & CurrentLoginUserID & ", " & intHistoryType & ", " _
                        & rsWO.Fields("wo_id").Value & ", " & cV2Q_String(rsWO.Fields("wo_description").Value) & ")"

            db.Execute(strSQL)
            strSQL = "SELECT * FROM [tblStopHistory];"
            rsHDoc.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)
            rsHDoc.MoveLast()
            histId = rsHDoc.Fields("HISTORY_ID").Value
            rsHDoc.Close()

            ' Update tblHistoryDoc
            strSQL = "INSERT INTO [tblHistoryDoc] (HISTORY_ID, DOC_PATH) VALUES (" & histId & ",'" & filePath & "');"
            db.Execute(strSQL)

            strSQL = "DELETE  FROM tblTmpWOReports WHERE OCTA_ID = " & rsAll.Fields("OCTA_ID").Value & ""
            dbRep.Execute(strSQL)

            strSQL = "DELETE  FROM tblWorkOrderReports WHERE OCTA_ID = " & rsAll.Fields("OCTA_ID").Value & ""
            dbRep.Execute(strSQL)

            rsAll.MoveNext()
        Loop

        If sMode = "EmailAll" Or sMode = "PrintEmailAll" Or sMode = "EmailCurrent" Then
            Call EmailWorkOrder(EmailList, WOList)
        End If

        CreateObject("WScript.Shell").Popup("Work Orders have been processed", 1, "Processed...")

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub
    Private Sub cmdIssueAll_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPrintEmailAll.Click

        Call IssueWO("PrintEmailAll")
        TblStopHistoryBindingSource.DataSource = TblStopHistoryTableAdapter.GetData()
        TblStopHistoryBindingSource.ResetBindings(False)
        Me.tdbStopHist.Refresh()

    End Sub

    Private Sub LoadWOPriorityCode()

        Dim rs As New ADODB.Recordset

        strSQL = "SELECT PRIORITY, DESCRIPTION FROM WO_PRIORITY_CODE WHERE ACTIVE = 1"

        cboPriorityWO.DisplayMember = "DESCRIPTION"
        cboPriorityWO.ValueMember = "PRIORITY"

        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("PRIORITY", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("PRIORITY").Value)
                rs.MoveNext()
            Loop
        End If

        cboPriorityWO.DataSource = tb
        cboPriorityWO.Enabled = True

        rs.Close()
        rs = Nothing

        cboPriorityWO.SelectedIndex = 0

    End Sub
    Private Sub cmWOPrintCurrent_Click(sender As Object, e As EventArgs) Handles cmWOPrintCurrent.Click

        Call IssueWO("PrintCurrent")
        TblStopHistoryBindingSource.DataSource = TblStopHistoryTableAdapter.GetData()
        TblStopHistoryBindingSource.ResetBindings(False)
        Me.tdbStopHist.Refresh()

    End Sub
    Private Sub cmdWOPrintAll_Click(sender As Object, e As EventArgs) Handles cmdWOPrintAll.Click

        Call IssueWO("PrintAll")
        TblStopHistoryBindingSource.DataSource = TblStopHistoryTableAdapter.GetData()
        TblStopHistoryBindingSource.ResetBindings(False)
        Me.tdbStopHist.Refresh()

    End Sub
    Private Sub cmdWOEmailCurrent_Click(sender As Object, e As EventArgs) Handles cmdWOEmailCurrent.Click

        Call IssueWO("EmailCurrent")
        TblStopHistoryBindingSource.DataSource = TblStopHistoryTableAdapter.GetData()
        TblStopHistoryBindingSource.ResetBindings(False)
        Me.tdbStopHist.Refresh()

    End Sub
    Public Sub EmailWorkOrder(ByVal Emaillist As ArrayList, ByVal WOList As ArrayList)
        On Error GoTo errHandler

        Dim strFPath As String = ""
        Dim strSendTo As String = ""
        Dim strCC1 As String = ""
        Dim strCC2 As String = ""
        Dim strCC As String = ""
        Dim strWOs As String = ""
        Dim sEmailAddress As String
        Dim sWONumber As String
        Dim strBody As String

        strBody = "The following Work Orders from OCTA are attached." & vbCrLf
        For Each sWONumber In WOList
            strBody = strBody & vbTab & sWONumber & vbCrLf
        Next

        Dim oApp As Microsoft.Office.Interop.Outlook._Application
        oApp = New Microsoft.Office.Interop.Outlook.Application

        Dim oMsg As Microsoft.Office.Interop.Outlook._MailItem
        oMsg = oApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem)

        oMsg.Subject = "New Work Order from OCTA."
        strSendTo = GetAppValue("WO_Email")
        strCC1 = GetAppValue("WO_Email_CC1")
        strCC2 = GetAppValue("WO_Email_CC2")
        strCC = strCC1 & "; " & strCC2
        MsgBox(strCC)
        oMsg.To = strSendTo
        oMsg.CC = strCC
        strFPath = GetReportPath()
        oMsg.Body = strBody
        oMsg.BodyFormat = Microsoft.Office.Interop.Outlook.OlBodyFormat.olFormatHTML

        For Each sEmailAddress In Emaillist
            If sEmailAddress <> "" Then
                Dim sBodyLen As Integer = 20
                Dim oAttachs As Microsoft.Office.Interop.Outlook.Attachments = oMsg.Attachments
                Dim oAttach As Microsoft.Office.Interop.Outlook.Attachment
                oAttach = oAttachs.Add(sEmailAddress, , sBodyLen, sEmailAddress)
            End If
        Next

        oMsg.Send()

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub
    Private Sub cmdWOEmailAll_Click(sender As Object, e As EventArgs) Handles cmdWOEmailAll.Click

        Call IssueWO("EmailAll")
        TblStopHistoryBindingSource.DataSource = TblStopHistoryTableAdapter.GetData()
        TblStopHistoryBindingSource.ResetBindings(False)
        Me.tdbStopHist.Refresh()

    End Sub
    Private Sub SSTab1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles SSTab1.SelectedIndexChanged

        If SSTab1.SelectedIndex = 6 Then
            Call UpdatePicture()
        End If

    End Sub
    Private Sub WOGrid1_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles WOGrid1.CurrentCellDirtyStateChanged

        On Error GoTo errHandler
        Dim sList As String = ""
        Dim sItemNumber As String = ""

        If WOGrid1.RowCount = 0 Then Exit Sub

        For i = 0 To WOGrid1.RowCount - 1
            If WOGrid1.Rows(i).Cells(0).Value Then
                sList = sList & Trim(WOGrid1.Rows(i).Cells(2).Value) & " - " & Trim(WOGrid1.Rows(i).Cells(1).Value) & vbCrLf
                sItemNumber = sItemNumber & Trim(WOGrid1.Rows(i).Cells(2).Value) & ", "
            End If
        Next

        If Len(sItemNumber) < 2 Then Exit Sub
        txtWorkOrdersWO.Text = sList
        txtWOItems.Text = sItemNumber.Substring(0, Len(sItemNumber) - 2)

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdSearch_Click(sender As Object, e As EventArgs) Handles cmdSearch.Click
        Dim sSearchString As String

        On Error GoTo errHandler

        sSearchString = Microsoft.VisualBasic.Interaction.InputBox("Enter Your Search Criteria", "Search Stop History")
        TblStopHistoryBindingSource.Filter = "REMARKS LIKE '%" & sSearchString & "%' AND OCTA_ID = " & txtOCTAID.Text & ""
        lblStopHistoryCount.Text = "Number of Records: " & tdbStopHist.RowCount & ""
        Me.tdbStopHist.Refresh()

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdRemoveFilter_Click(sender As Object, e As EventArgs) Handles cmdRemoveFilter.Click
        On Error GoTo errHandler

        TblStopHistoryBindingSource.Filter = "OCTA_ID = " & txtOCTAID.Text & ""
        lblStopHistoryCount.Text = "Number of Records: " & tdbStopHist.RowCount & ""
        Me.tdbStopHist.Refresh()

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub lnkArchivedDocs_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkArchivedDocs.LinkClicked
        On Error GoTo errHandler

        Dim rs As New ADODB.Recordset
        Dim strSQL As String

        strSQL = "SELECT DOCUMENT_ID FROM dbo.tblBusStopInformation WHERE OCTA_ID = " & Me.txtOCTAID.Text
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If IsDBNull(rs.Fields("DOCUMENT_ID").Value) Then
            MsgBox("No Archived Documents exist for this Stop ID", MsgBoxStyle.Information, "No Documents")
        Else
            System.Diagnostics.Process.Start("https://ecm.octa.net/snz/_layouts/15/DocIdRedir.aspx?ID=" & rs.Fields("DOCUMENT_ID").Value & "")
        End If

        rs.Close()
        rs = Nothing

        Exit Sub

errHandler:
        MsgBox(Err.Description)
    End Sub

    Private Sub dtpEndDate_Validating(sender As Object, e As CancelEventArgs) Handles dtpEndDate.Validating

        If dtpEndDate.Value < Date.Today Then
            MessageBox.Show("Date cannot be before today.")
            e.Cancel = True
        End If

    End Sub

    Private Sub cmdUpdateRemoveTP_Click(sender As Object, e As EventArgs) Handles cmdUpdateRemoveTP.Click
        On Error GoTo errHandler

        strSQL = "UPDATE dbo.tblBusStopStatus SET StartDate = '" & dtpStartDate.Value & "', "
        strSQL = strSQL & "EndDate = '" & dtpEndDate.Value & "', Description = '" & txtTPRemovalDesc.Text & "' "
        strSQL = strSQL & "WHERE ID = " & txtBusStopStatusID.Text & ""
        db.Execute(strSQL)
        MsgBox("Time Point has been updated")
        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdAddTP_Click(sender As Object, e As EventArgs) Handles cmdAddTP.Click
        On Error GoTo errHandler

        strSQL = "INSERT INTO dbo.tblBusStopStatus(BusStopID, Description, StartDate, EndDate, BSMCreated, CreatedBy) "
        strSQL = strSQL & "VALUES ('" & Me.txtOCTAID.Text & "', '" & txtTPRemovalDesc.Text & "', '" & dtpStartDate.Value & "', '" & dtpEndDate.Value & "', 1, '" & CurrentLoginUser & "')"

        db.Execute(strSQL)
        MsgBox("Time Point has been added")
        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdDeleteTP_Click(sender As Object, e As EventArgs) Handles cmdDeleteTP.Click
        On Error GoTo errHandler

        strSQL = "UPDATE dbo.tblBusStopStatus SET Description = '" & txtTPRemovalDesc.Text & "', Removed = 1, RemovedDate = '" & Date.Today() & "', RemovedBy = '" & CurrentLoginUser & "' WHERE ID = " & txtBusStopStatusID.Text & ""
        db.Execute(strSQL)
        MsgBox("Time Point has been removed from the Bus Stop Status List")
        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdViewActiveList_Click(sender As Object, e As EventArgs) Handles cmdViewActiveList.Click
        Dim rs As New ADODB.Recordset
        Dim strMsg As String = ""

        strSQL = "SELECT BusStopID, StartDate, EndDate FROM [dbo].[tblBusStopStatus] WHERE [BSMCreated] = 1 AND (RemovedDate) IS NULL"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                strMsg = strMsg & "Stop ID: " & rs.Fields("BusStopID").Value & " - Start Date: " & rs.Fields("StartDate").Value & " : End Date: " & rs.Fields("EndDate").Value & "" & vbCrLf
                rs.MoveNext()
            Loop
            MsgBox(strMsg, MsgBoxStyle.OkOnly, "List of TP's removed from OTP")
        Else
            MsgBox("No TP stops are on the list", MsgBoxStyle.OkOnly, "List of TP's removed from OTP")
        End If

        rs.Close()
        rs = Nothing

    End Sub
End Class