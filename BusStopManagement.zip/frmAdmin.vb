﻿Public Class frmAdmin
    Private Sub cmdAccount_Click(sender As Object, e As EventArgs) Handles cmdAccount.Click

        If basUtilities.CurrentUserRight < basUtilities.UserRight.SystemAdmin Then
            MsgBox(DENY_MESSAGE, MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        frmAccountSetup.ShowDialog()

    End Sub

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click

        Me.Close()

    End Sub

    Private Sub cmdUpdateReportPath_Click(sender As Object, e As EventArgs) Handles cmdUpdateReportPath.Click

        frmUpdateReportPath.ShowDialog()

    End Sub

    Private Sub cmdUpdateTables_Click(sender As Object, e As EventArgs) Handles cmdUpdateTables.Click

        frmUpdateTables.ShowDialog()

    End Sub
End Class