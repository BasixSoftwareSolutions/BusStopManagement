﻿Public Class frmAddMEmployee
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmAddMEmployee
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmAddMEmployee
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmAddMEmployee()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region

    Private Sub cmdAdd_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAdd.Click
        Dim strSQL As String

        If Trim(txtFirstName.Text) <> "" And Trim(txtLastName.Text) <> "" Then

            strSQL = "INSERT INTO tblMaintenanceEmployees (FIRST_NAME, LAST_NAME) VALUES " & "(" & Trim(cV2Q_String((txtFirstName.Text))) & ", " & Trim(cV2Q_String((txtLastName.Text))) & ")"
            db.Execute(strSQL)

            'CreateObject("WScript.Shell").Popup("Employee: " & txtFirstName.Text & " " & txtLastName.Text & " has been added to database.", 1, "Added")
            MsgBox("Employee: " & txtFirstName.Text & " " & txtLastName.Text & " has been added to database.", MsgBoxStyle.Information)

            Me.Close()
        Else
            MsgBox("Please enter both First Name and Last Name.", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub txtFirstName_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtFirstName.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub


    Private Sub txtLastName_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtLastName.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

End Class