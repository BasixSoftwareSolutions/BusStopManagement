﻿Imports System.Data.SqlClient
Imports System.Data

Public Class frmBSLandmarks

    Dim intID As Short
    Dim intEID As Short
    Dim strLM As String
    Dim strELM As String

    Private Sub cmdAdd_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAdd.Click
        Dim strSQL As String

        If intID = 0 Then Exit Sub
        If lstLandmarks.Items.Count >= 4 Then
            MsgBox("A stop can only have 4 landmarks.", MsgBoxStyle.Information)
            Exit Sub
        End If

        ' check if landmark selected aleardy exist...
        If LMExist() Then
            MsgBox("Landmark already exist for selected stop.", MsgBoxStyle.Information)
            Exit Sub
        End If

        strSQL = "INSERT INTO tblBusStopLandmarks (RTE, OCTA_ID, LANDMARK_ID, DIRECTION) " _
                & "VALUES (" & ROUTE_ID & ", " & OCTA_ID & ", " & intID & ",'" & DIR_DESC & "');"
        db.Execute(strSQL)

        LoadExistingLM()
    End Sub

    Private Function LMExist() As Boolean
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim bln As Boolean

        strSQL = "SELECT * FROM tblBusStopLandmarks WHERE " &
             "RTE = " & ROUTE_ID & " AND " &
             "OCTA_ID = " & OCTA_ID & " AND " &
             "LANDMARK_ID = " & intID &
             " AND DIRECTION = '" & DIR_DESC & "'"

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        bln = False
        If Not rs.EOF Then bln = True

        rs.Close()
        rs = Nothing

        LMExist = bln
    End Function

    Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
        Me.Close()
    End Sub

    Private Sub cmdRemove_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRemove.Click
        If strELM = "" Then Exit Sub

        Dim myT As New clsTokenizer
        Dim strSQL As String

        myT.SetString(strELM, "|")

        If MsgBox("Remove landmark: " & Trim(myT.TokenAt(0)) & "?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            strSQL = "DELETE  FROM tblBusStopLandmarks WHERE " &
                 "RTE = " & ROUTE_ID & " AND " &
                 "OCTA_ID = " & OCTA_ID & " AND " &
                 "DIRECTION = '" & DIR_DESC & "' AND " &
                 "LANDMARK_ID = " & myT.TokenAt(1)
            db.Execute(strSQL)
        End If

        myT = Nothing

        LoadExistingLM()
    End Sub

    Private Sub frmBSLandmarks_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        LoadLM()
        LoadExistingLM()

    End Sub

    Private Sub LoadLM()
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        LandmarkGrid.DataSource = Nothing
        LandmarkGrid.Rows.Clear()
        LandmarkGrid.Columns.Clear()
        LandmarkGrid.AutoGenerateColumns = False

        'Set Columns Count
        LandmarkGrid.ColumnCount = 2

        'Add Columns
        LandmarkGrid.Columns(0).Name = "ID"
        LandmarkGrid.Columns(0).HeaderText = "ID"
        LandmarkGrid.Columns(0).DataPropertyName = "ID"
        LandmarkGrid.Columns(0).Width = 50

        LandmarkGrid.Columns(1).Name = "DESCRIPTION"
        LandmarkGrid.Columns(1).HeaderText = "DESCRIPTION"
        LandmarkGrid.Columns(1).DataPropertyName = "DESCRIPTION"
        LandmarkGrid.Columns(1).Width = 250

        LandmarkGrid.DataSource = Nothing
        strSQL = "SELECT ID, DESCRIPTION FROM BS_LANDMARK_CODE WHERE ACTIVE =1 ORDER BY DESCRIPTION"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        Dim oConn As New SqlConnection(sConn)
        Dim dataadapter As New SqlDataAdapter(strSQL, oConn)
        Dim ds As New DataSet()
        oConn.Open()
        dataadapter.Fill(ds)
        oConn.Close()

        LandmarkGrid.DataSource = ds.Tables(0)

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub LoadExistingLM()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim i As Short

        ' Modified by Anuket 8/23/04
        strSQL = "SELECT blc.ID, blc.DESCRIPTION FROM BS_LANDMARK_CODE AS blc " &
             "LEFT JOIN tblBusStopLandmarks AS tbl ON blc.ID = tbl.LANDMARK_ID " &
             "WHERE tbl.RTE = " & ROUTE_ID & " AND " &
             "tbl.DIRECTION = '" & DIR_DESC & "' AND " &
             "tbl.OCTA_ID = " & OCTA_ID

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        lstLandmarks.Items.Clear()
        i = 0
        Do While Not rs.EOF
            If i > 3 Then Exit Do
            lstLandmarks.Items.Add(rs.Fields("DESCRIPTION").Value & "                                                                       " & "                                                                       |" & rs.Fields("ID").Value)
            rs.MoveNext()
            i = i + 1
        Loop

        rs.Close()
        rs = Nothing

    End Sub

    Private Sub LandmarkGrid_SelectionChanged(sender As Object, e As EventArgs) Handles LandmarkGrid.SelectionChanged
        On Error GoTo ExitOnError

        Dim vRow As Integer

        If LandmarkGrid.CurrentRow.Index < 1 Then Exit Sub
        vRow = LandmarkGrid.CurrentRow.Index
        strLM = LandmarkGrid.Item(1, vRow).Value
        intID = LandmarkGrid.Item(0, vRow).Value

ExitOnError:

    End Sub

    Private Sub lstLandmarks_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstLandmarks.SelectedIndexChanged
        If lstLandmarks.SelectedIndex <> -1 Then
            strELM = lstLandmarks.Text
        End If
    End Sub


End Class

