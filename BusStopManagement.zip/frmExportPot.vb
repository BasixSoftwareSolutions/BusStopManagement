﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.Text
Imports System.IO

Public Class frmExportPot

    Public rs2POT As New ADODB.Recordset
    Public FSys As Object
    Public pbpStatusMin As Integer
    Public pbpStatusMax As Integer
    Public pbpStatusValue As Integer
    Public pbpStatusWidthMax As Integer
    Dim cDbfPath As String
    Dim cDBFFileName As String
    Dim sFilePath As String

    Private Sub cmdExit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExit.Click
        Me.Close()
    End Sub

    Private Function ToLink_ID(ByRef octaid As String) As Object
        Dim i As Object
        Dim j As Short

        j = Len(Trim(octaid))
        ToLink_ID = Trim(octaid)
        If (j > 0) And (j < 7) Then
            For i = 1 To (7 - j)
                ToLink_ID = "0" & ToLink_ID
            Next i
        End If

    End Function

    Private Sub cmdPotFile_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPotFile.Click

        If Not GetDBFFileName() Then Exit Sub
        Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
        PreparePot()
        AddLandmark()
        AddXY()
        ChangeHardware()
        ExportPotsFile(sFilePath)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        MsgBox("Process Complete", vbInformation, "Done")
        Me.Close()

    End Sub

    Private Sub ChangeHardware()

        On Error GoTo errHandler

        Dim rs1 As New ADODB.Recordset
        Dim rs2 As New ADODB.Recordset
        Dim i As Short
        Dim strSQL As String

        strSQL = "SELECT OCTA_ID, HARDWARE FROM tmpPotTable"
        rs1.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

        lblProccess.Visible = True
        lblProccess.Text = "Step 4 of 5 Import Hardware..."
        pbProgressBar.Visible = True
        With pbProgressBar
            .Style = ProgressBarStyle.Blocks
            .Step = 1
            .Minimum = 0
            .Maximum = rs1.RecordCount
            .Value = 0
        End With
        Me.Refresh()

        For i = 0 To rs1.RecordCount - 1
            strSQL = "SELECT SIGN_POST_CONFIG_ID FROM tblSignCassette WHERE OCTA_ID = " & rs1.Fields("OCTA_ID").Value

            rs2.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

            If rs2.Fields("SIGN_POST_CONFIG_ID").Value = 2 And rs1.Fields("HARDWARE").Value = 0 Then
                rs1.Update("HARDWARE", 1)
            Else
                rs1.Update("HARDWARE", 0)
            End If

            pbProgressBar.PerformStep()
            rs2.Close()
            rs1.MoveNext()
        Next i

        rs1.Close()
        Exit Sub

errHandler:
        MsgBox(Err.Description)
        Resume Next
    End Sub

    Private Function GetDBFFileName() As Boolean
        Dim intPos As Short
        Dim strTemp As String
        Dim bln As Boolean = False
        Dim fd As FolderBrowserDialog = New FolderBrowserDialog()
        Dim strFileName As String = ""

        With fd
            .Description = "Export Pot File"
            .RootFolder = Environment.SpecialFolder.MyComputer
            .SelectedPath = "K:\SANZ\CurrentPOTS"
        End With

        If fd.ShowDialog() = DialogResult.OK Then
            strFileName = fd.SelectedPath & "\POTS.csv"
        End If

        If strFileName <> "" Then

            If System.IO.File.Exists(strFileName) Then
                If MsgBox("File already exist. Do you want To replace it?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                    GetDBFFileName = False
                    Exit Function
                Else
                    If Not KillExistFile((strFileName)) Then
                        MsgBox("Unable To replace file. File maybe In use by other program.", MsgBoxStyle.Exclamation)
                        GetDBFFileName = False
                        Exit Function
                    End If
                End If
            End If

            strTemp = strFileName
            sFilePath = strFileName
            intPos = InStrRev(strTemp, "\")
            cDbfPath = strTemp.Substring(0, intPos - 1)
            cDBFFileName = strTemp.Substring(intPos, Len(strTemp) - intPos)
            cDBFFileName = cDBFFileName.Substring(0, Len(cDBFFileName) - 4)
            bln = True
        End If

        GetDBFFileName = bln
    End Function

    Private Function KillExistFile(ByRef aPath As String) As Boolean
        On Error GoTo EH

        Kill(aPath)

        KillExistFile = True
        Exit Function
EH:
        KillExistFile = False
        Exit Function
    End Function

    Private Sub AddLandmark()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim rs2 As New ADODB.Recordset
        Dim strLM As String

        rs.Open("SELECT RTE, OCTA_ID FROM tmpPotTable ORDER BY RTE, OCTA_ID", db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

        lblProccess.Visible = True
        lblProccess.Text = "Step 2 of 5 Import Landmarks..."
        pbProgressBar.Visible = True
        With pbProgressBar
            .Style = ProgressBarStyle.Blocks
            .Step = 1
            .Minimum = 0
            .Maximum = rs.RecordCount
            .Value = 0
        End With
        Me.Refresh()

        Do While Not rs.EOF
            strSQL = "SELECT blm.DESCRIPTION FROM BS_LANDMARK_CODE AS blm " & "WHERE blm.ID IN (SELECT LANDMARK_ID FROM tblBusStopLandmarks AS bsl " & "WHERE bsl.RTE = " & rs.Fields("RTE").Value & " AND bsl.OCTA_ID = " & rs.Fields("OCTA_ID").Value & ")"
            rs2.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

            If Not rs2.EOF Then
                strLM = ""
                Do While Not rs2.EOF
                    strLM = strLM & IIf(IsDBNull(rs2.Fields("DESCRIPTION").Value), "", rs2.Fields("DESCRIPTION").Value) & " - "
                    rs2.MoveNext()
                Loop
                If strLM <> "" Then
                    strLM = strLM.Substring(0, Len(strLM) - 3)

                    strSQL = "UPDATE tmpPotTable SET LANDMARK = " & cV2Q_String(strLM) & " WHERE RTE = " & rs.Fields("RTE").Value & " AND OCTA_ID = " & rs.Fields("OCTA_ID").Value

                    db.Execute(strSQL)
                End If
            End If
            pbProgressBar.PerformStep()
            rs2.Close()
            rs.MoveNext()
        Loop

        rs.Close()

        rs2 = Nothing
        rs = Nothing


    End Sub

    Private Sub AddXY()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim rs2 As New ADODB.Recordset

        rs.Open("SELECT OCTA_ID, X_COOR, Y_COOR FROM tmpPotTable", db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

        lblProccess.Visible = True
        lblProccess.Text = "Step 3 of 5 Import Coordinates..."
        pbProgressBar.Visible = True
        With pbProgressBar
            .Style = ProgressBarStyle.Blocks
            .Step = 1
            .Minimum = 0
            .Maximum = rs.RecordCount
            .Value = 0
        End With
        Me.Refresh()

        Do While Not rs.EOF
            strSQL = "SELECT EASTING, NORTHING FROM tblStopCoord WHERE OCTA_ID = " & rs.Fields("OCTA_ID").Value
            rs2.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

            If Not rs2.EOF Then

                If IsDBNull(rs2.Fields("EASTING").Value) Then
                    rs.Update("X_COOR", 0)
                Else
                    rs.Update("X_COOR", rs2.Fields("EASTING").Value)
                End If

                If IsDBNull(rs2.Fields("NORTHING").Value) Then
                    rs.Update("Y_COOR", 0)
                Else
                    rs.Update("Y_COOR", rs2.Fields("NORTHING").Value)
                End If

            End If
            pbProgressBar.PerformStep()
            rs2.Close()
            rs.MoveNext()
        Loop

        rs.Close()
        rs2 = Nothing
        rs = Nothing

    End Sub

    Private Sub PreparePot()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim rs2 As New ADODB.Recordset
        Dim fld As ADODB.Field
        Dim NULL As System.DBNull = System.DBNull.Value

        strSQL = "TRUNCATE TABLE dbo.tmpPotTable"
        db.Execute(strSQL)

        strSQL = "SELECT bss.OCTA_ID, bss.SANZ_ID, cco.COUNTY, cci1.CITY, " _
                & "cci2.JURISDICTION AS JURISD, sdc.DIR AS ST_DIR, " _
                & "bsi.STREET_OF_TRAVEL AS STREET, stc1.[TYPE] AS ST_ST, blc.LOC AS NEAR_FAR, " _
                & "bsi.CROSS_STREET AS AT_ST, stc2.[TYPE] AS ATST_ST, bsi.TBM_PAGE AS TBM_COOR, " _
                & "ascc.STATUS AS ADA_STAT, rdc.DIR1 AS DIR, bss.RTE, bss.SEQ, bss.HARDWARE, " _
                & "(CONVERT(char(3), bss.RTE) + ' ' + rdc.DIR1 + ' ' + CONVERT(char(3), bss.SEQ)) AS STOP_ID, bss.TIMEPOINT AS TP, " _
                & "bss.PLACE_ID AS TP_PID, bss.PLACE_DESCRIPTION AS TP_DESCRIP, " _
                & "bsi.CROSS_STREET_1 AS COMM1, rcc.DESCRIPTION AS COMM2, bss.TRANSFERS AS TRANSFERS " _
                & "FROM ((((((((((((tblBusStopSequences AS bss " _
                & "LEFT JOIN tblBusStopInformation AS bsi ON bss.OCTA_ID = bsi.OCTA_ID) " _
                & "LEFT JOIN tblADAStatus AS ada ON bss.OCTA_ID = ada.OCTA_ID) " _
                & "LEFT JOIN COUNTY_CODE AS cco ON bsi.COUNTY_ID = cco.ID) " _
                & "LEFT JOIN CITY_CODE AS cci1 ON bsi.CITY_ID = cci1.ID) " _
                & "LEFT JOIN CITY_CODE AS cci2 ON bsi.JURISDICTION_ID = cci2.ID) " _
                & "LEFT JOIN ST_DIR_CODE AS sdc ON bsi.ST_DIR_ID = sdc.ID) " _
                & "LEFT JOIN ST_TYPE_CODE AS stc1 ON ((bsi.ST_TYPE_ID_1 = stc1.ID) " _
                & "OR (bsi.ST_TYPE_ID_1 IS NULL AND stc1.ID = 0))) " _
                & "LEFT JOIN BS_LOC_CODE AS blc ON bsi.BS_LOC_ID = blc.ID) " _
                & "LEFT JOIN ST_TYPE_CODE AS stc2 ON ((bsi.ST_TYPE_ID_2 = stc2.ID) " _
                & "OR (bsi.ST_TYPE_ID_2 IS NULL AND stc2.ID = 0))) " _
                & "LEFT JOIN ADA_STATUS_CODE AS ascc ON ada.ADA_STATUS_ID = ascc.ID) " _
                & "LEFT JOIN ROUTE_DIR_CODE AS rdc ON bss.RTE_DIR_ID = rdc.ID) " _
                & "LEFT JOIN ROUTE_COMMENT_CODE AS rcc ON bss.COMMENTS = rcc.ID) "
        strSQL = strSQL & "LEFT JOIN tblRoutes ON (bss.RTE = tblRoutes.RTE " _
                & "AND bss.RTE_DIR_ID = tblRoutes.RTE_DIR_ID) " _
                & "WHERE tblRoutes.ACTIVE = 1 " _
                & "ORDER BY bss.RTE, bss.RTE_DIR_ID, bss.SEQ, bss.OCTA_ID"

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)
        rs2.Open("tmpPotTable", db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdTableDirect)

        Dim stopID As String

        lblProccess.Visible = True
        lblProccess.Text = "Step 1 of 5 Import Bus Stop Information..."
        pbProgressBar.Visible = True
        With pbProgressBar
            .Style = ProgressBarStyle.Blocks
            .Step = 1
            .Minimum = 0
            .Maximum = rs.RecordCount
            .Value = 0
        End With
        Me.Refresh()

        Do While Not rs.EOF
            rs2.AddNew()
            For Each fld In rs2.Fields
                If UCase(fld.Name) = "ST_ST" Or UCase(fld.Name) = "ATST_ST" Then
                    If rs.Fields(fld.Name).Value = "_" Then
                        fld.Value = System.DBNull.Value
                    Else
                        fld.Value = rs.Fields(fld.Name).Value
                    End If
                ElseIf UCase(fld.Name) = "STOP_ID" Then
                    stopID = rs.Fields("RTE").Value & " " & rs.Fields("DIR").Value & " " & rs.Fields("SEQ").Value
                    fld.Value = stopID
                ElseIf UCase(fld.Name) = "LANDMARK" Or UCase(fld.Name) = "X_COOR" Or UCase(fld.Name) = "Y_COOR" Then
                    fld.Value = System.DBNull.Value
                ElseIf UCase(fld.Name) = "TRANSFERS" Then
                    fld.Value = ""
                Else
                    If UCase(fld.Name) = "TP_PID" Or UCase(fld.Name) = "TP_DESCRIP" Then
                        fld.Value = rs.Fields(fld.Name).Value.ToString().ToUpper()
                    Else
                        fld.Value = rs.Fields(fld.Name).Value
                    End If
                End If
            Next fld
            pbProgressBar.PerformStep()
            rs2.Update()
            rs.MoveNext()
        Loop

        rs.Close()
        rs = Nothing
        rs2.Close()
        rs2 = Nothing
    End Sub

    Private Sub ExportPotsFile(sFilePath As String)
        Try
            Dim oSDA As New SqlDataAdapter("SELECT * From dbo.tmpPotTable ORDER BY OCTA_ID", sConn)
            Dim commandBuilder As New SqlCommandBuilder(oSDA)

            Dim dt As New DataTable()
            dt.Locale = System.Globalization.CultureInfo.InvariantCulture
            oSDA.Fill(dt)

            Dim sw As New StreamWriter(sFilePath, False)

            ' First we will write the headers.
            Dim iColCount As Integer = dt.Columns.Count
            For i As Integer = 0 To iColCount - 1
                sw.Write(dt.Columns(i))
                If i < iColCount - 1 Then
                    sw.Write(",")
                End If
            Next
            sw.Write(sw.NewLine)

            lblProccess.Visible = True
            lblProccess.Text = "Step 5 of 5 Export CSV File..."
            pbProgressBar.Visible = True
            With pbProgressBar
                .Style = ProgressBarStyle.Blocks
                .Step = 1
                .Minimum = 0
                .Maximum = dt.Rows.Count
                .Value = 0
            End With
            Me.Refresh()

            ' Now write all the rows.
            For Each dr As DataRow In dt.Rows
                For i As Integer = 0 To iColCount - 1
                    If Not Convert.IsDBNull(dr(i)) Then
                        sw.Write(Replace(dr(i).ToString(), ", ", " - "))
                    End If
                    If i < iColCount - 1 Then
                        sw.Write(",")
                    End If
                Next
                sw.Write(sw.NewLine)
                pbProgressBar.PerformStep()
            Next
            sw.Close()

        Catch ex As SqlException
            MsgBox(Err.Description)
        End Try

    End Sub


End Class