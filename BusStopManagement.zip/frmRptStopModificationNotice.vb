﻿Public Class frmRptStopModificationNotice

    Public OID As Short
    Public srchFlag As Boolean
    Dim i As Short
    Dim j As Integer
    Dim ct As Short
    Dim rowIndex As Short

    Private Sub cmdDelete_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdDelete.Click

        If IsNothing(Me.dgvSMN.CurrentRow) Then
            MsgBox("No record has been selected", MsgBoxStyle.Information, "Select Record")
            Exit Sub
        End If

        If IsDBNull(rowIndex) Then
            Exit Sub
        End If

        Me.dgvSMN.Rows.RemoveAt(Me.dgvSMN.CurrentRow.Index)
        MsgBox("Record has been Deleted", vbInformation, "Deleted")

        ct = ct - 1

    End Sub

    Private Sub frmRptStopModificationNotice_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        Dim cIntColCount As Short
        cIntColCount = 5

        'Set Columns Count
        dgvSMN.ColumnCount = cIntColCount

        'Add Columns
        dgvSMN.Columns(0).Name = "OCTA_ID"
        dgvSMN.Columns(0).HeaderText = "OCTA ID"
        dgvSMN.Columns(0).DataPropertyName = "OCTA_ID"
        dgvSMN.Columns(0).Width = 75

        dgvSMN.Columns(1).Name = "LOCATION"
        dgvSMN.Columns(1).HeaderText = "LOCATION"
        dgvSMN.Columns(1).DataPropertyName = "LOCATION"
        dgvSMN.Columns(1).Width = 300

        dgvSMN.Columns(2).Name = "CITY"
        dgvSMN.Columns(2).HeaderText = "CITY"
        dgvSMN.Columns(2).DataPropertyName = "CITY"
        dgvSMN.Columns(2).Width = 150

        dgvSMN.Columns(3).Name = "ROUTE"
        dgvSMN.Columns(3).HeaderText = "ROUTE"
        dgvSMN.Columns(3).DataPropertyName = "ROUTE"
        dgvSMN.Columns(3).Width = 75

        dgvSMN.Columns(4).Name = "REMARKS"
        dgvSMN.Columns(4).HeaderText = "REMARKS"
        dgvSMN.Columns(4).DataPropertyName = "REMARKS"
        dgvSMN.Columns(4).Width = 200

        dtIssued.Format = DateTimePickerFormat.Custom
        dtIssued.CustomFormat = "MM/dd/yyyy"
        dtEffective.Format = DateTimePickerFormat.Custom
        dtEffective.CustomFormat = "MM/dd/yyyy"

        dtIssued.Value = Date.Now.ToShortDateString
        dtEffective.Value = Date.Now.ToShortDateString

    End Sub

    Private Sub cmdAdd_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAdd.Click

        frmSearchBusStopMisc.rptIndex = 1
        frmSearchBusStopMisc.ShowDialog()

        Dim rs As New ADODB.Recordset
        Dim rt As New ADODB.Recordset
        Dim strSQL As String
        Dim l As Short
        Dim location_Renamed, city As String
        Dim rte As String

        If srchFlag Then
            rte = ""
            ' for bus stop information
            strSQL = "" &
                    "SELECT " &
                    "bs.OCTA_ID, bs.SANZ_ID, stdir.DIR, bs.STREET_OF_TRAVEL, sttpc1.TYPE, bsloc.LOC, " &
                    "bs.CROSS_STREET, sttpc2.TYPE, bs.CROSS_STREET_1, ct.CITY " &
                    "FROM " &
                    "tblBusStopInformation bs, " &
                    "ST_DIR_CODE stdir, " &
                    "BS_LOC_CODE bsloc, " &
                    "CITY_CODE ct, " &
                    "ST_TYPE_CODE sttpc1, " &
                    "ST_TYPE_CODE sttpc2 " &
                    "WHERE " &
                    "(bs.OCTA_ID = " & OID & ") AND " &
                    "(bs.ST_DIR_ID = stdir.ID) AND " &
                    "(bs.BS_LOC_ID = bsloc.ID) AND " &
                    "(bs.CITY_ID = ct.ID) AND " &
                    "((bs.ST_TYPE_ID_1 = sttpc1.ID) OR (bs.ST_TYPE_ID_1 IS NULL AND sttpc1.ID = 0)) AND " &
                    "((bs.ST_TYPE_ID_2 = sttpc2.ID) OR (bs.ST_TYPE_ID_2 IS NULL AND sttpc2.ID = 0));"

            rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)

            location_Renamed = ""
            location_Renamed = location_Renamed & rs.Fields(2).Value & " " & rs.Fields(3).Value & " " & rs.Fields(4).Value & " / " & rs.Fields(5).Value & " " & rs.Fields(6).Value & " " & rs.Fields(7).Value & " " & rs.Fields(8).Value

            city = rs.Fields(9).Value

            ' for bus routes
            '*********************************************************************************
            strSQL = "" & "SELECT RTE, DIR FROM tblBusStopSequences bss, ROUTE_DIR_CODE rdc " _
                    & "WHERE bss.OCTA_ID = " & OID & " AND bss.RTE_DIR_ID = rdc.ID;"

            rt.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)
            '*********************************************************************************

            If rt.RecordCount < 1 Then ' incase busstop has no routes at present
                MsgBox("Not a valid sequence stop")
            Else
                rt.MoveFirst()

                Do While Not rt.EOF
                    rte = rte & rt.Fields("RTE").Value & rt.Fields("DIR").Value & ", "
                    rt.MoveNext()
                Loop

                l = Len(rte)

                If rte <> "" Then
                    rte = Mid(rte, 1, l - 2)
                End If

                Dim row1() As String = {OID, location_Renamed, city, rte, ""}
                Dim rows() As Object = {row1}

                Dim row As String()
                For Each row In rows
                    dgvSMN.Rows.Add(row)
                Next row

                ct = ct + 1

            End If

            rs.Close()
            rt.Close()

        End If

    End Sub

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdSave_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSave.Click

        Dim i, j As Short
        Dim strReportName As String = ""
        Dim strReportStatus As String

        'Delete table
        Dim strSQL As String
        strSQL = "DELETE  FROM [tblStopModifNoticeReports]"
        dbRep.Execute(strSQL)

        Dim tempStr As String

        'Save data from DataGridView
        For i = 0 To ct - 1
            strSQL = "" & "INSERT INTO [tblStopModifNoticeReports] (OCTA_ID, " & "LOCATION, CITY, ROUTE, REMARKS) VALUES ("
            For j = 0 To 4
                tempStr = Replace(UCase(dgvSMN.Rows(i).Cells(j).Value), "'", "''")
                If j = 0 Then
                    strSQL = strSQL & tempStr & ","
                ElseIf j < 4 Then
                    strSQL = strSQL & "'" & tempStr & "'" & ","
                Else
                    strSQL = strSQL & "'" & tempStr & "'"
                End If
            Next j
            strSQL = strSQL & ");"
            dbRep.Execute(strSQL)
        Next i

        'Prepare Report
        Dim tempDt, remarks As String
        Dim typeID As Short

        tempDt = dtIssued.Value.ToShortDateString
        remarks = "'BUS STOP MODIFICATION NOTICE WAS DISTRIBUTED'"
        typeID = 31 ' SMN Code

        Dim rs As New ADODB.Recordset
        Dim sanzid As String
        Dim tempStr3 As String
        Dim strExportFile As String
        Dim strFPath As String
        Dim ct1 As Short
        Dim objFile As New Scripting.FileSystemObject
        Dim fileExists As Boolean
        Dim directoryExists As Boolean
        Dim histId As Integer

        If ct > 0 Then
            ' set up report
            strReportName = "StopModificationNotice.rpt"

            tempStr = dtIssued.Value.ToString("MMMM dd, yyyy")

            strReportStatus = "Effective " & dtEffective.Value.ToString("MMMM dd, yyyy") & ", the following bus stop(s) will be modified:"

            tempStr3 = "SMN_" & dtIssued.Value.ToString("MMddyyyy")

            dbRep.Close()
            dbRep.Open()

            strFPath = GetAppValue("StopModNoticeReportPath")

            strExportFile = strFPath & tempStr3 & ".pdf"

            ct1 = 0

            fileExists = True

            Do While fileExists = True
                directoryExists = objFile.FolderExists(strFPath)

                If directoryExists = False Then
                    MsgBox("Cannot find the folder, please set a valid path")
                    Exit Sub
                End If

                fileExists = objFile.FileExists(strExportFile)

                If fileExists Then
                    ct1 = ct1 + 1
                    strExportFile = strFPath & tempStr3 & "_" & ct1 & ".pdf"
                End If
            Loop

            ' Stop history entry
            For i = 0 To dgvSMN.RowCount - 1
                strSQL = "SELECT SANZ_ID FROM tblBusStopInformation WHERE OCTA_ID = " & dgvSMN.Rows(i).Cells(0).Value & ";"
                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)
                sanzid = rs.Fields(0).Value
                strSQL = "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) VALUES (" & dgvSMN.Rows(i).Cells(0).Value & "," & "'" & sanzid & "'" & ",'" & tempDt & "'," & CurrentLoginUserID & "," & typeID & ",'" & UCase(dgvSMN.Rows(i).Cells(4).Value) & "');"
                rs.Close()
                db.Execute(strSQL)
            Next i

            ' Doc History
            strSQL = "SELECT * FROM [tblStopHistory];"

            rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)

            rs.MoveLast()

            For i = 0 To dgvSMN.RowCount - 1
                histId = rs.Fields("HISTORY_ID").Value
                strSQL = "INSERT INTO [tblHistoryDoc] (HISTORY_ID, DOC_PATH) VALUES (" & histId & ",'" & strExportFile & "');"
                db.Execute(strSQL)
                rs.MovePrevious()
            Next i

            rs.Close()
            MsgBox("Record has been Saved", vbInformation, "Saved")
            frmCrystalReportsWP.LoadReportWithExport(strReportName, strExportFile, strReportStatus, "")
        Else
            MsgBox("No Selections")
        End If

        Exit Sub

errHandler:

    End Sub
End Class