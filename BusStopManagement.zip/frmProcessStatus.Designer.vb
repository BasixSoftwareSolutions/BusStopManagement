﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProcessStatus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProcessStatus))
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.lblAct = New System.Windows.Forms.Label()
        Me.lblOne = New System.Windows.Forms.Label()
        Me.pbActivity = New System.Windows.Forms.ProgressBar()
        Me.SuspendLayout()
        '
        'lblStatus
        '
        Me.lblStatus.BackColor = System.Drawing.Color.Transparent
        Me.lblStatus.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblStatus.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.ForeColor = System.Drawing.Color.DimGray
        Me.lblStatus.Location = New System.Drawing.Point(83, 9)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblStatus.Size = New System.Drawing.Size(57, 17)
        Me.lblStatus.TabIndex = 7
        Me.lblStatus.Text = ". . . . . ."
        '
        'lblAct
        '
        Me.lblAct.BackColor = System.Drawing.Color.Transparent
        Me.lblAct.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblAct.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAct.ForeColor = System.Drawing.Color.DimGray
        Me.lblAct.Location = New System.Drawing.Point(11, 37)
        Me.lblAct.Name = "lblAct"
        Me.lblAct.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblAct.Size = New System.Drawing.Size(241, 17)
        Me.lblAct.TabIndex = 6
        Me.lblAct.Text = "Activity : Processing Report"
        '
        'lblOne
        '
        Me.lblOne.BackColor = System.Drawing.Color.Transparent
        Me.lblOne.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblOne.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOne.ForeColor = System.Drawing.Color.DimGray
        Me.lblOne.Location = New System.Drawing.Point(11, 9)
        Me.lblOne.Name = "lblOne"
        Me.lblOne.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblOne.Size = New System.Drawing.Size(73, 17)
        Me.lblOne.TabIndex = 4
        Me.lblOne.Text = "Please wait "
        '
        'pbActivity
        '
        Me.pbActivity.Location = New System.Drawing.Point(12, 67)
        Me.pbActivity.Name = "pbActivity"
        Me.pbActivity.Size = New System.Drawing.Size(239, 24)
        Me.pbActivity.Step = 1
        Me.pbActivity.TabIndex = 8
        '
        'frmProcessStatus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(260, 106)
        Me.Controls.Add(Me.pbActivity)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.lblAct)
        Me.Controls.Add(Me.lblOne)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmProcessStatus"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Please Wait....."
        Me.ResumeLayout(False)

    End Sub
    Public WithEvents lblStatus As Label
    Public WithEvents lblAct As Label
    Public WithEvents lblOne As Label
    Friend WithEvents pbActivity As ProgressBar
End Class
