﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmRptStopWorkOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRptStopWorkOrder))
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdOpenReport = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.DTPicker3 = New System.Windows.Forms.DateTimePicker()
        Me.DTPicker2 = New System.Windows.Forms.DateTimePicker()
        Me.dtpDateTo = New System.Windows.Forms.DateTimePicker()
        Me.dtpDateFrom = New System.Windows.Forms.DateTimePicker()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.optWOTR0 = New System.Windows.Forms.RadioButton()
        Me.optWOTR1 = New System.Windows.Forms.RadioButton()
        Me.optWOTR2 = New System.Windows.Forms.RadioButton()
        Me.Combo2 = New System.Windows.Forms.ComboBox()
        Me.Combo1 = New System.Windows.Forms.ComboBox()
        Me.optWorkOrderReport6 = New System.Windows.Forms.RadioButton()
        Me.optWorkOrderReport5 = New System.Windows.Forms.RadioButton()
        Me.txtWorkOrderNum = New System.Windows.Forms.TextBox()
        Me.optWorkOrderReport4 = New System.Windows.Forms.RadioButton()
        Me.optWorkOrderReport3 = New System.Windows.Forms.RadioButton()
        Me.optWorkOrderReport2 = New System.Windows.Forms.RadioButton()
        Me.optWorkOrderReport1 = New System.Windows.Forms.RadioButton()
        Me.optWorkOrderReport0 = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Frame1.SuspendLayout()
        Me.Frame2.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.Transparent
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(340, 260)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(89, 25)
        Me.cmdCancel.TabIndex = 16
        Me.cmdCancel.Text = "&Close"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdOpenReport
        '
        Me.cmdOpenReport.BackColor = System.Drawing.Color.Transparent
        Me.cmdOpenReport.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdOpenReport.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOpenReport.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdOpenReport.Location = New System.Drawing.Point(236, 260)
        Me.cmdOpenReport.Name = "cmdOpenReport"
        Me.cmdOpenReport.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdOpenReport.Size = New System.Drawing.Size(89, 25)
        Me.cmdOpenReport.TabIndex = 15
        Me.cmdOpenReport.Text = "&Open Report"
        Me.cmdOpenReport.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.DTPicker3)
        Me.Frame1.Controls.Add(Me.DTPicker2)
        Me.Frame1.Controls.Add(Me.dtpDateTo)
        Me.Frame1.Controls.Add(Me.dtpDateFrom)
        Me.Frame1.Controls.Add(Me.Frame2)
        Me.Frame1.Controls.Add(Me.Combo2)
        Me.Frame1.Controls.Add(Me.Combo1)
        Me.Frame1.Controls.Add(Me.optWorkOrderReport6)
        Me.Frame1.Controls.Add(Me.optWorkOrderReport5)
        Me.Frame1.Controls.Add(Me.txtWorkOrderNum)
        Me.Frame1.Controls.Add(Me.optWorkOrderReport4)
        Me.Frame1.Controls.Add(Me.optWorkOrderReport3)
        Me.Frame1.Controls.Add(Me.optWorkOrderReport2)
        Me.Frame1.Controls.Add(Me.optWorkOrderReport1)
        Me.Frame1.Controls.Add(Me.optWorkOrderReport0)
        Me.Frame1.Controls.Add(Me.Label3)
        Me.Frame1.Controls.Add(Me.Label1)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(12, 12)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(417, 241)
        Me.Frame1.TabIndex = 17
        Me.Frame1.TabStop = False
        '
        'DTPicker3
        '
        Me.DTPicker3.Location = New System.Drawing.Point(310, 147)
        Me.DTPicker3.Name = "DTPicker3"
        Me.DTPicker3.Size = New System.Drawing.Size(90, 20)
        Me.DTPicker3.TabIndex = 25
        '
        'DTPicker2
        '
        Me.DTPicker2.Location = New System.Drawing.Point(183, 146)
        Me.DTPicker2.Name = "DTPicker2"
        Me.DTPicker2.Size = New System.Drawing.Size(90, 20)
        Me.DTPicker2.TabIndex = 24
        '
        'dtpDateTo
        '
        Me.dtpDateTo.Location = New System.Drawing.Point(310, 121)
        Me.dtpDateTo.Name = "dtpDateTo"
        Me.dtpDateTo.Size = New System.Drawing.Size(90, 20)
        Me.dtpDateTo.TabIndex = 23
        '
        'dtpDateFrom
        '
        Me.dtpDateFrom.Location = New System.Drawing.Point(183, 120)
        Me.dtpDateFrom.Name = "dtpDateFrom"
        Me.dtpDateFrom.Size = New System.Drawing.Size(90, 20)
        Me.dtpDateFrom.TabIndex = 22
        '
        'Frame2
        '
        Me.Frame2.BackColor = System.Drawing.Color.Transparent
        Me.Frame2.Controls.Add(Me.optWOTR0)
        Me.Frame2.Controls.Add(Me.optWOTR1)
        Me.Frame2.Controls.Add(Me.optWOTR2)
        Me.Frame2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame2.Location = New System.Drawing.Point(183, 168)
        Me.Frame2.Name = "Frame2"
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Size = New System.Drawing.Size(215, 33)
        Me.Frame2.TabIndex = 20
        Me.Frame2.TabStop = False
        '
        'optWOTR0
        '
        Me.optWOTR0.BackColor = System.Drawing.Color.Transparent
        Me.optWOTR0.Checked = True
        Me.optWOTR0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optWOTR0.Enabled = False
        Me.optWOTR0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optWOTR0.ForeColor = System.Drawing.Color.DimGray
        Me.optWOTR0.Location = New System.Drawing.Point(8, 10)
        Me.optWOTR0.Name = "optWOTR0"
        Me.optWOTR0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optWOTR0.Size = New System.Drawing.Size(41, 17)
        Me.optWOTR0.TabIndex = 23
        Me.optWOTR0.TabStop = True
        Me.optWOTR0.Text = "All"
        Me.optWOTR0.UseVisualStyleBackColor = False
        '
        'optWOTR1
        '
        Me.optWOTR1.BackColor = System.Drawing.Color.Transparent
        Me.optWOTR1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optWOTR1.Enabled = False
        Me.optWOTR1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optWOTR1.ForeColor = System.Drawing.Color.DimGray
        Me.optWOTR1.Location = New System.Drawing.Point(55, 10)
        Me.optWOTR1.Name = "optWOTR1"
        Me.optWOTR1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optWOTR1.Size = New System.Drawing.Size(65, 17)
        Me.optWOTR1.TabIndex = 22
        Me.optWOTR1.TabStop = True
        Me.optWOTR1.Text = "Pending"
        Me.optWOTR1.UseVisualStyleBackColor = False
        '
        'optWOTR2
        '
        Me.optWOTR2.BackColor = System.Drawing.Color.Transparent
        Me.optWOTR2.Cursor = System.Windows.Forms.Cursors.Default
        Me.optWOTR2.Enabled = False
        Me.optWOTR2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optWOTR2.ForeColor = System.Drawing.Color.DimGray
        Me.optWOTR2.Location = New System.Drawing.Point(128, 10)
        Me.optWOTR2.Name = "optWOTR2"
        Me.optWOTR2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optWOTR2.Size = New System.Drawing.Size(73, 17)
        Me.optWOTR2.TabIndex = 21
        Me.optWOTR2.TabStop = True
        Me.optWOTR2.Text = "Completed"
        Me.optWOTR2.UseVisualStyleBackColor = False
        '
        'Combo2
        '
        Me.Combo2.BackColor = System.Drawing.SystemColors.Control
        Me.Combo2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Combo2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo2.Enabled = False
        Me.Combo2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Combo2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Combo2.Location = New System.Drawing.Point(254, 206)
        Me.Combo2.Name = "Combo2"
        Me.Combo2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Combo2.Size = New System.Drawing.Size(66, 22)
        Me.Combo2.TabIndex = 11
        '
        'Combo1
        '
        Me.Combo1.BackColor = System.Drawing.SystemColors.Control
        Me.Combo1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Combo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Combo1.Enabled = False
        Me.Combo1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Combo1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Combo1.Location = New System.Drawing.Point(183, 206)
        Me.Combo1.Name = "Combo1"
        Me.Combo1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Combo1.Size = New System.Drawing.Size(65, 22)
        Me.Combo1.TabIndex = 10
        '
        'optWorkOrderReport6
        '
        Me.optWorkOrderReport6.BackColor = System.Drawing.Color.Transparent
        Me.optWorkOrderReport6.Cursor = System.Windows.Forms.Cursors.Default
        Me.optWorkOrderReport6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optWorkOrderReport6.ForeColor = System.Drawing.Color.DimGray
        Me.optWorkOrderReport6.Location = New System.Drawing.Point(16, 208)
        Me.optWorkOrderReport6.Name = "optWorkOrderReport6"
        Me.optWorkOrderReport6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optWorkOrderReport6.Size = New System.Drawing.Size(140, 17)
        Me.optWorkOrderReport6.TabIndex = 9
        Me.optWorkOrderReport6.TabStop = True
        Me.optWorkOrderReport6.Tag = "6"
        Me.optWorkOrderReport6.Text = "Work Order Summary:"
        Me.optWorkOrderReport6.UseVisualStyleBackColor = False
        '
        'optWorkOrderReport5
        '
        Me.optWorkOrderReport5.BackColor = System.Drawing.Color.Transparent
        Me.optWorkOrderReport5.Cursor = System.Windows.Forms.Cursors.Default
        Me.optWorkOrderReport5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optWorkOrderReport5.ForeColor = System.Drawing.Color.DimGray
        Me.optWorkOrderReport5.Location = New System.Drawing.Point(16, 144)
        Me.optWorkOrderReport5.Name = "optWorkOrderReport5"
        Me.optWorkOrderReport5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optWorkOrderReport5.Size = New System.Drawing.Size(162, 19)
        Me.optWorkOrderReport5.TabIndex = 8
        Me.optWorkOrderReport5.TabStop = True
        Me.optWorkOrderReport5.Tag = "5"
        Me.optWorkOrderReport5.Text = "Work Order Task Report:"
        Me.optWorkOrderReport5.UseVisualStyleBackColor = False
        '
        'txtWorkOrderNum
        '
        Me.txtWorkOrderNum.AcceptsReturn = True
        Me.txtWorkOrderNum.BackColor = System.Drawing.SystemColors.Control
        Me.txtWorkOrderNum.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtWorkOrderNum.Enabled = False
        Me.txtWorkOrderNum.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWorkOrderNum.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWorkOrderNum.Location = New System.Drawing.Point(183, 93)
        Me.txtWorkOrderNum.MaxLength = 9
        Me.txtWorkOrderNum.Name = "txtWorkOrderNum"
        Me.txtWorkOrderNum.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtWorkOrderNum.Size = New System.Drawing.Size(90, 20)
        Me.txtWorkOrderNum.TabIndex = 4
        '
        'optWorkOrderReport4
        '
        Me.optWorkOrderReport4.BackColor = System.Drawing.Color.Transparent
        Me.optWorkOrderReport4.Cursor = System.Windows.Forms.Cursors.Default
        Me.optWorkOrderReport4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optWorkOrderReport4.ForeColor = System.Drawing.Color.DimGray
        Me.optWorkOrderReport4.Location = New System.Drawing.Point(16, 120)
        Me.optWorkOrderReport4.Name = "optWorkOrderReport4"
        Me.optWorkOrderReport4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optWorkOrderReport4.Size = New System.Drawing.Size(162, 17)
        Me.optWorkOrderReport4.TabIndex = 5
        Me.optWorkOrderReport4.TabStop = True
        Me.optWorkOrderReport4.Tag = "4"
        Me.optWorkOrderReport4.Text = "Completed WO's From:"
        Me.optWorkOrderReport4.UseVisualStyleBackColor = False
        '
        'optWorkOrderReport3
        '
        Me.optWorkOrderReport3.BackColor = System.Drawing.Color.Transparent
        Me.optWorkOrderReport3.Cursor = System.Windows.Forms.Cursors.Default
        Me.optWorkOrderReport3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optWorkOrderReport3.ForeColor = System.Drawing.Color.DimGray
        Me.optWorkOrderReport3.Location = New System.Drawing.Point(16, 96)
        Me.optWorkOrderReport3.Name = "optWorkOrderReport3"
        Me.optWorkOrderReport3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optWorkOrderReport3.Size = New System.Drawing.Size(121, 17)
        Me.optWorkOrderReport3.TabIndex = 3
        Me.optWorkOrderReport3.TabStop = True
        Me.optWorkOrderReport3.Tag = "3"
        Me.optWorkOrderReport3.Text = "Work Order Number:"
        Me.optWorkOrderReport3.UseVisualStyleBackColor = False
        '
        'optWorkOrderReport2
        '
        Me.optWorkOrderReport2.BackColor = System.Drawing.Color.Transparent
        Me.optWorkOrderReport2.Cursor = System.Windows.Forms.Cursors.Default
        Me.optWorkOrderReport2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optWorkOrderReport2.ForeColor = System.Drawing.Color.DimGray
        Me.optWorkOrderReport2.Location = New System.Drawing.Point(16, 72)
        Me.optWorkOrderReport2.Name = "optWorkOrderReport2"
        Me.optWorkOrderReport2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optWorkOrderReport2.Size = New System.Drawing.Size(153, 17)
        Me.optWorkOrderReport2.TabIndex = 2
        Me.optWorkOrderReport2.TabStop = True
        Me.optWorkOrderReport2.Tag = "2"
        Me.optWorkOrderReport2.Text = "All Completed Work Orders"
        Me.optWorkOrderReport2.UseVisualStyleBackColor = False
        '
        'optWorkOrderReport1
        '
        Me.optWorkOrderReport1.BackColor = System.Drawing.Color.Transparent
        Me.optWorkOrderReport1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optWorkOrderReport1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optWorkOrderReport1.ForeColor = System.Drawing.Color.DimGray
        Me.optWorkOrderReport1.Location = New System.Drawing.Point(16, 48)
        Me.optWorkOrderReport1.Name = "optWorkOrderReport1"
        Me.optWorkOrderReport1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optWorkOrderReport1.Size = New System.Drawing.Size(129, 17)
        Me.optWorkOrderReport1.TabIndex = 1
        Me.optWorkOrderReport1.TabStop = True
        Me.optWorkOrderReport1.Tag = "1"
        Me.optWorkOrderReport1.Text = "All Open Work Orders"
        Me.optWorkOrderReport1.UseVisualStyleBackColor = False
        '
        'optWorkOrderReport0
        '
        Me.optWorkOrderReport0.BackColor = System.Drawing.Color.Transparent
        Me.optWorkOrderReport0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optWorkOrderReport0.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optWorkOrderReport0.ForeColor = System.Drawing.Color.DimGray
        Me.optWorkOrderReport0.Location = New System.Drawing.Point(16, 24)
        Me.optWorkOrderReport0.Name = "optWorkOrderReport0"
        Me.optWorkOrderReport0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optWorkOrderReport0.Size = New System.Drawing.Size(105, 17)
        Me.optWorkOrderReport0.TabIndex = 0
        Me.optWorkOrderReport0.TabStop = True
        Me.optWorkOrderReport0.Tag = "0"
        Me.optWorkOrderReport0.Text = "All Work Orders"
        Me.optWorkOrderReport0.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(280, 149)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(25, 21)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "to"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(280, 126)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(25, 21)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "to"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'frmRptStopWorkOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(443, 294)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdOpenReport)
        Me.Controls.Add(Me.Frame1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmRptStopWorkOrder"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Work Order Reports"
        Me.Frame1.ResumeLayout(False)
        Me.Frame1.PerformLayout()
        Me.Frame2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents cmdCancel As Button
    Public WithEvents cmdOpenReport As Button
    Public WithEvents Frame1 As GroupBox
    Public WithEvents Frame2 As GroupBox
    Public WithEvents optWOTR0 As RadioButton
    Public WithEvents optWOTR1 As RadioButton
    Public WithEvents optWOTR2 As RadioButton
    Public WithEvents Combo2 As ComboBox
    Public WithEvents Combo1 As ComboBox
    Public WithEvents optWorkOrderReport6 As RadioButton
    Public WithEvents optWorkOrderReport5 As RadioButton
    Public WithEvents txtWorkOrderNum As TextBox
    Public WithEvents optWorkOrderReport4 As RadioButton
    Public WithEvents optWorkOrderReport3 As RadioButton
    Public WithEvents optWorkOrderReport2 As RadioButton
    Public WithEvents optWorkOrderReport1 As RadioButton
    Public WithEvents optWorkOrderReport0 As RadioButton
    Public WithEvents Label3 As Label
    Public WithEvents Label1 As Label
    Friend WithEvents DTPicker3 As DateTimePicker
    Friend WithEvents DTPicker2 As DateTimePicker
    Friend WithEvents dtpDateTo As DateTimePicker
    Friend WithEvents dtpDateFrom As DateTimePicker
End Class
