﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAdmin))
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmdUpdateTables = New System.Windows.Forms.Button()
        Me.cmdAccount = New System.Windows.Forms.Button()
        Me.cmdUpdateReportPath = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExit.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExit.Location = New System.Drawing.Point(85, 187)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExit.Size = New System.Drawing.Size(81, 25)
        Me.cmdExit.TabIndex = 7
        Me.cmdExit.Text = "&Close"
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.cmdUpdateTables)
        Me.Frame1.Controls.Add(Me.cmdAccount)
        Me.Frame1.Controls.Add(Me.cmdUpdateReportPath)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(18, 14)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(222, 161)
        Me.Frame1.TabIndex = 8
        Me.Frame1.TabStop = False
        '
        'cmdUpdateTables
        '
        Me.cmdUpdateTables.BackColor = System.Drawing.SystemColors.Control
        Me.cmdUpdateTables.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdUpdateTables.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdUpdateTables.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdUpdateTables.Location = New System.Drawing.Point(24, 65)
        Me.cmdUpdateTables.Name = "cmdUpdateTables"
        Me.cmdUpdateTables.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdUpdateTables.Size = New System.Drawing.Size(175, 32)
        Me.cmdUpdateTables.TabIndex = 1
        Me.cmdUpdateTables.Text = "Update &Tables"
        Me.cmdUpdateTables.UseVisualStyleBackColor = False
        '
        'cmdAccount
        '
        Me.cmdAccount.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAccount.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAccount.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAccount.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAccount.Location = New System.Drawing.Point(24, 24)
        Me.cmdAccount.Name = "cmdAccount"
        Me.cmdAccount.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAccount.Size = New System.Drawing.Size(175, 32)
        Me.cmdAccount.TabIndex = 0
        Me.cmdAccount.Text = "User &Account"
        Me.cmdAccount.UseVisualStyleBackColor = False
        '
        'cmdUpdateReportPath
        '
        Me.cmdUpdateReportPath.BackColor = System.Drawing.SystemColors.Control
        Me.cmdUpdateReportPath.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdUpdateReportPath.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdUpdateReportPath.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdUpdateReportPath.Location = New System.Drawing.Point(24, 108)
        Me.cmdUpdateReportPath.Name = "cmdUpdateReportPath"
        Me.cmdUpdateReportPath.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdUpdateReportPath.Size = New System.Drawing.Size(175, 32)
        Me.cmdUpdateReportPath.TabIndex = 3
        Me.cmdUpdateReportPath.Text = "Update &Report Path"
        Me.cmdUpdateReportPath.UseVisualStyleBackColor = False
        '
        'frmAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(257, 226)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.Frame1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmAdmin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Administrator's Utilities"
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents cmdExit As Button
    Public WithEvents Frame1 As GroupBox
    Public WithEvents cmdUpdateTables As Button
    Public WithEvents cmdAccount As Button
    Public WithEvents cmdUpdateReportPath As Button
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
End Class
