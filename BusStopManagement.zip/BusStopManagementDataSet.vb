﻿Partial Class BusStopManagementDataSet
End Class

Namespace BusStopManagementDataSetTableAdapters

    Partial Public Class tblStaffTableAdapter
    End Class
End Namespace
