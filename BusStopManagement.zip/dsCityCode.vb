﻿Partial Class dsCityCode
    Partial Public Class CITY_CODEDataTable
    End Class
End Class
