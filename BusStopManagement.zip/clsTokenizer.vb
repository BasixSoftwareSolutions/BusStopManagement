Option Strict Off
Option Explicit On
Friend Class clsTokenizer
	
	Private TheString As String
	Private TheDelimiter As String
	Private intCurrentToken As Short
	Private intTokenCount As Short
	Private tokenArray() As String
	
	Public Sub SetString(ByRef aString As String, ByRef aDelimiter As String)
		TheString = aString
		TheDelimiter = aDelimiter
		
		TokenizeIt()
	End Sub
	
	Private Sub TokenizeIt()
		Dim intPos As Short
		Dim intCount As Short
		Dim i As Short
		
		intPos = 0
		intCount = 1
		Do 
			'Starting position to search in method "InStr" is at least "1" not "0"
			intPos = InStr(intPos + 1, TheString, TheDelimiter, CompareMethod.Text)
			If intPos <> 0 Then
				intCount = intCount + 1
			End If
		Loop While (intPos <> 0)
		
		intTokenCount = intCount
		ReDim tokenArray(intCount)
		i = 0
		Do 
			intPos = InStr(TheString, TheDelimiter)
			If intPos <> 0 Then
				tokenArray(i) = Left(TheString, intPos - 1)
				TheString = Right(TheString, Len(TheString) - intPos)
			Else
				tokenArray(i) = TheString
			End If
			i = i + 1
		Loop While (intPos <> 0)
		
		intCurrentToken = 0
	End Sub
	
	Public ReadOnly Property TokenCount() As Short
		Get
			TokenCount = intTokenCount
		End Get
	End Property
	
	Public ReadOnly Property HasNextToken() As Boolean
		Get
			HasNextToken = (intCurrentToken < intTokenCount)
		End Get
	End Property
	
	Public ReadOnly Property NextToken() As String
		Get
			If intCurrentToken < intTokenCount Then
				NextToken = tokenArray(intCurrentToken)
				intCurrentToken = intCurrentToken + 1
			Else
				NextToken = ""
			End If
		End Get
	End Property
	
	Public ReadOnly Property TokenAt(ByVal Index As Integer) As String
		Get
			If Index >= 0 And Index < intTokenCount Then
				TokenAt = tokenArray(Index)
			Else
				TokenAt = ""
			End If
			
		End Get
	End Property
	
	Public ReadOnly Property TokenAtAndMove(ByVal Index As String) As String
		Get
			If CDbl(Index) >= 0 And CDbl(Index) < intTokenCount Then
				TokenAtAndMove = tokenArray(CInt(Index))
				intCurrentToken = CDbl(Index) + 1
			Else
				TokenAtAndMove = ""
			End If
		End Get
	End Property
End Class