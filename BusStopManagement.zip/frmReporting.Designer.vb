﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReporting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReporting))
        Me.cmdAdhocReports = New System.Windows.Forms.Button()
        Me.cmdDSCE = New System.Windows.Forms.Button()
        Me.cmdSMC = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdFollowUpReports = New System.Windows.Forms.Button()
        Me.cmdBusStopReports = New System.Windows.Forms.Button()
        Me.cmdRouteStopLists = New System.Windows.Forms.Button()
        Me.cmdWOReports = New System.Windows.Forms.Button()
        Me._Label1_3 = New System.Windows.Forms.Label()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me._Label1_7 = New System.Windows.Forms.Label()
        Me._Label1_6 = New System.Windows.Forms.Label()
        Me._Label1_5 = New System.Windows.Forms.Label()
        Me._Label1_4 = New System.Windows.Forms.Label()
        Me._Label1_2 = New System.Windows.Forms.Label()
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdAdhocReports
        '
        Me.cmdAdhocReports.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAdhocReports.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAdhocReports.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAdhocReports.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAdhocReports.Image = CType(resources.GetObject("cmdAdhocReports.Image"), System.Drawing.Image)
        Me.cmdAdhocReports.Location = New System.Drawing.Point(28, 193)
        Me.cmdAdhocReports.Name = "cmdAdhocReports"
        Me.cmdAdhocReports.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAdhocReports.Size = New System.Drawing.Size(33, 33)
        Me.cmdAdhocReports.TabIndex = 36
        Me.cmdAdhocReports.UseVisualStyleBackColor = False
        '
        'cmdDSCE
        '
        Me.cmdDSCE.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDSCE.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDSCE.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDSCE.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDSCE.Image = CType(resources.GetObject("cmdDSCE.Image"), System.Drawing.Image)
        Me.cmdDSCE.Location = New System.Drawing.Point(236, 137)
        Me.cmdDSCE.Name = "cmdDSCE"
        Me.cmdDSCE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDSCE.Size = New System.Drawing.Size(33, 33)
        Me.cmdDSCE.TabIndex = 27
        Me.cmdDSCE.UseVisualStyleBackColor = False
        '
        'cmdSMC
        '
        Me.cmdSMC.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSMC.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSMC.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSMC.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSMC.Image = CType(resources.GetObject("cmdSMC.Image"), System.Drawing.Image)
        Me.cmdSMC.Location = New System.Drawing.Point(28, 137)
        Me.cmdSMC.Name = "cmdSMC"
        Me.cmdSMC.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSMC.Size = New System.Drawing.Size(33, 33)
        Me.cmdSMC.TabIndex = 23
        Me.cmdSMC.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(362, 261)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(97, 25)
        Me.cmdCancel.TabIndex = 28
        Me.cmdCancel.Text = "&Close"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdFollowUpReports
        '
        Me.cmdFollowUpReports.BackColor = System.Drawing.SystemColors.Control
        Me.cmdFollowUpReports.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdFollowUpReports.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdFollowUpReports.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdFollowUpReports.Image = CType(resources.GetObject("cmdFollowUpReports.Image"), System.Drawing.Image)
        Me.cmdFollowUpReports.Location = New System.Drawing.Point(236, 81)
        Me.cmdFollowUpReports.Name = "cmdFollowUpReports"
        Me.cmdFollowUpReports.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdFollowUpReports.Size = New System.Drawing.Size(33, 33)
        Me.cmdFollowUpReports.TabIndex = 25
        Me.cmdFollowUpReports.UseVisualStyleBackColor = False
        '
        'cmdBusStopReports
        '
        Me.cmdBusStopReports.BackColor = System.Drawing.SystemColors.Control
        Me.cmdBusStopReports.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdBusStopReports.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBusStopReports.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdBusStopReports.Image = CType(resources.GetObject("cmdBusStopReports.Image"), System.Drawing.Image)
        Me.cmdBusStopReports.Location = New System.Drawing.Point(236, 25)
        Me.cmdBusStopReports.Name = "cmdBusStopReports"
        Me.cmdBusStopReports.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBusStopReports.Size = New System.Drawing.Size(33, 33)
        Me.cmdBusStopReports.TabIndex = 24
        Me.cmdBusStopReports.UseVisualStyleBackColor = False
        '
        'cmdRouteStopLists
        '
        Me.cmdRouteStopLists.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRouteStopLists.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRouteStopLists.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRouteStopLists.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRouteStopLists.Image = CType(resources.GetObject("cmdRouteStopLists.Image"), System.Drawing.Image)
        Me.cmdRouteStopLists.Location = New System.Drawing.Point(28, 81)
        Me.cmdRouteStopLists.Name = "cmdRouteStopLists"
        Me.cmdRouteStopLists.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRouteStopLists.Size = New System.Drawing.Size(33, 33)
        Me.cmdRouteStopLists.TabIndex = 22
        Me.cmdRouteStopLists.UseVisualStyleBackColor = False
        '
        'cmdWOReports
        '
        Me.cmdWOReports.BackColor = System.Drawing.SystemColors.Control
        Me.cmdWOReports.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdWOReports.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdWOReports.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdWOReports.Image = CType(resources.GetObject("cmdWOReports.Image"), System.Drawing.Image)
        Me.cmdWOReports.Location = New System.Drawing.Point(28, 25)
        Me.cmdWOReports.Name = "cmdWOReports"
        Me.cmdWOReports.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdWOReports.Size = New System.Drawing.Size(33, 33)
        Me.cmdWOReports.TabIndex = 21
        Me.cmdWOReports.UseVisualStyleBackColor = False
        '
        '_Label1_3
        '
        Me._Label1_3.BackColor = System.Drawing.Color.Transparent
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_3.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_3.Location = New System.Drawing.Point(68, 201)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(98, 17)
        Me._Label1_3.TabIndex = 37
        Me._Label1_3.Text = "Adhoc Reports"
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(12, 9)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(447, 233)
        Me.Shape1.TabIndex = 38
        '
        '_Label1_7
        '
        Me._Label1_7.BackColor = System.Drawing.Color.Transparent
        Me._Label1_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_7.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_7.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_7.Location = New System.Drawing.Point(276, 145)
        Me._Label1_7.Name = "_Label1_7"
        Me._Label1_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_7.Size = New System.Drawing.Size(174, 17)
        Me._Label1_7.TabIndex = 34
        Me._Label1_7.Text = "Damaged Stop Cost Estimate"
        '
        '_Label1_6
        '
        Me._Label1_6.BackColor = System.Drawing.Color.Transparent
        Me._Label1_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_6.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_6.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_6.Location = New System.Drawing.Point(68, 145)
        Me._Label1_6.Name = "_Label1_6"
        Me._Label1_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_6.Size = New System.Drawing.Size(143, 17)
        Me._Label1_6.TabIndex = 35
        Me._Label1_6.Text = "Stop Modification Notice"
        '
        '_Label1_5
        '
        Me._Label1_5.BackColor = System.Drawing.Color.Transparent
        Me._Label1_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_5.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_5.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_5.Location = New System.Drawing.Point(276, 89)
        Me._Label1_5.Name = "_Label1_5"
        Me._Label1_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_5.Size = New System.Drawing.Size(144, 17)
        Me._Label1_5.TabIndex = 32
        Me._Label1_5.Text = "Follow-up Work Reports"
        '
        '_Label1_4
        '
        Me._Label1_4.BackColor = System.Drawing.Color.Transparent
        Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_4.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_4.Location = New System.Drawing.Point(276, 33)
        Me._Label1_4.Name = "_Label1_4"
        Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_4.Size = New System.Drawing.Size(123, 17)
        Me._Label1_4.TabIndex = 31
        Me._Label1_4.Text = "Bus Stop Reports"
        '
        '_Label1_2
        '
        Me._Label1_2.BackColor = System.Drawing.Color.Transparent
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_2.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_2.Location = New System.Drawing.Point(68, 89)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(108, 17)
        Me._Label1_2.TabIndex = 30
        Me._Label1_2.Text = "Route Stop Lists"
        '
        '_Label1_0
        '
        Me._Label1_0.BackColor = System.Drawing.Color.Transparent
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_0.Location = New System.Drawing.Point(68, 33)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(127, 17)
        Me._Label1_0.TabIndex = 29
        Me._Label1_0.Text = "Work Order Reports"
        '
        'frmReporting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(475, 298)
        Me.Controls.Add(Me.cmdAdhocReports)
        Me.Controls.Add(Me.cmdDSCE)
        Me.Controls.Add(Me.cmdSMC)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdFollowUpReports)
        Me.Controls.Add(Me.cmdBusStopReports)
        Me.Controls.Add(Me.cmdRouteStopLists)
        Me.Controls.Add(Me.cmdWOReports)
        Me.Controls.Add(Me._Label1_3)
        Me.Controls.Add(Me._Label1_7)
        Me.Controls.Add(Me._Label1_6)
        Me.Controls.Add(Me._Label1_5)
        Me.Controls.Add(Me._Label1_4)
        Me.Controls.Add(Me._Label1_2)
        Me.Controls.Add(Me._Label1_0)
        Me.Controls.Add(Me.Shape1)
        Me.ForeColor = System.Drawing.Color.DimGray
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmReporting"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Reporting"
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents cmdAdhocReports As Button
    Public WithEvents cmdDSCE As Button
    Public WithEvents cmdSMC As Button
    Public WithEvents cmdCancel As Button
    Public WithEvents cmdFollowUpReports As Button
    Public WithEvents cmdBusStopReports As Button
    Public WithEvents cmdRouteStopLists As Button
    Public WithEvents cmdWOReports As Button
    Public WithEvents _Label1_3 As Label
    Public WithEvents Shape1 As Label
    Public WithEvents _Label1_7 As Label
    Public WithEvents _Label1_6 As Label
    Public WithEvents _Label1_5 As Label
    Public WithEvents _Label1_4 As Label
    Public WithEvents _Label1_2 As Label
    Public WithEvents _Label1_0 As Label
End Class
