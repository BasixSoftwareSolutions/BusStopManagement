﻿Partial Class dsBusStopStatusCode
    Partial Public Class BS_STATUS_CODEDataTable
    End Class
End Class
