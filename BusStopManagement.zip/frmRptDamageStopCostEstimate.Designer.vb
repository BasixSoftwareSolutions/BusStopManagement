﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRptDamageStopCostEstimate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRptDamageStopCostEstimate))
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cmdFind = New System.Windows.Forms.Button()
        Me.txtTax = New System.Windows.Forms.TextBox()
        Me.txtLabor = New System.Windows.Forms.TextBox()
        Me.txtOverhead = New System.Windows.Forms.TextBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtSTotal = New System.Windows.Forms.TextBox()
        Me.Text2 = New System.Windows.Forms.TextBox()
        Me.Text3 = New System.Windows.Forms.TextBox()
        Me.Text4 = New System.Windows.Forms.TextBox()
        Me.Text5 = New System.Windows.Forms.TextBox()
        Me.Text1 = New System.Windows.Forms.TextBox()
        Me.txtIncidentNo = New System.Windows.Forms.TextBox()
        Me.txtPDNO = New System.Windows.Forms.TextBox()
        Me.txtCRS4 = New System.Windows.Forms.TextBox()
        Me.txtCRS3 = New System.Windows.Forms.TextBox()
        Me.txtCRS2 = New System.Windows.Forms.TextBox()
        Me.txtCRS1 = New System.Windows.Forms.TextBox()
        Me.txtSt3 = New System.Windows.Forms.TextBox()
        Me.txtSt2 = New System.Windows.Forms.TextBox()
        Me.txtSt1 = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtSANZID = New System.Windows.Forms.TextBox()
        Me.txtOCTAID = New System.Windows.Forms.TextBox()
        Me.lblOverheadRate = New System.Windows.Forms.Label()
        Me.lblTaxRate = New System.Windows.Forms.Label()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TDBGrid1 = New System.Windows.Forms.DataGridView()
        Me.TblDamageStopCostBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsDamageReport = New BusStopManagement.dsDamageReport()
        Me.dtIncident = New System.Windows.Forms.DateTimePicker()
        Me.TblDamageStopCostTableAdapter = New BusStopManagement.dsDamageReportTableAdapters.tblDamageStopCostTableAdapter()
        Me.DESCRIPTIONDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SelectedItem = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.ItemQuantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.COSTDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.COST = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.TDBGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDamageStopCostBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsDamageReport, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdSave
        '
        Me.cmdSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSave.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSave.Location = New System.Drawing.Point(111, 546)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSave.Size = New System.Drawing.Size(73, 25)
        Me.cmdSave.TabIndex = 43
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(191, 546)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(73, 25)
        Me.cmdCancel.TabIndex = 44
        Me.cmdCancel.Text = "C&lear"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdExit
        '
        Me.cmdExit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdExit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExit.Location = New System.Drawing.Point(271, 546)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExit.Size = New System.Drawing.Size(73, 25)
        Me.cmdExit.TabIndex = 45
        Me.cmdExit.Text = "&Close"
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'cmdFind
        '
        Me.cmdFind.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdFind.BackColor = System.Drawing.SystemColors.Control
        Me.cmdFind.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdFind.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdFind.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdFind.Location = New System.Drawing.Point(31, 546)
        Me.cmdFind.Name = "cmdFind"
        Me.cmdFind.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdFind.Size = New System.Drawing.Size(73, 25)
        Me.cmdFind.TabIndex = 42
        Me.cmdFind.Text = "&Find"
        Me.cmdFind.UseVisualStyleBackColor = False
        '
        'txtTax
        '
        Me.txtTax.AcceptsReturn = True
        Me.txtTax.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTax.BackColor = System.Drawing.SystemColors.Window
        Me.txtTax.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTax.Enabled = False
        Me.txtTax.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTax.Location = New System.Drawing.Point(718, 536)
        Me.txtTax.MaxLength = 0
        Me.txtTax.Name = "txtTax"
        Me.txtTax.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTax.Size = New System.Drawing.Size(96, 20)
        Me.txtTax.TabIndex = 72
        Me.txtTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtLabor
        '
        Me.txtLabor.AcceptsReturn = True
        Me.txtLabor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLabor.BackColor = System.Drawing.SystemColors.Window
        Me.txtLabor.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLabor.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLabor.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtLabor.Location = New System.Drawing.Point(718, 560)
        Me.txtLabor.MaxLength = 0
        Me.txtLabor.Name = "txtLabor"
        Me.txtLabor.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtLabor.Size = New System.Drawing.Size(96, 20)
        Me.txtLabor.TabIndex = 41
        Me.txtLabor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtOverhead
        '
        Me.txtOverhead.AcceptsReturn = True
        Me.txtOverhead.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtOverhead.BackColor = System.Drawing.SystemColors.Window
        Me.txtOverhead.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtOverhead.Enabled = False
        Me.txtOverhead.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOverhead.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOverhead.Location = New System.Drawing.Point(718, 584)
        Me.txtOverhead.MaxLength = 0
        Me.txtOverhead.Name = "txtOverhead"
        Me.txtOverhead.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtOverhead.Size = New System.Drawing.Size(96, 20)
        Me.txtOverhead.TabIndex = 71
        Me.txtOverhead.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTotal
        '
        Me.txtTotal.AcceptsReturn = True
        Me.txtTotal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtTotal.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTotal.Enabled = False
        Me.txtTotal.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTotal.Location = New System.Drawing.Point(718, 608)
        Me.txtTotal.MaxLength = 0
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTotal.Size = New System.Drawing.Size(96, 20)
        Me.txtTotal.TabIndex = 70
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSTotal
        '
        Me.txtSTotal.AcceptsReturn = True
        Me.txtSTotal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtSTotal.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSTotal.Enabled = False
        Me.txtSTotal.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSTotal.Location = New System.Drawing.Point(718, 512)
        Me.txtSTotal.MaxLength = 0
        Me.txtSTotal.Name = "txtSTotal"
        Me.txtSTotal.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSTotal.Size = New System.Drawing.Size(96, 20)
        Me.txtSTotal.TabIndex = 69
        Me.txtSTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Text2
        '
        Me.Text2.AcceptsReturn = True
        Me.Text2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Text2.BackColor = System.Drawing.SystemColors.Window
        Me.Text2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text2.Enabled = False
        Me.Text2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text2.Location = New System.Drawing.Point(574, 536)
        Me.Text2.MaxLength = 0
        Me.Text2.Name = "Text2"
        Me.Text2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text2.Size = New System.Drawing.Size(145, 20)
        Me.Text2.TabIndex = 68
        Me.Text2.Text = "TAX:"
        Me.Text2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Text3
        '
        Me.Text3.AcceptsReturn = True
        Me.Text3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Text3.BackColor = System.Drawing.SystemColors.Window
        Me.Text3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text3.Enabled = False
        Me.Text3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text3.Location = New System.Drawing.Point(574, 560)
        Me.Text3.MaxLength = 0
        Me.Text3.Name = "Text3"
        Me.Text3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text3.Size = New System.Drawing.Size(145, 20)
        Me.Text3.TabIndex = 67
        Me.Text3.Text = "LABOR:"
        Me.Text3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Text4
        '
        Me.Text4.AcceptsReturn = True
        Me.Text4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Text4.BackColor = System.Drawing.SystemColors.Window
        Me.Text4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text4.Enabled = False
        Me.Text4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text4.Location = New System.Drawing.Point(574, 584)
        Me.Text4.MaxLength = 0
        Me.Text4.Name = "Text4"
        Me.Text4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text4.Size = New System.Drawing.Size(145, 20)
        Me.Text4.TabIndex = 66
        Me.Text4.Text = "OVERHEAD (43%):"
        Me.Text4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Text5
        '
        Me.Text5.AcceptsReturn = True
        Me.Text5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Text5.BackColor = System.Drawing.SystemColors.Window
        Me.Text5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text5.Enabled = False
        Me.Text5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text5.Location = New System.Drawing.Point(574, 608)
        Me.Text5.MaxLength = 0
        Me.Text5.Name = "Text5"
        Me.Text5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text5.Size = New System.Drawing.Size(145, 20)
        Me.Text5.TabIndex = 65
        Me.Text5.Text = "TOTAL:"
        Me.Text5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Text1
        '
        Me.Text1.AcceptsReturn = True
        Me.Text1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Text1.BackColor = System.Drawing.SystemColors.Window
        Me.Text1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Text1.Enabled = False
        Me.Text1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Text1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Text1.Location = New System.Drawing.Point(574, 512)
        Me.Text1.MaxLength = 0
        Me.Text1.Name = "Text1"
        Me.Text1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text1.Size = New System.Drawing.Size(145, 20)
        Me.Text1.TabIndex = 64
        Me.Text1.Text = "SUB TOTAL:"
        Me.Text1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtIncidentNo
        '
        Me.txtIncidentNo.AcceptsReturn = True
        Me.txtIncidentNo.BackColor = System.Drawing.SystemColors.Window
        Me.txtIncidentNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtIncidentNo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIncidentNo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtIncidentNo.Location = New System.Drawing.Point(521, 150)
        Me.txtIncidentNo.MaxLength = 0
        Me.txtIncidentNo.Name = "txtIncidentNo"
        Me.txtIncidentNo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtIncidentNo.Size = New System.Drawing.Size(113, 20)
        Me.txtIncidentNo.TabIndex = 40
        '
        'txtPDNO
        '
        Me.txtPDNO.AcceptsReturn = True
        Me.txtPDNO.BackColor = System.Drawing.SystemColors.Window
        Me.txtPDNO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPDNO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPDNO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPDNO.Location = New System.Drawing.Point(321, 150)
        Me.txtPDNO.MaxLength = 0
        Me.txtPDNO.Name = "txtPDNO"
        Me.txtPDNO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPDNO.Size = New System.Drawing.Size(105, 20)
        Me.txtPDNO.TabIndex = 39
        '
        'txtCRS4
        '
        Me.txtCRS4.AcceptsReturn = True
        Me.txtCRS4.BackColor = System.Drawing.SystemColors.Window
        Me.txtCRS4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCRS4.Enabled = False
        Me.txtCRS4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCRS4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCRS4.Location = New System.Drawing.Point(201, 118)
        Me.txtCRS4.MaxLength = 0
        Me.txtCRS4.Name = "txtCRS4"
        Me.txtCRS4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCRS4.Size = New System.Drawing.Size(265, 20)
        Me.txtCRS4.TabIndex = 55
        '
        'txtCRS3
        '
        Me.txtCRS3.AcceptsReturn = True
        Me.txtCRS3.BackColor = System.Drawing.SystemColors.Window
        Me.txtCRS3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCRS3.Enabled = False
        Me.txtCRS3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCRS3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCRS3.Location = New System.Drawing.Point(489, 88)
        Me.txtCRS3.MaxLength = 0
        Me.txtCRS3.Name = "txtCRS3"
        Me.txtCRS3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCRS3.Size = New System.Drawing.Size(41, 20)
        Me.txtCRS3.TabIndex = 54
        '
        'txtCRS2
        '
        Me.txtCRS2.AcceptsReturn = True
        Me.txtCRS2.BackColor = System.Drawing.SystemColors.Window
        Me.txtCRS2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCRS2.Enabled = False
        Me.txtCRS2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCRS2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCRS2.Location = New System.Drawing.Point(201, 88)
        Me.txtCRS2.MaxLength = 0
        Me.txtCRS2.Name = "txtCRS2"
        Me.txtCRS2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCRS2.Size = New System.Drawing.Size(265, 20)
        Me.txtCRS2.TabIndex = 53
        '
        'txtCRS1
        '
        Me.txtCRS1.AcceptsReturn = True
        Me.txtCRS1.BackColor = System.Drawing.SystemColors.Window
        Me.txtCRS1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCRS1.Enabled = False
        Me.txtCRS1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCRS1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCRS1.Location = New System.Drawing.Point(137, 88)
        Me.txtCRS1.MaxLength = 0
        Me.txtCRS1.Name = "txtCRS1"
        Me.txtCRS1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCRS1.Size = New System.Drawing.Size(41, 20)
        Me.txtCRS1.TabIndex = 52
        '
        'txtSt3
        '
        Me.txtSt3.AcceptsReturn = True
        Me.txtSt3.BackColor = System.Drawing.SystemColors.Window
        Me.txtSt3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSt3.Enabled = False
        Me.txtSt3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSt3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSt3.Location = New System.Drawing.Point(489, 58)
        Me.txtSt3.MaxLength = 0
        Me.txtSt3.Name = "txtSt3"
        Me.txtSt3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSt3.Size = New System.Drawing.Size(41, 20)
        Me.txtSt3.TabIndex = 51
        '
        'txtSt2
        '
        Me.txtSt2.AcceptsReturn = True
        Me.txtSt2.BackColor = System.Drawing.SystemColors.Window
        Me.txtSt2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSt2.Enabled = False
        Me.txtSt2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSt2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSt2.Location = New System.Drawing.Point(201, 58)
        Me.txtSt2.MaxLength = 0
        Me.txtSt2.Name = "txtSt2"
        Me.txtSt2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSt2.Size = New System.Drawing.Size(265, 20)
        Me.txtSt2.TabIndex = 50
        '
        'txtSt1
        '
        Me.txtSt1.AcceptsReturn = True
        Me.txtSt1.BackColor = System.Drawing.SystemColors.Window
        Me.txtSt1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSt1.Enabled = False
        Me.txtSt1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSt1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSt1.Location = New System.Drawing.Point(137, 58)
        Me.txtSt1.MaxLength = 0
        Me.txtSt1.Name = "txtSt1"
        Me.txtSt1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSt1.Size = New System.Drawing.Size(41, 20)
        Me.txtSt1.TabIndex = 49
        '
        'txtCity
        '
        Me.txtCity.AcceptsReturn = True
        Me.txtCity.BackColor = System.Drawing.SystemColors.Window
        Me.txtCity.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCity.Enabled = False
        Me.txtCity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCity.Location = New System.Drawing.Point(409, 22)
        Me.txtCity.MaxLength = 0
        Me.txtCity.Name = "txtCity"
        Me.txtCity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtCity.Size = New System.Drawing.Size(105, 20)
        Me.txtCity.TabIndex = 48
        '
        'txtSANZID
        '
        Me.txtSANZID.AcceptsReturn = True
        Me.txtSANZID.BackColor = System.Drawing.SystemColors.Window
        Me.txtSANZID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSANZID.Enabled = False
        Me.txtSANZID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSANZID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSANZID.Location = New System.Drawing.Point(249, 22)
        Me.txtSANZID.MaxLength = 0
        Me.txtSANZID.Name = "txtSANZID"
        Me.txtSANZID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSANZID.Size = New System.Drawing.Size(105, 20)
        Me.txtSANZID.TabIndex = 47
        '
        'txtOCTAID
        '
        Me.txtOCTAID.AcceptsReturn = True
        Me.txtOCTAID.BackColor = System.Drawing.SystemColors.Window
        Me.txtOCTAID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtOCTAID.Enabled = False
        Me.txtOCTAID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOCTAID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOCTAID.Location = New System.Drawing.Point(73, 22)
        Me.txtOCTAID.MaxLength = 0
        Me.txtOCTAID.Name = "txtOCTAID"
        Me.txtOCTAID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtOCTAID.Size = New System.Drawing.Size(105, 20)
        Me.txtOCTAID.TabIndex = 46
        '
        'lblOverheadRate
        '
        Me.lblOverheadRate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblOverheadRate.BackColor = System.Drawing.Color.Transparent
        Me.lblOverheadRate.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblOverheadRate.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOverheadRate.ForeColor = System.Drawing.Color.DimGray
        Me.lblOverheadRate.Location = New System.Drawing.Point(17, 630)
        Me.lblOverheadRate.Name = "lblOverheadRate"
        Me.lblOverheadRate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblOverheadRate.Size = New System.Drawing.Size(121, 17)
        Me.lblOverheadRate.TabIndex = 74
        Me.lblOverheadRate.Text = "Overhead Rate"
        '
        'lblTaxRate
        '
        Me.lblTaxRate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblTaxRate.BackColor = System.Drawing.Color.Transparent
        Me.lblTaxRate.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTaxRate.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTaxRate.ForeColor = System.Drawing.Color.DimGray
        Me.lblTaxRate.Location = New System.Drawing.Point(17, 614)
        Me.lblTaxRate.Name = "lblTaxRate"
        Me.lblTaxRate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTaxRate.Size = New System.Drawing.Size(121, 17)
        Me.lblTaxRate.TabIndex = 73
        Me.lblTaxRate.Text = "Tax Rate"
        '
        'Shape1
        '
        Me.Shape1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(23, 538)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(329, 41)
        Me.Shape1.TabIndex = 75
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DimGray
        Me.Label8.Location = New System.Drawing.Point(446, 154)
        Me.Label8.Name = "Label8"
        Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label8.Size = New System.Drawing.Size(72, 17)
        Me.Label8.TabIndex = 63
        Me.Label8.Text = "INCIDENT NO:"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.DimGray
        Me.Label7.Location = New System.Drawing.Point(232, 154)
        Me.Label7.Name = "Label7"
        Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label7.Size = New System.Drawing.Size(84, 17)
        Me.Label7.TabIndex = 62
        Me.Label7.Text = "PD REPORT NO:"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DimGray
        Me.Label6.Location = New System.Drawing.Point(17, 154)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(105, 17)
        Me.Label6.TabIndex = 61
        Me.Label6.Text = "DATE OF INCIDENT:"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DimGray
        Me.Label5.Location = New System.Drawing.Point(17, 92)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(89, 17)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "CROSS STREET:"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(17, 62)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(137, 17)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "STREET OF TRAVEL:"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(377, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(57, 17)
        Me.Label3.TabIndex = 58
        Me.Label3.Text = "CITY:"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(193, 26)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(57, 17)
        Me.Label2.TabIndex = 57
        Me.Label2.Text = "SANZ ID:"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(17, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(89, 17)
        Me.Label1.TabIndex = 56
        Me.Label1.Text = "OCTA ID:"
        '
        'TDBGrid1
        '
        Me.TDBGrid1.AllowUserToAddRows = False
        Me.TDBGrid1.AllowUserToDeleteRows = False
        Me.TDBGrid1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TDBGrid1.AutoGenerateColumns = False
        Me.TDBGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TDBGrid1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DESCRIPTIONDataGridViewTextBoxColumn, Me.SelectedItem, Me.ItemQuantity, Me.COSTDataGridViewTextBoxColumn, Me.COST})
        Me.TDBGrid1.DataSource = Me.TblDamageStopCostBindingSource
        Me.TDBGrid1.Location = New System.Drawing.Point(23, 182)
        Me.TDBGrid1.Name = "TDBGrid1"
        Me.TDBGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.TDBGrid1.Size = New System.Drawing.Size(791, 324)
        Me.TDBGrid1.TabIndex = 76
        '
        'TblDamageStopCostBindingSource
        '
        Me.TblDamageStopCostBindingSource.DataMember = "tblDamageStopCost"
        Me.TblDamageStopCostBindingSource.DataSource = Me.DsDamageReport
        '
        'DsDamageReport
        '
        Me.DsDamageReport.DataSetName = "dsDamageReport"
        Me.DsDamageReport.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'dtIncident
        '
        Me.dtIncident.Location = New System.Drawing.Point(119, 151)
        Me.dtIncident.Name = "dtIncident"
        Me.dtIncident.Size = New System.Drawing.Size(103, 20)
        Me.dtIncident.TabIndex = 77
        '
        'TblDamageStopCostTableAdapter
        '
        Me.TblDamageStopCostTableAdapter.ClearBeforeFill = True
        '
        'DESCRIPTIONDataGridViewTextBoxColumn
        '
        Me.DESCRIPTIONDataGridViewTextBoxColumn.DataPropertyName = "DESCRIPTION"
        Me.DESCRIPTIONDataGridViewTextBoxColumn.HeaderText = "DESCRIPTION"
        Me.DESCRIPTIONDataGridViewTextBoxColumn.Name = "DESCRIPTIONDataGridViewTextBoxColumn"
        Me.DESCRIPTIONDataGridViewTextBoxColumn.ReadOnly = True
        Me.DESCRIPTIONDataGridViewTextBoxColumn.Width = 275
        '
        'SelectedItem
        '
        Me.SelectedItem.HeaderText = ""
        Me.SelectedItem.Name = "SelectedItem"
        '
        'ItemQuantity
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ItemQuantity.DefaultCellStyle = DataGridViewCellStyle1
        Me.ItemQuantity.HeaderText = "QTY"
        Me.ItemQuantity.Name = "ItemQuantity"
        Me.ItemQuantity.Width = 75
        '
        'COSTDataGridViewTextBoxColumn
        '
        Me.COSTDataGridViewTextBoxColumn.DataPropertyName = "COST"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle2.Format = "C2"
        DataGridViewCellStyle2.NullValue = Nothing
        Me.COSTDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle2
        Me.COSTDataGridViewTextBoxColumn.HeaderText = "UNIT COST"
        Me.COSTDataGridViewTextBoxColumn.Name = "COSTDataGridViewTextBoxColumn"
        Me.COSTDataGridViewTextBoxColumn.ReadOnly = True
        Me.COSTDataGridViewTextBoxColumn.Width = 125
        '
        'COST
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle3.Format = "C2"
        DataGridViewCellStyle3.NullValue = Nothing
        Me.COST.DefaultCellStyle = DataGridViewCellStyle3
        Me.COST.HeaderText = "COST"
        Me.COST.Name = "COST"
        Me.COST.ReadOnly = True
        Me.COST.Width = 125
        '
        'frmRptDamageStopCostEstimate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(840, 649)
        Me.Controls.Add(Me.dtIncident)
        Me.Controls.Add(Me.TDBGrid1)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.cmdFind)
        Me.Controls.Add(Me.txtTax)
        Me.Controls.Add(Me.txtLabor)
        Me.Controls.Add(Me.txtOverhead)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.txtSTotal)
        Me.Controls.Add(Me.Text2)
        Me.Controls.Add(Me.Text3)
        Me.Controls.Add(Me.Text4)
        Me.Controls.Add(Me.Text5)
        Me.Controls.Add(Me.Text1)
        Me.Controls.Add(Me.txtIncidentNo)
        Me.Controls.Add(Me.txtPDNO)
        Me.Controls.Add(Me.txtCRS4)
        Me.Controls.Add(Me.txtCRS3)
        Me.Controls.Add(Me.txtCRS2)
        Me.Controls.Add(Me.txtCRS1)
        Me.Controls.Add(Me.txtSt3)
        Me.Controls.Add(Me.txtSt2)
        Me.Controls.Add(Me.txtSt1)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.txtSANZID)
        Me.Controls.Add(Me.txtOCTAID)
        Me.Controls.Add(Me.lblOverheadRate)
        Me.Controls.Add(Me.lblTaxRate)
        Me.Controls.Add(Me.Shape1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(856, 687)
        Me.Name = "frmRptDamageStopCostEstimate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Damage Stop Cost Estimate"
        CType(Me.TDBGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDamageStopCostBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsDamageReport, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents cmdSave As Button
    Public WithEvents cmdCancel As Button
    Public WithEvents cmdExit As Button
    Public WithEvents cmdFind As Button
    Public WithEvents txtTax As TextBox
    Public WithEvents txtLabor As TextBox
    Public WithEvents txtOverhead As TextBox
    Public WithEvents txtTotal As TextBox
    Public WithEvents txtSTotal As TextBox
    Public WithEvents Text2 As TextBox
    Public WithEvents Text3 As TextBox
    Public WithEvents Text4 As TextBox
    Public WithEvents Text5 As TextBox
    Public WithEvents Text1 As TextBox
    Public WithEvents txtIncidentNo As TextBox
    Public WithEvents txtPDNO As TextBox
    Public WithEvents txtCRS4 As TextBox
    Public WithEvents txtCRS3 As TextBox
    Public WithEvents txtCRS2 As TextBox
    Public WithEvents txtCRS1 As TextBox
    Public WithEvents txtSt3 As TextBox
    Public WithEvents txtSt2 As TextBox
    Public WithEvents txtSt1 As TextBox
    Public WithEvents txtCity As TextBox
    Public WithEvents txtSANZID As TextBox
    Public WithEvents txtOCTAID As TextBox
    Public WithEvents lblOverheadRate As Label
    Public WithEvents lblTaxRate As Label
    Public WithEvents Shape1 As Label
    Public WithEvents Label8 As Label
    Public WithEvents Label7 As Label
    Public WithEvents Label6 As Label
    Public WithEvents Label5 As Label
    Public WithEvents Label4 As Label
    Public WithEvents Label3 As Label
    Public WithEvents Label2 As Label
    Public WithEvents Label1 As Label
    Friend WithEvents TDBGrid1 As DataGridView
    Friend WithEvents dtIncident As DateTimePicker
    Friend WithEvents DsDamageReport As dsDamageReport
    Friend WithEvents TblDamageStopCostBindingSource As BindingSource
    Friend WithEvents TblDamageStopCostTableAdapter As dsDamageReportTableAdapters.tblDamageStopCostTableAdapter
    Friend WithEvents QUANTITYDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DESCRIPTIONDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SelectedItem As DataGridViewCheckBoxColumn
    Friend WithEvents ItemQuantity As DataGridViewTextBoxColumn
    Friend WithEvents COSTDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents COST As DataGridViewTextBoxColumn
End Class
