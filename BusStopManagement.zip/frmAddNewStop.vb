﻿Public Class frmAddNewStop

    Private Sub cboCity_SelectedValueChanged(sender As Object, e As EventArgs) Handles cboCity.SelectedValueChanged
        On Error Resume Next
        Dim strSQL As String
        Dim jurisdID As Integer
        Dim rsLookup As New ADODB.Recordset

        CITYCODEBindingSource2.Filter = "CITY = '" & Me.cboCity.Text & "'"
        CITYCODEBindingSource4.Filter = "JURISDICTION = '" & Me.cboJurisd.Text & "'"

        strSQL = "SELECT ID FROM CITY_CODE WHERE CITY = '" & Me.cboCity.Text & "'"
        rsLookup.Open(strSQL, db)
        jurisdID = rsLookup("ID").Value
        rsLookup.Close()

        TblBusStopInformationBindingSource.Filter = "JURISDICTION_ID = " & jurisdID & ""
        TDBGrid1.Refresh()
        lblNumberOfRecords.Text = "Number of Records: " & TDBGrid1.RowCount

        txtSANZID.Text = cboCity.Text & "."

    End Sub

    Private Sub cboJurisd_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboJurisd.SelectedIndexChanged

        CITYCODEBindingSource4.Filter = "JURISDICTION = '" & Me.cboJurisd.Text & "'"

        Dim rsJurClick As New ADODB.Recordset
        Dim strSQL As String
        Dim strAgencyID As String

        strSQL = "select * from city_code where jurisdiction = '" & cboJurisd.Text & "'"

        rsJurClick.Open(strSQL, db)
        cboAgencyDesc.Text = rsJurClick("Description").Value
        strAgencyID = rsJurClick("ID").Value
        cboCity.Text = rsJurClick("CITY").Value
        rsJurClick.Close()

        TblBusStopInformationBindingSource.Filter = "JURISDICTION_ID = " & strAgencyID & ""
        TDBGrid1.Refresh()
        lblNumberOfRecords.Text = "Number of Records: " & TDBGrid1.RowCount

        txtSANZID.Text = cboCity.Text & "."

    End Sub

    Private Sub frmAddNewStop_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        On Error GoTo errHandler

        Me.TblBusStopInformationTableAdapter.Fill(Me.DsAddNewStop.tblBusStopInformation)
        Me.TblBusStopInformationTableAdapter.Fill(Me.DsAddNewStop.tblBusStopInformation)
        Me.CITY_CODETableAdapter3.Fill(Me.DsAgencyDesc.CITY_CODE)
        Me.CITY_CODETableAdapter2.Fill(Me.DsAgencyCode.CITY_CODE)
        Me.CITY_CODETableAdapter1.Fill(Me.DsCityCode.CITY_CODE)
        Me.CITY_CODETableAdapter.Fill(Me.DsListOfCities.CITY_CODE)

        Exit Sub

errHandler:
        MsgBox(Err.Description)
        Resume Next

    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click

        Me.Close()

    End Sub

    Private Sub cmdInsertStop_Click(sender As Object, e As EventArgs) Handles cmdInsertStop.Click
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rsLookup As New ADODB.Recordset
        Dim rsCheck As New ADODB.Recordset
        Dim rsID As New ADODB.Recordset
        Dim cityID As Long
        Dim jurisdID As Long
        Dim strOCTAID As String = ""
        Dim strIDs As String = ""
        Dim strIDVals As String = ""
        Dim intHistoryType As Integer
        Dim strRemarks As String = ""
        Dim strDate As String = ""

        If Trim(txtSANZID.Text) = "" Then
            Exit Sub
        End If

        If Len(Trim(txtSANZID.Text)) <> 10 Then
            MsgBox("Invalid value! SANZ ID needs to be 10 characters long. ", vbExclamation, "SANZ ID")
            txtSANZID.SelectionStart = 0
            txtSANZID.SelectionLength = Len(txtSANZID.Text)
            txtSANZID.Select()
            Exit Sub
        End If

        If Len(Trim(txtSANZID.Text)) <= Len(Trim(cboCity.Text)) + 1 Then
            Exit Sub
        End If

        ' Make sure stop doesnt already exist
        strSQL = "SELECT count(*) as [num] FROM tblBusStopInformation WHERE SANZ_ID = '" & txtSANZID.Text & "'"
        rsCheck.Open(strSQL, db)

        If rsCheck("num").Value <> 0 Then
            MsgBox("Stop " & txtSANZID.Text & " already exists. Please try another SANZ ID.", vbCritical, "Duplicate SANZ ID")
            Exit Sub
        End If

        ' Get the City and Jurisdiction IDs
        strSQL = "SELECT TOP 1 ID FROM CITY_CODE WHERE CITY = '" & cboCity.Text & "'"
        rsLookup.Open(strSQL, db)
        cityID = rsLookup("ID").Value
        rsLookup.Close()

        strSQL = "SELECT ID FROM CITY_CODE WHERE Jurisdiction = '" & cboJurisd.Text & "'"
        rsLookup.Open(strSQL, db)
        jurisdID = rsLookup("ID").Value
        rsLookup.Close()

        strSQL = "INSERT INTO tblBusStopInformation (SANZ_ID, COUNTY_ID, CITY_ID, JURISDICTION_ID, ST_DIR_ID, BS_LOC_ID, EFFECTIVE_DATE) "
        strSQL = strSQL & "VALUES('" & txtSANZID.Text & "', 1, " & cityID & ", " & jurisdID & ", 1, 1, '" & Date.Today.ToShortDateString & "')"
        db.Execute(strSQL)

        strSQL = "SELECT MAX(OCTA_ID) FROM [tblBusStopInformation]"
        rsID.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)
        If Not (rsID.EOF And rsID.BOF) Then
            strOCTAID = rsID.Fields(0).Value
        End If
        rsID.Close()

        frmUpdateStop.TableAdapterManager.UpdateAll(frmUpdateStop.BusStopManagementDataSet2)

        ' Create entries in 1-1 relational tables for new stop
        strIDs = "(OCTA_ID, SANZ_ID)"
        strIDVals = "(" & strOCTAID & ", '" & txtSANZID.Text & "')"
        'strSQL = "INSERT INTO tblFaxUpdate " & strIDs & " VALUES " & strIDVals
        'db.Execute(strSQL)
        strSQL = "INSERT INTO tblSignCassette " & strIDs & " VALUES " & strIDVals
        db.Execute(strSQL)
        strSQL = "INSERT INTO tblStopTransAmenities " & strIDs & " VALUES " & strIDVals
        db.Execute(strSQL)
        strIDs = "(OCTA_ID, SANZ_ID, GPS_REQUIRED)"
        strIDVals = "(" & strOCTAID & ", '" & txtSANZID.Text & "', 1)"
        strSQL = "INSERT INTO tblStopCoord " & strIDs & " VALUES " & strIDVals
        db.Execute(strSQL)
        strIDs = "(OCTA_ID, SANZ_ID, ADA_STATUS_ID)"
        strIDVals = "(" & strOCTAID & ", '" & txtSANZID.Text & "', 4)" '4 for NOT SURVEYED
        strSQL = "INSERT INTO tblADAStatus " & strIDs & " VALUES " & strIDVals
        db.Execute(strSQL)

        'create history record
        intHistoryType = 2 'create new stop
        strRemarks = "'CREATE NEW STOP'"
        strDate = Date.Today.ToShortDateString

        strSQL = "INSERT INTO tblStopHistory (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, HISTORY_TYPE_ID, " & "REMARKS) VALUES (" & strOCTAID & ", '" & txtSANZID.Text & "', '" & strDate & "', " & CurrentLoginUserID & ", " & intHistoryType & ", " & strRemarks & ")"

        db.Execute(strSQL)

        'CreateObject("WScript.Shell").Popup("Stop " & txtSANZID.Text & " successfully added.", 1, "Added")
        MsgBox("Stop " & txtSANZID.Text & " successfully added.", MsgBoxStyle.Information)
        rsLookup = Nothing

        frmUpdateStop.Close()
        frmUpdateStop.Show()
        frmUpdateStop.TblBusStopInformationBindingSource.MoveLast()

        Me.Close()

        Exit Sub

errHandler:
        MsgBox(Err.Description)
        Resume Next

    End Sub


End Class