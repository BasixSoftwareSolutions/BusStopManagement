﻿Public Class frmLineFileRouteCopy
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmLineFileRouteCopy
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmLineFileRouteCopy
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmLineFileRouteCopy()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region
    Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
        Me.Close()
    End Sub

    Private Sub cmdCopy_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCopy.Click

        If Trim(txtRouteNo.Text) = "" Then
            MsgBox("Please enter a Route Number!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If cboRouteDir.SelectedIndex = -1 Then
            MsgBox("Please select a route direction!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If cboRouteDes.SelectedIndex = -1 Then
            MsgBox("Please select a route designation!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        ' Check if route number and direction have been used...
        On Error GoTo errHandler
        If RouteExist(CShort(txtRouteNo.Text), CByte(cboRouteDir.SelectedValue)) Then
            MsgBox("Route: " & txtRouteNo.Text & " " & cboRouteDir.Text & " already exists! Please enter a different route number and/or direction.", MsgBoxStyle.Exclamation)

            txtRouteNo.SelectionStart = 0
            txtRouteNo.SelectionLength = Len(txtRouteNo.Text)
            txtRouteNo.Focus()
            Exit Sub
        End If

        ' now ready to copy route...
        CopyRoute()

        ' reload all possible routes on frmLineFile form...
        frmLineFile.ReloadRoutes()

        Dim routeNo, routeDir As Short

        routeNo = CShort(txtRouteNo.Text)
        routeDir = cboRouteDir.SelectedValue

        frmLineFile.LoadStops4Route(routeNo, routeDir)

        Me.Close()

        Exit Sub

errHandler:
        MsgBox(Err.Description, MsgBoxStyle.Exclamation)
        Exit Sub

    End Sub

    Private Sub CopyRoute()
        Dim strSQL As String
        Dim rsD As New ADODB.Recordset
        Dim rsS As New ADODB.Recordset
        Dim fld As ADODB.Field
        Dim rActive As Integer

        If optActive0.Checked Then
            rActive = 1
        Else
            rActive = 0
        End If

        strSQL = "INSERT INTO tblRoutes(RTE, RTE_DIR_ID, RTE_DESIGNATION_ID, " & "EFFECTIVE_DATE, ACTIVE) VALUES (" & txtRouteNo.Text & ", " & cboRouteDir.SelectedValue & ", " & cboRouteDes.SelectedValue & ", " & "'" & DateTimePicker1.Value.ToShortDateString & "', " & rActive & ")"

        db.Execute(strSQL)

        ' also copy route direction information in tblBusStopSequences table
        strSQL = "SELECT * FROM tblBusStopSequences" & " WHERE RTE = " & ROUTE_ID & " AND RTE_DIR_ID = " & DIR_ID

        rsS.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)

        rsD.Open("tblBusStopSequences", db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdTableDirect)

        Do While Not rsS.EOF
            rsD.AddNew()
            For Each fld In rsD.Fields
                If UCase(fld.Name) = "RTE" Then
                    fld.Value = CShort(txtRouteNo.Text)
                ElseIf UCase(fld.Name) = "RTE_DIR_ID" Then
                    fld.Value = cboRouteDir.SelectedValue
                Else
                    fld.Value = rsS.Fields(fld.Name).Value
                End If
            Next fld
            rsD.Update()
            rsS.MoveNext()
        Loop

        rsS.Close()
        rsD.Close()

        rsS = Nothing
        rsD = Nothing

        MsgBox("Route: " & txtRouteNo.Text & " (" & cboRouteDir.Text & ")" & " has been copied to the database.", MsgBoxStyle.Information)
    End Sub

    Private Function RouteExist(ByRef aRoute As Short, ByRef aDirID As Byte) As Boolean
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim bln As Boolean

        strSQL = "SELECT * FROM tblRoutes WHERE RTE = " & aRoute & " AND RTE_DIR_ID = " & aDirID
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        bln = False
        If Not rs.EOF Then
            bln = True
        End If

        rs.Close()
        rs = Nothing

        RouteExist = bln
    End Function

    Private Sub frmLineFileRouteCopy_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        LoadDirection()
        LoadDesignation()
        SetValues()
    End Sub

    Private Sub SetValues()
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim i As Short
        Dim dEffDate As Date

        Dim result As String

        strSQL = "SELECT * FROM tblRoutes WHERE RTE = " & ROUTE_ID & " AND RTE_DIR_ID = " & DIR_ID

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        txtRouteNo.Text = rs.Fields("RTE").Value

        For i = 0 To cboRouteDir.Items.Count - 1
            cboRouteDir.SelectedIndex = i
            If cboRouteDir.SelectedValue = rs.Fields("RTE_DIR_ID").Value Then
                cboRouteDir.SelectedIndex = i
                Exit For
            End If
        Next

        If Not IsDBNull(rs.Fields("RTE_DESIGNATION_ID").Value) Then

            For i = 0 To cboRouteDes.Items.Count - 1
                cboRouteDes.SelectedIndex = i
                If cboRouteDes.SelectedValue = rs.Fields("RTE_DESIGNATION_ID").Value Then
                    cboRouteDes.SelectedIndex = i
                    Exit For
                End If
            Next

            If i < cboRouteDes.Items.Count - 1 Then
                cboRouteDes.SelectedIndex = i
            End If
        End If

        If Not IsDBNull(rs.Fields("EFFECTIVE_DATE").Value) Then
            txtEffDate.Text = rs.Fields("EFFECTIVE_DATE").Value
            dEffDate = CDate(txtEffDate.Text)
            DateTimePicker1.Value = New Date(dEffDate.Year, dEffDate.Month, dEffDate.Day)
        Else
            DateTimePicker1.Value = Today
            txtEffDate.Text = Date.Now.ToShortDateString
        End If

        If rs.Fields("ACTIVE").Value = True Then
            optActive0.Checked = True
        Else
            optActive1.Checked = True
        End If

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub
    Private Sub LoadDirection()
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT * FROM ROUTE_DIR_CODE WHERE ACTIVE =1 ORDER BY ID"

        cboRouteDir.DisplayMember = "DESCRIPTION"
        cboRouteDir.ValueMember = "ID"
        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If

        cboRouteDir.DataSource = tb
        cboRouteDir.Enabled = True

        rs.Close()
        rs = Nothing
        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub
    Private Sub LoadDesignation()
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT * FROM ROUTE_DESIGNATION_CODE WHERE ACTIVE =1 ORDER BY ID"
        cboRouteDes.DisplayMember = "DESCRIPTION"
        cboRouteDes.ValueMember = "ID"
        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If

        cboRouteDes.DataSource = tb
        cboRouteDes.Enabled = True

        rs.Close()
        rs = Nothing
        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub txtRouteNo_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtRouteNo.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)

        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If

        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub
End Class