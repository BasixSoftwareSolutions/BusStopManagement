﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPathUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPathUpdate))
        Me.cmdQuit = New System.Windows.Forms.Button()
        Me.cmdBrowse = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.optBrowse4 = New System.Windows.Forms.RadioButton()
        Me.optBrowse3 = New System.Windows.Forms.RadioButton()
        Me.optBrowse2 = New System.Windows.Forms.RadioButton()
        Me.optBrowse1 = New System.Windows.Forms.RadioButton()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdQuit
        '
        Me.cmdQuit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdQuit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdQuit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdQuit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdQuit.Location = New System.Drawing.Point(152, 109)
        Me.cmdQuit.Name = "cmdQuit"
        Me.cmdQuit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdQuit.Size = New System.Drawing.Size(66, 25)
        Me.cmdQuit.TabIndex = 9
        Me.cmdQuit.Text = "&Close"
        Me.cmdQuit.UseVisualStyleBackColor = False
        '
        'cmdBrowse
        '
        Me.cmdBrowse.BackColor = System.Drawing.SystemColors.Control
        Me.cmdBrowse.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdBrowse.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBrowse.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdBrowse.Location = New System.Drawing.Point(152, 77)
        Me.cmdBrowse.Name = "cmdBrowse"
        Me.cmdBrowse.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBrowse.Size = New System.Drawing.Size(66, 25)
        Me.cmdBrowse.TabIndex = 8
        Me.cmdBrowse.Text = "&Browse"
        Me.cmdBrowse.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.optBrowse4)
        Me.Frame1.Controls.Add(Me.optBrowse3)
        Me.Frame1.Controls.Add(Me.optBrowse2)
        Me.Frame1.Controls.Add(Me.optBrowse1)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.Color.DimGray
        Me.Frame1.Location = New System.Drawing.Point(16, 13)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(129, 130)
        Me.Frame1.TabIndex = 7
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Browse For:"
        '
        'optBrowse4
        '
        Me.optBrowse4.BackColor = System.Drawing.Color.Ivory
        Me.optBrowse4.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBrowse4.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBrowse4.ForeColor = System.Drawing.Color.DimGray
        Me.optBrowse4.Location = New System.Drawing.Point(16, 96)
        Me.optBrowse4.Name = "optBrowse4"
        Me.optBrowse4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBrowse4.Size = New System.Drawing.Size(105, 21)
        Me.optBrowse4.TabIndex = 4
        Me.optBrowse4.Text = "Printers"
        Me.optBrowse4.UseVisualStyleBackColor = False
        '
        'optBrowse3
        '
        Me.optBrowse3.BackColor = System.Drawing.Color.Ivory
        Me.optBrowse3.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBrowse3.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBrowse3.ForeColor = System.Drawing.Color.DimGray
        Me.optBrowse3.Location = New System.Drawing.Point(16, 72)
        Me.optBrowse3.Name = "optBrowse3"
        Me.optBrowse3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBrowse3.Size = New System.Drawing.Size(105, 21)
        Me.optBrowse3.TabIndex = 3
        Me.optBrowse3.Text = "Computers"
        Me.optBrowse3.UseVisualStyleBackColor = False
        '
        'optBrowse2
        '
        Me.optBrowse2.BackColor = System.Drawing.Color.Ivory
        Me.optBrowse2.Checked = True
        Me.optBrowse2.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBrowse2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBrowse2.ForeColor = System.Drawing.Color.DimGray
        Me.optBrowse2.Location = New System.Drawing.Point(16, 48)
        Me.optBrowse2.Name = "optBrowse2"
        Me.optBrowse2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBrowse2.Size = New System.Drawing.Size(105, 21)
        Me.optBrowse2.TabIndex = 2
        Me.optBrowse2.TabStop = True
        Me.optBrowse2.Text = "Folders and Files"
        Me.optBrowse2.UseVisualStyleBackColor = False
        '
        'optBrowse1
        '
        Me.optBrowse1.BackColor = System.Drawing.Color.Ivory
        Me.optBrowse1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBrowse1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBrowse1.ForeColor = System.Drawing.Color.DimGray
        Me.optBrowse1.Location = New System.Drawing.Point(16, 24)
        Me.optBrowse1.Name = "optBrowse1"
        Me.optBrowse1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBrowse1.Size = New System.Drawing.Size(105, 21)
        Me.optBrowse1.TabIndex = 1
        Me.optBrowse1.Text = "Folders"
        Me.optBrowse1.UseVisualStyleBackColor = False
        '
        'frmPathUpdate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(232, 155)
        Me.Controls.Add(Me.cmdQuit)
        Me.Controls.Add(Me.cmdBrowse)
        Me.Controls.Add(Me.Frame1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmPathUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Path Update"
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents cmdQuit As Button
    Public WithEvents cmdBrowse As Button
    Public WithEvents Frame1 As GroupBox
    Public WithEvents optBrowse4 As RadioButton
    Public WithEvents optBrowse3 As RadioButton
    Public WithEvents optBrowse2 As RadioButton
    Public WithEvents optBrowse1 As RadioButton
End Class
