﻿Partial Class BusStopManagementDataSet2
    Partial Public Class tblStopImagesDataTable
    End Class
End Class

Namespace BusStopManagementDataSet2TableAdapters

    Partial Public Class tblStopImagesTableAdapter
    End Class
End Namespace
