﻿
Public Class frmMiscDocs

    Private rs As New ADODB.Recordset
    Dim lngHistoryID As Integer
    Dim strHistoryDocPath As String
    Dim intDocID As Integer

    Private Sub cmdAdd_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAdd.Click
        On Error GoTo ErrHand

        Dim strFiles As Object
        Dim fName As String
        Dim fd As OpenFileDialog = New OpenFileDialog()

        With fd
            .Title = "Change image path to..."
            .InitialDirectory = "K:\SANZ\"
            .FilterIndex = 2
            .RestoreDirectory = True
        End With

        If fd.ShowDialog() = DialogResult.OK Then
            strSQL = "INSERT INTO tblHistoryDoc (HISTORY_ID, DOC_PATH) VALUES(" & gEditHistoryID & ", '" & fd.FileName & "')"
            db.Execute(strSQL)

            Me.TblHistoryDocTableAdapter.Fill(Me.DsStopHistoryDocs.tblHistoryDoc)
            TblHistoryDocBindingSource.Filter = "HISTORY_ID = " & gEditHistoryID
            Me.dgvMiscDocs.Refresh()

            MsgBox("Record has been added.", vbInformation, "Deleted")
        End If

        Exit Sub

ErrHand:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
        Me.Close()
    End Sub

    Private Sub cmdRem_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRem.Click
        On Error GoTo errHandler

        Dim lngRow As Integer
        Dim lngID As Integer
        Dim strSQL As String
        Dim vRow As VariantType

        If basUtilities.CurrentUserRight < basUtilities.UserRight.SystemAdmin Then
            MsgBox(DENY_MESSAGE, MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If strHistoryDocPath.ToString = "" Then Exit Sub

        If MsgBox("Remove selected history document?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
            Exit Sub
        End If

        ' Delete based on currently selected record
        strSQL = "DELETE FROM tblHistoryDoc WHERE DOC_ID = " & intDocID
        db.Execute(strSQL)

        TblHistoryDocBindingSource.DataSource = TblHistoryDocTableAdapter.GetData()
        TblHistoryDocBindingSource.ResetBindings(False)
        Me.dgvMiscDocs.Refresh()

        MsgBox("Record has been deleted.", vbInformation, "Deleted")

        Exit Sub
errHandler:
        MsgBox(Err.Description)
    End Sub

    Private Sub cmdView_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdView.Click
        Dim objFS As Scripting.FileSystemObject

        objFS = CreateObject("Scripting.FileSystemObject")

        ' make sure a document is selected
        If strHistoryDocPath.ToString <> "" Then
            ' make sure file still exists
            If objFS.FileExists(strHistoryDocPath) Then
                ' open file based on its shell association
                ShellExecute(0, "Open", strHistoryDocPath, "", "", SW_SHOWNORMAL)
            Else
                MsgBox("File no longer exists")
            End If
        Else
            MsgBox("Please select a document to view.")
        End If

        objFS = Nothing
    End Sub

    Private Sub frmMiscDocs_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        On Error GoTo errHandler

        Me.TblHistoryDocTableAdapter.Fill(Me.DsStopHistoryDocs.tblHistoryDoc)
        TblHistoryDocBindingSource.Filter = "HISTORY_ID = " & gEditHistoryID
        Me.dgvMiscDocs.Refresh()

        Exit Sub

errHandler:
        MsgBox(Err.Description)
    End Sub

    Private Sub dgvMiscDocs_SelectionChanged(sender As Object, e As EventArgs) Handles dgvMiscDocs.SelectionChanged
        On Error GoTo errHandler

        Dim vRow As VariantType

        vRow = dgvMiscDocs.CurrentRow.Index

        If vRow < 0 Then Exit Sub
        intDocID = dgvMiscDocs.Item(0, vRow).Value
        lngHistoryID = dgvMiscDocs.Item(1, vRow).Value
        strHistoryDocPath = dgvMiscDocs.Item(2, vRow).Value.ToString

        Exit Sub

errHandler:
    End Sub
End Class