﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSpellChecker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSpellChecker))
        Me.cmdIgnore = New System.Windows.Forms.Button()
        Me.cmdChange = New System.Windows.Forms.Button()
        Me.txtBadWord = New System.Windows.Forms.TextBox()
        Me.lstSuggestions = New System.Windows.Forms.ListBox()
        Me.txtReplace = New System.Windows.Forms.TextBox()
        Me.Line2 = New System.Windows.Forms.Label()
        Me.Line1 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblCaption = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdIgnore
        '
        Me.cmdIgnore.BackColor = System.Drawing.SystemColors.Control
        Me.cmdIgnore.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdIgnore.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdIgnore.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdIgnore.Location = New System.Drawing.Point(102, 336)
        Me.cmdIgnore.Name = "cmdIgnore"
        Me.cmdIgnore.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdIgnore.Size = New System.Drawing.Size(72, 27)
        Me.cmdIgnore.TabIndex = 19
        Me.cmdIgnore.Text = "&Ignore"
        Me.cmdIgnore.UseVisualStyleBackColor = False
        '
        'cmdChange
        '
        Me.cmdChange.BackColor = System.Drawing.SystemColors.Control
        Me.cmdChange.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdChange.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdChange.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdChange.Location = New System.Drawing.Point(22, 336)
        Me.cmdChange.Name = "cmdChange"
        Me.cmdChange.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdChange.Size = New System.Drawing.Size(72, 27)
        Me.cmdChange.TabIndex = 18
        Me.cmdChange.Text = "C&hange"
        Me.cmdChange.UseVisualStyleBackColor = False
        '
        'txtBadWord
        '
        Me.txtBadWord.AcceptsReturn = True
        Me.txtBadWord.BackColor = System.Drawing.Color.White
        Me.txtBadWord.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBadWord.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBadWord.ForeColor = System.Drawing.Color.Black
        Me.txtBadWord.Location = New System.Drawing.Point(22, 76)
        Me.txtBadWord.MaxLength = 0
        Me.txtBadWord.Name = "txtBadWord"
        Me.txtBadWord.ReadOnly = True
        Me.txtBadWord.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBadWord.Size = New System.Drawing.Size(317, 20)
        Me.txtBadWord.TabIndex = 13
        Me.txtBadWord.TabStop = False
        '
        'lstSuggestions
        '
        Me.lstSuggestions.BackColor = System.Drawing.Color.White
        Me.lstSuggestions.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstSuggestions.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstSuggestions.ForeColor = System.Drawing.Color.Black
        Me.lstSuggestions.ItemHeight = 14
        Me.lstSuggestions.Location = New System.Drawing.Point(22, 127)
        Me.lstSuggestions.Name = "lstSuggestions"
        Me.lstSuggestions.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstSuggestions.Size = New System.Drawing.Size(317, 130)
        Me.lstSuggestions.TabIndex = 12
        '
        'txtReplace
        '
        Me.txtReplace.AcceptsReturn = True
        Me.txtReplace.BackColor = System.Drawing.Color.White
        Me.txtReplace.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtReplace.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtReplace.ForeColor = System.Drawing.Color.Black
        Me.txtReplace.Location = New System.Drawing.Point(22, 291)
        Me.txtReplace.MaxLength = 0
        Me.txtReplace.Name = "txtReplace"
        Me.txtReplace.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtReplace.Size = New System.Drawing.Size(317, 20)
        Me.txtReplace.TabIndex = 11
        Me.txtReplace.TabStop = False
        '
        'Line2
        '
        Me.Line2.BackColor = System.Drawing.Color.DimGray
        Me.Line2.Location = New System.Drawing.Point(21, 325)
        Me.Line2.Name = "Line2"
        Me.Line2.Size = New System.Drawing.Size(324, 1)
        Me.Line2.TabIndex = 20
        '
        'Line1
        '
        Me.Line1.BackColor = System.Drawing.Color.White
        Me.Line1.Location = New System.Drawing.Point(21, 40)
        Me.Line1.Name = "Line1"
        Me.Line1.Size = New System.Drawing.Size(324, 1)
        Me.Line1.TabIndex = 21
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(22, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(181, 16)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "NOT IN DICTIONARY:"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(22, 111)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(166, 16)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "SUGGESTIONS:"
        '
        'lblCaption
        '
        Me.lblCaption.BackColor = System.Drawing.Color.Transparent
        Me.lblCaption.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCaption.ForeColor = System.Drawing.Color.DimGray
        Me.lblCaption.Location = New System.Drawing.Point(12, 16)
        Me.lblCaption.Name = "lblCaption"
        Me.lblCaption.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblCaption.Size = New System.Drawing.Size(281, 27)
        Me.lblCaption.TabIndex = 15
        Me.lblCaption.Text = "  Suggestions"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(22, 275)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(181, 16)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "REPLACE WITH:"
        '
        'frmSpellChecker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(354, 374)
        Me.Controls.Add(Me.cmdIgnore)
        Me.Controls.Add(Me.cmdChange)
        Me.Controls.Add(Me.txtBadWord)
        Me.Controls.Add(Me.lstSuggestions)
        Me.Controls.Add(Me.txtReplace)
        Me.Controls.Add(Me.Line2)
        Me.Controls.Add(Me.Line1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblCaption)
        Me.Controls.Add(Me.Label3)
        Me.ForeColor = System.Drawing.Color.DimGray
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmSpellChecker"
        Me.Text = "Spell Checker"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents cmdIgnore As Button
    Public WithEvents cmdChange As Button
    Public WithEvents txtBadWord As TextBox
    Public WithEvents lstSuggestions As ListBox
    Public WithEvents txtReplace As TextBox
    Public WithEvents Line2 As Label
    Public WithEvents Line1 As Label
    Public WithEvents Label1 As Label
    Public WithEvents Label2 As Label
    Public WithEvents lblCaption As Label
    Public WithEvents Label3 As Label
End Class
