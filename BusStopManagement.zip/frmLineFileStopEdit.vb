﻿Public Class frmLineFileStopEdit
    Private Shared m_vb6FormDefInstance As frmLineFileStopEdit
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmLineFileStopEdit
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmLineFileStopEdit()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property

    Dim chkFlag As Boolean
    Dim forceTP As Boolean

    Private Sub frmLineFileStopEdit_Load(sender As Object, e As EventArgs) Handles Me.Load

        forceTP = False
        ' Route
        lblRouteInfo.Text = frmLineFile.cboRouteNo.Text & " - " & frmLineFile.cboRouteDir.Text & " - " & frmLineFile.txtRouteDes.Text
        ' new stop information
        SetStopInfo()
        ' Time Point
        LoadTPInfo()
        ' Sequence Number
        txtSeqNo.Text = CStr(SeqLowerBound)
        ' Hardware
        LoadHardware()
        ' Landmarks
        LoadLandmarks()
        ' Comments
        LoadComment()

    End Sub
    Private Sub SetStopInfo()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT bsi.SANZ_ID, sdc.DIR, " _
                & "(bsi.STREET_OF_TRAVEL " & "+ ' ' + stc1.TYPE) AS FULL_STREET, " _
                & "blc.LOC, (bsi.CROSS_STREET " & "+ ' ' + stc2.TYPE) AS FULL_XSTREET, " _
                & "bsi.CROSS_STREET_1 " _
                & "FROM (((tblBusStopInformation AS bsi " _
                & "LEFT JOIN ST_DIR_CODE AS sdc ON bsi.ST_DIR_ID = sdc.ID) " _
                & "LEFT JOIN ST_TYPE_CODE AS stc1 ON ((bsi.ST_TYPE_ID_1 = stc1.ID) Or " _
                & "(bsi.ST_TYPE_ID_1 Is NULL And stc1.ID = 0))) " _
                & "LEFT JOIN BS_LOC_CODE AS blc ON bsi.BS_LOC_ID = blc.ID) " _
                & "LEFT JOIN ST_TYPE_CODE AS stc2 ON ((bsi.ST_TYPE_ID_2 = stc2.ID) Or " _
                & "(bsi.ST_TYPE_ID_2 Is NULL And stc2.ID = 0)) " _
                & " WHERE bsi.OCTA_ID = " & OCTA_ID

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not rs.EOF Then
            txtOCTA_ID.Text = CStr(OCTA_ID)
            txtSANZ_ID.Text = rs.Fields("SANZ_ID").Value
            txtDIR.Text = rs.Fields("DIR").Value
            txtStreet.Text = Replace(rs.Fields("FULL_STREET").Value, "_", "")
            txtLOC.Text = rs.Fields("LOC").Value
            txtXStreet.Text = Replace(rs.Fields("FULL_XSTREET").Value, "_", "") & IIf(IsDBNull(rs.Fields("CROSS_STREET_1").Value), "", " " & rs.Fields("CROSS_STREET_1").Value)
        Else
            MsgBox("Unable to find stop information for stop: " & OCTA_ID)
        End If

        rs.Close()
        rs = Nothing

    End Sub
    Private Sub LoadTPInfo()
        Dim rs As New ADODB.Recordset
        Dim rtp As New ADODB.Recordset
        Dim cIndex, i As Short
        Dim tStr As String = ""

        strSQL = "SELECT TIMEPOINT, PLACE_ID, PLACE_DESCRIPTION, TRANSFERS FROM tblBusStopSequences " _
                   & "WHERE " & "RTE = " & ROUTE_ID & " " _
                   & "And " & "RTE_DIR_ID = " & DIR_ID & " " _
                   & "And SEQ = " & SeqLowerBound & " And " & "OCTA_ID = " & OCTA_ID

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not rs.EOF Then
            If rs.Fields("TIMEPOINT").Value Then
                cboTPID.Items.Clear()
                cboTPID.Enabled = True
                strSQL = "SELECT * FROM TIME_POINT_DESC ORDER BY PlaceName"
                rtp.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                If Not rtp.EOF Then
                    rtp.MoveFirst()
                    Do While Not rtp.EOF
                        If Not IsDBNull(rtp.Fields("PlaceName").Value) Then
                            cboTPID.Items.Add(UCase(rtp.Fields("PlaceName").Value))
                        End If
                        rtp.MoveNext()
                    Loop
                End If
                rtp.Close()
                If Not IsDBNull(rs.Fields("PLACE_ID").Value) Then
                    tStr = rs.Fields("PLACE_ID").Value
                End If

                For i = 0 To cboTPID.Items.Count - 1
                    cboTPID.SelectedIndex = i
                    If UCase(tStr) = UCase(cboTPID.Text) Then
                        cIndex = i
                    End If
                Next i

                If cIndex >= 0 Then
                    cboTPID.SelectedIndex = cIndex
                    strSQL = "SELECT Description FROM TIME_POINT_DESC WHERE PlaceName = '" & cboTPID.Text & "'"
                    rtp.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)
                    If Not rtp.EOF Then
                        rtp.MoveFirst()
                        If Not IsDBNull(rtp.Fields("Description").Value) Then
                            tStr = rtp.Fields("Description").Value
                            txtTPDesc.Text = tStr
                        End If
                    End If
                    rtp.Close()
                Else
                    txtTPDesc.Text = ""
                    cboTPID.SelectedIndex = -1
                End If
                optTimePoint0.Checked = True
            Else
                optTimePoint1.Checked = True
                txtTPDesc.Text = ""
                cboTPID.Text = ""
            End If
            txtTransferInfo.Text = IIf(IsDBNull(rs.Fields("TRANSFERS").Value), "", rs.Fields("TRANSFERS").Value)
        End If

        rs.Close()
        rs = Nothing

    End Sub
    Private Sub LoadHardware()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        cboHardware.Items.Clear()
        cboHardware.Items.Add(CStr(0))
        cboHardware.Items.Add(CStr(9))

        ' Set current value...
        strSQL = "SELECT HARDWARE FROM tblBusStopSequences WHERE " _
                & "RTE = " & ROUTE_ID & " AND " _
                & "RTE_DIR_ID = " & DIR_ID & " AND " _
                & "SEQ = " & SeqLowerBound & " And " & "OCTA_ID = " & OCTA_ID

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not rs.EOF Then
            If rs.Fields(0).Value = 0 Then
                cboHardware.SelectedIndex = 0
            ElseIf rs.Fields(0).Value = 9 Then
                cboHardware.SelectedIndex = 1
            End If
        End If

        rs.Close()
        rs = Nothing
    End Sub
    Private Sub LoadLandmarks()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT lmc.DESCRIPTION FROM tblBusStopLandmarks AS bsl " _
                & "LEFT JOIN BS_LANDMARK_CODE AS lmc ON bsl.LANDMARK_ID = lmc.ID " _
                & "WHERE bsl.OCTA_ID = " & OCTA_ID & " And " _
                & "bsl.RTE = " & ROUTE_ID & " And " _
                & "bsl.DIRECTION = '" & frmLineFile.cboRouteDir.Text & "' ORDER BY lmc.DESCRIPTION"

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount < 1 Then
            lstLandmarks.Items.Clear()
        End If

        Do While Not rs.EOF
            lstLandmarks.Items.Add(rs.Fields("DESCRIPTION").Value)
            rs.MoveNext()
        Loop

        rs.Close()
        rs = Nothing

    End Sub
    Private Sub LoadComment()
        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT * FROM ROUTE_COMMENT_CODE WHERE ACTIVE =1 ORDER BY ID"
        cboComment.DisplayMember = "DESCRIPTION"
        cboComment.ValueMember = "ID"

        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        tb.Rows.Add("", -1)

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rs.EOF And rs.BOF) > 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If

        cboComment.DataSource = tb
        cboComment.Enabled = True

        ' Set current value...

        rs.Close()
        strSQL = "SELECT COMMENTS FROM tblBusStopSequences WHERE " _
                    & "RTE = " & ROUTE_ID & " AND " _
                    & "RTE_DIR_ID = " & DIR_ID & " " _
                    & "AND SEQ = " & SeqLowerBound & " And " & "OCTA_ID = " & OCTA_ID

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        Dim i As Short
        If Not (rs.EOF And rs.BOF) Then
            If Not IsDBNull(rs.Fields("COMMENTS").Value) Then

                For i = 0 To cboComment.Items.Count - 1
                    cboComment.SelectedIndex = i
                    If CInt(rs.Fields("COMMENTS").Value) = cboComment.SelectedValue Then
                        Exit For
                    Else
                        cboComment.SelectedIndex = 0
                    End If
                Next

                If i < cboComment.Items.Count Then
                    cboComment.SelectedIndex = i
                End If
            End If
        End If

        rs.Close()
        rs = Nothing
    End Sub
    Private Sub txtSeqNo_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtSeqNo.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 8 Then KeyAscii = 0
        End If

        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtTPDesc_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtTPDesc.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtTPID_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtTPID.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtTransferInfo_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtTransferInfo.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub LoadTimePt()

        Dim rs As New ADODB.Recordset
        Dim strSQL As String
        Dim i As Short
        If forceTP = True Then
            strSQL = "SELECT * FROM TIME_POINT_DESC"

            rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

            If Not rs.EOF Then
                txtTPDesc.Text = ""
                cboTPID.Items.Clear()
                cboTPID.Enabled = True
                rs.MoveFirst()

                For i = 0 To rs.RecordCount - 1
                    If Not IsDBNull(rs.Fields("PlaceName").Value) Then
                        cboTPID.Items.Add(rs.Fields("PlaceName").Value)
                    End If
                    rs.MoveNext()
                Next i
            End If
            rs.Close()
        Else
            forceTP = True
            Exit Sub
        End If
    End Sub

    Private Sub optTimePoint0_CheckedChanged(sender As Object, e As EventArgs) Handles optTimePoint0.CheckedChanged

        If optTimePoint0.Checked Then
            cboTPID.Enabled = True
            LoadTimePt()
        Else
            forceTP = True
            txtTPDesc.Text = ""
            cboTPID.Items.Clear()
            cboTPID.Enabled = False
        End If

    End Sub

    Private Sub cmdAddLandmark_Click(sender As Object, e As EventArgs) Handles cmdAddLandmark.Click
        frmBSLandmarks.ShowDialog()
        LoadLandmarks()
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        ' Check for all required information
        If optTimePoint0.Checked Then

            If cboTPID.SelectedIndex = -1 Then
                MsgBox("Please select a value for Time Point ID.")
                cboTPID.Focus()
                Exit Sub
            End If


            If Trim(txtTPDesc.Text) = "" Then
                MsgBox("Please enter a value for Time Point Description.")
                txtTPDesc.Focus()
                Exit Sub
            End If
        End If

        If Trim(txtSeqNo.Text) = "" Then
            MsgBox("Please enter a sequence no from the list.")
            Exit Sub
        Else
            ' Check if sequence no has been used for the same route...
            If SeqNoInUse() Then
                MsgBox("Sequence Number: " & txtSeqNo.Text & " has been used. Please enter a different one.", MsgBoxStyle.Exclamation)
                txtSeqNo.SelectionStart = 0
                txtSeqNo.SelectionLength = Len(txtSeqNo.Text)
                txtSeqNo.Focus()
                Exit Sub
            End If
        End If

        If cboHardware.SelectedIndex = -1 Then
            MsgBox("Please select a hardware type from the list.")
            Exit Sub
        End If

        ' now ready to update stop information...
        UpdateStopInfoInRoute()

        If chkFlag Then
            Me.Close()
        End If
    End Sub
    Private Function SeqNoInUse() As Boolean

        On Error GoTo errHandler
        If CShort(txtSeqNo.Text) = SeqLowerBound Then
            SeqNoInUse = False
            Exit Function
        End If

        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim bln As Boolean

        strSQL = "SELECT * FROM tblBusStopSequences WHERE " _
                & "RTE = " & ROUTE_ID & " And " _
                & "RTE_DIR_ID = " & DIR_ID & " And SEQ = " & txtSeqNo.Text

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        bln = False
        If Not rs.EOF Then
            bln = True
        End If

        rs.Close()
        rs = Nothing

        SeqNoInUse = bln

        Exit Function

errHandler:
        MsgBox("Invalid Value")
        Exit Function

    End Function
    Private Sub UpdateStopInfoInRoute()
        Dim strSQL As String
        Dim bFlag As Byte

        If optTimePoint0.Checked = True Then
            bFlag = 1
        Else
            bFlag = 0
        End If

        If optTimePoint0.Checked Then
            If cboComment.SelectedIndex <> -1 Then
                strSQL = "UPDATE tblBusStopSequences SET " _
                        & "TIMEPOINT = " & bFlag & ", " _
                        & "PLACE_ID = " & cV2Q_String((cboTPID.Text)) & ", " _
                        & "PLACE_DESCRIPTION = " & cV2Q_String((txtTPDesc.Text)) & ", " _
                        & "SEQ = " & txtSeqNo.Text & ", HARDWARE = " & cboHardware.Text & ", " _
                        & "TRANSFERS = " & cV2Q_String((txtTransferInfo.Text)) & ", " _
                        & "COMMENTS = " & cboComment.SelectedValue & " " _
                        & "WHERE RTE = " & ROUTE_ID & " " _
                        & "And RTE_DIR_ID = " & DIR_ID & " " _
                        & "And SEQ = " & SeqLowerBound & " " _
                        & "And OCTA_ID = " & txtOCTA_ID.Text
            Else
                strSQL = "UPDATE tblBusStopSequences SET " _
                        & "TIMEPOINT = " & bFlag & ", " _
                        & "PLACE_ID = " & cV2Q_String((cboTPID.Text)) & ", " _
                        & "PLACE_DESCRIPTION = " & cV2Q_String((txtTPDesc.Text)) & ", " _
                        & "SEQ = " & txtSeqNo.Text & ", " _
                        & "HARDWARE = " & cboHardware.Text & ", " _
                        & "TRANSFERS = " & cV2Q_String((txtTransferInfo.Text)) & " " _
                        & "WHERE RTE = " & ROUTE_ID & " " _
                        & "And RTE_DIR_ID = " & DIR_ID & " " _
                        & "And SEQ = " & SeqLowerBound & " And OCTA_ID = " & txtOCTA_ID.Text
            End If
        Else
            If cboComment.SelectedIndex <> -1 Then
                strSQL = "UPDATE tblBusStopSequences SET " _
                        & "TIMEPOINT = " & bFlag & ", " _
                        & "PLACE_ID = '', " _
                        & "PLACE_DESCRIPTION = '', " _
                        & "SEQ = " & txtSeqNo.Text & ", " _
                        & "HARDWARE = " & cboHardware.Text & ", " _
                        & "TRANSFERS = " & cV2Q_String((txtTransferInfo.Text)) & ", " _
                        & "COMMENTS = " & cboComment.SelectedValue & " " _
                        & "WHERE RTE = " & ROUTE_ID & " " _
                        & "And RTE_DIR_ID = " & DIR_ID & " " _
                        & "And SEQ = " & SeqLowerBound & " And OCTA_ID = " & txtOCTA_ID.Text
            Else
                strSQL = "UPDATE tblBusStopSequences SET " _
                        & "TIMEPOINT = " & bFlag & ", " _
                        & "PLACE_ID = '', " _
                        & "PLACE_DESCRIPTION = '', " _
                        & "SEQ = " & txtSeqNo.Text & ", " _
                        & "HARDWARE = " & cboHardware.Text & ", " _
                        & "TRANSFERS = " & cV2Q_String((txtTransferInfo.Text)) & " " _
                        & "WHERE RTE = " & ROUTE_ID & " " _
                        & "AND RTE_DIR_ID = " & DIR_ID & " " _
                        & "AND SEQ = " & SeqLowerBound & " AND OCTA_ID = " & txtOCTA_ID.Text
            End If
        End If

        On Error GoTo errHandler
        db.Execute(strSQL)

        chkFlag = True

        Call frmLineFile.LoadStops4Route(CShort(ROUTE_ID), DIR_ID)

        Exit Sub

errHandler:
        chkFlag = False
        Exit Sub

    End Sub

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        Me.Close()

    End Sub

    Private Sub cboTPID_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cboTPID.SelectionChangeCommitted

        If cboTPID.SelectedIndex < 0 Then
            txtTPDesc.Text = ""
            Exit Sub
        End If

        Dim rs As New ADODB.Recordset
        Dim strSQL As String
        strSQL = "SELECT * FROM TIME_POINT_DESC"
        Dim i As Short

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

        If Not rs.EOF Then

            rs.MoveFirst()

            For i = 0 To rs.RecordCount - 1
                If rs.Fields("PlaceName").Value = cboTPID.SelectedItem Then
                    txtTPDesc.Text = rs.Fields("Description").Value
                End If
                rs.MoveNext()
            Next i
        End If
        rs.Close()

    End Sub
End Class