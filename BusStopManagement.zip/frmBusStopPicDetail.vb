﻿Imports ZPBlib
Imports System.Data.SqlClient
Public Class frmBusStopPicDetail

#Region "Image initialization"

    Private Sub NewImage()

        If Me.txtPicPath.Text <> "" Then
            Try
                ZoomPictureBox1.Image() = New Bitmap(Trim(Me.txtPicPath.Text.ToString))
            Catch
                MessageBox.Show("Error reading image from file " & Trim(Me.txtPicPath.Text.ToString))
            End Try
        End If

    End Sub

#End Region

    Private Sub cmdGoogleMaps_Click(sender As Object, e As EventArgs) Handles cmdGoogleMaps.Click

        Dim rs As New ADODB.Recordset
        Dim strSQL As String

        Try
            strSQL = "SELECT MapURL FROM qryBusStopLatLon WHERE OCTA_ID = " & CInt(frmUpdateStop.txtPictureOCTA_ID.Text)
            rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

            If Not rs.EOF Then
                ShellExecute(Me.Handle.ToInt32, "open", rs.Fields("MapURL").Value, vbNullString, "", 0)
            Else
                MsgBox("Bus Stop location data could not be found", MsgBoxStyle.Information, "Lat/Lon Data missing")
            End If

            rs.Close()
            rs = Nothing

        Catch ex As Exception
            MsgBox("Bus Stop location data could not be found." & vbCrLf & ex.Message, vbInformation, "Lat/Lon is missing")
        End Try

    End Sub

    Private Sub frmBusStopPicDetail_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim iStopID As Integer

        Me.TblStopImagesTableAdapter.Fill(Me.BusStopManagementDataSet2.tblStopImages)

        Try
            iStopID = CInt(frmUpdateStop.txtPictureOCTA_ID.Text)
            'iRecordID = frmUpdateStop.txtPicNo.Text
            DetailStopImagesBindingSource.Filter = "OCTA_ID = " & iStopID & ""
            DetailStopImagesBindingSource.Sort = "ID"
            'Me.DetailStopImagesBindingSource.Position = Me.DetailStopImagesBindingSource.Find("ID", iRecordID)
            ZoomPictureBox1.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or
            AnchorStyles.Right Or AnchorStyles.Top
        Catch
            MessageBox.Show("Error " & Err.Description)
        End Try

    End Sub

    Private Sub TblStopImagesBindingSource_CurrentChanged(sender As Object, e As EventArgs) Handles DetailStopImagesBindingSource.CurrentChanged

        If Trim(Me.txtPicPath.Text) <> "" Then
            Try
                ZoomPictureBox1.Image() = New Bitmap(Trim(Me.txtPicPath.Text))
            Catch
                MessageBox.Show("Error reading image from file " & Trim(Me.txtPicPath.Text))
            End Try
        End If

    End Sub

End Class