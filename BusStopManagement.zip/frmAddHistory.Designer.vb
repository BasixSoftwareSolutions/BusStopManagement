﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddHistory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAddHistory))
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.cboHistType = New System.Windows.Forms.ComboBox()
        Me.cboEmployee = New System.Windows.Forms.ComboBox()
        Me.txtSANZID = New System.Windows.Forms.TextBox()
        Me._label1_3 = New System.Windows.Forms.Label()
        Me._label1_2 = New System.Windows.Forms.Label()
        Me._label1_1 = New System.Windows.Forms.Label()
        Me._label1_4 = New System.Windows.Forms.Label()
        Me._label1_0 = New System.Windows.Forms.Label()
        Me.dtHistoryDate = New System.Windows.Forms.DateTimePicker()
        Me.cmdSpellCheck = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(79, 221)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(65, 25)
        Me.cmdCancel.TabIndex = 28
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdOK
        '
        Me.cmdOK.BackColor = System.Drawing.SystemColors.Control
        Me.cmdOK.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdOK.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdOK.Location = New System.Drawing.Point(15, 221)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdOK.Size = New System.Drawing.Size(49, 25)
        Me.cmdOK.TabIndex = 27
        Me.cmdOK.Text = "&OK"
        Me.cmdOK.UseVisualStyleBackColor = False
        '
        'txtRemarks
        '
        Me.txtRemarks.AcceptsReturn = True
        Me.txtRemarks.BackColor = System.Drawing.SystemColors.Window
        Me.txtRemarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRemarks.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRemarks.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRemarks.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRemarks.Location = New System.Drawing.Point(14, 143)
        Me.txtRemarks.MaxLength = 0
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRemarks.Size = New System.Drawing.Size(338, 65)
        Me.txtRemarks.TabIndex = 21
        '
        'cboHistType
        '
        Me.cboHistType.BackColor = System.Drawing.SystemColors.Window
        Me.cboHistType.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboHistType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboHistType.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboHistType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboHistType.Location = New System.Drawing.Point(79, 84)
        Me.cboHistType.Name = "cboHistType"
        Me.cboHistType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboHistType.Size = New System.Drawing.Size(273, 22)
        Me.cboHistType.TabIndex = 20
        '
        'cboEmployee
        '
        Me.cboEmployee.BackColor = System.Drawing.SystemColors.Window
        Me.cboEmployee.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboEmployee.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEmployee.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboEmployee.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboEmployee.Location = New System.Drawing.Point(79, 47)
        Me.cboEmployee.Name = "cboEmployee"
        Me.cboEmployee.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboEmployee.Size = New System.Drawing.Size(273, 22)
        Me.cboEmployee.TabIndex = 19
        '
        'txtSANZID
        '
        Me.txtSANZID.AcceptsReturn = True
        Me.txtSANZID.BackColor = System.Drawing.SystemColors.Control
        Me.txtSANZID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSANZID.Enabled = False
        Me.txtSANZID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSANZID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSANZID.Location = New System.Drawing.Point(79, 12)
        Me.txtSANZID.MaxLength = 0
        Me.txtSANZID.Name = "txtSANZID"
        Me.txtSANZID.ReadOnly = True
        Me.txtSANZID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSANZID.Size = New System.Drawing.Size(89, 20)
        Me.txtSANZID.TabIndex = 16
        '
        '_label1_3
        '
        Me._label1_3.AutoSize = True
        Me._label1_3.BackColor = System.Drawing.Color.Transparent
        Me._label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._label1_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._label1_3.ForeColor = System.Drawing.Color.DimGray
        Me._label1_3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me._label1_3.Location = New System.Drawing.Point(39, 87)
        Me._label1_3.Name = "_label1_3"
        Me._label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._label1_3.Size = New System.Drawing.Size(36, 14)
        Me._label1_3.TabIndex = 26
        Me._label1_3.Text = "TYPE:"
        Me._label1_3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_label1_2
        '
        Me._label1_2.AutoSize = True
        Me._label1_2.BackColor = System.Drawing.Color.Transparent
        Me._label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._label1_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._label1_2.ForeColor = System.Drawing.Color.DimGray
        Me._label1_2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me._label1_2.Location = New System.Drawing.Point(11, 50)
        Me._label1_2.Name = "_label1_2"
        Me._label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._label1_2.Size = New System.Drawing.Size(64, 14)
        Me._label1_2.TabIndex = 25
        Me._label1_2.Text = "EMPLOYEE:"
        Me._label1_2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_label1_1
        '
        Me._label1_1.AutoSize = True
        Me._label1_1.BackColor = System.Drawing.Color.Transparent
        Me._label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._label1_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._label1_1.ForeColor = System.Drawing.Color.DimGray
        Me._label1_1.Location = New System.Drawing.Point(14, 127)
        Me._label1_1.Name = "_label1_1"
        Me._label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._label1_1.Size = New System.Drawing.Size(52, 14)
        Me._label1_1.TabIndex = 24
        Me._label1_1.Text = "Remarks:"
        '
        '_label1_4
        '
        Me._label1_4.AutoSize = True
        Me._label1_4.BackColor = System.Drawing.Color.Transparent
        Me._label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._label1_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._label1_4.ForeColor = System.Drawing.Color.DimGray
        Me._label1_4.Location = New System.Drawing.Point(174, 14)
        Me._label1_4.Name = "_label1_4"
        Me._label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._label1_4.Size = New System.Drawing.Size(84, 14)
        Me._label1_4.TabIndex = 22
        Me._label1_4.Text = "HISTORY DATE:"
        Me._label1_4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_label1_0
        '
        Me._label1_0.AutoSize = True
        Me._label1_0.BackColor = System.Drawing.Color.Transparent
        Me._label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._label1_0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._label1_0.ForeColor = System.Drawing.Color.DimGray
        Me._label1_0.Location = New System.Drawing.Point(24, 14)
        Me._label1_0.Name = "_label1_0"
        Me._label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._label1_0.Size = New System.Drawing.Size(51, 14)
        Me._label1_0.TabIndex = 17
        Me._label1_0.Text = "SANZ ID:"
        Me._label1_0.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'dtHistoryDate
        '
        Me.dtHistoryDate.Location = New System.Drawing.Point(265, 12)
        Me.dtHistoryDate.Name = "dtHistoryDate"
        Me.dtHistoryDate.Size = New System.Drawing.Size(87, 20)
        Me.dtHistoryDate.TabIndex = 31
        '
        'cmdSpellCheck
        '
        Me.cmdSpellCheck.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSpellCheck.Image = CType(resources.GetObject("cmdSpellCheck.Image"), System.Drawing.Image)
        Me.cmdSpellCheck.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdSpellCheck.Location = New System.Drawing.Point(264, 113)
        Me.cmdSpellCheck.Name = "cmdSpellCheck"
        Me.cmdSpellCheck.Size = New System.Drawing.Size(88, 24)
        Me.cmdSpellCheck.TabIndex = 32
        Me.cmdSpellCheck.Text = "Spell Check"
        Me.cmdSpellCheck.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdSpellCheck.UseVisualStyleBackColor = True
        '
        'frmAddHistory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(366, 254)
        Me.Controls.Add(Me.cmdSpellCheck)
        Me.Controls.Add(Me.dtHistoryDate)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.txtRemarks)
        Me.Controls.Add(Me.cboHistType)
        Me.Controls.Add(Me.cboEmployee)
        Me.Controls.Add(Me.txtSANZID)
        Me.Controls.Add(Me._label1_3)
        Me.Controls.Add(Me._label1_2)
        Me.Controls.Add(Me._label1_1)
        Me.Controls.Add(Me._label1_4)
        Me.Controls.Add(Me._label1_0)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmAddHistory"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add History"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents cmdCancel As Button
    Public WithEvents cmdOK As Button
    Public WithEvents txtRemarks As TextBox
    Public WithEvents cboHistType As ComboBox
    Public WithEvents cboEmployee As ComboBox
    Public WithEvents txtSANZID As TextBox
    Public WithEvents _label1_3 As Label
    Public WithEvents _label1_2 As Label
    Public WithEvents _label1_1 As Label
    Public WithEvents _label1_4 As Label
    Public WithEvents _label1_0 As Label
    Friend WithEvents dtHistoryDate As DateTimePicker
    Friend WithEvents cmdSpellCheck As Button
End Class
