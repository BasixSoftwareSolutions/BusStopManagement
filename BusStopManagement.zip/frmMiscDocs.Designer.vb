﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMiscDocs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMiscDocs))
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdRem = New System.Windows.Forms.Button()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.cmdView = New System.Windows.Forms.Button()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.dgvMiscDocs = New System.Windows.Forms.DataGridView()
        Me.DOCIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HISTORYIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DOCPATHDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DOCNAMEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblHistoryDocBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsStopHistoryDocs = New BusStopManagement.dsStopHistoryDocs()
        Me.TblHistoryDocTableAdapter = New BusStopManagement.dsStopHistoryDocsTableAdapters.tblHistoryDocTableAdapter()
        CType(Me.dgvMiscDocs, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblHistoryDocBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsStopHistoryDocs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(342, 179)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(89, 25)
        Me.cmdClose.TabIndex = 10
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdRem
        '
        Me.cmdRem.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRem.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRem.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRem.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRem.Location = New System.Drawing.Point(342, 83)
        Me.cmdRem.Name = "cmdRem"
        Me.cmdRem.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRem.Size = New System.Drawing.Size(89, 25)
        Me.cmdRem.TabIndex = 9
        Me.cmdRem.Text = "&Remove"
        Me.cmdRem.UseVisualStyleBackColor = False
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAdd.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdAdd.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdAdd.Location = New System.Drawing.Point(342, 51)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdAdd.Size = New System.Drawing.Size(89, 25)
        Me.cmdAdd.TabIndex = 8
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'cmdView
        '
        Me.cmdView.BackColor = System.Drawing.SystemColors.Control
        Me.cmdView.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdView.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdView.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdView.Location = New System.Drawing.Point(342, 19)
        Me.cmdView.Name = "cmdView"
        Me.cmdView.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdView.Size = New System.Drawing.Size(89, 25)
        Me.cmdView.TabIndex = 7
        Me.cmdView.Text = "&View"
        Me.cmdView.UseVisualStyleBackColor = False
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(334, 11)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(105, 105)
        Me.Shape1.TabIndex = 11
        '
        'dgvMiscDocs
        '
        Me.dgvMiscDocs.AllowUserToAddRows = False
        Me.dgvMiscDocs.AllowUserToDeleteRows = False
        Me.dgvMiscDocs.AutoGenerateColumns = False
        Me.dgvMiscDocs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvMiscDocs.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DOCIDDataGridViewTextBoxColumn, Me.HISTORYIDDataGridViewTextBoxColumn, Me.DOCPATHDataGridViewTextBoxColumn, Me.DOCNAMEDataGridViewTextBoxColumn})
        Me.dgvMiscDocs.DataSource = Me.TblHistoryDocBindingSource
        Me.dgvMiscDocs.Location = New System.Drawing.Point(12, 12)
        Me.dgvMiscDocs.Name = "dgvMiscDocs"
        Me.dgvMiscDocs.ReadOnly = True
        Me.dgvMiscDocs.Size = New System.Drawing.Size(313, 192)
        Me.dgvMiscDocs.TabIndex = 13
        '
        'DOCIDDataGridViewTextBoxColumn
        '
        Me.DOCIDDataGridViewTextBoxColumn.DataPropertyName = "DOC_ID"
        Me.DOCIDDataGridViewTextBoxColumn.HeaderText = "DOC_ID"
        Me.DOCIDDataGridViewTextBoxColumn.MinimumWidth = 2
        Me.DOCIDDataGridViewTextBoxColumn.Name = "DOCIDDataGridViewTextBoxColumn"
        Me.DOCIDDataGridViewTextBoxColumn.ReadOnly = True
        Me.DOCIDDataGridViewTextBoxColumn.Visible = False
        Me.DOCIDDataGridViewTextBoxColumn.Width = 2
        '
        'HISTORYIDDataGridViewTextBoxColumn
        '
        Me.HISTORYIDDataGridViewTextBoxColumn.DataPropertyName = "HISTORY_ID"
        Me.HISTORYIDDataGridViewTextBoxColumn.HeaderText = "HISTORY_ID"
        Me.HISTORYIDDataGridViewTextBoxColumn.MinimumWidth = 2
        Me.HISTORYIDDataGridViewTextBoxColumn.Name = "HISTORYIDDataGridViewTextBoxColumn"
        Me.HISTORYIDDataGridViewTextBoxColumn.ReadOnly = True
        Me.HISTORYIDDataGridViewTextBoxColumn.Visible = False
        Me.HISTORYIDDataGridViewTextBoxColumn.Width = 2
        '
        'DOCPATHDataGridViewTextBoxColumn
        '
        Me.DOCPATHDataGridViewTextBoxColumn.DataPropertyName = "DOC_PATH"
        Me.DOCPATHDataGridViewTextBoxColumn.HeaderText = "DOC_PATH"
        Me.DOCPATHDataGridViewTextBoxColumn.MinimumWidth = 2
        Me.DOCPATHDataGridViewTextBoxColumn.Name = "DOCPATHDataGridViewTextBoxColumn"
        Me.DOCPATHDataGridViewTextBoxColumn.ReadOnly = True
        Me.DOCPATHDataGridViewTextBoxColumn.Visible = False
        Me.DOCPATHDataGridViewTextBoxColumn.Width = 2
        '
        'DOCNAMEDataGridViewTextBoxColumn
        '
        Me.DOCNAMEDataGridViewTextBoxColumn.DataPropertyName = "DOC_NAME"
        Me.DOCNAMEDataGridViewTextBoxColumn.HeaderText = "DOCUMENT NAME"
        Me.DOCNAMEDataGridViewTextBoxColumn.Name = "DOCNAMEDataGridViewTextBoxColumn"
        Me.DOCNAMEDataGridViewTextBoxColumn.ReadOnly = True
        Me.DOCNAMEDataGridViewTextBoxColumn.Width = 250
        '
        'TblHistoryDocBindingSource
        '
        Me.TblHistoryDocBindingSource.DataMember = "tblHistoryDoc"
        Me.TblHistoryDocBindingSource.DataSource = Me.DsStopHistoryDocs
        '
        'DsStopHistoryDocs
        '
        Me.DsStopHistoryDocs.DataSetName = "dsStopHistoryDocs"
        Me.DsStopHistoryDocs.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblHistoryDocTableAdapter
        '
        Me.TblHistoryDocTableAdapter.ClearBeforeFill = True
        '
        'frmMiscDocs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(452, 220)
        Me.Controls.Add(Me.dgvMiscDocs)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.cmdRem)
        Me.Controls.Add(Me.cmdAdd)
        Me.Controls.Add(Me.cmdView)
        Me.Controls.Add(Me.Shape1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMiscDocs"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Miscellaneous Documents"
        Me.TopMost = True
        CType(Me.dgvMiscDocs, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblHistoryDocBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsStopHistoryDocs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents cmdClose As Button
    Public WithEvents cmdRem As Button
    Public WithEvents cmdAdd As Button
    Public WithEvents cmdView As Button
    Public WithEvents Shape1 As Label
    Friend WithEvents DsStopHistoryDocs As dsStopHistoryDocs
    Friend WithEvents TblHistoryDocBindingSource As BindingSource
    Friend WithEvents TblHistoryDocTableAdapter As dsStopHistoryDocsTableAdapters.tblHistoryDocTableAdapter
    Friend WithEvents dgvMiscDocs As DataGridView
    Friend WithEvents DOCIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HISTORYIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DOCPATHDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DOCNAMEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
