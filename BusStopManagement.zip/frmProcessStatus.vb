﻿
Public Class frmProcessStatus
    Public pbStatusMin As Long
    Public pbStatusMax As Long
    Public pbStatusValue As Long
    Public pbStatusWidthMax As Long

    Public Sub IncrementProgressBar(ByVal iValue As Integer)

        pbActivity.Value = pbActivity.Value + iValue

    End Sub
End Class