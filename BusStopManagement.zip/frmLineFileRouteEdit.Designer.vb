﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLineFileRouteEdit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLineFileRouteEdit))
        Me.txtRouteNo = New System.Windows.Forms.TextBox()
        Me.cboRouteDes = New System.Windows.Forms.ComboBox()
        Me.cboRouteDir = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.txtEffDate = New System.Windows.Forms.TextBox()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdCreate = New System.Windows.Forms.Button()
        Me.optActive1 = New System.Windows.Forms.RadioButton()
        Me.optActive0 = New System.Windows.Forms.RadioButton()
        Me.Shape2 = New System.Windows.Forms.Label()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtRouteNo
        '
        Me.txtRouteNo.Location = New System.Drawing.Point(122, 21)
        Me.txtRouteNo.Name = "txtRouteNo"
        Me.txtRouteNo.Size = New System.Drawing.Size(56, 20)
        Me.txtRouteNo.TabIndex = 50
        '
        'cboRouteDes
        '
        Me.cboRouteDes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRouteDes.FormattingEnabled = True
        Me.cboRouteDes.Location = New System.Drawing.Point(122, 85)
        Me.cboRouteDes.Name = "cboRouteDes"
        Me.cboRouteDes.Size = New System.Drawing.Size(203, 21)
        Me.cboRouteDes.TabIndex = 49
        '
        'cboRouteDir
        '
        Me.cboRouteDir.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRouteDir.FormattingEnabled = True
        Me.cboRouteDir.Location = New System.Drawing.Point(121, 53)
        Me.cboRouteDir.Name = "cboRouteDir"
        Me.cboRouteDir.Size = New System.Drawing.Size(204, 21)
        Me.cboRouteDir.TabIndex = 48
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DimGray
        Me.Label5.Location = New System.Drawing.Point(77, 150)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 14)
        Me.Label5.TabIndex = 47
        Me.Label5.Text = "Active:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(38, 122)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 14)
        Me.Label4.TabIndex = 46
        Me.Label4.Text = "Effective Date:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(47, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 14)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "Designation:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(63, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 14)
        Me.Label2.TabIndex = 44
        Me.Label2.Text = "Direction:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(63, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 14)
        Me.Label1.TabIndex = 43
        Me.Label1.Text = "Route No:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(122, 119)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(203, 20)
        Me.DateTimePicker1.TabIndex = 42
        '
        'txtEffDate
        '
        Me.txtEffDate.AcceptsReturn = True
        Me.txtEffDate.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.txtEffDate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtEffDate.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEffDate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtEffDate.Location = New System.Drawing.Point(11, 182)
        Me.txtEffDate.MaxLength = 0
        Me.txtEffDate.Name = "txtEffDate"
        Me.txtEffDate.ReadOnly = True
        Me.txtEffDate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtEffDate.Size = New System.Drawing.Size(25, 20)
        Me.txtEffDate.TabIndex = 39
        Me.txtEffDate.TabStop = False
        Me.txtEffDate.Visible = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(183, 190)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(81, 25)
        Me.cmdClose.TabIndex = 38
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdCreate
        '
        Me.cmdCreate.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCreate.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCreate.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCreate.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCreate.Location = New System.Drawing.Point(87, 190)
        Me.cmdCreate.Name = "cmdCreate"
        Me.cmdCreate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCreate.Size = New System.Drawing.Size(81, 25)
        Me.cmdCreate.TabIndex = 37
        Me.cmdCreate.Text = "&Update"
        Me.cmdCreate.UseVisualStyleBackColor = False
        '
        'optActive1
        '
        Me.optActive1.BackColor = System.Drawing.Color.Transparent
        Me.optActive1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optActive1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optActive1.ForeColor = System.Drawing.Color.DimGray
        Me.optActive1.Location = New System.Drawing.Point(185, 149)
        Me.optActive1.Name = "optActive1"
        Me.optActive1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optActive1.Size = New System.Drawing.Size(57, 17)
        Me.optActive1.TabIndex = 36
        Me.optActive1.Text = "NO"
        Me.optActive1.UseVisualStyleBackColor = False
        '
        'optActive0
        '
        Me.optActive0.BackColor = System.Drawing.Color.Transparent
        Me.optActive0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optActive0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optActive0.ForeColor = System.Drawing.Color.DimGray
        Me.optActive0.Location = New System.Drawing.Point(121, 149)
        Me.optActive0.Name = "optActive0"
        Me.optActive0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optActive0.Size = New System.Drawing.Size(57, 17)
        Me.optActive0.TabIndex = 35
        Me.optActive0.Text = "YES"
        Me.optActive0.UseVisualStyleBackColor = False
        '
        'Shape2
        '
        Me.Shape2.BackColor = System.Drawing.Color.Transparent
        Me.Shape2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape2.Location = New System.Drawing.Point(79, 182)
        Me.Shape2.Name = "Shape2"
        Me.Shape2.Size = New System.Drawing.Size(193, 41)
        Me.Shape2.TabIndex = 40
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(11, 13)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(347, 161)
        Me.Shape1.TabIndex = 41
        '
        'frmLineFileRouteEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(369, 232)
        Me.Controls.Add(Me.txtRouteNo)
        Me.Controls.Add(Me.cboRouteDes)
        Me.Controls.Add(Me.cboRouteDir)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.txtEffDate)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.cmdCreate)
        Me.Controls.Add(Me.optActive1)
        Me.Controls.Add(Me.optActive0)
        Me.Controls.Add(Me.Shape2)
        Me.Controls.Add(Me.Shape1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmLineFileRouteEdit"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Edit Route"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtRouteNo As TextBox
    Friend WithEvents cboRouteDes As ComboBox
    Friend WithEvents cboRouteDir As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Public WithEvents txtEffDate As TextBox
    Public WithEvents cmdClose As Button
    Public WithEvents cmdCreate As Button
    Public WithEvents optActive1 As RadioButton
    Public WithEvents optActive0 As RadioButton
    Public WithEvents Shape2 As Label
    Public WithEvents Shape1 As Label
End Class
