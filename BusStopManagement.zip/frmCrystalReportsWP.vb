﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class frmCrystalReportsWP
    Dim Form_hWnd As Integer
    Dim Report As CRAXDRT.Report
    Public rpt As CRAXDRT.ExportOptions
    Public expFlag As Boolean
    Public typeIndex As Short

    Public Sub LoadDamageCostReport(ByRef filePath As String, ByRef sSubjectLine As String, ByRef sPDNO As String,
                                    ByRef sIncidentNo As String, ByRef dIncidentDate As Date,
                                    ByRef sFrom As String, ByRef sSubTotal As String,
                                    ByRef sTax As String, ByRef sLabor As String,
                                    ByRef sOverhead As String, ByRef sTotal As String,
                                    ByRef taxRate As String, ByRef overheadRate As String)

        Dim cryRpt As New ReportDocument
        Dim sReportName As String

        sReportName = "DamageStopCost.rpt"

        cryRpt.Load(GetReportPath() & "" & sReportName)
        cryRpt.SetDatabaseLogon(DB_USER, DB_PASSWORD)

        cryRpt.Refresh()
        cView.ReportSource = cryRpt



        cryRpt.SetParameterValue("File", "File: " & filePath)
        cryRpt.SetParameterValue("SubjectLine", sSubjectLine)
        cryRpt.SetParameterValue("PDNO", sPDNO)
        cryRpt.SetParameterValue("IncidentNo", sIncidentNo)
        cryRpt.SetParameterValue("IncidentDate", dIncidentDate)
        cryRpt.SetParameterValue("From", sFrom)
        cryRpt.SetParameterValue("SubTotal", FormatCurrency(sSubTotal, 2))
        cryRpt.SetParameterValue("Tax", FormatCurrency(sTax, 2))
        cryRpt.SetParameterValue("Labor", FormatCurrency(sLabor, 2))
        cryRpt.SetParameterValue("Overhead", FormatCurrency(sOverhead, 2))
        cryRpt.SetParameterValue("Total", FormatCurrency(sTotal, 2))
        cryRpt.SetParameterValue("Tax@", FormatPercent(taxRate, 2))
        cryRpt.SetParameterValue("Overhead@", FormatPercent(overheadRate, 2))

        cView.Refresh()

        '***Export Report***********************************************************************
        Dim CrExportOptions As ExportOptions
        Dim CrDiskFileDestinationOptions As New DiskFileDestinationOptions()
        Dim CrFormatTypeOptions As New PdfRtfWordFormatOptions()
        CrDiskFileDestinationOptions.DiskFileName = filePath
        CrExportOptions = cryRpt.ExportOptions
        With CrExportOptions
            .ExportDestinationType = ExportDestinationType.DiskFile
            .DestinationOptions = CrDiskFileDestinationOptions
            .FormatOptions = CrFormatTypeOptions
            .ExportFormatType = ExportFormatType.PortableDocFormat
        End With
        cryRpt.Export()
        '*****************************************************************

        Me.BringToFront()
        Me.ShowDialog()
        cryRpt.Dispose()

        Exit Sub

errHandler:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Public Sub LoadReport(ByRef sReportName As String, ByRef sReportTitle As String, ByRef sReportStatus As String, ByRef sReportFooter As String)
        On Error GoTo errHandler

        Dim cryRpt As New ReportDocument

        cryRpt.Load(GetReportPath() & "" & sReportName)
        cryRpt.SetDatabaseLogon(DB_USER, DB_PASSWORD)

        If sReportTitle <> "" Then
            cryRpt.SummaryInfo.ReportTitle = sReportTitle
        End If

        If sReportStatus <> "" Then
            cryRpt.SummaryInfo.ReportComments = sReportStatus
        End If

        If sReportFooter <> "" Then
            cryRpt.SummaryInfo.ReportAuthor = sReportFooter
        End If

        cryRpt.Refresh()
        cView.ReportSource = cryRpt
        cView.Refresh()

        Me.BringToFront()
        Me.ShowDialog()
        cryRpt.Dispose()

        Exit Sub
errHandler:
        MsgBox(Err.Number & " | " & Err.Description & " | " & Err.Source & " | " & Err.LastDllError)
        Exit Sub
    End Sub

    Public Sub LoadReportWithExport(ByRef sReportName As String, ByRef sExportFile As String, ByRef sReportStatus As String, ByRef sReportFooter As String)
        ' load the report given

        On Error GoTo errHandler

        Dim cryRpt As New ReportDocument

        cryRpt.Load(GetReportPath() & "" & sReportName)
        cryRpt.SetDatabaseLogon(DB_USER, DB_PASSWORD)

        If sExportFile <> "" Then
            cryRpt.SummaryInfo.ReportTitle = sExportFile
        End If

        If sReportStatus <> "" Then
            cryRpt.SummaryInfo.ReportComments = sReportStatus
        End If

        If sReportFooter <> "" Then
            cryRpt.SummaryInfo.ReportAuthor = sReportFooter
        End If

        cryRpt.Refresh()
        cView.ReportSource = cryRpt
        cView.Refresh()

        '***Export Report**************************************************
        Dim CrExportOptions As ExportOptions
        Dim CrDiskFileDestinationOptions As New DiskFileDestinationOptions()
        Dim CrFormatTypeOptions As New PdfRtfWordFormatOptions()
        CrDiskFileDestinationOptions.DiskFileName = sExportFile
        CrExportOptions = cryRpt.ExportOptions
        With CrExportOptions
            .ExportDestinationType = ExportDestinationType.DiskFile
            .ExportFormatType = ExportFormatType.PortableDocFormat
            .DestinationOptions = CrDiskFileDestinationOptions
            .FormatOptions = CrFormatTypeOptions
        End With
        cryRpt.Export()
        '*****************************************************************

        Me.BringToFront()
        Me.ShowDialog()
        cryRpt.Dispose()

        Exit Sub

errHandler:
        MsgBox(Err.Description)
        Exit Sub
    End Sub


    Public Sub LoadExportOnly(ByRef sReportName As String, ByRef filePath As String, ByRef PrintMode As Boolean)
        On Error GoTo errHandler

        Dim cryRpt As New ReportDocument

        cryRpt.Load(GetReportPath() & "" & sReportName)
        cryRpt.SetDatabaseLogon(DB_USER, DB_PASSWORD)

        cryRpt.Refresh()
        cView.ReportSource = cryRpt
        cView.Refresh()

        '***Export Report***********************************************************************
        Dim CrExportOptions As ExportOptions
        Dim CrDiskFileDestinationOptions As New DiskFileDestinationOptions()
        'Dim CrFormatTypeOptions As New PdfRtfWordFormatOptions()
        Dim CrFormatTypeOptions As New PdfRtfWordFormatOptions()
        CrDiskFileDestinationOptions.DiskFileName = filePath
        CrExportOptions = cryRpt.ExportOptions
        With CrExportOptions
            .ExportFormatType = ExportFormatType.WordForWindows
            .ExportDestinationType = ExportDestinationType.DiskFile
            '.ExportFormatType = ExportFormatType.PortableDocFormat
            .DestinationOptions = CrDiskFileDestinationOptions
            .FormatOptions = CrFormatTypeOptions
        End With
        cryRpt.Export()
        '*****************************************************************
        If PrintMode Then
            cryRpt.PrintToPrinter(1, True, 0, 0) 'Allows printing directly to default printing without previewing 
            'Me.BringToFront()
            'Me.ShowDialog()
        End If

        cryRpt.Dispose()

        Exit Sub

errHandler:
        MsgBox(Err.Description)
        Exit Sub
    End Sub

    Public Sub LoadReport2(ByRef cRep As CRAXDRT.Report)
        ' load the report given
        cView.ReportSource = cRep
        'cView.ViewReport()
        cView.Show()
        Report = cRep

        Dim response As Object
        Dim tmpTxt As String

        tmpTxt = "Create a Report file. If you choose not to create a word file at this time," & "you can select the export option while the report is still active."

        response = MsgBox(tmpTxt, MsgBoxStyle.YesNo)

        If response = MsgBoxResult.Yes Then
            rpt = Report.ExportOptions
            rpt.DestinationType = CRAXDRT.CRExportDestinationType.crEDTDiskFile
            'frmExportReport.ShowDialog()

            On Error GoTo errHandler

            If expFlag Then
                Report.Export(False)
            End If
        End If

        Me.ShowDialog()

        Exit Sub

errHandler:
        MsgBox(Err.Number & " | " & Err.Description & " | " & Err.Source & " | " & Err.LastDllError)
        Exit Sub
    End Sub

    Private Sub frmCrystalReportsWP_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
        ' maximize the control to the bound window
        cView.Width = IIf(Me.Width, (Me.Width - 50), 0) ' - 50 for borders
        cView.Height = IIf(Me.Height > 50, (Me.Height - 50), 0) ' - 400 for title bar

    End Sub

    Private Sub frmCrystalReportsWP_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Form_hWnd = FindWindow(vbNullString, "Report Viewer")
        If Form_hWnd <> 0 Then
            SetWindowPos(Form_hWnd, HWND_TOPMOST, 0, 0, 0, 0, FLAGS)
        End If
    End Sub
    Private Sub frmCrystalReportsWP_Closed(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Closed
        Report = Nothing
    End Sub

End Class