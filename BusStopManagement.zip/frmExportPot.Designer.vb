﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmExportPot
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmExportPot))
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.lblProccess = New System.Windows.Forms.Label()
        Me.pbProgressBar = New System.Windows.Forms.ProgressBar()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cmdPotFile = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.Frame1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.lblProccess)
        Me.Frame1.Controls.Add(Me.pbProgressBar)
        Me.Frame1.Controls.Add(Me.cmdExit)
        Me.Frame1.Controls.Add(Me.cmdPotFile)
        Me.Frame1.Controls.Add(Me.Label1)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.Color.DimGray
        Me.Frame1.Location = New System.Drawing.Point(12, 12)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(433, 143)
        Me.Frame1.TabIndex = 4
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Export POT Files"
        '
        'lblProccess
        '
        Me.lblProccess.Font = New System.Drawing.Font("Arial", 7.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProccess.Location = New System.Drawing.Point(20, 125)
        Me.lblProccess.Name = "lblProccess"
        Me.lblProccess.Size = New System.Drawing.Size(389, 17)
        Me.lblProccess.TabIndex = 6
        Me.lblProccess.Text = "Import Bus Stop Information"
        Me.lblProccess.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblProccess.Visible = False
        '
        'pbProgressBar
        '
        Me.pbProgressBar.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.pbProgressBar.Location = New System.Drawing.Point(20, 102)
        Me.pbProgressBar.Name = "pbProgressBar"
        Me.pbProgressBar.Size = New System.Drawing.Size(389, 23)
        Me.pbProgressBar.TabIndex = 5
        Me.pbProgressBar.Visible = False
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExit.Location = New System.Drawing.Point(220, 66)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExit.Size = New System.Drawing.Size(73, 25)
        Me.cmdExit.TabIndex = 0
        Me.cmdExit.Text = "&Cancel"
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'cmdPotFile
        '
        Me.cmdPotFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPotFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPotFile.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPotFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPotFile.Location = New System.Drawing.Point(140, 66)
        Me.cmdPotFile.Name = "cmdPotFile"
        Me.cmdPotFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPotFile.Size = New System.Drawing.Size(73, 25)
        Me.cmdPotFile.TabIndex = 1
        Me.cmdPotFile.Text = "&Ok"
        Me.cmdPotFile.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(17, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(393, 37)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "You're going to export a POT file. The process may take several minutes. Do you w" &
    "ant to continue?"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmExportPot
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(462, 167)
        Me.Controls.Add(Me.Frame1)
        Me.ForeColor = System.Drawing.Color.DimGray
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmExportPot"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Export POT File"
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents Frame1 As GroupBox
    Public WithEvents cmdExit As Button
    Public WithEvents cmdPotFile As Button
    Public WithEvents Label1 As Label
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents pbProgressBar As ProgressBar
    Friend WithEvents lblProccess As Label
End Class
