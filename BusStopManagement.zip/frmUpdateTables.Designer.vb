﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmUpdateTables
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUpdateTables))
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.lstTables = New System.Windows.Forms.ListBox()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.TdbGrid1 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BusStopManagementDataSet1 = New BusStopManagement.BusStopManagementDataSet1()
        Me.BSMTableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BSMTableAdapter = New BusStopManagement.BusStopManagementDataSet1TableAdapters.ADA_STATUS_CODETableAdapter()
        Me.lblTotalRecords = New System.Windows.Forms.Label()
        CType(Me.TdbGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusStopManagementDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BSMTableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdExit
        '
        Me.cmdExit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdExit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExit.Location = New System.Drawing.Point(381, 630)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExit.Size = New System.Drawing.Size(105, 25)
        Me.cmdExit.TabIndex = 11
        Me.cmdExit.Text = "&Close"
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdEdit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdEdit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdEdit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdEdit.Location = New System.Drawing.Point(266, 630)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdEdit.Size = New System.Drawing.Size(105, 25)
        Me.cmdEdit.TabIndex = 10
        Me.cmdEdit.Text = "&Save Changes"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'lstTables
        '
        Me.lstTables.BackColor = System.Drawing.Color.White
        Me.lstTables.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstTables.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstTables.ForeColor = System.Drawing.Color.DimGray
        Me.lstTables.ItemHeight = 16
        Me.lstTables.Location = New System.Drawing.Point(12, 48)
        Me.lstTables.Name = "lstTables"
        Me.lstTables.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstTables.Size = New System.Drawing.Size(236, 564)
        Me.lstTables.Sorted = True
        Me.lstTables.TabIndex = 7
        '
        'Shape1
        '
        Me.Shape1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(256, 621)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(242, 41)
        Me.Shape1.TabIndex = 12
        '
        'TdbGrid1
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        Me.TdbGrid1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.TdbGrid1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TdbGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TdbGrid1.Location = New System.Drawing.Point(255, 48)
        Me.TdbGrid1.MinimumSize = New System.Drawing.Size(742, 564)
        Me.TdbGrid1.Name = "TdbGrid1"
        Me.TdbGrid1.Size = New System.Drawing.Size(742, 564)
        Me.TdbGrid1.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(12, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 15)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "List of Tables"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(253, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 15)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Table Data"
        '
        'BusStopManagementDataSet1
        '
        Me.BusStopManagementDataSet1.DataSetName = "BusStopManagementDataSet1"
        Me.BusStopManagementDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BSMTableBindingSource
        '
        Me.BSMTableBindingSource.DataMember = "ADA_STATUS_CODE"
        Me.BSMTableBindingSource.DataSource = Me.BusStopManagementDataSet1
        '
        'BSMTableAdapter
        '
        Me.BSMTableAdapter.ClearBeforeFill = True
        '
        'lblTotalRecords
        '
        Me.lblTotalRecords.AutoSize = True
        Me.lblTotalRecords.ForeColor = System.Drawing.Color.DimGray
        Me.lblTotalRecords.Location = New System.Drawing.Point(9, 622)
        Me.lblTotalRecords.Name = "lblTotalRecords"
        Me.lblTotalRecords.Size = New System.Drawing.Size(86, 13)
        Me.lblTotalRecords.TabIndex = 16
        Me.lblTotalRecords.Text = "Total Records: 0"
        '
        'frmUpdateTables
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(1016, 670)
        Me.Controls.Add(Me.lblTotalRecords)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TdbGrid1)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.lstTables)
        Me.Controls.Add(Me.Shape1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(1032, 708)
        Me.Name = "frmUpdateTables"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Update Tables"
        CType(Me.TdbGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusStopManagementDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BSMTableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents cmdExit As Button
    Public WithEvents cmdEdit As Button
    Public WithEvents lstTables As ListBox
    Public WithEvents Shape1 As Label
    Friend WithEvents TdbGrid1 As DataGridView
    Friend WithEvents BusStopManagementDataSet1 As BusStopManagementDataSet1
    Friend WithEvents BSMTableBindingSource As BindingSource
    Friend WithEvents BSMTableAdapter As BusStopManagementDataSet1TableAdapters.ADA_STATUS_CODETableAdapter
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblTotalRecords As Label
End Class
