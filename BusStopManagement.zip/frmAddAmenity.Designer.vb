﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddAmenity
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAddAmenity))
        Me.txtSanz_ID = New System.Windows.Forms.TextBox()
        Me.TblStopPsgrAmenitiesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsPassAmenities = New BusStopManagement.dsPassAmenities()
        Me.cmdOk = New System.Windows.Forms.Button()
        Me.cboOwner = New System.Windows.Forms.ComboBox()
        Me.AMENITIESOWNERCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsAmentityOwner = New BusStopManagement.dsAmentityOwner()
        Me.cboType = New System.Windows.Forms.ComboBox()
        Me.AMENITIESTYPECODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsAmenityTypeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsAmenityType = New BusStopManagement.dsAmenityType()
        Me.txtNum = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.Shape2 = New System.Windows.Forms.Label()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me._Label1_0 = New System.Windows.Forms.Label()
        Me._Label1_1 = New System.Windows.Forms.Label()
        Me._Label1_4 = New System.Windows.Forms.Label()
        Me._Label1_3 = New System.Windows.Forms.Label()
        Me._Label1_2 = New System.Windows.Forms.Label()
        Me._lbl_labels_1 = New System.Windows.Forms.Label()
        Me.dtDate = New System.Windows.Forms.DateTimePicker()
        Me.dtTime = New System.Windows.Forms.DateTimePicker()
        Me.TblStopPsgrAmenitiesTableAdapter = New BusStopManagement.dsPassAmenitiesTableAdapters.tblStopPsgrAmenitiesTableAdapter()
        Me.AMENITIES_TYPE_CODETableAdapter = New BusStopManagement.dsAmenityTypeTableAdapters.AMENITIES_TYPE_CODETableAdapter()
        Me.AMENITIES_OWNER_CODETableAdapter = New BusStopManagement.dsAmentityOwnerTableAdapters.AMENITIES_OWNER_CODETableAdapter()
        CType(Me.TblStopPsgrAmenitiesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsPassAmenities, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AMENITIESOWNERCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsAmentityOwner, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AMENITIESTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsAmenityTypeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsAmenityType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtSanz_ID
        '
        Me.txtSanz_ID.AcceptsReturn = True
        Me.txtSanz_ID.BackColor = System.Drawing.SystemColors.Window
        Me.txtSanz_ID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSanz_ID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopPsgrAmenitiesBindingSource, "SANZ_ID", True))
        Me.txtSanz_ID.Enabled = False
        Me.txtSanz_ID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSanz_ID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSanz_ID.Location = New System.Drawing.Point(68, 17)
        Me.txtSanz_ID.MaxLength = 0
        Me.txtSanz_ID.Name = "txtSanz_ID"
        Me.txtSanz_ID.ReadOnly = True
        Me.txtSanz_ID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSanz_ID.Size = New System.Drawing.Size(88, 20)
        Me.txtSanz_ID.TabIndex = 26
        '
        'TblStopPsgrAmenitiesBindingSource
        '
        Me.TblStopPsgrAmenitiesBindingSource.DataMember = "tblStopPsgrAmenities"
        Me.TblStopPsgrAmenitiesBindingSource.DataSource = Me.DsPassAmenities
        '
        'DsPassAmenities
        '
        Me.DsPassAmenities.DataSetName = "dsPassAmenities"
        Me.DsPassAmenities.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmdOk
        '
        Me.cmdOk.BackColor = System.Drawing.SystemColors.Control
        Me.cmdOk.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdOk.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdOk.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdOk.Location = New System.Drawing.Point(188, 162)
        Me.cmdOk.Name = "cmdOk"
        Me.cmdOk.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdOk.Size = New System.Drawing.Size(73, 25)
        Me.cmdOk.TabIndex = 19
        Me.cmdOk.Text = "&OK"
        Me.cmdOk.UseVisualStyleBackColor = False
        '
        'cboOwner
        '
        Me.cboOwner.BackColor = System.Drawing.SystemColors.Window
        Me.cboOwner.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboOwner.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblStopPsgrAmenitiesBindingSource, "AMENITIES_OWNER_ID", True))
        Me.cboOwner.DataSource = Me.AMENITIESOWNERCODEBindingSource
        Me.cboOwner.DisplayMember = "DESCRIPTION"
        Me.cboOwner.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboOwner.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboOwner.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboOwner.Location = New System.Drawing.Point(68, 113)
        Me.cboOwner.Name = "cboOwner"
        Me.cboOwner.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboOwner.Size = New System.Drawing.Size(273, 22)
        Me.cboOwner.TabIndex = 18
        Me.cboOwner.ValueMember = "ID"
        '
        'AMENITIESOWNERCODEBindingSource
        '
        Me.AMENITIESOWNERCODEBindingSource.DataMember = "AMENITIES_OWNER_CODE"
        Me.AMENITIESOWNERCODEBindingSource.DataSource = Me.DsAmentityOwner
        '
        'DsAmentityOwner
        '
        Me.DsAmentityOwner.DataSetName = "dsAmentityOwner"
        Me.DsAmentityOwner.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboType
        '
        Me.cboType.BackColor = System.Drawing.SystemColors.Window
        Me.cboType.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboType.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopPsgrAmenitiesBindingSource, "AMENITIES_TYPE_ID", True))
        Me.cboType.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblStopPsgrAmenitiesBindingSource, "AMENITIES_TYPE_ID", True))
        Me.cboType.DataSource = Me.AMENITIESTYPECODEBindingSource
        Me.cboType.DisplayMember = "DESCRIPTION"
        Me.cboType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboType.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboType.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboType.Location = New System.Drawing.Point(68, 81)
        Me.cboType.Name = "cboType"
        Me.cboType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboType.Size = New System.Drawing.Size(273, 22)
        Me.cboType.TabIndex = 17
        Me.cboType.ValueMember = "ID"
        '
        'AMENITIESTYPECODEBindingSource
        '
        Me.AMENITIESTYPECODEBindingSource.DataMember = "AMENITIES_TYPE_CODE"
        Me.AMENITIESTYPECODEBindingSource.DataSource = Me.DsAmenityTypeBindingSource
        '
        'DsAmenityTypeBindingSource
        '
        Me.DsAmenityTypeBindingSource.DataSource = Me.DsAmenityType
        Me.DsAmenityTypeBindingSource.Position = 0
        '
        'DsAmenityType
        '
        Me.DsAmenityType.DataSetName = "dsAmenityType"
        Me.DsAmenityType.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtNum
        '
        Me.txtNum.AcceptsReturn = True
        Me.txtNum.BackColor = System.Drawing.SystemColors.Window
        Me.txtNum.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNum.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblStopPsgrAmenitiesBindingSource, "NUM", True))
        Me.txtNum.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNum.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNum.Location = New System.Drawing.Point(68, 49)
        Me.txtNum.MaxLength = 3
        Me.txtNum.Name = "txtNum"
        Me.txtNum.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtNum.Size = New System.Drawing.Size(89, 20)
        Me.txtNum.TabIndex = 16
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(268, 162)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(73, 25)
        Me.cmdCancel.TabIndex = 20
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'Shape2
        '
        Me.Shape2.BackColor = System.Drawing.Color.Transparent
        Me.Shape2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape2.Location = New System.Drawing.Point(12, 8)
        Me.Shape2.Name = "Shape2"
        Me.Shape2.Size = New System.Drawing.Size(337, 137)
        Me.Shape2.TabIndex = 28
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(179, 154)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(169, 41)
        Me.Shape1.TabIndex = 29
        '
        '_Label1_0
        '
        Me._Label1_0.AutoSize = True
        Me._Label1_0.BackColor = System.Drawing.Color.Transparent
        Me._Label1_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_0.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_0.Location = New System.Drawing.Point(17, 20)
        Me._Label1_0.Name = "_Label1_0"
        Me._Label1_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_0.Size = New System.Drawing.Size(51, 14)
        Me._Label1_0.TabIndex = 27
        Me._Label1_0.Text = "SANZ ID:"
        Me._Label1_0.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_1
        '
        Me._Label1_1.AutoSize = True
        Me._Label1_1.BackColor = System.Drawing.Color.Transparent
        Me._Label1_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_1.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_1.Location = New System.Drawing.Point(171, 53)
        Me._Label1_1.Name = "_Label1_1"
        Me._Label1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_1.Size = New System.Drawing.Size(85, 14)
        Me._Label1_1.TabIndex = 25
        Me._Label1_1.Text = "TIME SURVYED:"
        Me._Label1_1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_4
        '
        Me._Label1_4.AutoSize = True
        Me._Label1_4.BackColor = System.Drawing.Color.Transparent
        Me._Label1_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_4.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_4.Location = New System.Drawing.Point(171, 21)
        Me._Label1_4.Name = "_Label1_4"
        Me._Label1_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_4.Size = New System.Drawing.Size(89, 14)
        Me._Label1_4.TabIndex = 24
        Me._Label1_4.Text = "DATE SURVYED:"
        Me._Label1_4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_3
        '
        Me._Label1_3.AutoSize = True
        Me._Label1_3.BackColor = System.Drawing.Color.Transparent
        Me._Label1_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_3.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_3.Location = New System.Drawing.Point(17, 116)
        Me._Label1_3.Name = "_Label1_3"
        Me._Label1_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_3.Size = New System.Drawing.Size(48, 14)
        Me._Label1_3.TabIndex = 23
        Me._Label1_3.Text = "OWNER:"
        Me._Label1_3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_Label1_2
        '
        Me._Label1_2.AutoSize = True
        Me._Label1_2.BackColor = System.Drawing.Color.Transparent
        Me._Label1_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label1_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label1_2.ForeColor = System.Drawing.Color.DimGray
        Me._Label1_2.Location = New System.Drawing.Point(29, 84)
        Me._Label1_2.Name = "_Label1_2"
        Me._Label1_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label1_2.Size = New System.Drawing.Size(36, 14)
        Me._Label1_2.TabIndex = 22
        Me._Label1_2.Text = "TYPE:"
        Me._Label1_2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        '_lbl_labels_1
        '
        Me._lbl_labels_1.AutoSize = True
        Me._lbl_labels_1.BackColor = System.Drawing.Color.Transparent
        Me._lbl_labels_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._lbl_labels_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._lbl_labels_1.ForeColor = System.Drawing.Color.DimGray
        Me._lbl_labels_1.Location = New System.Drawing.Point(36, 53)
        Me._lbl_labels_1.Name = "_lbl_labels_1"
        Me._lbl_labels_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lbl_labels_1.Size = New System.Drawing.Size(32, 14)
        Me._lbl_labels_1.TabIndex = 21
        Me._lbl_labels_1.Text = "NUM:"
        Me._lbl_labels_1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'dtDate
        '
        Me.dtDate.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblStopPsgrAmenitiesBindingSource, "DATE_SURV", True, System.Windows.Forms.DataSourceUpdateMode.OnValidation, Nothing, "d"))
        Me.dtDate.Location = New System.Drawing.Point(259, 17)
        Me.dtDate.Name = "dtDate"
        Me.dtDate.Size = New System.Drawing.Size(82, 20)
        Me.dtDate.TabIndex = 30
        '
        'dtTime
        '
        Me.dtTime.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblStopPsgrAmenitiesBindingSource, "TIME_SURV", True, System.Windows.Forms.DataSourceUpdateMode.OnValidation, Nothing, "t"))
        Me.dtTime.Location = New System.Drawing.Point(259, 49)
        Me.dtTime.Name = "dtTime"
        Me.dtTime.Size = New System.Drawing.Size(82, 20)
        Me.dtTime.TabIndex = 31
        '
        'TblStopPsgrAmenitiesTableAdapter
        '
        Me.TblStopPsgrAmenitiesTableAdapter.ClearBeforeFill = True
        '
        'AMENITIES_TYPE_CODETableAdapter
        '
        Me.AMENITIES_TYPE_CODETableAdapter.ClearBeforeFill = True
        '
        'AMENITIES_OWNER_CODETableAdapter
        '
        Me.AMENITIES_OWNER_CODETableAdapter.ClearBeforeFill = True
        '
        'frmAddAmenity
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(359, 206)
        Me.Controls.Add(Me.dtTime)
        Me.Controls.Add(Me.dtDate)
        Me.Controls.Add(Me.txtSanz_ID)
        Me.Controls.Add(Me.cmdOk)
        Me.Controls.Add(Me.cboOwner)
        Me.Controls.Add(Me.cboType)
        Me.Controls.Add(Me.txtNum)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.Shape1)
        Me.Controls.Add(Me._Label1_0)
        Me.Controls.Add(Me._Label1_1)
        Me.Controls.Add(Me._Label1_4)
        Me.Controls.Add(Me._Label1_3)
        Me.Controls.Add(Me._Label1_2)
        Me.Controls.Add(Me._lbl_labels_1)
        Me.Controls.Add(Me.Shape2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmAddAmenity"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add Amenity"
        CType(Me.TblStopPsgrAmenitiesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsPassAmenities, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AMENITIESOWNERCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsAmentityOwner, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AMENITIESTYPECODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsAmenityTypeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsAmenityType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents txtSanz_ID As TextBox
    Public WithEvents cmdOk As Button
    Public WithEvents cboOwner As ComboBox
    Public WithEvents cboType As ComboBox
    Public WithEvents txtNum As TextBox
    Public WithEvents cmdCancel As Button
    Public WithEvents Shape2 As Label
    Public WithEvents Shape1 As Label
    Public WithEvents _Label1_0 As Label
    Public WithEvents _Label1_1 As Label
    Public WithEvents _Label1_4 As Label
    Public WithEvents _Label1_3 As Label
    Public WithEvents _Label1_2 As Label
    Public WithEvents _lbl_labels_1 As Label
    Friend WithEvents dtDate As DateTimePicker
    Friend WithEvents dtTime As DateTimePicker
    Friend WithEvents DsPassAmenities As dsPassAmenities
    Friend WithEvents TblStopPsgrAmenitiesBindingSource As BindingSource
    Friend WithEvents TblStopPsgrAmenitiesTableAdapter As dsPassAmenitiesTableAdapters.tblStopPsgrAmenitiesTableAdapter
    Friend WithEvents DsAmenityTypeBindingSource As BindingSource
    Friend WithEvents DsAmenityType As dsAmenityType
    Friend WithEvents AMENITIESTYPECODEBindingSource As BindingSource
    Friend WithEvents AMENITIES_TYPE_CODETableAdapter As dsAmenityTypeTableAdapters.AMENITIES_TYPE_CODETableAdapter
    Friend WithEvents DsAmentityOwner As dsAmentityOwner
    Friend WithEvents AMENITIESOWNERCODEBindingSource As BindingSource
    Friend WithEvents AMENITIES_OWNER_CODETableAdapter As dsAmentityOwnerTableAdapters.AMENITIES_OWNER_CODETableAdapter
End Class
