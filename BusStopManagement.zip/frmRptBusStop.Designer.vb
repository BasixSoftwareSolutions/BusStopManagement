﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmRptBusStop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRptBusStop))
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdPrint = New System.Windows.Forms.Button()
        Me.ADASTATUSCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsADAStatusDescBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsADAStatusDesc = New BusStopManagement.dsADAStatusDesc()
        Me.CITYCODEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsCityCode = New BusStopManagement.dsCityCode()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.BusStopManagementDataSet1 = New BusStopManagement.BusStopManagementDataSet1()
        Me.ADA_STATUS_CODETableAdapter = New BusStopManagement.dsADAStatusDescTableAdapters.ADA_STATUS_CODETableAdapter()
        Me.CITY_CODETableAdapter = New BusStopManagement.dsCityCodeTableAdapters.CITY_CODETableAdapter()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cboADAJurisd = New System.Windows.Forms.ComboBox()
        Me.optBusStopADA0 = New System.Windows.Forms.RadioButton()
        Me.optBusStopADA1 = New System.Windows.Forms.RadioButton()
        Me.Frame5 = New System.Windows.Forms.GroupBox()
        Me.optStopStatus2 = New System.Windows.Forms.RadioButton()
        Me.optStopStatus1 = New System.Windows.Forms.RadioButton()
        Me.optStopStatus0 = New System.Windows.Forms.RadioButton()
        Me.cboCountyOption = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.optBusStop6 = New System.Windows.Forms.RadioButton()
        Me.optBusStop5 = New System.Windows.Forms.RadioButton()
        Me.txtOCTAID = New System.Windows.Forms.TextBox()
        Me.optBusStop4 = New System.Windows.Forms.RadioButton()
        Me.optBusStopHistory0 = New System.Windows.Forms.RadioButton()
        Me.optBusStopHistory1 = New System.Windows.Forms.RadioButton()
        Me.optBusStop2 = New System.Windows.Forms.RadioButton()
        Me.optBusStop3 = New System.Windows.Forms.RadioButton()
        Me.cboStreet = New System.Windows.Forms.ComboBox()
        Me.cboByJurisd = New System.Windows.Forms.ComboBox()
        Me.optBusStop1 = New System.Windows.Forms.RadioButton()
        Me.optBusStop0 = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboWithinJurisd = New System.Windows.Forms.ComboBox()
        Me.cboStreetGhost = New System.Windows.Forms.ComboBox()
        CType(Me.ADASTATUSCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsADAStatusDescBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsADAStatusDesc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CITYCODEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsCityCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusStopManagementDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Frame5.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(549, 332)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(105, 25)
        Me.cmdCancel.TabIndex = 48
        Me.cmdCancel.Text = "&Close"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdPrint
        '
        Me.cmdPrint.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPrint.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPrint.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPrint.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPrint.Location = New System.Drawing.Point(549, 300)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPrint.Size = New System.Drawing.Size(105, 25)
        Me.cmdPrint.TabIndex = 47
        Me.cmdPrint.Text = "&Print Report"
        Me.cmdPrint.UseVisualStyleBackColor = False
        '
        'ADASTATUSCODEBindingSource
        '
        Me.ADASTATUSCODEBindingSource.DataMember = "ADA_STATUS_CODE"
        Me.ADASTATUSCODEBindingSource.DataSource = Me.DsADAStatusDescBindingSource
        '
        'DsADAStatusDescBindingSource
        '
        Me.DsADAStatusDescBindingSource.DataSource = Me.DsADAStatusDesc
        Me.DsADAStatusDescBindingSource.Position = 0
        '
        'DsADAStatusDesc
        '
        Me.DsADAStatusDesc.DataSetName = "dsADAStatusDesc"
        Me.DsADAStatusDesc.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CITYCODEBindingSource
        '
        Me.CITYCODEBindingSource.DataMember = "CITY_CODE"
        Me.CITYCODEBindingSource.DataSource = Me.DsCityCode
        '
        'DsCityCode
        '
        Me.DsCityCode.DataSetName = "dsCityCode"
        Me.DsCityCode.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(541, 292)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(121, 73)
        Me.Shape1.TabIndex = 55
        '
        'BusStopManagementDataSet1
        '
        Me.BusStopManagementDataSet1.DataSetName = "BusStopManagementDataSet1"
        Me.BusStopManagementDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ADA_STATUS_CODETableAdapter
        '
        Me.ADA_STATUS_CODETableAdapter.ClearBeforeFill = True
        '
        'CITY_CODETableAdapter
        '
        Me.CITY_CODETableAdapter.ClearBeforeFill = True
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.cmdCancel)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.cmdPrint)
        Me.Panel1.Controls.Add(Me.Shape1)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Controls.Add(Me.Frame5)
        Me.Panel1.Controls.Add(Me.cboCountyOption)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.optBusStop6)
        Me.Panel1.Controls.Add(Me.optBusStop5)
        Me.Panel1.Controls.Add(Me.txtOCTAID)
        Me.Panel1.Controls.Add(Me.optBusStop4)
        Me.Panel1.Controls.Add(Me.optBusStopHistory0)
        Me.Panel1.Controls.Add(Me.optBusStopHistory1)
        Me.Panel1.Controls.Add(Me.optBusStop2)
        Me.Panel1.Controls.Add(Me.optBusStop3)
        Me.Panel1.Controls.Add(Me.cboStreet)
        Me.Panel1.Controls.Add(Me.cboByJurisd)
        Me.Panel1.Controls.Add(Me.optBusStop1)
        Me.Panel1.Controls.Add(Me.optBusStop0)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.cboWithinJurisd)
        Me.Panel1.Controls.Add(Me.cboStreetGhost)
        Me.Panel1.Location = New System.Drawing.Point(13, 8)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(674, 376)
        Me.Panel1.TabIndex = 65
        '
        'Label9
        '
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Location = New System.Drawing.Point(130, 312)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(367, 1)
        Me.Label9.TabIndex = 87
        Me.Label9.Text = "Label9"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.DimGray
        Me.Label10.Location = New System.Drawing.Point(15, 303)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(112, 14)
        Me.Label10.TabIndex = 86
        Me.Label10.Text = "Bus Stop Summary"
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Location = New System.Drawing.Point(176, 207)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(321, 1)
        Me.Label7.TabIndex = 85
        Me.Label7.Text = "Label7"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.DimGray
        Me.Label8.Location = New System.Drawing.Point(19, 198)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(153, 14)
        Me.Label8.TabIndex = 84
        Me.Label8.Text = "Individual Bus Stop History"
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Location = New System.Drawing.Point(128, 114)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(370, 1)
        Me.Label5.TabIndex = 83
        Me.Label5.Text = "Label5"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.DimGray
        Me.Label6.Location = New System.Drawing.Point(19, 105)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(105, 14)
        Me.Label6.TabIndex = 82
        Me.Label6.Text = "Bus Stops by ADA"
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Location = New System.Drawing.Point(149, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(353, 1)
        Me.Label4.TabIndex = 81
        Me.Label4.Text = "Label4"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(19, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(129, 14)
        Me.Label3.TabIndex = 80
        Me.Label3.Text = "Bus Stops by Location"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cboADAJurisd)
        Me.GroupBox1.Controls.Add(Me.optBusStopADA0)
        Me.GroupBox1.Controls.Add(Me.optBusStopADA1)
        Me.GroupBox1.Location = New System.Drawing.Point(156, 119)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(236, 65)
        Me.GroupBox1.TabIndex = 79
        Me.GroupBox1.TabStop = False
        '
        'cboADAJurisd
        '
        Me.cboADAJurisd.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.cboADAJurisd.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboADAJurisd.DataSource = Me.CITYCODEBindingSource
        Me.cboADAJurisd.DisplayMember = "CITY"
        Me.cboADAJurisd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboADAJurisd.Enabled = False
        Me.cboADAJurisd.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboADAJurisd.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboADAJurisd.Location = New System.Drawing.Point(105, 10)
        Me.cboADAJurisd.Name = "cboADAJurisd"
        Me.cboADAJurisd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboADAJurisd.Size = New System.Drawing.Size(122, 22)
        Me.cboADAJurisd.TabIndex = 67
        Me.cboADAJurisd.ValueMember = "ID"
        '
        'optBusStopADA0
        '
        Me.optBusStopADA0.BackColor = System.Drawing.Color.Transparent
        Me.optBusStopADA0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStopADA0.Enabled = False
        Me.optBusStopADA0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStopADA0.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStopADA0.Location = New System.Drawing.Point(10, 10)
        Me.optBusStopADA0.Name = "optBusStopADA0"
        Me.optBusStopADA0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStopADA0.Size = New System.Drawing.Size(89, 17)
        Me.optBusStopADA0.TabIndex = 68
        Me.optBusStopADA0.Text = "Within City of"
        Me.optBusStopADA0.UseVisualStyleBackColor = False
        '
        'optBusStopADA1
        '
        Me.optBusStopADA1.BackColor = System.Drawing.Color.Transparent
        Me.optBusStopADA1.Checked = True
        Me.optBusStopADA1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStopADA1.Enabled = False
        Me.optBusStopADA1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStopADA1.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStopADA1.Location = New System.Drawing.Point(10, 36)
        Me.optBusStopADA1.Name = "optBusStopADA1"
        Me.optBusStopADA1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStopADA1.Size = New System.Drawing.Size(49, 17)
        Me.optBusStopADA1.TabIndex = 69
        Me.optBusStopADA1.TabStop = True
        Me.optBusStopADA1.Text = "All"
        Me.optBusStopADA1.UseVisualStyleBackColor = False
        '
        'Frame5
        '
        Me.Frame5.BackColor = System.Drawing.Color.Transparent
        Me.Frame5.Controls.Add(Me.optStopStatus2)
        Me.Frame5.Controls.Add(Me.optStopStatus1)
        Me.Frame5.Controls.Add(Me.optStopStatus0)
        Me.Frame5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame5.Location = New System.Drawing.Point(539, 15)
        Me.Frame5.Name = "Frame5"
        Me.Frame5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame5.Size = New System.Drawing.Size(121, 105)
        Me.Frame5.TabIndex = 78
        Me.Frame5.TabStop = False
        '
        'optStopStatus2
        '
        Me.optStopStatus2.BackColor = System.Drawing.Color.Transparent
        Me.optStopStatus2.Cursor = System.Windows.Forms.Cursors.Default
        Me.optStopStatus2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optStopStatus2.ForeColor = System.Drawing.Color.DimGray
        Me.optStopStatus2.Location = New System.Drawing.Point(16, 72)
        Me.optStopStatus2.Name = "optStopStatus2"
        Me.optStopStatus2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optStopStatus2.Size = New System.Drawing.Size(89, 25)
        Me.optStopStatus2.TabIndex = 8
        Me.optStopStatus2.Text = "Both"
        Me.optStopStatus2.UseVisualStyleBackColor = False
        '
        'optStopStatus1
        '
        Me.optStopStatus1.BackColor = System.Drawing.Color.Transparent
        Me.optStopStatus1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optStopStatus1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optStopStatus1.ForeColor = System.Drawing.Color.DimGray
        Me.optStopStatus1.Location = New System.Drawing.Point(16, 45)
        Me.optStopStatus1.Name = "optStopStatus1"
        Me.optStopStatus1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optStopStatus1.Size = New System.Drawing.Size(89, 25)
        Me.optStopStatus1.TabIndex = 7
        Me.optStopStatus1.Text = "Non-Active"
        Me.optStopStatus1.UseVisualStyleBackColor = False
        '
        'optStopStatus0
        '
        Me.optStopStatus0.BackColor = System.Drawing.Color.Transparent
        Me.optStopStatus0.Checked = True
        Me.optStopStatus0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optStopStatus0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optStopStatus0.ForeColor = System.Drawing.Color.DimGray
        Me.optStopStatus0.Location = New System.Drawing.Point(16, 19)
        Me.optStopStatus0.Name = "optStopStatus0"
        Me.optStopStatus0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optStopStatus0.Size = New System.Drawing.Size(89, 25)
        Me.optStopStatus0.TabIndex = 6
        Me.optStopStatus0.TabStop = True
        Me.optStopStatus0.Text = "Active"
        Me.optStopStatus0.UseVisualStyleBackColor = False
        '
        'cboCountyOption
        '
        Me.cboCountyOption.BackColor = System.Drawing.SystemColors.Window
        Me.cboCountyOption.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboCountyOption.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCountyOption.Enabled = False
        Me.cboCountyOption.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCountyOption.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboCountyOption.Location = New System.Drawing.Point(283, 326)
        Me.cboCountyOption.Name = "cboCountyOption"
        Me.cboCountyOption.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboCountyOption.Size = New System.Drawing.Size(137, 22)
        Me.cboCountyOption.TabIndex = 76
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(251, 327)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(27, 17)
        Me.Label2.TabIndex = 77
        Me.Label2.Text = "By County:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'optBusStop6
        '
        Me.optBusStop6.BackColor = System.Drawing.Color.Transparent
        Me.optBusStop6.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStop6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStop6.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStop6.Location = New System.Drawing.Point(156, 327)
        Me.optBusStop6.Name = "optBusStop6"
        Me.optBusStop6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStop6.Size = New System.Drawing.Size(81, 17)
        Me.optBusStop6.TabIndex = 75
        Me.optBusStop6.Text = "Amenities"
        Me.optBusStop6.UseVisualStyleBackColor = False
        '
        'optBusStop5
        '
        Me.optBusStop5.BackColor = System.Drawing.Color.Transparent
        Me.optBusStop5.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStop5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStop5.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStop5.Location = New System.Drawing.Point(52, 327)
        Me.optBusStop5.Name = "optBusStop5"
        Me.optBusStop5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStop5.Size = New System.Drawing.Size(81, 17)
        Me.optBusStop5.TabIndex = 74
        Me.optBusStop5.Text = "ADA Status"
        Me.optBusStop5.UseVisualStyleBackColor = False
        '
        'txtOCTAID
        '
        Me.txtOCTAID.AcceptsReturn = True
        Me.txtOCTAID.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtOCTAID.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtOCTAID.Enabled = False
        Me.txtOCTAID.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtOCTAID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOCTAID.Location = New System.Drawing.Point(124, 224)
        Me.txtOCTAID.MaxLength = 0
        Me.txtOCTAID.Name = "txtOCTAID"
        Me.txtOCTAID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtOCTAID.Size = New System.Drawing.Size(81, 20)
        Me.txtOCTAID.TabIndex = 73
        '
        'optBusStop4
        '
        Me.optBusStop4.BackColor = System.Drawing.Color.Transparent
        Me.optBusStop4.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStop4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStop4.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStop4.Location = New System.Drawing.Point(52, 224)
        Me.optBusStop4.Name = "optBusStop4"
        Me.optBusStop4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStop4.Size = New System.Drawing.Size(73, 17)
        Me.optBusStop4.TabIndex = 72
        Me.optBusStop4.Text = "OCTA ID:"
        Me.optBusStop4.UseVisualStyleBackColor = False
        '
        'optBusStopHistory0
        '
        Me.optBusStopHistory0.BackColor = System.Drawing.Color.Transparent
        Me.optBusStopHistory0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStopHistory0.Enabled = False
        Me.optBusStopHistory0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStopHistory0.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStopHistory0.Location = New System.Drawing.Point(71, 248)
        Me.optBusStopHistory0.Name = "optBusStopHistory0"
        Me.optBusStopHistory0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStopHistory0.Size = New System.Drawing.Size(145, 17)
        Me.optBusStopHistory0.TabIndex = 70
        Me.optBusStopHistory0.Text = "All History"
        Me.optBusStopHistory0.UseVisualStyleBackColor = False
        '
        'optBusStopHistory1
        '
        Me.optBusStopHistory1.BackColor = System.Drawing.Color.Transparent
        Me.optBusStopHistory1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStopHistory1.Enabled = False
        Me.optBusStopHistory1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStopHistory1.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStopHistory1.Location = New System.Drawing.Point(71, 272)
        Me.optBusStopHistory1.Name = "optBusStopHistory1"
        Me.optBusStopHistory1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStopHistory1.Size = New System.Drawing.Size(145, 17)
        Me.optBusStopHistory1.TabIndex = 71
        Me.optBusStopHistory1.Text = "Work Order History"
        Me.optBusStopHistory1.UseVisualStyleBackColor = False
        '
        'optBusStop2
        '
        Me.optBusStop2.BackColor = System.Drawing.Color.Transparent
        Me.optBusStop2.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStop2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStop2.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStop2.Location = New System.Drawing.Point(53, 131)
        Me.optBusStop2.Name = "optBusStop2"
        Me.optBusStop2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStop2.Size = New System.Drawing.Size(95, 17)
        Me.optBusStop2.TabIndex = 65
        Me.optBusStop2.Text = "Surveyed"
        Me.optBusStop2.UseVisualStyleBackColor = False
        '
        'optBusStop3
        '
        Me.optBusStop3.BackColor = System.Drawing.Color.Transparent
        Me.optBusStop3.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStop3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStop3.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStop3.Location = New System.Drawing.Point(53, 159)
        Me.optBusStop3.Name = "optBusStop3"
        Me.optBusStop3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStop3.Size = New System.Drawing.Size(95, 17)
        Me.optBusStop3.TabIndex = 66
        Me.optBusStop3.Text = "Not Surveyed"
        Me.optBusStop3.UseVisualStyleBackColor = False
        '
        'cboStreet
        '
        Me.cboStreet.BackColor = System.Drawing.SystemColors.Menu
        Me.cboStreet.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboStreet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStreet.Enabled = False
        Me.cboStreet.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboStreet.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboStreet.Location = New System.Drawing.Point(175, 66)
        Me.cboStreet.Name = "cboStreet"
        Me.cboStreet.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboStreet.Size = New System.Drawing.Size(169, 22)
        Me.cboStreet.TabIndex = 44
        '
        'cboByJurisd
        '
        Me.cboByJurisd.BackColor = System.Drawing.SystemColors.Window
        Me.cboByJurisd.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboByJurisd.DataSource = Me.CITYCODEBindingSource
        Me.cboByJurisd.DisplayMember = "CITY"
        Me.cboByJurisd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboByJurisd.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboByJurisd.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboByJurisd.Location = New System.Drawing.Point(175, 38)
        Me.cboByJurisd.Name = "cboByJurisd"
        Me.cboByJurisd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboByJurisd.Size = New System.Drawing.Size(169, 22)
        Me.cboByJurisd.TabIndex = 42
        Me.cboByJurisd.ValueMember = "ID"
        '
        'optBusStop1
        '
        Me.optBusStop1.BackColor = System.Drawing.Color.Transparent
        Me.optBusStop1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStop1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStop1.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStop1.Location = New System.Drawing.Point(55, 66)
        Me.optBusStop1.Name = "optBusStop1"
        Me.optBusStop1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStop1.Size = New System.Drawing.Size(121, 21)
        Me.optBusStop1.TabIndex = 43
        Me.optBusStop1.Text = "Bus Stops on Street"
        Me.optBusStop1.UseVisualStyleBackColor = False
        '
        'optBusStop0
        '
        Me.optBusStop0.BackColor = System.Drawing.Color.Transparent
        Me.optBusStop0.Checked = True
        Me.optBusStop0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optBusStop0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optBusStop0.ForeColor = System.Drawing.Color.DimGray
        Me.optBusStop0.Location = New System.Drawing.Point(55, 40)
        Me.optBusStop0.Name = "optBusStop0"
        Me.optBusStop0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optBusStop0.Size = New System.Drawing.Size(113, 17)
        Me.optBusStop0.TabIndex = 41
        Me.optBusStop0.TabStop = True
        Me.optBusStop0.Text = "Bus Stops by City"
        Me.optBusStop0.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(354, 70)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(57, 17)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "Within City of"
        '
        'cboWithinJurisd
        '
        Me.cboWithinJurisd.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.cboWithinJurisd.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboWithinJurisd.DataSource = Me.CITYCODEBindingSource
        Me.cboWithinJurisd.DisplayMember = "CITY"
        Me.cboWithinJurisd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboWithinJurisd.Enabled = False
        Me.cboWithinJurisd.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboWithinJurisd.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboWithinJurisd.Location = New System.Drawing.Point(414, 66)
        Me.cboWithinJurisd.Name = "cboWithinJurisd"
        Me.cboWithinJurisd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboWithinJurisd.Size = New System.Drawing.Size(81, 22)
        Me.cboWithinJurisd.TabIndex = 45
        Me.cboWithinJurisd.ValueMember = "ID"
        '
        'cboStreetGhost
        '
        Me.cboStreetGhost.BackColor = System.Drawing.SystemColors.Window
        Me.cboStreetGhost.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboStreetGhost.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboStreetGhost.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboStreetGhost.Location = New System.Drawing.Point(-178, 117)
        Me.cboStreetGhost.Name = "cboStreetGhost"
        Me.cboStreetGhost.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboStreetGhost.Size = New System.Drawing.Size(169, 22)
        Me.cboStreetGhost.TabIndex = 39
        Me.cboStreetGhost.Visible = False
        '
        'frmRptBusStop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(702, 401)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmRptBusStop"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Bus Stop Reports"
        CType(Me.ADASTATUSCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsADAStatusDescBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsADAStatusDesc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CITYCODEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsCityCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusStopManagementDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.Frame5.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Public WithEvents cmdCancel As Button
    Public WithEvents cmdPrint As Button
    Public WithEvents Shape1 As Label
    Friend WithEvents BusStopManagementDataSet1 As BusStopManagementDataSet1
    Friend WithEvents DsADAStatusDescBindingSource As BindingSource
    Friend WithEvents DsADAStatusDesc As dsADAStatusDesc
    Friend WithEvents ADASTATUSCODEBindingSource As BindingSource
    Friend WithEvents ADA_STATUS_CODETableAdapter As dsADAStatusDescTableAdapters.ADA_STATUS_CODETableAdapter
    Friend WithEvents DsCityCode As dsCityCode
    Friend WithEvents CITYCODEBindingSource As BindingSource
    Friend WithEvents CITY_CODETableAdapter As dsCityCodeTableAdapters.CITY_CODETableAdapter
    Friend WithEvents Panel1 As Panel
    Public WithEvents Frame5 As GroupBox
    Public WithEvents optStopStatus2 As RadioButton
    Public WithEvents optStopStatus1 As RadioButton
    Public WithEvents optStopStatus0 As RadioButton
    Public WithEvents cboCountyOption As ComboBox
    Public WithEvents Label2 As Label
    Public WithEvents optBusStop6 As RadioButton
    Public WithEvents optBusStop5 As RadioButton
    Public WithEvents txtOCTAID As TextBox
    Public WithEvents optBusStop4 As RadioButton
    Public WithEvents optBusStopHistory0 As RadioButton
    Public WithEvents optBusStopHistory1 As RadioButton
    Public WithEvents cboADAJurisd As ComboBox
    Public WithEvents optBusStopADA0 As RadioButton
    Public WithEvents optBusStopADA1 As RadioButton
    Public WithEvents optBusStop2 As RadioButton
    Public WithEvents optBusStop3 As RadioButton
    Public WithEvents cboStreet As ComboBox
    Public WithEvents cboByJurisd As ComboBox
    Public WithEvents optBusStop1 As RadioButton
    Public WithEvents optBusStop0 As RadioButton
    Public WithEvents Label1 As Label
    Public WithEvents cboWithinJurisd As ComboBox
    Public WithEvents cboStreetGhost As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
End Class
