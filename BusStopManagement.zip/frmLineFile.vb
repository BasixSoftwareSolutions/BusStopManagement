﻿Imports System.Data.SqlClient
Imports System.Data
Public Class frmLineFile
    Dim bLoad As Boolean = False
    Public currentOCTA_ID As Integer

    Public Sub ReloadRoutes()
        LoadRoutes()
        cboRouteDir.DataSource = Nothing
        RouteGrid.DataMember = Nothing
        txtRouteDes.Text = ""
        ' Disable some buttons
        ButtonStatus(False)
    End Sub
    Private Sub LoadRoutes()
        Dim strSQL As String = ""
        Dim rs As New ADODB.Recordset

        If optActive.Checked Then
            strSQL = "SELECT DISTINCT RTE FROM tblRoutes WHERE ACTIVE = 1 ORDER BY RTE"
        Else
            strSQL = "SELECT DISTINCT RTE FROM tblRoutes WHERE ACTIVE = 0 ORDER BY RTE"
        End If

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        cboRouteNo.Items.Clear()

        Do While Not rs.EOF
            cboRouteNo.Items.Add(rs.Fields("RTE").Value)
            rs.MoveNext()
        Loop

        rs.Close()
        rs = Nothing

    End Sub
    Private Sub optInActive_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles optInactive.CheckedChanged
        If eventSender.Checked Then
            RouteGrid.DataSource = Nothing
            cboRouteDir.DataSource = Nothing
            txtRouteDes.Text = ""
            cmdDeleteRoute.Enabled = False
            LoadRoutes()
            ButtonStatus(False)
        End If
    End Sub
    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub
    Private Sub LoadDesignation(ByRef aRoute As Short, ByRef aDirID As Byte)

        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT rdc.DESCRIPTION FROM tblRoutes AS a " & "LEFT JOIN ROUTE_DESIGNATION_CODE AS rdc ON a.RTE_DESIGNATION_ID = rdc.ID " & "WHERE a.RTE = " & aRoute & " AND a.RTE_DIR_ID = " & aDirID
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not rs.EOF Then
            txtRouteDes.Text = IIf(IsDBNull(rs.Fields("DESCRIPTION").Value), "NOT SET", rs.Fields("DESCRIPTION").Value)
        End If

        rs.Close()
        rs = Nothing
        Exit Sub

errHandler:
        MsgBox(Err.Description)
    End Sub

    Private Sub frmLineFile_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim l As Single = (BSMMain.ClientSize.Width - Me.Width) / 2
        Dim t As Single = ((BSMMain.ClientSize.Height - Me.Height) / 2) - 30
        Me.SetBounds(l, t, Me.Width, Me.Height)
        Me.MdiParent = BSMMain
        Me.RouteGrid.Width = 0.94 * Me.Width
        Me.RouteGrid.Height = 0.68 * Me.Height
        Call LoadRoutes()

    End Sub

    Private Sub cboRouteNo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboRouteNo.SelectedIndexChanged
        Dim strSQL As String = ""

        If cboRouteNo.SelectedIndex <> -1 Then
            RouteGrid.DataSource = Nothing
            ROUTE_ID = cboRouteNo.Text

            If optActive.Checked Then
                strSQL = "SELECT dir.DESCRIPTION, dir.ID FROM ROUTE_DIR_CODE AS dir " & "INNER JOIN (SELECT RTE_DIR_ID FROM tblRoutes " & "WHERE ACTIVE = 1 AND RTE = " & cboRouteNo.Text & ") AS bss ON dir.ID = bss.RTE_DIR_ID " & "ORDER BY dir.ID"
            ElseIf optInactive.Checked Then
                strSQL = "SELECT dir.DESCRIPTION, dir.ID FROM ROUTE_DIR_CODE AS dir " & "INNER JOIN (SELECT RTE_DIR_ID FROM tblRoutes " & "WHERE ACTIVE = 0 AND RTE = " & cboRouteNo.Text & ") AS bss ON dir.ID = bss.RTE_DIR_ID " & "ORDER BY dir.ID"
            End If

            cboRouteDir.DisplayMember = "DESCRIPTION"
            cboRouteDir.ValueMember = "ID"
            Dim tb As New DataTable
            tb.Columns.Add("DESCRIPTION", GetType(String))
            tb.Columns.Add("ID", GetType(Integer))

            Dim rs = New ADODB.Recordset
            rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

            If rs.RecordCount <> 0 Then rs.MoveLast()
            If rs.RecordCount > 0 Then
                rs.MoveFirst()
                Do While rs.EOF = False
                    tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                    rs.MoveNext()
                Loop
            End If
            bLoad = False
            cboRouteDir.DataSource = tb
            cboRouteDir.Enabled = True
            bLoad = True
            ' Disable some buttons
            ButtonStatus(False)
            txtRouteDes.Text = ""
        Else
            cboRouteDir.Enabled = False
        End If

        cboRouteDir.Text = ""

    End Sub

    Private Sub ButtonStatus(ByRef setActive As Boolean)

        ' Enable/Disable some buttons
        cmdEditRoute.Enabled = setActive
        cmdCopyRoute.Enabled = setActive

        If setActive And optActive.Checked Then
            cmdDeleteRoute.Enabled = True
        Else
            cmdDeleteRoute.Enabled = False
        End If

        cmdAddStop.Enabled = setActive
        cmdEditStop.Enabled = setActive
        cmdDeleteStop.Enabled = setActive
        cmdReSeqStop.Enabled = setActive
        cmdStopDetails.Enabled = setActive

    End Sub

    Public Sub LoadStops4Route(ByRef aRoute As Short, ByRef aDirID As Byte)

        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT bss.OCTA_ID, bss.SANZ_ID, sdc.DIR, " _
                    & "(bsi.STREET_OF_TRAVEL + ' ' + stc1.TYPE) AS FULL_STREET, " _
                    & "blc.LOC, (bsi.CROSS_STREET + ' ' + stc2.TYPE) AS FULL_XSTREET, " _
                    & "bsi.CROSS_STREET_1, bss.TIMEPOINT, " _
                    & "bss.SEQ, bss.HARDWARE, bss.TRANSFERS, rcc.DESCRIPTION " _
                    & "FROM (((((tblBusStopSequences AS bss " _
                    & "LEFT JOIN tblBusStopInformation AS bsi ON bss.OCTA_ID = bsi.OCTA_ID) " _
                    & "LEFT JOIN ST_DIR_CODE AS sdc ON bsi.ST_DIR_ID = sdc.ID) " _
                    & "LEFT JOIN ST_TYPE_CODE AS stc1 ON ((bsi.ST_TYPE_ID_1 = stc1.ID) " _
                    & "OR (bsi.ST_TYPE_ID_1 IS NULL AND stc1.ID = 0))) " _
                    & "LEFT JOIN BS_LOC_CODE AS blc ON bsi.BS_LOC_ID = blc.ID) " _
                    & "LEFT JOIN ST_TYPE_CODE AS stc2 ON ((bsi.ST_TYPE_ID_2 = stc2.ID) " _
                    & "OR (bsi.ST_TYPE_ID_2 IS NULL AND stc2.ID = 0))) " _
                    & "LEFT JOIN ROUTE_COMMENT_CODE AS rcc ON bss.COMMENTS = rcc.ID " _
                    & "WHERE bss.RTE = " & aRoute & " AND bss.RTE_DIR_ID = " & aDirID & " ORDER BY bss.SEQ"

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)

        Dim oConn As New SqlConnection(sConn)
        Dim dataadapter As New SqlDataAdapter(strSQL, oConn)
        Dim ds As New DataSet()
        oConn.Open()
        dataadapter.Fill(ds, "LoadSearchGrid")
        oConn.Close()

        RouteGrid.DataSource = ds
        RouteGrid.DataMember = "LoadSearchGrid"

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cboRouteDir_SelectedValueChanged(sender As Object, e As EventArgs) Handles cboRouteDir.SelectedValueChanged
        Dim bDir As Byte

        If bLoad Then
            bDir = cboRouteDir.SelectedValue
            DIR_ID = bDir
            LoadStops4Route(CInt(cboRouteNo.Text), bDir)
            LoadDesignation(CInt(cboRouteNo.Text), bDir)

            ' Enable some buttons
            Call ButtonStatus(True)
        End If
    End Sub

    Private Sub RouteGrid_SelectionChanged(sender As Object, e As EventArgs) Handles RouteGrid.SelectionChanged
        On Error GoTo ErrorMessage

        Dim i As Integer

        i = RouteGrid.CurrentRow.Index
        ROUTE_ID = cboRouteNo.Text
        ROUTE_DESC = txtRouteDes.Text
        DIR_DESC = cboRouteDir.Text
        OCTA_ID = RouteGrid.Item(0, i).Value
        SANZ_ID = RouteGrid.Item(1, i).Value
        SeqLowerBound = RouteGrid.Item(8, i).Value
        If (i + 1) < RouteGrid.Rows.Count Then
            SeqUpperBound = RouteGrid.Item(8, RouteGrid.Rows.Count - 2).Value
        Else
            SeqUpperBound = 0
        End If

        Exit Sub

ErrorMessage:
        MsgBox(Err.Description)
    End Sub

    Private Sub cmdEditRoute_Click(sender As Object, e As EventArgs) Handles cmdEditRoute.Click

        frmLineFileRouteEdit.ShowDialog()

    End Sub

    Private Sub cmdDeleteRoute_Click(sender As Object, e As EventArgs) Handles cmdDeleteRoute.Click

        If MsgBox("Deactivate route: " & cboRouteNo.Text & " (" & cboRouteDir.Text & ")?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            UpdateDeleteOnlyRoute()
            LoadRoutes()
            cboRouteDir.DataSource = Nothing
            ' Disable some buttons
            ButtonStatus(False)
            RouteGrid.DataSource = Nothing

        End If
    End Sub

    Private Sub UpdateDeleteOnlyRoute()
        Dim strSQL As String
        Dim dt As String
        On Error GoTo errHandler

        dt = Date.Now.ToShortDateString

        strSQL = "UPDATE tblRoutes SET EFFECTIVE_DATE = '" & dt & "', ACTIVE =  0" & " WHERE RTE = " & cboRouteNo.Text & " AND RTE_DIR_ID = " & cboRouteDir.SelectedValue

        db.Execute(strSQL)

        ' Check if Stop is being use for other active route or routes
        ' If not inactivate stop
        Dim i, OID, j As Short
        Dim rs As New ADODB.Recordset
        Dim rs2 As New ADODB.Recordset
        Dim typeID As Short
        Dim remarks As String
        Dim sanzid As String
        Dim tempDt As String
        Dim direction As String

        typeID = 26

        strSQL = "SELECT * FROM tblBusStopSequences bs, ROUTE_DIR_CODE rdc" & " WHERE bs.RTE = " & cboRouteNo.Text & " AND bs.RTE_DIR_ID = " & cboRouteDir.SelectedValue & " AND bs.RTE_DIR_ID = rdc.ID"

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

        If rs.RecordCount > 0 Then

            rs.MoveFirst()
            For i = 0 To rs.RecordCount - 1

                OID = rs.Fields("OCTA_ID").Value
                sanzid = rs.Fields("SANZ_ID").Value
                direction = rs.Fields("DIR").Value

                'route is deactivated
                strSQL = "SELECT * FROM tblBusStopSequences ts, tblRoutes tr" & " WHERE ts.OCTA_ID = " & OID & " AND ts.RTE = tr.RTE AND ts.RTE_DIR_ID =" & " tr.RTE_DIR_ID AND tr.ACTIVE = 1"

                rs2.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                If rs2.RecordCount < 1 Then ' Stop is deactivated, as it is taken out of all routes
                    strSQL = "UPDATE tblBusStopInformation SET ACTIVE_STOP = 0 WHERE " & "OCTA_ID = " & OID

                    remarks = "'BUS STOP REMOVED AND WILL NO LONGER BE SERVICED BY ROUTE # " & cboRouteNo.Text & " " & direction & "'"
                    db.Execute(strSQL)
                Else ' Leave it alone, just make the history entry
                    remarks = "'ROUTE # " & cboRouteNo.Text & " " & direction & " WILL NO LONGER PROVIDE SERVICE TO THIS STOP'"
                End If

                rs2.Close()

                ' Make stop history entry
                strSQL = "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) VALUES (" & OID & "," & "'" & sanzid & "'" & ",'" & dt & "'," & CurrentLoginUserID & "," & typeID & "," & remarks & ");"

                db.Execute(strSQL)

                rs.MoveNext()
            Next i

            rs.Close()
        End If

        MsgBox("Route Deactivated", MsgBoxStyle.Information)

        Exit Sub

errHandler:
        MsgBox(Err.Description)
    End Sub

    Private Sub cmdReSeqStop_Click(sender As Object, e As EventArgs) Handles cmdReSeqStop.Click
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim intSeq As Short
        Dim bDir As Byte

        If MsgBox("Re-sequence bus stops?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

            strSQL = "UPDATE tblBusStopSequences SET SEQ = (SEQ + 10000) WHERE " & "RTE = " & cboRouteNo.Text & " AND RTE_DIR_ID = " & cboRouteDir.SelectedValue
            db.Execute(strSQL)

            strSQL = "SELECT * FROM tblBusStopSequences WHERE " & "RTE = " & cboRouteNo.Text & " AND RTE_DIR_ID = " & cboRouteDir.SelectedValue & " ORDER BY SEQ"

            rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

            intSeq = 10
            Do While Not rs.EOF
                strSQL = "UPDATE tblBusStopSequences SET SEQ = " & intSeq & " WHERE RTE = " & rs.Fields("RTE").Value & " AND RTE_DIR_ID = " & rs.Fields("RTE_DIR_ID").Value & " AND SEQ = " & rs.Fields("SEQ").Value & " AND OCTA_ID = " & rs.Fields("OCTA_ID").Value
                db.Execute(strSQL)

                intSeq = intSeq + 10
                rs.MoveNext()
            Loop

            rs.Close()

            bDir = cboRouteDir.SelectedValue
            LoadStops4Route(CShort(cboRouteNo.Text), bDir)
            LoadDesignation(CShort(cboRouteNo.Text), bDir)

            MsgBox("Bus Stops have been resequenced.", vbInformation, "Process complete.")

        End If

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdCreateRoute_Click(sender As Object, e As EventArgs) Handles cmdCreateRoute.Click

        frmLineFileRouteAdd.ShowDialog()

    End Sub

    Private Sub cmdCopyRoute_Click(sender As Object, e As EventArgs) Handles cmdCopyRoute.Click

        frmLineFileRouteCopy.ShowDialog()

    End Sub


    Private Sub cmdDeleteStop_Click(sender As Object, e As EventArgs) Handles cmdDeleteStop.Click

        frmLineFileDelOpt.DefInstance.Text = "DELETE OCTA_ID No. " & OCTA_ID & " FROM:"
        frmLineFileDelOpt.DefInstance.ShowDialog()

        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim myDate As Date
        Dim rsDir As New ADODB.Recordset
        Dim rteDir As String
        Dim remarks As String
        Dim typeID As Short
        If DELETE_STOP_FLAG = 0 Then
            If MsgBox("Delete stop " & OCTA_ID & " from Route?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                strSQL = "DELETE FROM tblBusStopSequences WHERE RTE = " & cboRouteNo.Text & " AND RTE_DIR_ID = " & cboRouteDir.SelectedValue & " AND SEQ = " & SeqLowerBound & " AND OCTA_ID = " & OCTA_ID
                db.Execute(strSQL)

                ' Delete Landmarks for stop and route, Added by Anuket 8/23/04
                strSQL = "DELETE FROM tblBusStopLandmarks WHERE RTE = " & cboRouteNo.Text & " AND OCTA_ID = " & OCTA_ID & " AND DIRECTION = '" & cboRouteDir.Text & "'"
                db.Execute(strSQL)

                ' Check if Stop is being use for other route...
                strSQL = "SELECT TOP 1 * FROM tblBusStopSequences AS bss " & "LEFT JOIN tblRoutes AS rts ON (bss.RTE = rts.RTE " & "AND bss.RTE_DIR_ID = rts.RTE_DIR_ID AND rts.ACTIVE = 1) " & "WHERE bss.OCTA_ID = " & OCTA_ID

                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

                myDate = Today

                ' Stop History, deleted from single route may be all but 2 entries needed

                strSQL = "SELECT DIR FROM ROUTE_DIR_CODE WHERE ID = '" & DIR_ID & "'"
                rsDir.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
                rsDir.MoveFirst()

                rteDir = rsDir.Fields(0).Value

                rsDir.Close()

                remarks = "'BUS STOP WAS REMOVED FROM ROUTE " & cboRouteNo.Text & " " & rteDir & "'"
                typeID = 26

                strSQL = "" & "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) VALUES (" & OCTA_ID & ",'" & SANZ_ID & "','" & myDate & "'," & CurrentLoginUserID & "," & typeID & "," & remarks & ");"
                db.Execute(strSQL)

                If rs.EOF Then ' not being used in any other places..
                    ' Set Stop status to inactive...
                    strSQL = "UPDATE tblBusStopInformation SET ACTIVE_STOP = 0 " & "WHERE OCTA_ID = " & OCTA_ID
                    db.Execute(strSQL)

                    remarks = "'BUS STOP WAS REMOVED FROM ALL ROUTES AND IS NOW INACTIVE'"
                    typeID = 4

                    strSQL = "" & "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) VALUES (" & OCTA_ID & ",'" & SANZ_ID & "','" & myDate & "'," & CurrentLoginUserID & "," & typeID & "," & remarks & ");"

                    db.Execute(strSQL)

                End If

                rs.Close()
                rs = Nothing

                ' reload...
                LoadStops4Route(CShort(cboRouteNo.Text), cboRouteDir.SelectedValue)
            End If
        ElseIf DELETE_STOP_FLAG = 1 Then
            frmLineFileDeleteStop.DefInstance.Text = "DELETE OCTA_ID No. " & OCTA_ID & " FROM:"
            frmLineFileDeleteStop.DefInstance.ShowDialog()

            ' reload...
            LoadStops4Route(CShort(cboRouteNo.Text), cboRouteDir.SelectedValue)

        Else
            Exit Sub
        End If

    End Sub

    Private Sub cmdEditStop_Click(sender As Object, e As EventArgs) Handles cmdEditStop.Click

        If OCTA_ID <> 0 Then
            frmLineFileStopEdit.ShowDialog()
        End If

    End Sub

    Private Sub cmdAddStop_Click(sender As Object, e As EventArgs) Handles cmdAddStop.Click

        frmLineFileSearchStop.ShowDialog()

    End Sub

    Private Sub frmLineFile_Resize(sender As Object, e As EventArgs) Handles Me.Resize

        Me.RouteGrid.Width = 0.94 * Me.Width
        Me.RouteGrid.Height = 0.68 * Me.Height

    End Sub

    Private Sub cmdStopDetails_Click(sender As Object, e As EventArgs) Handles cmdStopDetails.Click
        Dim vRow As Integer

        If RouteGrid.CurrentRow.Index < 0 Then Exit Sub
        vRow = RouteGrid.CurrentRow.Index
        currentOCTA_ID = RouteGrid.Item(0, vRow).Value

        frmUpdateStop.Show()

        If currentOCTA_ID <> 0 Then
            frmUpdateStop.GoToStopID(currentOCTA_ID)
        Else
            MsgBox("Please select a stop.")
        End If

    End Sub
End Class