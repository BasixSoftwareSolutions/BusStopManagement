﻿Public Class frmWorkOrderCompletion

    Private intWOID As Integer
    Private strSQL As String
    Dim strSANZ_ID As String

    Private Sub cmdAdd_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAdd.Click

        frmAddMEmployee.DefInstance.ShowDialog()
        Call RefreshNewEmployee()

    End Sub

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdClear_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClear.Click
        txtWONum.Text = ""
        txtOCTAID.Text = ""
        strSANZ_ID = ""
        txtIssDate.Text = ""
        txtIssBy.Text = ""
        txtLocation1.Text = ""
        txtLocation2.Text = ""
        txtLocation3.Text = ""
        txtCity.Text = ""
        txtCost.Text = ""

        dtpCompDate.Value = GetToken(CStr(Now), 1, " ")

        cboCompletedBy.SelectedIndex = -1

        txtRemarks.Text = ""

        cbxNeedGPS.CheckState = System.Windows.Forms.CheckState.Unchecked
        cbxNeedIns.CheckState = System.Windows.Forms.CheckState.Unchecked

        intWOID = 0
        txtWONum.Focus()
    End Sub

    Public Sub cmdFindWO_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdFindWO.Click

        Call FindWO()

    End Sub

    Public Sub FindWO()
        On Error GoTo errHandler

        Dim rsWOInfo As New ADODB.Recordset

        ' Check to make sure a valid WO number is entered
        If txtWONum.Text <> "" And IsNumeric(txtWONum.Text) Then
            intWOID = CInt(txtWONum.Text)
            strSQL = "SELECT wo.OCTA_ID, wo.SANZ_ID, wo.WO_DATE_ISSUED, wo.WO_ISSUED_BY, " & "(sdc.DIR + ' ' + tbi.STREET_OF_TRAVEL) AS FULL_STREET, " & "(blc.LOC + ' ' + tbi.CROSS_STREET) AS FULL_XSTREET, " & "tbi.CROSS_STREET_1, cc.CITY FROM (((tblWorkOrders AS wo " & "LEFT JOIN tblBusStopInformation AS tbi ON wo.OCTA_ID = tbi.OCTA_ID) " & "LEFT JOIN ST_DIR_CODE AS sdc ON tbi.ST_DIR_ID = sdc.ID) " & "LEFT JOIN BS_LOC_CODE AS blc ON tbi.BS_LOC_ID = blc.ID) " & "LEFT JOIN CITY_CODE AS cc ON tbi.CITY_ID = cc.ID " & "WHERE wo.WO_COMPLETE_DATE IS NULL AND wo.WO_ID = " & intWOID
            rsWOInfo.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)

            ' check to see if there is a pending work order with that number
            If rsWOInfo.RecordCount <> 0 Then
                txtOCTAID.Text = rsWOInfo.Fields("OCTA_ID").Value
                strSANZ_ID = rsWOInfo.Fields("SANZ_ID").Value
                txtIssDate.Text = rsWOInfo.Fields("WO_DATE_ISSUED").Value
                txtIssBy.Text = rsWOInfo.Fields("WO_ISSUED_BY").Value
                txtLocation1.Text = rsWOInfo.Fields("FULL_STREET").Value
                txtLocation2.Text = rsWOInfo.Fields("FULL_XSTREET").Value
                If Not IsDBNull(rsWOInfo.Fields("CROSS_STREET_1").Value) Then
                    txtLocation3.Text = rsWOInfo.Fields("CROSS_STREET_1").Value
                End If
                txtCity.Text = rsWOInfo.Fields("CITY").Value

                cboCompletedBy.SelectedIndex = -1

                If txtOCTAID.Text <> "" Then SetFlags()

            Else
                MsgBox("Work Order Number: " & txtWONum.Text & " doesn't exist OR has already been closed!", MsgBoxStyle.Information)
                cmdClear_Click(cmdClear, New System.EventArgs())
                Exit Sub
            End If
        Else
            MsgBox("Please enter a numeric value for work order number to search.", MsgBoxStyle.Information)
            txtWONum.SelectionStart = 0
            txtWONum.SelectionLength = Len(txtWONum.Text)
            txtWONum.Focus()
        End If

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdSearch_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSearch.Click

        frmOpenWO.ShowDialog()

    End Sub

    Private Sub cmdSubmit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSubmit.Click
        On Error GoTo errHandler

        Dim trs As New ADODB.Recordset
        Dim tempStr As String
        Dim cmpBy As Short

        strSQL = "SELECT * FROM tblMaintenanceEmployees;"

        trs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)

        If trs.RecordCount > 0 Then
            trs.MoveFirst()
            Do While Not trs.EOF
                tempStr = trs.Fields(1).Value + " " + trs.Fields(2).Value
                If cboCompletedBy.Text = tempStr Then
                    cmpBy = trs.Fields(0).Value
                End If
                trs.MoveNext()
            Loop
        End If

        trs.Close()

        tempStr = CStr(cmpBy)

        Dim intHistoryType As Short
        Dim strRemarks As String

        ' re-check the WO number
        If intWOID <> 0 Then

            If Not IsNumeric(txtCost.Text) Then
                MsgBox("Please enter a value for work order cost.", MsgBoxStyle.Exclamation)
                txtCost.Focus()
                Exit Sub
            End If

            ' make sure required fields are filled out
            If cboCompletedBy.SelectedIndex <> -1 And IsDate(dtpCompDate.Value) Then
                If CheckCompletedDate() Then
                    ' update the database with new information
                    strSQL = "UPDATE tblWorkOrders SET WO_COMPLETED_BY = " & "'" & cboCompletedBy.Text & "'" & ", " & "WO_COMPLETE_DATE = '" & dtpCompDate.Value & "', " & "WO_REMARKS = " & cV2Q_String((txtRemarks.Text)) & ", " & "WO_COST = " & CSng(txtCost.Text) & " WHERE WO_ID = " & intWOID

                    db.Execute(strSQL)

                    UpdateFlags()

                    intHistoryType = 23 ' Work Order...

                    If txtRemarks.Text = "" Then
                        strRemarks = "WORK ORDER NO. " & intWOID & " COMPLETED"
                    Else
                        strRemarks = "WORK ORDER NO. " & intWOID & " COMPLETED. " & txtRemarks.Text
                    End If
                    ' Save a record into History table...
                    'strSQL = "INSERT INTO tblStopHistory (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, HISTORY_TYPE_ID, WO_NUM, " & "REMARKS) VALUES (" & txtOCTAID.Text & ", '" & strSANZ_ID & "', '" & dtpCompDate.Value & "', " & CurrentLoginUserID & ", " & intHistoryType & ", " & intWOID & ", '" & strRemarks & "')"

                    MsgBox("Work Order " & intWOID & " has been completed.", vbInformation, "Complete")
                    cmdClear_Click(cmdClear, New System.EventArgs())
                End If
            Else
                MsgBox("Please fill out the required fields:" & vbCrLf & "('Completed by' and 'Completion date')")
            End If
        Else
            MsgBox("Please find the work order first.")
        End If

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Function CheckCompletedDate() As Boolean
        If txtIssDate.Text <> "" Then
            If IsDate(txtIssDate.Text) Then
                If CDate(txtIssDate.Text) > dtpCompDate.Value Then
                    MsgBox("Invalid completion date! It must be later than Issued date.", MsgBoxStyle.Exclamation)
                    dtpCompDate.Focus()
                    CheckCompletedDate = False
                    Exit Function
                End If
            End If
        End If

        CheckCompletedDate = True
    End Function

    Private Sub UpdateFlags()
        Dim strSQL As String

        If cbxNeedGPS.CheckState = System.Windows.Forms.CheckState.Checked Then
            strSQL = "UPDATE tblStopCoord SET GPS_REQUIRED = 1 WHERE OCTA_ID = " & txtOCTAID.Text
        Else
            strSQL = "UPDATE tblStopCoord SET GPS_REQUIRED = 0 WHERE OCTA_ID = " & txtOCTAID.Text
        End If
        db.Execute(strSQL)

        If cbxNeedIns.CheckState = System.Windows.Forms.CheckState.Checked Then
            strSQL = "UPDATE tblSignCassette SET PERM_INSERT = 1 WHERE OCTA_ID = " & txtOCTAID.Text
        Else
            strSQL = "UPDATE tblSignCassette SET PERM_INSERT = 0 WHERE OCTA_ID = " & txtOCTAID.Text
        End If
        db.Execute(strSQL)

    End Sub

    Private Sub frmWorkOrderCompletion_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Dim rsEE As New ADODB.Recordset

        Dim l As Single = (BSMMain.ClientSize.Width - Me.Width) / 2
        Dim t As Single = ((BSMMain.ClientSize.Height - Me.Height) / 2) - 30
        Me.SetBounds(l, t, Me.Width, Me.Height)
        Me.MdiParent = BSMMain

        intWOID = 0
        dtpCompDate.Value = GetToken(CStr(Now), 1, " ")

        strSQL = "SELECT (FIRST_NAME + ' ' + LAST_NAME) AS FULL_NAME, ID FROM " & "tblMaintenanceEmployees ORDER BY FIRST_NAME, LAST_NAME"

        cboCompletedBy.DisplayMember = "FULL_NAME"
        cboCompletedBy.ValueMember = "ID"

        Dim tb As New DataTable
        tb.Columns.Add("FULL_NAME", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rsEE.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rsEE.EOF And rsEE.BOF) Then
            rsEE.MoveFirst()
            Do While rsEE.EOF = False
                tb.Rows.Add(rsEE.Fields("FULL_NAME").Value, rsEE.Fields("ID").Value)
                rsEE.MoveNext()
            Loop
        End If
        tb.Rows.Add("", -1)

        cboCompletedBy.DataSource = tb
        cboCompletedBy.Enabled = True

        rsEE.Close()
        rsEE = Nothing

        cboCompletedBy.SelectedIndex = -1

    End Sub

    Private Sub SetFlags()
        Dim strSQL As String
        Dim rsFlags As New ADODB.Recordset

        strSQL = "SELECT GPS_REQUIRED FROM tblStopCoord WHERE OCTA_ID = " & txtOCTAID.Text
        rsFlags.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If rsFlags.EOF Then
            cbxNeedGPS.CheckState = System.Windows.Forms.CheckState.Unchecked
        Else
            If rsFlags.Fields("GPS_REQUIRED").Value Then
                cbxNeedGPS.CheckState = System.Windows.Forms.CheckState.Checked
            Else
                cbxNeedGPS.CheckState = System.Windows.Forms.CheckState.Unchecked
            End If
        End If

        rsFlags.Close()

        strSQL = "SELECT PERM_INSERT FROM tblSignCassette WHERE OCTA_ID = " & txtOCTAID.Text
        rsFlags.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If rsFlags.EOF Then
            cbxNeedIns.CheckState = System.Windows.Forms.CheckState.Unchecked
        Else
            If rsFlags.Fields("PERM_INSERT").Value Then
                cbxNeedIns.CheckState = System.Windows.Forms.CheckState.Checked
            Else
                cbxNeedIns.CheckState = System.Windows.Forms.CheckState.Unchecked
            End If
        End If

        rsFlags.Close()
        rsFlags = Nothing

    End Sub

    Private Sub txtCost_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtCost.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii < 48 Or KeyAscii > 57 Then
            If KeyAscii <> 46 Then
                If KeyAscii <> 8 Then KeyAscii = 0
            End If
        End If

        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtRemarks_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtRemarks.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii >= 97 And KeyAscii <= 122 Then
            KeyAscii = KeyAscii - 32
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub txtWONum_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles txtWONum.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii = 13 Then
            cmdFindWO_Click(cmdFindWO, New System.EventArgs())
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub RefreshNewEmployee()
        Dim rsEE As New ADODB.Recordset

        strSQL = "SELECT (FIRST_NAME + ' ' + LAST_NAME) AS FULL_NAME, ID FROM " & "tblMaintenanceEmployees ORDER BY FIRST_NAME, LAST_NAME"

        cboCompletedBy.DisplayMember = "FULL_NAME"
        cboCompletedBy.ValueMember = "ID"

        Dim tb As New DataTable
        tb.Columns.Add("FULL_NAME", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rsEE.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rsEE.EOF And rsEE.BOF) Then
            rsEE.MoveFirst()
            Do While rsEE.EOF = False
                tb.Rows.Add(rsEE.Fields("FULL_NAME").Value, rsEE.Fields("ID").Value)
                rsEE.MoveNext()
            Loop
        End If
        tb.Rows.Add("", -1)

        cboCompletedBy.DataSource = tb
        cboCompletedBy.Enabled = True

        rsEE.Close()
        rsEE = Nothing

    End Sub
End Class