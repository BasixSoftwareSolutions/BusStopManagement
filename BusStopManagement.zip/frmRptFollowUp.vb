﻿
Public Class frmRptFollowUp
    Private optFollowup() As RadioButton

    Public Sub New()
        InitializeComponent()
        optFollowup = New RadioButton() {optFollowup1, optFollowup2, optFollowup3, optFollowup4, optFollowup5}
    End Sub

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdClearHastus_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClearHastus.Click
        Dim strSQL As Object
        If MsgBox("Reset all UPDATE HASTUS flags to false?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            strSQL = "UPDATE tblBusStopInformation SET UPDATE_HASTUS = 0"
            db.Execute(strSQL)
        End If
    End Sub

    Private Sub cmdClearStopFile_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClearStopFile.Click
        Dim strSQL As Object
        If MsgBox("Reset all CREATE/UPDATE STOP FILE flags to false?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            strSQL = "UPDATE tblBusStopInformation SET CREATE_UPDATE_STOP_FILE = 0"
            db.Execute(strSQL)
        End If
    End Sub

    Private Sub cmdExportToExcel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdExportToExcel.Click
        Dim strSQL As String
        Dim rsData As New ADODB.Recordset
        Dim sFileName As String = ""
        Dim oXLApp As Object
        Dim oXLBook As Object
        Dim oXLSheet As Object
        Dim i As Short

        Me.Enabled = False
        Me.Cursor = System.Windows.Forms.Cursors.WaitCursor

        ' delete any existing data
        strSQL = "DELETE FROM [tblFollowUpReports]"
        dbRep.Execute(strSQL)

        If optFollowup(0).Checked = True Then
            sFileName = "Requires_GPS_Survey"

            strSQL = "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " &
                 "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " &
                 "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " &
                 "FROM (((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " &
                 "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " &
                 "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " &
                 "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " &
                 "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " &
                 "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " &
                 "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID) " &
                 "LEFT JOIN tblStopCoord AS gps ON info.OCTA_ID = gps.OCTA_ID " &
                 "Where ((([gps].[GPS_REQUIRED]) = 1)) " &
                 "ORDER BY info.SANZ_ID"

        ElseIf optFollowup(1).Checked = True Then
            sFileName = "Needs_Permanent_Cassette_Insert"

            strSQL = "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " &
                 "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " &
                 "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " &
                 "FROM (((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " &
                 "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " &
                 "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID) " &
                 "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " &
                 "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " &
                 "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " &
                 "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " &
                 "LEFT JOIN tblSignCassette AS sp ON info.OCTA_ID = sp.OCTA_ID " &
                 "Where ((([sp].[PERM_INSERT]) = 1 )) " &
                 "ORDER BY info.OCTA_ID"

        ElseIf optFollowup(2).Checked = True Then
            sFileName = "Needs_Photographs"

            strSQL = "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " &
                 "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " &
                 "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " &
                 "FROM ((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " &
                 "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " &
                 "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " &
                 "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " &
                 "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " &
                 "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " &
                 "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " &
                 "Where ((([info].[NEW_IMAGE_REQUIRED]) = 1 )) " &
                 "ORDER BY info.OCTA_ID"

        ElseIf optFollowup(3).Checked = True Then
            sFileName = "Needs_Update_Hastus"

            strSQL = "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " &
                 "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " &
                 "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " &
                 "FROM ((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " &
                 "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " &
                 "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " &
                 "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " &
                 "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " &
                 "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " &
                 "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " &
                 "Where ((([info].[UPDATE_HASTUS]) = 1 )) " &
                 "ORDER BY info.OCTA_ID"

        ElseIf optFollowup(4).Checked = True Then
            sFileName = "Needs_Create_Update_Stop_File"

            strSQL = "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " &
                 "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " &
                 "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " &
                 "FROM ((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " &
                 "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " &
                 "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " &
                 "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " &
                 "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " &
                 "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " &
                 "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " &
                 "Where ((([info].[CREATE_UPDATE_STOP_FILE]) = 1 )) " &
                 "ORDER BY info.OCTA_ID"

        End If

        rsData.Open(strSQL, dbRep, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        sFileName = "C:\Temp\" & sFileName & ".xls"

        oXLApp = CreateObject("Excel.Application")
        If Dir(sFileName) = "" Then
            oXLBook = oXLApp.Workbooks.Add
        Else
            oXLBook = oXLApp.Workbooks.Open(sFileName)
        End If
        oXLSheet = oXLBook.Worksheets(1)

        oXLSheet.UsedRange.Clear()
        For i = 0 To rsData.Fields.Count - 1
            oXLSheet.Cells(1, i + 1) = rsData.Fields(i).Name
        Next i
        oXLSheet.Range("A2").CopyFromRecordset(rsData)

        oXLSheet = Nothing
        oXLBook.SaveAs(sFileName)
        oXLBook.Close(savechanges:=False)
        oXLBook = Nothing
        oXLApp.Quit()
        oXLApp = Nothing

        rsData.Close()
        rsData = Nothing

        Me.Enabled = True
        Me.Cursor = System.Windows.Forms.Cursors.Default
        MsgBox("The Excel file was created at " & sFileName & "", MsgBoxStyle.Information, "File Created")

    End Sub

    Private Sub cmdPrint_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPrint.Click

        Dim strSQL As String
        Dim rsData As New ADODB.Recordset
        Dim strReportTitle As String = "Follow Up Report"

        Me.Enabled = False
        Me.Cursor = System.Windows.Forms.Cursors.WaitCursor

        ' delete any existing data
        strSQL = "DELETE FROM tblFollowUpReports"
        dbRep.Execute(strSQL)

        If optFollowup(0).Checked = True Then
            strReportTitle = "Requires GPS Survey"

            strSQL = "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " &
                 "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " &
                 "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " &
                 "FROM (((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " &
                 "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " &
                 "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " &
                 "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " &
                 "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " &
                 "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " &
                 "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID) " &
                 "LEFT JOIN tblStopCoord AS gps ON info.OCTA_ID = gps.OCTA_ID " &
                 "Where ((([gps].[GPS_REQUIRED]) = 1)) " &
                 "ORDER BY info.SANZ_ID"

        ElseIf optFollowup(1).Checked = True Then
            ' set label
            strReportTitle = "Needs Permanent Cassette Insert"

            strSQL = "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " &
                 "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " &
                 "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " &
                 "FROM (((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " &
                 "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " &
                 "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID) " &
                 "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " &
                 "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " &
                 "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " &
                 "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " &
                 "LEFT JOIN tblSignCassette AS sp ON info.OCTA_ID = sp.OCTA_ID " &
                 "Where ((([sp].[PERM_INSERT]) = 1 )) " &
                 "ORDER BY info.OCTA_ID"

        ElseIf optFollowup(2).Checked = True Then
            ' set label
            strReportTitle = "Needs Photographs"

            strSQL = "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " &
                 "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " &
                 "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " &
                 "FROM ((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " &
                 "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " &
                 "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " &
                 "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " &
                 "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " &
                 "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " &
                 "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " &
                 "Where ((([info].[NEW_IMAGE_REQUIRED]) = 1 )) " &
                 "ORDER BY info.OCTA_ID"

        ElseIf optFollowup(3).Checked = True Then
            'Set label
            strReportTitle = "Needs Update Hastus"

            strSQL = "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " &
                 "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " &
                 "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " &
                 "FROM ((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " &
                 "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " &
                 "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " &
                 "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " &
                 "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " &
                 "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " &
                 "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " &
                 "Where ((([info].[UPDATE_HASTUS]) = 1 )) " &
                 "ORDER BY info.OCTA_ID"

        ElseIf optFollowup(4).Checked = True Then
            'Set label
            strReportTitle = "Needs Create/Update Stop File"

            strSQL = "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " &
                 "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " &
                 "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " &
                 "FROM ((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " &
                 "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " &
                 "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " &
                 "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " &
                 "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " &
                 "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " &
                 "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " &
                 "Where ((([info].[CREATE_UPDATE_STOP_FILE]) = 1 )) " &
                 "ORDER BY info.OCTA_ID"
        End If
        rsData.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        CopyADOtoAccessNoPause2(rsData, dbRep, "tblFollowUpReports")

        rsData.Close()
        rsData = Nothing

        dbRep.Close()
        dbRep.Open()

        Me.Enabled = True
        Me.Cursor = System.Windows.Forms.Cursors.Default

        frmCrystalReportsWP.LoadReport("FollowUpReport.rpt", strReportTitle, "", "")

    End Sub



End Class