﻿Public Class frmLineFileDelOpt
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmLineFileDelOpt
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmLineFileDelOpt
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmLineFileDelOpt()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region

    Private Sub frmLineFileDelOpt_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        opt1.Checked = True
    End Sub

    Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOK.Click

        If opt1.Checked Then
            DELETE_STOP_FLAG = 0
        ElseIf opt2.Checked Then
            DELETE_STOP_FLAG = 1
        End If

        Me.Close()
    End Sub

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        DELETE_STOP_FLAG = 2
        Me.Close()
    End Sub
End Class