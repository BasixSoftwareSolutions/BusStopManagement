﻿Public Class frmSpellChecker
    Private mlngLengthDifference As Integer
    Private mstrReplacementWord As String

    Const HTCAPTION As Short = 2
    Const WM_NCLBUTTONDOWN As Short = &HA1S

    Private Declare Function ReleaseCapture Lib "user32" () As Integer
    Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByRef lParam As VariantType) As Integer

    Private Sub cmdChange_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdChange.Click
        Dim strText As String
        '
        ' Set the misspelled word's properties.
        '
        strText = Trim(txtReplace.Text)

        If strText = "" And lstSuggestions.SelectedIndex = -1 Then
            Exit Sub
        End If

        If strText <> "" Then
            mlngLengthDifference = Len(strText) - Len(txtBadWord.Text)
            mstrReplacementWord = strText
        Else
            mlngLengthDifference = Len(lstSuggestions.Text) - Len(txtBadWord.Text)
            mstrReplacementWord = lstSuggestions.Text
        End If

        Me.Hide()

    End Sub

    Private Sub cmdIgnore_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdIgnore.Click
        '
        ' Close this form.
        '
        mlngLengthDifference = 0
        mstrReplacementWord = ""
        Me.Hide()

    End Sub

    'UPGRADE_WARNING: Form event frmSpellChecker.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
    Private Sub frmSpellChecker_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
        '
        ' Position the form caption.
        '
        lblCaption.Left = 0
        lblCaption.Width = Me.Width

    End Sub

    Private Sub lblCaption_MouseDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles lblCaption.MouseDown
        Dim Button As Short = eventArgs.Button \ &H100000
        Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
        'Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
        'Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
        '
        ' Allow the form to be moved.
        '
        Call ReleaseCapture()
        Call SendMessage(Handle.ToInt32, WM_NCLBUTTONDOWN, HTCAPTION, 0)

    End Sub
    Private Sub lstSuggestions_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstSuggestions.DoubleClick
        '
        ' Replace the misspelled word.
        '
        mlngLengthDifference = Len(lstSuggestions.Text) - Len(txtBadWord.Text)
        mstrReplacementWord = lstSuggestions.Text
        Me.Hide()

    End Sub
    Public ReadOnly Property LengthDifference() As Integer
        Get
            LengthDifference = mlngLengthDifference
        End Get
    End Property
    Public ReadOnly Property ReplacementWord() As String
        Get
            ReplacementWord = Trim(mstrReplacementWord)
        End Get
    End Property
End Class