﻿Imports System.Data.SqlClient
Public Class frmOpenWO

    Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click

        Me.Close()

    End Sub

    Private Sub cmdSelect_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSelect.Click
        On Error GoTo errHandler

        If CShort(tdgOpenWO.Item(0, tdgOpenWO.CurrentRow.Index).Value) > 0 Then
            frmWorkOrderCompletion.txtWONum.Text = CStr(CShort(tdgOpenWO.Item(0, tdgOpenWO.CurrentRow.Index).Value))
            frmWorkOrderCompletion.FindWO()
            Me.Close()
        Else
            MsgBox("Please select a record first.", MsgBoxStyle.Critical, "Select record")
        End If
        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub frmOpenWO_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        Me.TblMaintenanceEmployeesTableAdapter.Fill(Me.DsMaintenanceEmployees1.tblMaintenanceEmployees)
        Me.TblWorkOrdersTableAdapter.Fill(Me.DsOpenWorkOrders.tblWorkOrders)

    End Sub

    Private Sub tsbEditWO_Click(sender As Object, e As EventArgs) Handles tsbEditWO.Click
        Dim sFormat As String = "MM/dd/yyyy"

        On Error GoTo errHandler

        For Each rw As DataGridViewRow In Me.tdgOpenWO.Rows
            If rw.Cells(4).Value = True Then
                Dim iWorkOrderID As Integer = 0
                Dim strCompletedBy As String = ""
                Dim dtCompletedDate As Date = Date.Now.ToString(sFormat)
                Dim strRemarks As String = ""
                Dim sngCost As Single = 0.00

                'Completed By Value
                If IsDBNull(rw.Cells(8).Value) Then
                    strCompletedBy = "N/A _"
                Else
                    strCompletedBy = rw.Cells(8).Value
                End If
                'Completed Date Value
                If IsDBNull(rw.Cells(7).Value) Then
                    dtCompletedDate = Date.Now.ToString(sFormat)
                Else
                    dtCompletedDate = rw.Cells(7).Value
                End If
                'Remarks Value
                If IsDBNull(rw.Cells(5).Value) Then
                    strRemarks = ""
                Else
                    strRemarks = cV2Q_String(rw.Cells(5).Value)
                End If
                'Cost Value
                If IsDBNull(rw.Cells(6).Value) Then
                    sngCost = 0.00
                Else
                    sngCost = CSng(rw.Cells(6).Value)
                End If
                'Work Order ID Value
                If IsDBNull(rw.Cells(0).Value) Then
                    iWorkOrderID = 0
                Else
                    iWorkOrderID = CInt(rw.Cells(0).Value)
                End If

                If iWorkOrderID <> 0 Then
                    strSQL = ""
                    strSQL = "UPDATE tblWorkOrders SET "
                    strSQL = strSQL & "WO_COMPLETED_BY = " & "'" & strCompletedBy & "'" & ", "
                    strSQL = strSQL & "WO_COMPLETE_DATE = '" & dtCompletedDate.ToString(sFormat) & "', "
                    strSQL = strSQL & "WO_REMARKS = " & (strRemarks) & ", "
                    strSQL = strSQL & "WO_COST = " & sngCost & " "
                    strSQL = strSQL & "WHERE WO_ID = " & iWorkOrderID & ""
                    'MsgBox(strSQL)
                    db.Execute(strSQL)
                End If
            End If
        Next
        MessageBox.Show("Record has been saved.")

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub tdgOpenWO_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles tdgOpenWO.CellValueChanged
        Dim sFormat As String = "MM/dd/yyyy"

        If e.RowIndex = -1 Then Exit Sub

        If CShort(tdgOpenWO.Item(4, tdgOpenWO.CurrentRow.Index).Value) = 0 Then
            tdgOpenWO.Item(0, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Empty
            tdgOpenWO.Item(1, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Empty
            tdgOpenWO.Item(2, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Empty
            tdgOpenWO.Item(3, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Empty
            tdgOpenWO.Item(4, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Empty
            tdgOpenWO.Item(5, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Empty
            tdgOpenWO.Item(6, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Empty
            tdgOpenWO.Item(7, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Empty
        Else
            tdgOpenWO.Item(0, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Coral
            tdgOpenWO.Item(1, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Coral
            tdgOpenWO.Item(2, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Coral
            tdgOpenWO.Item(3, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Coral
            tdgOpenWO.Item(4, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Coral
            tdgOpenWO.Item(5, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Coral
            tdgOpenWO.Item(6, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Coral
            tdgOpenWO.Item(7, tdgOpenWO.CurrentRow.Index).Style.BackColor = Color.Coral
            If IsDBNull(tdgOpenWO.Item(7, tdgOpenWO.CurrentRow.Index).Value) Then tdgOpenWO.Item(7, tdgOpenWO.CurrentRow.Index).Value = Date.Now.ToString(sFormat)
            If IsDBNull(tdgOpenWO.Item(8, tdgOpenWO.CurrentRow.Index).Value) Then tdgOpenWO.Item(8, tdgOpenWO.CurrentRow.Index).Value = "N/A _"

        End If

    End Sub

    Private Sub tdgOpenWO_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles tdgOpenWO.CurrentCellDirtyStateChanged

        If tdgOpenWO.IsCurrentCellDirty Then
            tdgOpenWO.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If

    End Sub

    Private Sub txtSearchWO_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSearchWO.KeyPress
        If Asc(e.KeyChar) = 13 Then
            If IsNumeric(txtSearchWO.Text) Then
                Me.TblWorkOrdersBindingSource.Position = Me.TblWorkOrdersBindingSource.Find("Work Order ID", txtSearchWO.Text)
            End If
        End If
    End Sub

    Private Sub txtSearchStopID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSearchStopID.KeyPress
        If Asc(e.KeyChar) = 13 Then
            If IsNumeric(txtSearchStopID.Text) Then
                Me.TblWorkOrdersBindingSource.Position = Me.TblWorkOrdersBindingSource.Find("OCTA ID", txtSearchStopID.Text)
            End If
        End If
    End Sub
End Class