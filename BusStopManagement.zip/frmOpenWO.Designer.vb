﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmOpenWO
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOpenWO))
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.tdgOpenWO = New System.Windows.Forms.DataGridView()
        Me.TblMaintenanceEmployeesBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsMaintenanceEmployees1 = New BusStopManagement.dsMaintenanceEmployees()
        Me.TblWorkOrdersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DsOpenWorkOrders = New BusStopManagement.dsOpenWorkOrders()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdSelect = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.TblWorkOrdersTableAdapter = New BusStopManagement.dsOpenWorkOrdersTableAdapters.tblWorkOrdersTableAdapter()
        Me.bnOpenWO = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsbEditWO = New System.Windows.Forms.ToolStripButton()
        Me.TblMaintenanceEmployeesTableAdapter = New BusStopManagement.dsMaintenanceEmployeesTableAdapters.tblMaintenanceEmployeesTableAdapter()
        Me.txtSearchWO = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSearchStopID = New System.Windows.Forms.TextBox()
        Me.WorkOrderIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OCTA_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WODateIssuedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WODescriptionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.chkCompleted = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.WO_REMARKS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WO_COST = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WOCompletionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.WO_COMPLETED_BY = New System.Windows.Forms.DataGridViewComboBoxColumn()
        CType(Me.tdgOpenWO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblMaintenanceEmployeesBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsMaintenanceEmployees1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblWorkOrdersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsOpenWorkOrders, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bnOpenWO, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.bnOpenWO.SuspendLayout()
        Me.SuspendLayout()
        '
        'tdgOpenWO
        '
        Me.tdgOpenWO.AllowUserToAddRows = False
        Me.tdgOpenWO.AllowUserToDeleteRows = False
        Me.tdgOpenWO.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.Ivory
        Me.tdgOpenWO.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.tdgOpenWO.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tdgOpenWO.AutoGenerateColumns = False
        Me.tdgOpenWO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.tdgOpenWO.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.WorkOrderIDDataGridViewTextBoxColumn, Me.OCTA_ID, Me.WODateIssuedDataGridViewTextBoxColumn, Me.WODescriptionDataGridViewTextBoxColumn, Me.chkCompleted, Me.WO_REMARKS, Me.WO_COST, Me.WOCompletionDataGridViewTextBoxColumn, Me.WO_COMPLETED_BY})
        Me.tdgOpenWO.DataSource = Me.TblWorkOrdersBindingSource
        Me.tdgOpenWO.Location = New System.Drawing.Point(15, 28)
        Me.tdgOpenWO.MultiSelect = False
        Me.tdgOpenWO.Name = "tdgOpenWO"
        Me.tdgOpenWO.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.tdgOpenWO.Size = New System.Drawing.Size(1307, 375)
        Me.tdgOpenWO.TabIndex = 7
        '
        'TblMaintenanceEmployeesBindingSource1
        '
        Me.TblMaintenanceEmployeesBindingSource1.DataMember = "tblMaintenanceEmployees"
        Me.TblMaintenanceEmployeesBindingSource1.DataSource = Me.DsMaintenanceEmployees1
        '
        'DsMaintenanceEmployees1
        '
        Me.DsMaintenanceEmployees1.DataSetName = "dsMaintenanceEmployees"
        Me.DsMaintenanceEmployees1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblWorkOrdersBindingSource
        '
        Me.TblWorkOrdersBindingSource.DataMember = "tblWorkOrders"
        Me.TblWorkOrdersBindingSource.DataSource = Me.DsOpenWorkOrders
        '
        'DsOpenWorkOrders
        '
        Me.DsOpenWorkOrders.DataSetName = "dsOpenWorkOrders"
        Me.DsOpenWorkOrders.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(121, 425)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(89, 25)
        Me.cmdClose.TabIndex = 5
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdSelect
        '
        Me.cmdSelect.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdSelect.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSelect.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSelect.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSelect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSelect.Location = New System.Drawing.Point(17, 425)
        Me.cmdSelect.Name = "cmdSelect"
        Me.cmdSelect.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSelect.Size = New System.Drawing.Size(89, 25)
        Me.cmdSelect.TabIndex = 4
        Me.cmdSelect.Text = "&Select"
        Me.cmdSelect.UseVisualStyleBackColor = False
        '
        'Frame1
        '
        Me.Frame1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(9, 409)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(209, 49)
        Me.Frame1.TabIndex = 6
        Me.Frame1.TabStop = False
        '
        'TblWorkOrdersTableAdapter
        '
        Me.TblWorkOrdersTableAdapter.ClearBeforeFill = True
        '
        'bnOpenWO
        '
        Me.bnOpenWO.AddNewItem = Nothing
        Me.bnOpenWO.BindingSource = Me.TblWorkOrdersBindingSource
        Me.bnOpenWO.CountItem = Me.BindingNavigatorCountItem
        Me.bnOpenWO.DeleteItem = Nothing
        Me.bnOpenWO.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.tsbEditWO})
        Me.bnOpenWO.Location = New System.Drawing.Point(0, 0)
        Me.bnOpenWO.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.bnOpenWO.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.bnOpenWO.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.bnOpenWO.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.bnOpenWO.Name = "bnOpenWO"
        Me.bnOpenWO.PositionItem = Me.BindingNavigatorPositionItem
        Me.bnOpenWO.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.bnOpenWO.Size = New System.Drawing.Size(1373, 25)
        Me.bnOpenWO.TabIndex = 8
        Me.bnOpenWO.Text = "BindingNavigator1"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'tsbEditWO
        '
        Me.tsbEditWO.Image = CType(resources.GetObject("tsbEditWO.Image"), System.Drawing.Image)
        Me.tsbEditWO.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.tsbEditWO.Name = "tsbEditWO"
        Me.tsbEditWO.Size = New System.Drawing.Size(120, 22)
        Me.tsbEditWO.Text = "Close Work Order"
        '
        'TblMaintenanceEmployeesTableAdapter
        '
        Me.TblMaintenanceEmployeesTableAdapter.ClearBeforeFill = True
        '
        'txtSearchWO
        '
        Me.txtSearchWO.Location = New System.Drawing.Point(426, 426)
        Me.txtSearchWO.Name = "txtSearchWO"
        Me.txtSearchWO.Size = New System.Drawing.Size(100, 20)
        Me.txtSearchWO.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(287, 429)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 13)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Search Open Work Orders:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(584, 429)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Search By Stop ID:"
        '
        'txtSearchStopID
        '
        Me.txtSearchStopID.Location = New System.Drawing.Point(685, 426)
        Me.txtSearchStopID.Name = "txtSearchStopID"
        Me.txtSearchStopID.Size = New System.Drawing.Size(100, 20)
        Me.txtSearchStopID.TabIndex = 11
        '
        'WorkOrderIDDataGridViewTextBoxColumn
        '
        Me.WorkOrderIDDataGridViewTextBoxColumn.DataPropertyName = "Work Order ID"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.WorkOrderIDDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle2
        Me.WorkOrderIDDataGridViewTextBoxColumn.HeaderText = "WO ID"
        Me.WorkOrderIDDataGridViewTextBoxColumn.Name = "WorkOrderIDDataGridViewTextBoxColumn"
        Me.WorkOrderIDDataGridViewTextBoxColumn.ReadOnly = True
        Me.WorkOrderIDDataGridViewTextBoxColumn.Width = 75
        '
        'OCTA_ID
        '
        Me.OCTA_ID.DataPropertyName = "OCTA ID"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.OCTA_ID.DefaultCellStyle = DataGridViewCellStyle3
        Me.OCTA_ID.HeaderText = "OCTA ID"
        Me.OCTA_ID.Name = "OCTA_ID"
        Me.OCTA_ID.ReadOnly = True
        Me.OCTA_ID.Width = 75
        '
        'WODateIssuedDataGridViewTextBoxColumn
        '
        Me.WODateIssuedDataGridViewTextBoxColumn.DataPropertyName = "WO Date Issued"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.WODateIssuedDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle4
        Me.WODateIssuedDataGridViewTextBoxColumn.HeaderText = "WO Date Issued"
        Me.WODateIssuedDataGridViewTextBoxColumn.Name = "WODateIssuedDataGridViewTextBoxColumn"
        Me.WODateIssuedDataGridViewTextBoxColumn.ReadOnly = True
        Me.WODateIssuedDataGridViewTextBoxColumn.Width = 125
        '
        'WODescriptionDataGridViewTextBoxColumn
        '
        Me.WODescriptionDataGridViewTextBoxColumn.DataPropertyName = "WO Description"
        Me.WODescriptionDataGridViewTextBoxColumn.HeaderText = "WO Description"
        Me.WODescriptionDataGridViewTextBoxColumn.Name = "WODescriptionDataGridViewTextBoxColumn"
        Me.WODescriptionDataGridViewTextBoxColumn.ReadOnly = True
        Me.WODescriptionDataGridViewTextBoxColumn.Width = 300
        '
        'chkCompleted
        '
        Me.chkCompleted.HeaderText = "Completed"
        Me.chkCompleted.Name = "chkCompleted"
        '
        'WO_REMARKS
        '
        Me.WO_REMARKS.DataPropertyName = "WO_REMARKS"
        Me.WO_REMARKS.HeaderText = "WO Remarks"
        Me.WO_REMARKS.Name = "WO_REMARKS"
        Me.WO_REMARKS.Width = 200
        '
        'WO_COST
        '
        Me.WO_COST.DataPropertyName = "WO_COST"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle5.Format = "C2"
        DataGridViewCellStyle5.NullValue = Nothing
        Me.WO_COST.DefaultCellStyle = DataGridViewCellStyle5
        Me.WO_COST.HeaderText = "WO Cost"
        Me.WO_COST.Name = "WO_COST"
        '
        'WOCompletionDataGridViewTextBoxColumn
        '
        Me.WOCompletionDataGridViewTextBoxColumn.DataPropertyName = "WO Completion"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.Format = "g"
        DataGridViewCellStyle6.NullValue = Nothing
        Me.WOCompletionDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle6
        Me.WOCompletionDataGridViewTextBoxColumn.HeaderText = "Completed Date"
        Me.WOCompletionDataGridViewTextBoxColumn.Name = "WOCompletionDataGridViewTextBoxColumn"
        Me.WOCompletionDataGridViewTextBoxColumn.Width = 125
        '
        'WO_COMPLETED_BY
        '
        Me.WO_COMPLETED_BY.DataPropertyName = "WO_COMPLETED_BY"
        Me.WO_COMPLETED_BY.DataSource = Me.TblMaintenanceEmployeesBindingSource1
        Me.WO_COMPLETED_BY.DisplayMember = "FULL_NAME"
        Me.WO_COMPLETED_BY.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox
        Me.WO_COMPLETED_BY.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.WO_COMPLETED_BY.HeaderText = "Completed By"
        Me.WO_COMPLETED_BY.Name = "WO_COMPLETED_BY"
        Me.WO_COMPLETED_BY.ValueMember = "FULL_NAME"
        Me.WO_COMPLETED_BY.Width = 150
        '
        'frmOpenWO
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(1373, 462)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtSearchStopID)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtSearchWO)
        Me.Controls.Add(Me.bnOpenWO)
        Me.Controls.Add(Me.tdgOpenWO)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.cmdSelect)
        Me.Controls.Add(Me.Frame1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(800, 500)
        Me.Name = "frmOpenWO"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Open Work Orders"
        Me.TopMost = True
        CType(Me.tdgOpenWO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblMaintenanceEmployeesBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsMaintenanceEmployees1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblWorkOrdersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsOpenWorkOrders, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bnOpenWO, System.ComponentModel.ISupportInitialize).EndInit()
        Me.bnOpenWO.ResumeLayout(False)
        Me.bnOpenWO.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents cmdClose As Button
    Public WithEvents cmdSelect As Button
    Public WithEvents Frame1 As GroupBox
    Friend WithEvents DsOpenWorkOrders As dsOpenWorkOrders
    Friend WithEvents TblWorkOrdersBindingSource As BindingSource
    Friend WithEvents TblWorkOrdersTableAdapter As dsOpenWorkOrdersTableAdapters.tblWorkOrdersTableAdapter
    Friend WithEvents tdgOpenWO As DataGridView
    Friend WithEvents bnOpenWO As BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents tsbEditWO As ToolStripButton
    Friend WithEvents TblMaintenanceEmployeesTableAdapter As dsMaintenanceEmployeesTableAdapters.tblMaintenanceEmployeesTableAdapter
    Friend WithEvents DsMaintenanceEmployees1 As dsMaintenanceEmployees
    Friend WithEvents TblMaintenanceEmployeesBindingSource1 As BindingSource
    Friend WithEvents txtSearchWO As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtSearchStopID As TextBox
    Friend WithEvents WorkOrderIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents OCTA_ID As DataGridViewTextBoxColumn
    Friend WithEvents WODateIssuedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents WODescriptionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents chkCompleted As DataGridViewCheckBoxColumn
    Friend WithEvents WO_REMARKS As DataGridViewTextBoxColumn
    Friend WithEvents WO_COST As DataGridViewTextBoxColumn
    Friend WithEvents WOCompletionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents WO_COMPLETED_BY As DataGridViewComboBoxColumn
End Class
