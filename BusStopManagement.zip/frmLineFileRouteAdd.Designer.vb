﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLineFileRouteAdd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdCreate = New System.Windows.Forms.Button()
        Me.optActive1 = New System.Windows.Forms.RadioButton()
        Me.optActive0 = New System.Windows.Forms.RadioButton()
        Me.txtRouteNo = New System.Windows.Forms.TextBox()
        Me.Shape1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cboRouteDir = New System.Windows.Forms.ComboBox()
        Me.cboRouteDes = New System.Windows.Forms.ComboBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(196, 178)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(81, 25)
        Me.cmdClose.TabIndex = 21
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'cmdCreate
        '
        Me.cmdCreate.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCreate.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCreate.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCreate.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCreate.Location = New System.Drawing.Point(100, 178)
        Me.cmdCreate.Name = "cmdCreate"
        Me.cmdCreate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCreate.Size = New System.Drawing.Size(81, 25)
        Me.cmdCreate.TabIndex = 20
        Me.cmdCreate.Text = "C&reate"
        Me.cmdCreate.UseVisualStyleBackColor = False
        '
        'optActive1
        '
        Me.optActive1.BackColor = System.Drawing.Color.Transparent
        Me.optActive1.Cursor = System.Windows.Forms.Cursors.Default
        Me.optActive1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optActive1.ForeColor = System.Drawing.Color.DimGray
        Me.optActive1.Location = New System.Drawing.Point(204, 146)
        Me.optActive1.Name = "optActive1"
        Me.optActive1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optActive1.Size = New System.Drawing.Size(57, 17)
        Me.optActive1.TabIndex = 19
        Me.optActive1.TabStop = True
        Me.optActive1.Text = "NO"
        Me.optActive1.UseVisualStyleBackColor = False
        '
        'optActive0
        '
        Me.optActive0.BackColor = System.Drawing.Color.Transparent
        Me.optActive0.Cursor = System.Windows.Forms.Cursors.Default
        Me.optActive0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.optActive0.ForeColor = System.Drawing.Color.DimGray
        Me.optActive0.Location = New System.Drawing.Point(140, 146)
        Me.optActive0.Name = "optActive0"
        Me.optActive0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optActive0.Size = New System.Drawing.Size(57, 17)
        Me.optActive0.TabIndex = 18
        Me.optActive0.TabStop = True
        Me.optActive0.Text = "YES"
        Me.optActive0.UseVisualStyleBackColor = False
        '
        'txtRouteNo
        '
        Me.txtRouteNo.AcceptsReturn = True
        Me.txtRouteNo.BackColor = System.Drawing.SystemColors.Window
        Me.txtRouteNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtRouteNo.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRouteNo.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRouteNo.Location = New System.Drawing.Point(140, 18)
        Me.txtRouteNo.MaxLength = 0
        Me.txtRouteNo.Name = "txtRouteNo"
        Me.txtRouteNo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtRouteNo.Size = New System.Drawing.Size(57, 20)
        Me.txtRouteNo.TabIndex = 14
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(92, 170)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(193, 41)
        Me.Shape1.TabIndex = 22
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(52, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(81, 21)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "DIRECTION:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DimGray
        Me.Label3.Location = New System.Drawing.Point(36, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(97, 21)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "DESIGNATION:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DimGray
        Me.Label4.Location = New System.Drawing.Point(20, 121)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(113, 21)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "EFFECTIVE DATE:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(52, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(81, 21)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "ROUTE NO:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.DimGray
        Me.Label5.Location = New System.Drawing.Point(76, 146)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(57, 25)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "ACTIVE:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cboRouteDir
        '
        Me.cboRouteDir.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRouteDir.FormattingEnabled = True
        Me.cboRouteDir.Location = New System.Drawing.Point(140, 53)
        Me.cboRouteDir.Name = "cboRouteDir"
        Me.cboRouteDir.Size = New System.Drawing.Size(195, 21)
        Me.cboRouteDir.TabIndex = 27
        '
        'cboRouteDes
        '
        Me.cboRouteDes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboRouteDes.FormattingEnabled = True
        Me.cboRouteDes.Location = New System.Drawing.Point(140, 85)
        Me.cboRouteDes.Name = "cboRouteDes"
        Me.cboRouteDes.Size = New System.Drawing.Size(195, 21)
        Me.cboRouteDes.TabIndex = 28
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(140, 118)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(195, 20)
        Me.DateTimePicker1.TabIndex = 29
        '
        'frmLineFileRouteAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(387, 227)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.cboRouteDes)
        Me.Controls.Add(Me.cboRouteDir)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.cmdCreate)
        Me.Controls.Add(Me.optActive1)
        Me.Controls.Add(Me.optActive0)
        Me.Controls.Add(Me.txtRouteNo)
        Me.Controls.Add(Me.Shape1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label5)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmLineFileRouteAdd"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add Route"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents cmdClose As Button
    Public WithEvents cmdCreate As Button
    Public WithEvents optActive1 As RadioButton
    Public WithEvents optActive0 As RadioButton
    Public WithEvents txtRouteNo As TextBox
    Public WithEvents Shape1 As Label
    Public WithEvents Label2 As Label
    Public WithEvents Label3 As Label
    Public WithEvents Label4 As Label
    Public WithEvents Label1 As Label
    Public WithEvents Label5 As Label
    Friend WithEvents cboRouteDir As ComboBox
    Friend WithEvents cboRouteDes As ComboBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
End Class
