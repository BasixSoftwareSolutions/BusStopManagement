﻿Public Class frmLineFileRouteEdit
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmLineFileRouteEdit
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmLineFileRouteEdit
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmLineFileRouteEdit()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region


    Dim routeExists As Boolean

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click

        Me.Close()

    End Sub

    Private Sub frmLineFileRouteEdit_Load(sender As Object, e As EventArgs) Handles Me.Load

        LoadDirection()
        LoadDesignation()
        SetValues()

    End Sub

    Private Sub SetValues()
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim i As Short
        Dim dEffDate As Date

        Dim result As String

        strSQL = "SELECT * FROM tblRoutes WHERE RTE = " & ROUTE_ID & " AND RTE_DIR_ID = " & DIR_ID

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        txtRouteNo.Text = rs.Fields("RTE").Value

        For i = 0 To cboRouteDir.Items.Count - 1
            cboRouteDir.SelectedIndex = i
            If cboRouteDir.SelectedValue = rs.Fields("RTE_DIR_ID").Value Then
                cboRouteDir.SelectedIndex = i
                Exit For
            End If
        Next

        If Not IsDBNull(rs.Fields("RTE_DESIGNATION_ID").Value) Then

            For i = 0 To cboRouteDes.Items.Count - 1
                cboRouteDes.SelectedIndex = i
                If cboRouteDes.SelectedValue = rs.Fields("RTE_DESIGNATION_ID").Value Then
                    cboRouteDes.SelectedIndex = i
                    Exit For
                End If
            Next

            If i < cboRouteDes.Items.Count - 1 Then
                cboRouteDes.SelectedIndex = i
            End If
        End If

        If Not IsDBNull(rs.Fields("EFFECTIVE_DATE").Value) Then
            txtEffDate.Text = rs.Fields("EFFECTIVE_DATE").Value
            dEffDate = CDate(txtEffDate.Text)
            DateTimePicker1.Value = New Date(dEffDate.Year, dEffDate.Month, dEffDate.Day)
        Else
            DateTimePicker1.Value = Today
            txtEffDate.Text = Date.Now.ToShortDateString
        End If

        If rs.Fields("ACTIVE").Value = True Then
            optActive0.Checked = True
        Else
            optActive1.Checked = True
        End If

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub
    Private Sub LoadDirection()
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT * FROM ROUTE_DIR_CODE WHERE ACTIVE =1 ORDER BY ID"

        cboRouteDir.DisplayMember = "DESCRIPTION"
        cboRouteDir.ValueMember = "ID"
        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then rs.MoveLast()
        If rs.RecordCount > 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If

        cboRouteDir.DataSource = tb
        cboRouteDir.Enabled = True

        rs.Close()
        rs = Nothing
        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub LoadDesignation()
        On Error GoTo errHandler

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT * FROM ROUTE_DESIGNATION_CODE WHERE ACTIVE =1 ORDER BY ID"
        cboRouteDes.DisplayMember = "DESCRIPTION"
        cboRouteDes.ValueMember = "ID"
        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If rs.RecordCount <> 0 Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If

        cboRouteDes.DataSource = tb
        cboRouteDes.Enabled = True

        rs.Close()
        rs = Nothing
        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdCreate_Click(sender As Object, e As EventArgs) Handles cmdCreate.Click
        Dim Index As Short
        Index = cboRouteDir.SelectedIndex

        If Trim(txtRouteNo.Text) = "" Then
            MsgBox("Please enter a route number!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If


        If cboRouteDir.SelectedIndex = -1 Then
            MsgBox("Please select a route direction!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If cboRouteDes.SelectedIndex = -1 Then
            MsgBox("Please select a route designation!", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        routeExists = False

        Dim rs As New ADODB.Recordset
        Dim strSQL As String
        Dim activevalue As Boolean

        If optActive0.Checked Then
            activevalue = True
        Else
            activevalue = False
        End If

        strSQL = "SELECT * FROM tblRoutes WHERE RTE = " & txtRouteNo.Text & " AND " & "RTE_DIR_ID = " & cboRouteDir.SelectedValue
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)
        ' this is to check if only designation was changed
        If (rs.EOF And rs.BOF) Then
            UpdateRoute()
        Else
            strSQL = "UPDATE tblRoutes SET RTE_DESIGNATION_ID = " & cboRouteDes.SelectedValue & " WHERE RTE = " & txtRouteNo.Text & " AND RTE_DIR_ID = " & cboRouteDir.SelectedValue
            db.Execute(strSQL)
        End If

        rs.Close()

        If routeExists Then
            Exit Sub
        End If

        ' reload all possible routes on frmLineFile form...
        ' ....
        frmLineFile.ReloadRoutes()

        Dim routeNo, routeDir As Short

        routeNo = CShort(txtRouteNo.Text)
        routeDir = cboRouteDes.SelectedValue

        frmLineFile.LoadStops4Route(routeNo, routeDir)

        Me.Close()

    End Sub

    Private Sub UpdateRoute()
        Dim strSQL As String
        Dim rActive As Integer
        Dim sActive As Boolean
        Dim dt As Date

        If optActive0.Checked Then
            rActive = 1
        Else
            rActive = 0
        End If

        On Error GoTo errHandler

        If IsDBNull(DateTimePicker1.Value) Then
            strSQL = "UPDATE tblRoutes SET RTE_DIR_ID = " & cboRouteDir.SelectedValue & ", RTE_DESIGNATION_ID = " & cboRouteDes.SelectedValue & ", ACTIVE = " & rActive & " WHERE RTE = " & txtRouteNo.Text & " AND RTE_DIR_ID = " & cboRouteDir.SelectedValue
        Else
            dt = DateTimePicker1.Value
            dt = dt.ToShortDateString
            strSQL = "UPDATE tblRoutes SET RTE_DIR_ID = " & cboRouteDir.SelectedValue & ", RTE_DESIGNATION_ID = " & cboRouteDes.SelectedValue & ", EFFECTIVE_DATE = '" & dt & "', ACTIVE = " & rActive & " WHERE RTE = " & ROUTE_ID & " AND RTE_DIR_ID = " & cboRouteDir.SelectedValue
        End If

        db.Execute(strSQL)

        ' also update route direction information in tblBusStopSequences table
        strSQL = "UPDATE tblBusStopSequences SET RTE_DIR_ID = " & cboRouteDir.SelectedValue & " WHERE RTE = " & ROUTE_ID & " AND RTE_DIR_ID = " & cboRouteDir.SelectedValue

        db.Execute(strSQL)

        ' Check if Stop is being use for other active route or routes
        ' If not inactivate stop
        Dim i, OID, j As Short
        Dim rs As New ADODB.Recordset
        Dim rs2 As New ADODB.Recordset
        Dim typeID As Short
        Dim remarks As String
        Dim sanzid As String
        Dim tempDt As Date
        Dim direction As String

        typeID = 26
        tempDt = DateTimePicker1.Value
        tempDt = tempDt.ToShortDateString

        strSQL = "SELECT * FROM tblBusStopSequences bs, ROUTE_DIR_CODE rdc" & " WHERE bs.RTE = " & ROUTE_ID & " AND bs.RTE_DIR_ID = " & cboRouteDir.SelectedValue & " AND bs.RTE_DIR_ID = rdc.ID"

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

        If rs.RecordCount > 0 Then

            rs.MoveFirst()
            For i = 0 To rs.RecordCount - 1

                OID = rs.Fields("OCTA_ID").Value
                sanzid = rs.Fields("SANZ_ID").Value
                direction = rs.Fields("DIR").Value

                If rActive = True Then ' route is activated
                    ' Check if stop is active
                    strSQL = "SELECT OCTA_ID, ACTIVE_STOP FROM tblBusStopInformation WHERE OCTA_ID = " & OID
                    rs2.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)
                    rs2.MoveFirst()

                    sActive = rs2.Fields("ACTIVE_STOP").Value

                    rs2.Close()

                    If sActive Then ' If active just make the history entry
                        remarks = "'ROUTE # " & ROUTE_ID & " " & direction & " WILL BEGIN SERVICING THIS " & "BUS STOP WITH THE UPCOMING SERVICE CHANGE'"
                    Else ' Activate Stop
                        ' If a route is activated then a stop in that route has to be activated.
                        ' there is a chance that this may create an issue through the update stop interfac
                        ' But that issue will need to be resolved through checks
                        strSQL = "UPDATE tblBusStopInformation SET ACTIVE_STOP = 1 WHERE " & "OCTA_ID = " & OID
                        db.Execute(strSQL)

                        remarks = "'ROUTE # " & ROUTE_ID & " " & direction & " AND BUS STOP RE-ACTIVATED FOR " & "THE UPCOMING SERVICE CHANGE'"
                    End If

                Else ' route is deactivated
                    strSQL = "SELECT * FROM tblBusStopSequences ts, tblRoutes tr" & " WHERE ts.OCTA_ID = " & OID & " AND ts.RTE = tr.RTE AND ts.RTE_DIR_ID =" & " tr.RTE_DIR_ID AND tr.ACTIVE = 1"

                    rs2.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

                    If rs2.RecordCount < 1 Then ' Stop is deactivated, as it is taken out of all routes
                        strSQL = "UPDATE tblBusStopInformation SET ACTIVE_STOP = 0 WHERE " & "OCTA_ID = " & OID

                        remarks = "'BUS STOP REMOVED AND WILL NO LONGER BE SERVICED BY ROUTE # " & ROUTE_ID & " " & direction & "'"
                        db.Execute(strSQL)
                    Else ' Leave it alone, just make the history entry

                        remarks = "'ROUTE # " & ROUTE_ID & " " & direction & " WILL NO LONGER PROVIDE SERVICE TO THIS STOP'"

                    End If

                    rs2.Close()

                End If

                ' Make stop history entry
                strSQL = "INSERT INTO [tblStopHistory] (OCTA_ID, SANZ_ID, [DATE], STAFF_ID, " & "HISTORY_TYPE_ID, REMARKS) VALUES (" & OID & "," & "'" & sanzid & "'" & "," & tempDt & "," & Environ("USERNAME") & "," & typeID & "," & remarks & ");"

                db.Execute(strSQL)

                rs.MoveNext()
            Next i

            rs.Close()
        End If

        MsgBox("Route: " & txtRouteNo.Text & " has been updated to the database.", MsgBoxStyle.Information)

        Exit Sub

errHandler:
        routeExists = True
        MsgBox("Route " & txtRouteNo.Text & " " & cboRouteDir.Text & " already exists",  , "Error")
    End Sub

    Private Function RouteExist(ByRef aRoute As Short, ByRef aDirID As Byte) As Boolean
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim bln As Boolean

        strSQL = "SELECT * FROM tblRoutes WHERE RTE = " & aRoute & " AND RTE_DIR_ID = " & aDirID
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        bln = False
        If Not rs.EOF Then
            bln = True
        End If

        rs.Close()
        rs = Nothing

        RouteExist = bln
    End Function
End Class