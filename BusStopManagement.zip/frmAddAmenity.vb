﻿Public Class frmAddAmenity

    Dim strSANZID As String
    Dim strOCTAID As Integer

    Private Sub LoadOwnerType()

        Dim rs As New ADODB.Recordset

        strSQL = "SELECT ID, OWNER, DESCRIPTION FROM AMENITIES_OWNER_CODE WHERE ACTIVE = 1"

        cboOwner.DisplayMember = "DESCRIPTION"
        cboOwner.ValueMember = "ID"

        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If
        tb.Rows.Add("", -1)

        cboOwner.DataSource = tb
        cboOwner.Enabled = True

        rs.Close()
        rs = Nothing

        cboOwner.SelectedIndex = 0

    End Sub
    Private Sub LoadAmenityType()

        Dim rs As New ADODB.Recordset

        strSQL = "SELECT ID, TYPE, DESCRIPTION FROM AMENITIES_TYPE_CODE WHERE ACTIVE = 1"

        cboType.DisplayMember = "DESCRIPTION"
        cboType.ValueMember = "ID"

        Dim tb As New DataTable
        tb.Columns.Add("DESCRIPTION", GetType(String))
        tb.Columns.Add("ID", GetType(Integer))

        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If Not (rs.EOF And rs.BOF) Then
            rs.MoveFirst()
            Do While rs.EOF = False
                tb.Rows.Add(rs.Fields("DESCRIPTION").Value, rs.Fields("ID").Value)
                rs.MoveNext()
            Loop
        End If
        tb.Rows.Add("", -1)

        cboType.DataSource = tb
        cboType.Enabled = True

        rs.Close()
        rs = Nothing

        cboType.SelectedIndex = 0

    End Sub
    Private Sub frmAddAmenity_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        On Error GoTo errHandler

        Dim rsAddAmen As New ADODB.Recordset

        'Me.AMENITIES_OWNER_CODETableAdapter.Fill(Me.DsAmentityOwner.AMENITIES_OWNER_CODE)
        'Me.AMENITIES_TYPE_CODETableAdapter.Fill(Me.DsAmenityType.AMENITIES_TYPE_CODE)
        'Me.AMENITIES_TYPE_CODETableAdapter.Fill(Me.DsAmenityType.AMENITIES_TYPE_CODE)
        'Me.TblStopPsgrAmenitiesTableAdapter.Fill(Me.DsPassAmenities.tblStopPsgrAmenities)

        strSANZID = frmUpdateStop.txtSANZID.Text
        strOCTAID = CInt(frmUpdateStop.txtOCTAID.Text)
        txtSanz_ID.Text = strSANZID

        Call LoadOwnerType()
        Call LoadAmenityType()

        dtDate.Format = DateTimePickerFormat.Custom
        dtDate.CustomFormat = "MM/dd/yyyy"
        dtTime.Format = DateTimePickerFormat.Time
        dtTime.ShowUpDown = True

        dtDate.Value = Date.Today.ToShortDateString
        dtTime.Value = Date.Now.ToString

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOk.Click
        On Error GoTo errHandler

        If Not IsNumeric(txtNum.Text) Then
            MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
            txtNum.SelectionStart = 0
            txtNum.SelectionLength = Len(txtNum.Text)
            txtNum.Focus()
            Exit Sub
        Else
            If CShort(txtNum.Text) > 255 Then
                MsgBox("Invalid value!", MsgBoxStyle.Exclamation)
                txtNum.SelectionStart = 0
                txtNum.SelectionLength = Len(txtNum.Text)
                txtNum.Focus()
                Exit Sub
            End If
        End If

        If cboType.SelectedIndex = -1 Then
            MsgBox("Please select an amenity type.", MsgBoxStyle.Exclamation)
            cboType.Focus()
            Exit Sub
        End If

        If cboOwner.SelectedIndex = -1 Then
            MsgBox("Please select an amenity owner.", MsgBoxStyle.Exclamation)
            cboOwner.Focus()
            Exit Sub
        End If

        Dim lngNum As Integer
        Dim intType As Short
        Dim intOwner As Short
        Dim strDate As String
        Dim strTime As String
        Dim strType As String
        Dim strOwner As String
        Dim strSQL As String

        lngNum = CInt(txtNum.Text)
        strType = cboType.Text
        strOwner = cboOwner.Text
        strDate = dtDate.Value
        strTime = dtTime.Value
        intType = cboType.SelectedValue
        intOwner = cboOwner.SelectedValue

        ' Insert the entry based on values given
        strSQL = "INSERT INTO tblStopPsgrAmenities " _
                & "(OCTA_ID, SANZ_ID, NUM, AMENITIES_TYPE_ID, " _
                & "AMENITIES_OWNER_ID, DATE_SURV, TIME_SURV) " _
                & "VALUES (" & strOCTAID & ", '" & strSANZID & "', " & lngNum & ", " & intType & ", " & intOwner & ", '" & strDate & "', '" & strTime & "')"

        db.Execute(strSQL)
        Me.Close()

        Exit Sub

errHandler:
        MsgBox(Err.Description)

    End Sub
End Class