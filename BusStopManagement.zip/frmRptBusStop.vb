﻿Imports System.Data.SqlClient

Public Class frmRptBusStop

    Private optBusStop() As RadioButton
    Private optStopStatus() As RadioButton
    Private optBusStopADA() As RadioButton
    Private optBusStopHistory() As RadioButton

    Public Sub New()
        InitializeComponent()
        optBusStop = New RadioButton() {optBusStop0, optBusStop1, optBusStop2, optBusStop3, optBusStop4, optBusStop5, optBusStop6}
        optStopStatus = New RadioButton() {optStopStatus0, optStopStatus1, optStopStatus2}
        optBusStopADA = New RadioButton() {optBusStopADA0, optBusStopADA1}
        optBusStopHistory = New RadioButton() {optBusStopHistory0, optBusStopHistory1}
    End Sub

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdPrint_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPrint.Click
        Dim strSQL As String = ""
        Dim intType As Short
        Dim strLabel As String = ""
        Dim strFooterLabel As String = ""
        Dim strReportName As String = ""
        Dim strTableName As String = ""
        Dim blnSummaryReport As Boolean
        Dim strWhereClause2 As String
        Dim strStopStatus As String
        Dim strStatus As String
        Dim strTitle As String = ""
        Dim strFooter As String = ""
        Dim myTokenizer As New clsTokenizer
        Dim iStreetType As Integer = 0

        If optStopStatus(0).Checked Then
            strStopStatus = " AND info.ACTIVE_STOP = 1 "
            strStatus = "ALL ACTIVE STOPS"
        ElseIf optStopStatus(1).Checked Then
            strStopStatus = " AND info.ACTIVE_STOP <> 1 "
            strStatus = "ALL NON-ACTIVE STOPS"
        Else
            strStopStatus = ""
            strStatus = "ALL STOPS"
        End If

        blnSummaryReport = False
        If optBusStop(0).Checked Then
            'Bus Stop report by Jurisdiction
            'get jurisdiction id
            intType = cboByJurisd.SelectedValue

            strSQL = "INSERT INTO tblBusStopReport(OCTA_ID, SANZ_ID, CITY, TBM_PAGE, DIR, STREET_OF_TRAVEL, STTYPE, LOC, CROSS_STREET, XSTTYPE, CROSS_STREET_1) " _
                        & "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " _
                        & "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " _
                        & "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " _
                        & "FROM ((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " _
                        & "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " _
                        & "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " _
                        & "Or (info.ST_TYPE_ID_1 Is NULL And type1.ID = 0))) " _
                        & "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " _
                        & "Or (info.ST_TYPE_ID_2 Is NULL And type2.ID = 0))) " _
                        & "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " _
                        & "WHERE info.CITY_ID = " & intType & strStopStatus & " ORDER BY CAST(LEFT(info.SANZ_ID, Patindex('%[^-.0-9]%', info.SANZ_ID + 'x') - 1) AS Float), info.SANZ_ID"

            strTitle = "OCTA - BUS STOPS REPORT"
            strLabel = "CITY OF " & GetCityName(cboByJurisd.SelectedValue)
            strFooter = "BUS STOP REPORT: " & strLabel & "  (" & strStatus & ")"
            strReportName = "BusStopReport.rpt"
            strTableName = "tblBusStopReport"
        ElseIf optBusStop(1).Checked Then
            'Bus Stop report by STREET_OF_TRAVEL within a JURISDICTION
            'get jurisdiction id
            intType = cboWithinJurisd.SelectedValue
            iStreetType = CInt(Mid(cboStreetGhost.Text, InStr(cboStreetGhost.Text, "|") + 1, Len(cboStreetGhost.Text) - InStr(cboStreetGhost.Text, "|")))

            strSQL = "INSERT INTO tblBusStopReport(OCTA_ID, SANZ_ID, CITY, TBM_PAGE, DIR, STREET_OF_TRAVEL, STTYPE, LOC, CROSS_STREET, XSTTYPE, CROSS_STREET_1) " _
                & "SELECT info.OCTA_ID, info.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " _
                & "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " _
                & "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " _
                & "FROM ((((tblBusStopInformation AS info LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " _
                & "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " _
                & "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " _
                & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                & "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " _
                & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " _
                & "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " _
                & "WHERE info.CITY_ID = " & intType & " AND info.STREET_OF_TRAVEL + ' ' + type1.TYPE = '" & Me.cboStreet.Text & "' " & strStopStatus & " " _
                & "ORDER BY CAST(LEFT(info.SANZ_ID, Patindex('%[^-.0-9]%', info.SANZ_ID + 'x') - 1) AS Float), info.SANZ_ID"

            strTitle = "OCTA - BUS STOPS REPORT"
            strLabel = cboStreet.Text & " - CITY OF " & GetCityName(cboWithinJurisd.SelectedValue)
            strFooter = "BUS STOP REPORT: " & strLabel & "  (" & strStatus & ")"
            strReportName = "BusStopReport.rpt"
            strTableName = "tblBusStopReport"
        ElseIf optBusStop(2).Checked Then
            'Bus Stop report for surveyed stops within a JURISDICTION OR ALL
            If optBusStopADA(0).Checked Then
                'get jurisdiction id
                intType = cboADAJurisd.SelectedValue
                strSQL = "INSERT INTO tblBusStopReport(OCTA_ID, SANZ_ID, CITY, TBM_PAGE, DIR, STREET_OF_TRAVEL, STTYPE, LOC, CROSS_STREET, XSTTYPE, CROSS_STREET_1) " _
                    & "SELECT ada.OCTA_ID, ada.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " _
                    & "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " _
                    & "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " _
                    & "FROM (((((tblADAStatus AS ada LEFT JOIN tblBusStopInformation AS info ON ada.OCTA_ID = info.OCTA_ID) " _
                    & "LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " _
                    & "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " _
                    & "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " _
                    & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                    & "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " _
                    & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " _
                    & "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " _
                    & "WHERE ada.SURVEYED = 1 AND info.CITY_ID = " & intType & strStopStatus & " ORDER BY CAST(LEFT(ada.SANZ_ID, Patindex('%[^-.0-9]%', ada.SANZ_ID + 'x') - 1) AS Float), ada.SANZ_ID"

                strTitle = "OCTA - BUS STOPS SURVEYED FOR ADA"
                strLabel = "CITY OF " & GetCityName(cboADAJurisd.SelectedValue)
                strFooter = "SURVEYED ADA BUS STOP REPORT: " & strLabel & "  (" & strStatus & ")"
                strReportName = "BusStopReport.rpt"
            Else
                strSQL = "INSERT INTO tblBusStopReport(OCTA_ID, SANZ_ID, CITY, TBM_PAGE, DIR, STREET_OF_TRAVEL, STTYPE, LOC, CROSS_STREET, XSTTYPE, CROSS_STREET_1) " _
                    & "SELECT ada.OCTA_ID, ada.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " _
                    & "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " _
                    & "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " _
                    & "FROM (((((tblADAStatus AS ada LEFT JOIN tblBusStopInformation AS info ON ada.OCTA_ID = info.OCTA_ID) " _
                    & "LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " _
                    & "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " _
                    & "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " _
                    & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                    & "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " _
                    & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " _
                    & "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " _
                    & "WHERE ada.SURVEYED = 1 " & strStopStatus & " ORDER BY info.CITY_ID, CAST(LEFT(ada.SANZ_ID, Patindex('%[^-.0-9]%', ada.SANZ_ID + 'x') - 1) AS Float), ada.SANZ_ID"

                strTitle = "OCTA - ALL BUS STOPS SURVEYED FOR ADA"
                strLabel = ""
                strFooter = "SURVEYED ADA BUS STOP REPORT: ALL CITIES  (" & strStatus & ")"
                strReportName = "BusStopReportAll.rpt"
            End If
            strTableName = "tblBusStopReport"
        ElseIf optBusStop(3).Checked Then
            'Bus Stop report for NOT surveyed stops within a JURISDICTION OR ALL
            If optBusStopADA(0).Checked Then
                'get jurisdiction id
                intType = cboADAJurisd.SelectedValue
                strSQL = "INSERT INTO tblBusStopReport(OCTA_ID, SANZ_ID, CITY, TBM_PAGE, DIR, STREET_OF_TRAVEL, STTYPE, LOC, CROSS_STREET, XSTTYPE, CROSS_STREET_1) " _
                    & "SELECT ada.OCTA_ID, ada.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " _
                    & "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " _
                    & "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " _
                    & "FROM (((((tblADAStatus AS ada LEFT JOIN tblBusStopInformation AS info ON ada.OCTA_ID = info.OCTA_ID) " _
                    & "LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " _
                    & "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " _
                    & "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " _
                    & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                    & "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " _
                    & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " _
                    & "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " _
                    & "WHERE ada.SURVEYED = 0 AND info.CITY_ID = " & intType & strStopStatus & " ORDER BY CAST(LEFT(ada.SANZ_ID, Patindex('%[^-.0-9]%', ada.SANZ_ID + 'x') - 1) AS Float), ada.SANZ_ID"

                strTitle = "OCTA - BUS STOPS NOT SURVEYED FOR ADA"
                strLabel = "CITY OF " & GetCityName(cboADAJurisd.SelectedValue)
                strFooter = "NOT SURVEYED ADA BUS STOP REPORT: " & strLabel & "  (" & strStatus & ")"
                strReportName = "BusStopReport.rpt"
            Else
                strSQL = "INSERT INTO tblBusStopReport(OCTA_ID, SANZ_ID, CITY, TBM_PAGE, DIR, STREET_OF_TRAVEL, STTYPE, LOC, CROSS_STREET, XSTTYPE, CROSS_STREET_1) " _
                    & "SELECT ada.OCTA_ID, ada.SANZ_ID, city.CITY, info.TBM_PAGE, dir.DIR, " _
                    & "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " _
                    & "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " _
                    & "FROM (((((tblADAStatus AS ada LEFT JOIN tblBusStopInformation AS info ON ada.OCTA_ID = info.OCTA_ID) " _
                    & "LEFT JOIN CITY_CODE AS city ON info.CITY_ID = city.ID) " _
                    & "LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " _
                    & "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " _
                    & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
                    & "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " _
                    & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " _
                    & "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " _
                    & "WHERE ada.SURVEYED = 0 " & strStopStatus & " ORDER BY CAST(LEFT(ada.SANZ_ID, Patindex('%[^-.0-9]%', ada.SANZ_ID + 'x') - 1) AS Float), ada.SANZ_ID"

                strTitle = "OCTA - BUS STOPS NOT SURVEYED FOR ADA"
                strLabel = ""
                strFooter = "NOT SURVEYED ADA BUS STOP REPORT: ALL CITIES  (" & strStatus & ")"
                strReportName = "BusStopReportAll.rpt"
            End If

            strTableName = "tblBusStopReport"
        ElseIf optBusStop(4).Checked Or optBusStopHistory(0).Checked Or optBusStopHistory(1).Checked Then
            If Not IsNumeric(txtOCTAID.Text) Then
                MsgBox("Invalid OCTA ID!", MsgBoxStyle.Exclamation)
                Exit Sub
            End If

            If optBusStopHistory(0).Checked Then 'Get all bus stop history
                strSQL = "INSERT INTO tblBusStopHistoryReport(DATE_ISSUED, FULL_NAME, TYPE, WO_NUM, REMARKS, CreatedDate) " _
                    & "SELECT CONVERT(varchar(10), shis.DATE, 101) AS DATE_ISSUED, stf.FNAME + ' ' + stf.LNAME as FULL_NAME, hist.TYPE, shis.WO_NUM, shis.REMARKS, shis.CreatedDate " _
                    & "FROM (tblStopHistory AS shis LEFT JOIN tblStaff AS stf ON shis.STAFF_ID = stf.STAFF_ID) " _
                    & "LEFT JOIN HISTORY_TYPE_CODE AS hist ON shis.HISTORY_TYPE_ID = hist.ID " _
                    & "WHERE (shis.OCTA_ID = " & txtOCTAID.Text & ") " & " ORDER BY shis.DATE DESC"

                strTitle = "OCTA - BUS STOPS HISTORY REPORT"
                strLabel = GetStopLocation(CInt(txtOCTAID.Text))
                strStatus = "COMPLETE HISTORY"
                strFooter = strLabel & " (" & strStatus & ")"
                strReportName = "BusStopHistoryReport.rpt"
                strTableName = "tblBusStopHistoryReport"
            Else 'Get work order history
                strSQL = "INSERT INTO tblBusStopWOHistoryReport(DATE_ISSUED, DATE_CLOSED, FULL_NAME, TYPE, WO_NUM, REMARKS, CreatedDate) " _
                    & "SELECT shis.[DATE] AS DATE_ISSUED, wow.WO_COMPLETE_DATE AS DATE_CLOSED, " _
                    & "stff.FNAME + ' ' + stff.LNAME AS FULL_NAME, " _
                    & "histt.TYPE, shis.WO_NUM, shis.REMARKS, shis.CreatedDate " _
                    & "FROM ((tblStopHistory AS shis LEFT JOIN tblStaff AS stff ON shis.STAFF_ID = stff.STAFF_ID) " _
                    & "LEFT JOIN tblWorkOrders AS wow ON shis.WO_NUM = wow.WO_ID) " _
                    & "LEFT JOIN HISTORY_TYPE_CODE AS histt ON shis.HISTORY_TYPE_ID = histt.ID " _
                    & "WHERE shis.WO_NUM IS NOT NULL AND shis.OCTA_ID = " & txtOCTAID.Text & " ORDER BY shis.DATE DESC"

                strTitle = "OCTA - BUS STOPS WORK ORDER REPORT"
                strLabel = GetStopLocation(CInt(txtOCTAID.Text))
                strStatus = "WORK ORDER HISTORY"
                strFooter = strLabel & " (" & strStatus & ")"
                strReportName = "BusStopWOHistoryReport.rpt"
                strTableName = "tblBusStopWOHistoryReport"
            End If
        ElseIf optBusStop(5).Checked Then
            Select Case cboCountyOption.SelectedIndex
                Case 1
                    strWhereClause2 = " AND COUNTY_ID = 1" 'Orange county
                    strFooterLabel = "ORANGE COUNTY"
                Case 2
                    strWhereClause2 = " AND COUNTY_ID = 2" 'LA county
                    strFooterLabel = "LOS ANGELES COUNTY"
                Case 3
                    strWhereClause2 = " AND COUNTY_ID = 3" 'Riverside county
                    strFooterLabel = "RIVERSIDE COUNTY"
                Case Else
                    strWhereClause2 = ""
                    strFooterLabel = "ALL COUNTIES"
            End Select
            strSQL = "SELECT ID, DESCRIPTION FROM CITY_CODE WHERE IS_CITY = 1" & strWhereClause2 & " ORDER BY DESCRIPTION"

            Call PrepareDataADA(strSQL)

            strLabel = strStatus & " - " & strFooterLabel
            strFooterLabel = "ADA Status - " & strStatus & " - " & strFooterLabel
            strReportName = "ADASummaryReport.rpt"

            blnSummaryReport = True
        ElseIf optBusStop(6).Checked Then
            Select Case cboCountyOption.SelectedIndex
                Case 1
                    strWhereClause2 = " AND COUNTY_ID = 1" 'Orange county
                    strFooterLabel = "ORANGE COUNTY"
                Case 2
                    strWhereClause2 = " AND COUNTY_ID = 2" 'LA county
                    strFooterLabel = "LOS ANGELES COUNTY"
                Case 3
                    strWhereClause2 = " AND COUNTY_ID = 3" 'Riverside county
                    strFooterLabel = "RIVERSIDE COUNTY"
                Case Else
                    strWhereClause2 = ""
                    strFooterLabel = "ALL COUNTIES"
            End Select
            strSQL = "SELECT ID, DESCRIPTION FROM CITY_CODE WHERE IS_CITY = 1" & strWhereClause2 & " ORDER BY DESCRIPTION"

            Call PrepareDataAmenity(strSQL)

            strLabel = strStatus & " - " & strFooterLabel
            strFooterLabel = "Amenities - " & strStatus & " - " & strFooterLabel
            strReportName = "AmenitySummaryReport.rpt"

            blnSummaryReport = True
        End If

        myTokenizer = Nothing

        'call to prepare report
        If blnSummaryReport Then
            Call PrepareSummaryReport(strLabel, strReportName, strFooterLabel)
        Else
            Call PrepareReport(strSQL, strTitle, strLabel, strStatus, strReportName, strTableName, strFooter)
        End If
    End Sub

    Private Function GetStopLocation(ByRef aOCTA_ID As Integer) As String
        Dim rsLoc As New ADODB.Recordset
        Dim strSQL As String
        Dim strReturn As String
        Dim strDIR As String
        Dim strStreet As String
        Dim strCross As String
        Dim strType1 As String
        Dim strType2 As String
        Dim strLoc As String
        Dim strCross2 As String

        strSQL = "SELECT info.SANZ_ID, dir.DIR, " _
            & "info.STREET_OF_TRAVEL, type1.TYPE AS STTYPE, loc.LOC, info.CROSS_STREET, " _
            & "type2.TYPE AS XSTTYPE, info.CROSS_STREET_1 " _
            & "FROM (((tblBusStopInformation AS info LEFT JOIN ST_DIR_CODE AS dir ON info.ST_DIR_ID = dir.ID) " _
            & "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " _
            & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))) " _
            & "LEFT JOIN ST_TYPE_CODE as [type2] ON ((info.ST_TYPE_ID_2 = type2.ID) " _
            & "OR (info.ST_TYPE_ID_2 IS NULL AND type2.ID = 0))) " _
            & "LEFT JOIN BS_LOC_CODE AS loc ON info.BS_LOC_ID = loc.ID " _
            & "Where (info.OCTA_ID = " & aOCTA_ID & ")"

        rsLoc.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        strReturn = ""
        If Not rsLoc.EOF Then
            strDIR = IIf(IsDBNull(rsLoc.Fields("DIR").Value), "", rsLoc.Fields("DIR").Value)
            strStreet = IIf(IsDBNull(rsLoc.Fields("STREET_OF_TRAVEL").Value), "", " " & rsLoc.Fields("STREET_OF_TRAVEL").Value)
            strCross = IIf(IsDBNull(rsLoc.Fields("CROSS_STREET").Value), "", " " & rsLoc.Fields("CROSS_STREET").Value)
            strType1 = IIf(IsDBNull(rsLoc.Fields("STTYPE").Value), "", " " & rsLoc.Fields("STTYPE").Value)
            strType2 = IIf(IsDBNull(rsLoc.Fields("XSTTYPE").Value), "", " " & rsLoc.Fields("XSTTYPE").Value)
            strLoc = IIf(IsDBNull(rsLoc.Fields("LOC").Value), "", rsLoc.Fields("LOC").Value)
            strCross2 = IIf(IsDBNull(rsLoc.Fields("CROSS_STREET_1").Value), "", " " & rsLoc.Fields("CROSS_STREET_1").Value)

            strReturn = Trim(strDIR & strStreet & strType1)
            strReturn = strReturn & " / " & Trim(strLoc & strCross & strType2) & strCross2
        End If

        rsLoc.Close()
        rsLoc = Nothing
        GetStopLocation = strReturn
    End Function

    Private Function GetCityName(ByRef aID As Short) As String
        Dim rsCName As New ADODB.Recordset
        Dim strSQL As String
        Dim strCity As String

        strSQL = "SELECT CITY, DESCRIPTION FROM CITY_CODE WHERE ID = " & aID
        rsCName.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        If rsCName.EOF Then
            strCity = "Unknown City"
        Else
            strCity = IIf(IsDBNull(rsCName.Fields("DESCRIPTION").Value), rsCName.Fields("CITY").Value, rsCName.Fields("DESCRIPTION").Value)
        End If

        rsCName.Close()
        rsCName = Nothing

        GetCityName = strCity
    End Function

    Private Sub PrepareDataADA(ByRef aCitySQL As String)
        Dim strSQL As String
        Dim rsID As New ADODB.Recordset
        Dim rsCount As New ADODB.Recordset
        Dim rsDest As New ADODB.Recordset
        Dim lngPACount, lngFACount, lngTotalCount, lngABCount, lngIACount As Integer
        Dim lngNSCount As Integer
        Dim strStopStatus As String

        If optStopStatus(0).Checked Then
            strStopStatus = " AND info.ACTIVE_STOP = 1"
        ElseIf optStopStatus(1).Checked Then
            strStopStatus = " AND info.ACTIVE_STOP <> 1"
        Else
            strStopStatus = ""
        End If

        '///////////////ADA STATUS ID////////////////
        '1 - F - FULLY ACCESSIBLE
        '2 - P - PARTIALLY ACCESSIBLE
        '3 - I - INACCESSIBLE
        '4 - N - NOT SURVEYED
        '5 - A - ACCESSIBLE - BUT NEEDS IMPROVEMENTS
        '////////////////////////////////////////////

        rsID.Open(aCitySQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        'Clear up destination
        strSQL = "DELETE  FROM tblADASummaryReport"
        dbRep.Execute(strSQL)
        'open destination table
        rsDest.Open("tblADASummaryReport", dbRep, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdTableDirect)

        Do While Not rsID.EOF
            'Total number of stops in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblBusStopInformation AS info " & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & strStopStatus
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngTotalCount = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of FA stops in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblBusStopInformation AS info " _
                & "LEFT JOIN tblADAStatus AS ada ON info.OCTA_ID = ada.OCTA_ID " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & " AND ada.ADA_STATUS_ID = 1" & strStopStatus
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngFACount = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of AB stops in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblBusStopInformation AS info " _
                & "LEFT JOIN tblADAStatus AS ada ON info.OCTA_ID = ada.OCTA_ID " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & " AND ada.ADA_STATUS_ID = 5" & strStopStatus
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngABCount = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of PA stops in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblBusStopInformation AS info " _
                & "LEFT JOIN tblADAStatus AS ada ON info.OCTA_ID = ada.OCTA_ID " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & " AND ada.ADA_STATUS_ID = 2" & strStopStatus
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngPACount = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of IA stops in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblBusStopInformation AS info " _
                & "LEFT JOIN tblADAStatus AS ada ON info.OCTA_ID = ada.OCTA_ID " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & " AND ada.ADA_STATUS_ID = 3" & strStopStatus
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngIACount = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of NS stops in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblBusStopInformation AS info " _
                & "LEFT JOIN tblADAStatus AS ada ON info.OCTA_ID = ada.OCTA_ID " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & " AND ada.ADA_STATUS_ID = 4" & strStopStatus
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngNSCount = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            rsDest.AddNew()
            rsDest.Fields("CITY").Value = rsID.Fields("DESCRIPTION").Value
            rsDest.Fields("TOTAL_STOPS").Value = lngTotalCount
            rsDest.Fields("FA_STOPS").Value = lngFACount
            rsDest.Fields("AB_STOPS").Value = lngABCount
            rsDest.Fields("PA_STOPS").Value = lngPACount
            rsDest.Fields("IA_STOPS").Value = lngIACount
            rsDest.Fields("NS_STOPS").Value = lngNSCount
            rsDest.Update()

            rsID.MoveNext()
        Loop

        rsCount = Nothing
        rsDest.Close()
        rsDest = Nothing
        rsID.Close()
        rsID = Nothing

        dbRep.Close()
        dbRep.Open()
    End Sub

    Private Sub PrepareDataAmenity(ByRef aCitySQL As String)
        Dim strSQL As String
        Dim rsID As New ADODB.Recordset
        Dim rsCount As New ADODB.Recordset
        Dim rsDest As New ADODB.Recordset
        Dim lngWBench, lngWCan, lngTotal, lngTotalCan, lngTotalBench As Integer
        Dim lngWPad, lngWShelter, lngTotalShelter, lngWTurnout As Integer
        Dim strStopStatus As String

        If optStopStatus(0).Checked Then
            strStopStatus = " AND info.ACTIVE_STOP = 1"
        ElseIf optStopStatus(1).Checked Then
            strStopStatus = " AND info.ACTIVE_STOP <> 1"
        Else
            strStopStatus = ""
        End If

        '///////////////ADA STATUS ID////////////////
        '1 - BN - BENCH
        '2 - BR - BIKE RACK
        '3 - SH - SHELTER
        '4 - TC - TRASH CAN
        '5 - VM - VENDING MACHINE
        '////////////////////////////////////////////

        rsID.Open(aCitySQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        'Clear up destination
        strSQL = "DELETE  FROM tblAmenitySummaryReport"
        dbRep.Execute(strSQL)
        'open destination table
        rsDest.Open("tblAmenitySummaryReport", dbRep, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdTableDirect)

        Do While Not rsID.EOF
            'Total number of stops in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblBusStopInformation AS info " & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & strStopStatus
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngTotal = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of stops with trash can in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblStopPsgrAmenities AS psg " _
                & "INNER JOIN (SELECT OCTA_ID FROM tblBusStopInformation AS info " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & strStopStatus & ") AS bus ON psg.OCTA_ID = bus.OCTA_ID " _
                & "WHERE psg.AMENITIES_TYPE_ID = 4"
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngWCan = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of trash cans in city bus stops
            strSQL = "SELECT SUM(NUM) AS STOP_COUNT FROM tblStopPsgrAmenities AS psg " _
                & "INNER JOIN (SELECT OCTA_ID FROM tblBusStopInformation AS info " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & strStopStatus & ") AS bus ON psg.OCTA_ID = bus.OCTA_ID " _
                & "WHERE psg.AMENITIES_TYPE_ID = 4"
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngTotalCan = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of stops with benches in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblStopPsgrAmenities AS psg " _
                & "INNER JOIN (SELECT OCTA_ID FROM tblBusStopInformation AS info " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & strStopStatus & ") AS bus ON psg.OCTA_ID = bus.OCTA_ID " _
                & "WHERE psg.AMENITIES_TYPE_ID = 1"
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngWBench = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of benches in city bus stops
            strSQL = "SELECT SUM(NUM) AS STOP_COUNT FROM tblStopPsgrAmenities AS psg " _
                & "INNER JOIN (SELECT OCTA_ID FROM tblBusStopInformation AS info " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & strStopStatus & ") AS bus ON psg.OCTA_ID = bus.OCTA_ID " _
                & "WHERE psg.AMENITIES_TYPE_ID = 1"
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngTotalBench = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of stops with shelter in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblStopPsgrAmenities AS psg " _
                & "INNER JOIN (SELECT OCTA_ID FROM tblBusStopInformation AS info " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & strStopStatus & ") AS bus ON psg.OCTA_ID = bus.OCTA_ID " _
                & "WHERE psg.AMENITIES_TYPE_ID = 3"
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngWShelter = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of shelters in city bus stops
            strSQL = "SELECT SUM(NUM) AS STOP_COUNT FROM tblStopPsgrAmenities AS psg " _
                & "INNER JOIN (SELECT OCTA_ID FROM tblBusStopInformation AS info " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & strStopStatus & ") AS bus ON psg.OCTA_ID = bus.OCTA_ID " _
                & "WHERE psg.AMENITIES_TYPE_ID = 3"
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngTotalShelter = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of stops with bus pads in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblBusStopInformation AS info " _
                & "LEFT JOIN tblStopTransAmenities AS sta ON info.OCTA_ID = sta.OCTA_ID " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & strStopStatus & " AND sta.BUS_PAD = 1"
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngWPad = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            'Total number of stops with turnout in city
            strSQL = "SELECT COUNT(*) AS STOP_COUNT FROM tblBusStopInformation AS info " _
                & "LEFT JOIN tblStopTransAmenities AS sta ON info.OCTA_ID = sta.OCTA_ID " _
                & "WHERE info.CITY_ID = " & rsID.Fields("ID").Value & strStopStatus & " AND sta.TURNOUT = 1"
            rsCount.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)
            lngWTurnout = IIf(IsDBNull(rsCount.Fields("STOP_COUNT").Value), 0, rsCount.Fields("STOP_COUNT").Value)
            rsCount.Close()

            rsDest.AddNew()
            rsDest.Fields("CITY").Value = rsID.Fields("DESCRIPTION").Value
            rsDest.Fields("TOTAL_STOPS").Value = lngTotal
            rsDest.Fields("WC_STOPS").Value = lngWCan
            rsDest.Fields("TOTAL_CANS").Value = lngTotalCan
            rsDest.Fields("WB_STOPS").Value = lngWBench
            rsDest.Fields("TOTAL_BENCHES").Value = lngTotalBench
            rsDest.Fields("WS_STOPS").Value = lngWShelter
            rsDest.Fields("TOTAL_SHELTERS").Value = lngTotalShelter
            rsDest.Fields("WP_STOPS").Value = lngWPad
            rsDest.Fields("WT_STOPS").Value = lngWTurnout
            rsDest.Update()

            rsID.MoveNext()
        Loop

        rsCount = Nothing
        rsDest.Close()
        rsDest = Nothing
        rsID.Close()
        rsID = Nothing

        dbRep.Close()
        dbRep.Open()
    End Sub

    Private Sub PrepareSummaryReport(ByRef aLabelText As String, ByRef aReportName As String, Optional ByRef aFooterLabel As String = "")

        frmCrystalReportsWP.LoadReport(aReportName, "", aLabelText, aFooterLabel)

    End Sub

    Private Sub PrepareReport(ByRef aSQL As String, ByRef aTitle As String, ByRef aLabelText As String, ByRef aStatus As String, ByRef aReportName As String, ByRef aTableName As String, Optional ByRef aFooterText As String = "")
        Dim strSQL As String
        Dim blnShowReport As Boolean
        Dim iCount As Integer
        Dim oConn As New SqlConnection(sConn)

        Me.Enabled = False
        Me.Cursor = System.Windows.Forms.Cursors.WaitCursor

        ' delete any existing data
        strSQL = "DELETE FROM [" & aTableName & "]"
        dbRep.Execute(strSQL)

        Using cmd As SqlCommand = New SqlCommand(aSQL, oConn)
            oConn.Open()
            iCount = Convert.ToInt32(cmd.ExecuteNonQuery())
            oConn.Close()
        End Using

        If iCount > 0 Then
            blnShowReport = True
        Else
            MsgBox("Could Not Locate Requested Bus Stops. Re-Check Your Data And Try Again.", MsgBoxStyle.Information)
            blnShowReport = False
        End If

        Me.Enabled = True
        Me.Cursor = System.Windows.Forms.Cursors.Default

        'ByRef sReportName As String, ByRef sReportTitle As String, ByRef sReportStatus As String, ByRef sReportFooter As String
        If blnShowReport Then frmCrystalReportsWP.LoadReport(aReportName, aTitle, aLabelText, aFooterText)

    End Sub

    Private Sub frmRptBusStop_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        On Error GoTo errHandler

        Me.CITY_CODETableAdapter.Fill(Me.DsCityCode.CITY_CODE)
        Me.ADA_STATUS_CODETableAdapter.Fill(Me.DsADAStatusDesc.ADA_STATUS_CODE)

        LoadStreet()
        LoadCountyOption()

        optStopStatus(0).Checked = True

        AddHandler optBusStop(0).CheckedChanged, AddressOf optBusStop_CheckedChanged
        AddHandler optBusStop(1).CheckedChanged, AddressOf optBusStop_CheckedChanged
        AddHandler optBusStop(2).CheckedChanged, AddressOf optBusStop_CheckedChanged
        AddHandler optBusStop(3).CheckedChanged, AddressOf optBusStop_CheckedChanged
        AddHandler optBusStop(4).CheckedChanged, AddressOf optBusStop_CheckedChanged
        AddHandler optBusStop(5).CheckedChanged, AddressOf optBusStop_CheckedChanged
        AddHandler optBusStop(6).CheckedChanged, AddressOf optBusStop_CheckedChanged
        AddHandler optBusStopADA(0).CheckedChanged, AddressOf optBusStopADA_CheckedChanged
        AddHandler optBusStopADA(1).CheckedChanged, AddressOf optBusStopADA_CheckedChanged

        Exit Sub
errHandler:
        MsgBox(Err.Number & " | " & Err.Description & " | " & Err.Source & " | " & Err.LastDllError)
        Exit Sub

    End Sub

    Private Sub LoadStreet()
        Dim strSQL As String
        Dim rsData As New ADODB.Recordset
        Dim strType As String

        strSQL = "SELECT DISTINCT STREET_OF_TRAVEL, ST_TYPE_ID_1, type1.TYPE AS STTYPE FROM tblBusStopInformation as info " _
            & "LEFT JOIN ST_TYPE_CODE as [type1] ON ((info.ST_TYPE_ID_1 = type1.ID) " _
            & "OR (info.ST_TYPE_ID_1 IS NULL AND type1.ID = 0))"

        rsData.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        Do While Not rsData.EOF
            If Not IsDBNull(rsData.Fields("STREET_OF_TRAVEL").Value) Then
                strType = ""
                If Not IsDBNull(rsData.Fields("STTYPE").Value) Then
                    If Trim(rsData.Fields("STTYPE").Value) <> "_" Then
                        strType = rsData.Fields("STTYPE").Value
                    End If
                End If
                cboStreet.Items.Add(rsData.Fields("STREET_OF_TRAVEL").Value & " " & strType)
                cboStreetGhost.Items.Add(rsData.Fields("STREET_OF_TRAVEL").Value & "|" & rsData.Fields("ST_TYPE_ID_1").Value)
            End If
            rsData.MoveNext()
        Loop

        If cboStreet.Items.Count > 0 Then cboStreet.SelectedIndex = 0
        rsData.Close()
        rsData = Nothing
    End Sub

    Private Sub LoadCountyOption()

        cboCountyOption.Items.Clear()
        cboCountyOption.Items.Add("All")
        cboCountyOption.Items.Add("Orange County Only")
        cboCountyOption.Items.Add("LA County Only")
        cboCountyOption.Items.Add("Riverside County Only")

        cboCountyOption.SelectedIndex = 0
    End Sub
    Private Sub optBusStop_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

        If sender.Checked Then
            Select Case sender.name
                Case "optBusStop0"
                    CboEnabled(cboByJurisd, True)
                    CboEnabled(cboStreet, False)
                    CboEnabled(cboWithinJurisd, False)
                    CboEnabled(cboADAJurisd, False)
                    CboEnabled(cboCountyOption, False)
                    TxtEnabled(txtOCTAID, False)
                    optBusStopADA(0).Enabled = False
                    optBusStopADA(1).Enabled = False
                    optBusStopHistory(0).Enabled = False
                    optBusStopHistory(1).Enabled = False
                Case "optBusStop1"
                    CboEnabled(cboByJurisd, False)
                    CboEnabled(cboStreet, True)
                    CboEnabled(cboWithinJurisd, True)
                    CboEnabled(cboADAJurisd, False)
                    CboEnabled(cboCountyOption, False)
                    TxtEnabled(txtOCTAID, False)
                    optBusStopADA(0).Enabled = False
                    optBusStopADA(1).Enabled = False
                    optBusStopHistory(0).Enabled = False
                    optBusStopHistory(1).Enabled = False
                Case "optBusStop2"
                    CboEnabled(cboByJurisd, False)
                    CboEnabled(cboStreet, False)
                    CboEnabled(cboWithinJurisd, False)
                    CboEnabled(cboCountyOption, False)
                    If optBusStopADA0.Checked = True Then
                        CboEnabled(cboADAJurisd, True)
                    Else
                        CboEnabled(cboADAJurisd, False)
                    End If
                    TxtEnabled(txtOCTAID, False)
                    optBusStopADA(0).Enabled = True
                    optBusStopADA(1).Enabled = True
                    optBusStopHistory(0).Enabled = False
                    optBusStopHistory(1).Enabled = False
                Case "optBusStop3"
                    CboEnabled(cboByJurisd, False)
                    CboEnabled(cboStreet, False)
                    CboEnabled(cboWithinJurisd, False)
                    CboEnabled(cboCountyOption, False)
                    If optBusStopADA(0).Checked = True Then
                        CboEnabled(cboADAJurisd, True)
                    Else
                        CboEnabled(cboADAJurisd, False)
                    End If
                    TxtEnabled(txtOCTAID, False)
                    optBusStopADA(0).Enabled = True
                    optBusStopADA(1).Enabled = True
                    optBusStopHistory(0).Enabled = False
                    optBusStopHistory(1).Enabled = False
                Case "optBusStop4"
                    CboEnabled(cboByJurisd, False)
                    CboEnabled(cboStreet, False)
                    CboEnabled(cboWithinJurisd, False)
                    CboEnabled(cboADAJurisd, False)
                    CboEnabled(cboCountyOption, False)
                    TxtEnabled(txtOCTAID, True)
                    optBusStopADA(0).Enabled = False
                    optBusStopADA(1).Enabled = False
                    optBusStopHistory(0).Enabled = True
                    optBusStopHistory(0).Checked = True
                    optBusStopHistory(1).Enabled = True
                Case "optBusStop5"
                    CboEnabled(cboByJurisd, False)
                    CboEnabled(cboStreet, False)
                    CboEnabled(cboWithinJurisd, False)
                    CboEnabled(cboCountyOption, True)
                    CboEnabled(cboADAJurisd, False)
                    TxtEnabled(txtOCTAID, False)
                    optBusStopADA(0).Enabled = False
                    optBusStopADA(1).Enabled = False
                    optBusStopHistory(0).Enabled = False
                    optBusStopHistory(1).Enabled = False
                Case "optBusStop6"
                    CboEnabled(cboByJurisd, False)
                    CboEnabled(cboStreet, False)
                    CboEnabled(cboWithinJurisd, False)
                    CboEnabled(cboCountyOption, True)
                    CboEnabled(cboADAJurisd, False)
                    TxtEnabled(txtOCTAID, False)
                    optBusStopADA(0).Enabled = False
                    optBusStopADA(1).Enabled = False
                    optBusStopHistory(0).Enabled = False
                    optBusStopHistory(1).Enabled = False
            End Select
        End If
    End Sub

    Private Sub txtOCTAID_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs)
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
        If KeyAscii = 13 Then
            cmdPrint_Click(cmdPrint, New System.EventArgs())
        End If
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub optBusStopADA_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If sender.Checked Then

            If sender.name = "optBusStopADA0" Then
                CboEnabled(cboADAJurisd, True)
            Else
                CboEnabled(cboADAJurisd, False)
            End If
        End If
    End Sub

    Private Sub cboStreet_SelectedValueChanged(sender As Object, e As EventArgs) Handles cboStreet.SelectedValueChanged

        cboStreetGhost.SelectedIndex = cboStreet.SelectedIndex

    End Sub

End Class