﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ZPBlib")> 
<Assembly: AssemblyDescription("ZoomPictureBox library project posted on VBForums")> 
<Assembly: AssemblyCompany(" ")> 
<Assembly: AssemblyProduct("ZPBlib")> 
<Assembly: AssemblyCopyright("Copyright ©   Vic Joseph 2012")> 
<Assembly: AssemblyTrademark("BB")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("c7392447-5ed2-4d95-a780-81da48461212")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.1.0")> 
