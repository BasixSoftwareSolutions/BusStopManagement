﻿Option Strict Off
Option Explicit On
Imports System.Configuration
Module basUtilities
    Public DB_PASSWORD As String
    Public DB_SERVER As String
    Public DB_USER As String
    Public DB_NAME As String
    Public strSQL As String
    Public rs As New ADODB.Recordset
    Public rsRouteInfo As New ADODB.Recordset
    Public dbRep As New ADODB.Connection
    Public SeqLowerBound As Short
    Public SeqUpperBound As Short
    Public db As New ADODB.Connection
    Public oConn As ADODB.Connection
    Public sConn As String
    Public OCTA_ID As Integer
    Public SANZ_ID As String
    Public ROUTE_ID As String
    Public ROUTE_DESC As String
    Public DIR_ID As Integer
    Public DIR_DESC As String
    Public DELETE_STOP_FLAG As Integer

    'Login Variables
    Public CurrentLoginUser As String
    Public CurrentLoginFullName As String
    Public CurrentLoginUserID As Integer = 999
    Public IsAdminUser As Boolean

    Public Const CB_ERR = (-1)
    Public Const CB_FINDSTRING = &H14C
    Public Const CB_FINDSTRINGEXACT = &H158
    Public Const CB_SHOWDROPDOWN = &H14F
    Public Const CB_GETDROPPEDSTATE = &H157

    Public CurrentUserRight As UserRight
    Public gBlnUpdateFormUp As Boolean
    Public gBlnCallFromArcView As Boolean
    Public gEditHistoryID As Integer

    Public Const DENY_POWER_USER_MESSAGE As String = "Access denied! Only Administrator is allowed for this operation."
    Public Const DENY_MESSAGE As String = "Access denied! Limited user not allow for this operation"

    'Constants for API functions
    Public Const SWP_NOMOVE As Short = 2
    Public Const SWP_NOSIZE As Short = 1
    Public Const FLAGS As Boolean = SWP_NOMOVE Or SWP_NOSIZE
    Public Const HWND_TOPMOST As Short = -1
    Public Const HWND_NOTOPMOST As Short = -2
    Public Const SW_SHOWNORMAL As Short = 1
    Public Const SW_SHOWMINIMIZED As Short = 2
    Public Const SW_SHOWMAXIMIZED As Short = 3
    Public Const ERR_DUPLICATE_KEY As Short = 91
    Public Const ITEM_NONEXIST As Short = 5
    Public Const ERR_APP_NOTFOUND As Integer = 429

    'API Functions
    Public Declare Function FindWindow Lib "user32.dll" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String) As Integer
    Public Declare Function SetWindowPos Lib "user32" (ByVal hwnd As Integer, ByVal hWndInsertAfter As Integer, ByVal X As Integer, ByVal Y As Integer, ByVal cx As Integer, ByVal cy As Integer, ByVal wFlags As Integer) As Integer
    Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
    Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" _
    (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, ByVal lParam As VariantType) As Long
    Public Declare Function ShellExecute Lib "Shell32.dll" Alias "ShellExecuteA" (ByVal hwnd As Integer, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Integer) As Integer


    Public Enum UserRight
        SystemAdmin = 3
        PowerUser = 2
        Viewer = 1
    End Enum

    Public Sub Main()

        On Error GoTo errHandler

        DB_PASSWORD = "oicu812"
        DB_SERVER = "ormsql24"
        DB_USER = "BSM_User"
        DB_NAME = "BusStopManagement"

        'Use SQL Server 13 driver
        db.ConnectionString = "Driver={ODBC Driver 13 for SQL Server};server=" & DB_SERVER & ";database=" & DB_NAME & ";uid=" & DB_USER & ";pwd=" & DB_PASSWORD & ";"
        db.Open()

        dbRep.ConnectionString = "Driver={ODBC Driver 13 for SQL Server};server=" & DB_SERVER & ";database=" & DB_NAME & ";uid=" & DB_USER & ";pwd=" & DB_PASSWORD & ";"
        dbRep.Open()

        sConn = "Data Source=" & DB_SERVER & ";Initial Catalog=" & DB_NAME & ";UID=" & DB_USER & ";PWD=" & DB_PASSWORD & ""

        Exit Sub

SQL_Server_11:
        'Use SQL Server 11 driver
        db.ConnectionString = "Provider=SQLNCLI11;Server=" & DB_SERVER & ";Database=" & DB_NAME & ";UID=" & DB_USER & ";PWD=" & DB_PASSWORD & ""
        db.Open()

        dbRep.ConnectionString = "Provider=SQLNCLI11;Server=" & DB_SERVER & ";Database=" & DB_NAME & ";UID=" & DB_USER & ";PWD=" & DB_PASSWORD & ""
        dbRep.Open()

        sConn = "Data Source=" & DB_SERVER & ";Initial Catalog=" & DB_NAME & ";UID=" & DB_USER & ";PWD=" & DB_PASSWORD & ""
        MsgBox("Use SQL Server 11 driver")
        Exit Sub

errHandler:
        GoTo SQL_Server_11

    End Sub
    Public Function GetAppValue(ByRef sName As String) As String

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT Value FROM dbo.tblAppValues WHERE RTRIM(Name) = '" & sName & "'"
        rs.Open(strSQL, db)

        If Not rs.EOF Then
            GetAppValue = Trim(rs.Fields("Value").Value)
        Else
            MsgBox("The Report Path could not be found.", MsgBoxStyle.Critical, "Path not found!")
            GetAppValue = "Path Not Found"
        End If

        rs.Close()
        rs = Nothing

    End Function
    Public Function cV2Q_String(ByRef V As Object) As String

        If IsDBNull(V) Or V = "" Then
            cV2Q_String = "NULL"
        Else
            cV2Q_String = "'" & Replace(V, "'", "''") & "'"
        End If
    End Function

    Public Sub TxtEnabled(txtVal As TextBox, blnValue As Boolean)
        If blnValue = True Then
            txtVal.Enabled = True
            txtVal.BackColor = System.Drawing.ColorTranslator.FromOle(&H80000005)
        ElseIf blnValue = False Then
            txtVal.Enabled = False
            txtVal.BackColor = System.Drawing.ColorTranslator.FromOle(&H80000004)
        End If
    End Sub
    Public Function addQuotes(ByRef inString As String) As String
        addQuotes = Chr(39) & inString & Chr(39)
    End Function

    Public Sub CboEnabled(ByRef cboVal As System.Windows.Forms.ComboBox, ByRef blnValue As Boolean)
        If blnValue = True Then
            cboVal.Enabled = True
            cboVal.BackColor = System.Drawing.ColorTranslator.FromOle(&H80000005)
        ElseIf blnValue = False Then
            cboVal.Enabled = False
            cboVal.BackColor = System.Drawing.ColorTranslator.FromOle(&H80000004)
        End If

    End Sub

    Function GetToken(ByVal strVal As String, ByRef intIndex As Short, ByRef strDelimiter As String) As String
        Dim intStopPos1 As Short
        Dim intStopPos2 As Short
        Dim i As Short
        For i = 1 To intIndex - 1
            intStopPos1 = intStopPos1 + InStr(strVal, strDelimiter) + Len(strDelimiter) - 1
        Next
        intStopPos2 = InStr(intStopPos1 + 1, strVal, strDelimiter)
        If intStopPos2 = 0 Then intStopPos2 = Len(strVal)
        GetToken = Left(Right(strVal, Len(strVal) - intStopPos1), intStopPos2)
    End Function

    Public Function GetUserName() As String

        GetUserName = Environ("USERNAME")

    End Function
    Public Function OkToUse() As Boolean
        Dim rsStaff As New ADODB.Recordset
        Dim strSQL As String
        Dim strFName As String
        Dim strLName As String

        OkToUse = False
        CurrentLoginUser = GetUserName()

        strSQL = "select * from tblStaff where name = '" & CurrentLoginUser & "'"
        rsStaff.Open(strSQL, db)
        If Not rsStaff.EOF Then
            'frmMain.DefInstance.lblCurrentUser.Text = CurrentLoginUser
            If (UCase(rsStaff.Fields("privilege").Value) = "ADMIN") Then
                IsAdminUser = True
                CurrentUserRight = UserRight.SystemAdmin
                'frmMain.DefInstance.lblPrivilege.Text = "A"
                'frmMain.DefInstance.cmdAdmin.Enabled = True
            ElseIf (UCase(rsStaff.Fields("privilege").Value) = "POWER") Then
                IsAdminUser = False
                CurrentUserRight = UserRight.PowerUser
                'frmMain.DefInstance.lblPrivilege.Text = "P"
                'frmMain.DefInstance.cmdAdmin.Enabled = True
            Else
                IsAdminUser = False
                CurrentUserRight = UserRight.Viewer
                'frmMain.DefInstance.lblPrivilege.Text = "U"
                'frmMain.DefInstance.cmdAdmin.Enabled = False
            End If
            CurrentLoginUserID = rsStaff.Fields("STAFF_ID").Value
            'record user full name
            strFName = IIf(IsDBNull(rsStaff.Fields("FNAME").Value), "", rsStaff.Fields("FNAME").Value)
            strLName = IIf(IsDBNull(rsStaff.Fields("LNAME").Value), "", rsStaff.Fields("LNAME").Value)
            CurrentLoginFullName = strFName & " " & strLName
            'if not values for both first name and last name then use login name
            If Trim(CurrentLoginFullName) = "" Then CurrentLoginFullName = CurrentLoginUser

            rsStaff.Close()
            rsStaff = Nothing

            'Flag user for logging in
            strSQL = "UPDATE tblStaff SET LOGGED_IN = 1 WHERE STAFF_ID = " & CurrentLoginUserID
            db.Execute(strSQL)

            OkToUse = True
            'frmMain.DefInstance.Show()
            Exit Function
        Else
            OkToUse = False
            rsStaff.Close()
            rsStaff = Nothing
        End If

    End Function

    Public Function GetReportPath() As String

        Dim strSQL As String
        Dim rs As New ADODB.Recordset

        strSQL = "SELECT Value FROM dbo.tblAppValues WHERE RTRIM(Name) = 'ReportPath'"
        rs.Open(strSQL, db)

        If Not rs.EOF Then
            GetReportPath = Trim(rs.Fields("Value").Value)
        Else
            MsgBox("The Report Path could not be found.", MsgBoxStyle.Critical, "Path not found!")
            GetReportPath = "Path Not Found"
        End If

        rs.Close()
        rs = Nothing

    End Function

    Public Function GetItemIndex(aCbo As ComboBox, aItemID As Integer) As Integer
        Dim j As Integer

        j = -1
        'For i = 0 To aCbo.ListCount - 1
        'If aItemID = aCbo.ItemData(i) Then
        'j = i
        'Exit For
        'End If
        'Next

        GetItemIndex = j
    End Function
    Public Sub FillCombo(ByRef sql As String, ByRef cbo As System.Windows.Forms.ComboBox, Optional ByRef withBlank As Boolean = False)

        Dim rs As New ADODB.Recordset

        cbo.Items.Clear()
        If withBlank = True Then cbo.Items.Add(" ")
        rs.Open(sql, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)
        Do Until rs.EOF
            cbo.Items.Add(rs.Fields(0).Value)
            rs.MoveNext()
        Loop
        cbo.SelectedIndex = -1
        rs.Close()
        rs = Nothing

    End Sub

    Public Sub FillCombo2ItemData(ByRef sql As String, ByRef cbo As System.Windows.Forms.ComboBox)

        Dim rs As New ADODB.Recordset

        cbo.Items.Clear()
        rs.Open(sql, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)
        Do Until rs.EOF
            'cbo.Items.Add(New VB6.ListBoxItem(rs.Fields(0).Value, rs.Fields(1).Value))
            rs.MoveNext()
        Loop
        cbo.SelectedIndex = -1
        rs.Close()
        rs = Nothing

    End Sub

    Public Sub FillCombo3ItemData(ByRef sql As String, ByRef cbo As System.Windows.Forms.ComboBox)

        Dim rs As New ADODB.Recordset
        Dim strFName As String
        Dim strLName As String

        cbo.Items.Clear()
        rs.Open(sql, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)
        Do Until rs.EOF
            strFName = IIf(IsDBNull(rs.Fields(0).Value), "", rs.Fields(0).Value)
            strLName = IIf(IsDBNull(rs.Fields(1).Value), "", rs.Fields(1).Value)
            'cbo.Items.Add(New VB6.ListBoxItem(strFName & " " & strLName, rs.Fields(2).Value))
            rs.MoveNext()
        Loop
        cbo.SelectedIndex = -1
        rs.Close()
        rs = Nothing

    End Sub
    Public Sub FillCombo2(ByRef sql As String, ByRef cbo As System.Windows.Forms.ComboBox, Optional ByRef EmptyFirstRow As Boolean = False)

        Dim rs As New ADODB.Recordset

        cbo.Items.Clear()

        rs.Open(sql, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)

        If Not rs.EOF Then
            If EmptyFirstRow Then cbo.Items.Add(" ")
        End If

        Do Until rs.EOF
            cbo.Items.Add((rs.Fields(0).Value & " - " & rs.Fields(1).Value))
            rs.MoveNext()
        Loop
        cbo.SelectedIndex = -1
        rs.Close()
        rs = Nothing

    End Sub
    Public Sub FillCombo2a(ByRef sql As String, ByRef cbo As System.Windows.Forms.ComboBox, Optional ByRef EmptyFirstRow As Boolean = False)

        Dim rs As New ADODB.Recordset

        cbo.Items.Clear()

        rs.Open(sql, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)

        If Not rs.EOF Then
            If EmptyFirstRow Then cbo.Items.Add(" ")
        End If

        Do Until rs.EOF
            cbo.Items.Add((MakeSameLen(Trim(rs.Fields(0).Value)) & "|" & rs.Fields(1).Value))
            rs.MoveNext()
        Loop
        cbo.SelectedIndex = -1
        rs.Close()
        rs = Nothing

    End Sub
    Private Function MakeSameLen(ByRef astr As String) As String
        Dim intLen As Short
        Dim i As Short

        intLen = 7

        i = Len(astr)

        Do While i <= intLen
            astr = astr & " "
            i = i + 1
        Loop

        MakeSameLen = astr
    End Function

    Public Sub CopyADOtoAccess(ByRef rsFrom As ADODB.Recordset, ByRef dbTo As ADODB.Connection, ByRef strTableTo As String, Optional ByRef strAssignField As String = "")
        Dim strSQL As String
        Dim fld As ADODB.Field
        Dim strFieldList As String
        Dim strValueList As String
        Dim rsUpdate As New ADODB.Recordset
        Dim i As Integer
        Dim rsTo As New ADODB.Recordset
        Dim strValue As String

        rsFrom.MoveLast()
        rsFrom.MoveFirst()

        If rsFrom.RecordCount <> -1 Then
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            frmProcessStatus.Show() 'vbModal
            frmProcessStatus.lblAct.Text = "Activity : Processing Report"
            frmProcessStatus.Refresh()
            frmUpdateStop.Refresh()

            'pbActivity
            frmProcessStatus.pbActivity.Minimum = 0
            frmProcessStatus.pbActivity.Value = 0
            frmProcessStatus.pbActivity.Maximum = rsFrom.RecordCount
        End If

        rsTo.Open("SELECT TOP 1 * FROM " & strTableTo, dbTo)

        Do While Not rsFrom.EOF
            i = 0
            strFieldList = ""
            strValueList = ""
            strSQL = ""
            For Each fld In rsTo.Fields
                If fld.Name <> strAssignField And fld.Name <> "WO_REMARKS" Then
                    strFieldList = strFieldList & fld.Name & ", " 'use comma as delimiter
                    If fld.Name = "WO_DESCRIPTION" Then
                        strValue = cV2Q_String(Trim(rsFrom.Fields(fld.Name).Value))
                        strValueList = strValueList & strValue.Replace(Chr(34), "") & ", "
                    Else
                        If fld.Type = ADODB.DataTypeEnum.adSingle Or fld.Type = ADODB.DataTypeEnum.adVarWChar Or fld.Type = ADODB.DataTypeEnum.adLongVarWChar Or fld.Type = ADODB.DataTypeEnum.adUnsignedTinyInt Or fld.Type = ADODB.DataTypeEnum.adInteger Or fld.Type = ADODB.DataTypeEnum.adVarChar Or fld.Type = ADODB.DataTypeEnum.adDate Or fld.Type = ADODB.DataTypeEnum.adDBDate Or fld.Type = ADODB.DataTypeEnum.adDBTimeStamp Then
                            If IsDBNull(rsFrom.Fields(fld.Name).Value) Then
                                If fld.Type = ADODB.DataTypeEnum.adDate Or fld.Type = ADODB.DataTypeEnum.adDBDate Then
                                    strValueList = strValueList & "null, "
                                Else
                                    strValueList = strValueList & "null, "
                                End If
                            Else
                                strValueList = strValueList & Chr(39) & rsFrom.Fields(fld.Name).Value & "', "
                            End If
                        Else
                            If rsFrom.Fields(fld.Name).Value = "False" Then
                                strValueList = strValueList & "0, "
                            ElseIf rsFrom.Fields(fld.Name).Value = "True" Then
                                strValueList = strValueList & "1, "
                            Else
                                strValueList = strValueList & rsFrom.Fields(fld.Name).Value & ", "
                            End If
                        End If
                    End If
                    i = i + 1
                End If
            Next fld
            strFieldList = Left(strFieldList, Len(strFieldList) - 2)
            strValueList = Left(strValueList, Len(strValueList) - 2)
            strSQL = "INSERT INTO dbo." & strTableTo & " (" & strFieldList & ") VALUES (" & strValueList & ")"

            dbTo.Execute(strSQL)
            If strAssignField <> "" Then
                strSQL = "SELECT MAX(" & strAssignField & ") as NEW_ID FROM " & strTableTo
                rsUpdate.Open(strSQL, dbTo)
                rsFrom.Update(strAssignField, rsUpdate.Fields("NEW_ID"))
                rsUpdate.Close()
            End If

            If System.Windows.Forms.Cursor.Current.Equals(System.Windows.Forms.Cursors.WaitCursor) Then
                frmProcessStatus.IncrementProgressBar(1)
            End If
            frmProcessStatus.pbActivity.PerformStep()
            frmProcessStatus.Refresh()
            rsFrom.MoveNext()
        Loop

        If System.Windows.Forms.Cursor.Current.Equals(System.Windows.Forms.Cursors.WaitCursor) Then
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End If
        rsTo.Close()
        rsTo = Nothing
        rsUpdate = Nothing
        frmProcessStatus.Close()

    End Sub

    Public Sub CopyADOtoAccessNoPause2(ByRef rsFrom As ADODB.Recordset, ByRef dbTo As ADODB.Connection, ByRef strTableTo As String, Optional ByRef strAssignField As String = "")
        Dim fld As ADODB.Field
        Dim rsTo As New ADODB.Recordset

        Try
            rsFrom.MoveLast()
            rsFrom.MoveFirst()

            If rsFrom.RecordCount <> -1 Then
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
                frmProcessStatus.Show() 'vbModal
                frmProcessStatus.lblAct.Text = "Activity : Processing Report"
                frmProcessStatus.Refresh()

                'pbActivity
                frmProcessStatus.pbActivity.Minimum = 0
                frmProcessStatus.pbActivity.Value = 0
                frmProcessStatus.pbActivity.Maximum = rsFrom.RecordCount
            End If

            rsTo.Open(strTableTo, db, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdTableDirect)

            Do While Not rsFrom.EOF
                rsTo.AddNew()
                For Each fld In rsTo.Fields
                    If rsTo.Fields(fld.Name).Type = ADODB.DataTypeEnum.adVarChar Or rsTo.Fields(fld.Name).Type = ADODB.DataTypeEnum.adVarWChar Or rsTo.Fields(fld.Name).Type = ADODB.DataTypeEnum.adDBTimeStamp Then
                        If IsDBNull(rsFrom.Fields(fld.Name).Value) Then
                            If fld.Type = ADODB.DataTypeEnum.adDate Or fld.Type = ADODB.DataTypeEnum.adDBDate Or fld.Type = ADODB.DataTypeEnum.adDBTimeStamp Then
                                rsTo.Fields(fld.Name).Value = Now.ToLongDateString
                            Else
                                rsTo.Fields(fld.Name).Value = " "
                            End If
                        Else
                            rsTo.Fields(fld.Name).Value = Trim(rsFrom.Fields(fld.Name).Value)
                        End If
                    Else
                        If IsDBNull(rsFrom.Fields(fld.Name).Value) Then
                            rsTo.Fields(fld.Name).Value = 0
                        Else
                            rsTo.Fields(fld.Name).Value = Trim(rsFrom.Fields(fld.Name).Value)
                        End If
                    End If
                Next fld

                rsTo.Update()

                frmProcessStatus.pbActivity.PerformStep()
                frmProcessStatus.Refresh()
                rsFrom.MoveNext()
            Loop

            If System.Windows.Forms.Cursor.Current.Equals(System.Windows.Forms.Cursors.WaitCursor) Then
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            End If

            rsTo.Close()
            rsTo = Nothing
            frmProcessStatus.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

End Module
