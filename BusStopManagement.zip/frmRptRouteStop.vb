﻿Public Class frmRptRouteStop
    Private optCopy() As RadioButton
    Private intIndex As Short

    Public Sub New()

        InitializeComponent()
        optCopy = New RadioButton() {optCopy0, optCopy1, optCopy2, optCopy3, optCopy4, optCopy5}

    End Sub

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub cmdPrint_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPrint.Click
        Dim strSQL As String = ""
        Dim rsData As New ADODB.Recordset
        Dim strWhereClause As String = ""
        Dim rsRS As New ADODB.Recordset
        Dim rsLM As New ADODB.Recordset
        Dim strLM As String = ""
        Dim sReportName As String = ""

        ' clear the report table
        strSQL = "DELETE FROM dbo.tblRouteReports"
        dbRep.Execute(strSQL)

        Select Case intIndex
            Case 0 ' a route range for Office and Field copy
                sReportName = "RouteReport.rpt"

                If cboOfficeFrom.Text = "" Then
                    MsgBox("Please enter routes to print")
                    Exit Sub
                ElseIf Not (IsNumeric(cboOfficeFrom.Text) Or IsNumeric(cboOfficeTo.Text)) Then
                    MsgBox("Please enter a valid route number")
                    Exit Sub
                ElseIf cboOfficeTo.Text = "" Then
                    strWhereClause = "AND bss.RTE = " & cboOfficeFrom.Text
                Else
                    strWhereClause = "AND bss.RTE >= " & cboOfficeFrom.Text & " AND bss.RTE <= " & cboOfficeTo.Text
                End If
            Case 1 ' all routes for Office and Field copy
                sReportName = "RouteReport.rpt"

                strWhereClause = ""
            Case 2 ' a route range for Information Center and Drivers Copy
                sReportName = "RouteReportInfo.rpt"

                If cboDriverFrom.Text = "" Then
                    MsgBox("Please enter routes to print")
                    Exit Sub
                ElseIf Not (IsNumeric(cboDriverFrom.Text) Or IsNumeric(cboDriverTo.Text)) Then
                    MsgBox("Please enter a valid route number")
                    Exit Sub
                ElseIf cboDriverTo.Text = "" Then
                    strWhereClause = "AND bss.RTE = " & cboDriverFrom.Text
                Else
                    strWhereClause = "AND bss.RTE >= " & cboDriverFrom.Text & " AND bss.RTE <= " & cboDriverTo.Text
                End If
            Case 3 ' all routes for Information Center and Drivers Copy
                sReportName = "RouteReportInfo.rpt"

                strWhereClause = ""
            Case 4 ' a route range for Contractors copy
                sReportName = "RouteReportContractor.rpt"

                If cboContractorFrom.Text = "" Then
                    MsgBox("Please enter routes to print")
                    Exit Sub
                ElseIf Not (IsNumeric(cboContractorFrom.Text) Or IsNumeric(cboContractorTo.Text)) Then
                    MsgBox("Please enter a valid route number")
                    Exit Sub
                ElseIf cboContractorTo.Text = "" Then
                    strWhereClause = "AND bss.RTE = " & cboContractorFrom.Text
                Else
                    strWhereClause = "AND bss.RTE >= " & cboContractorFrom.Text & " AND bss.RTE <= " & cboContractorTo.Text
                End If
            Case 5 ' all routes for Contractors copy
                sReportName = "RouteReportContractor.rpt"

                strWhereClause = ""
        End Select

        strSQL = "SELECT bss.RTE, rdc.DIR1 AS RTE_DIR, bss.SEQ, ccc.DESCRIPTION AS CITY, " & "sdc.DIR AS STOP_DIR, bsi.STREET_OF_TRAVEL, stc1.TYPE AS TYPE1, " & "aaa.STATUS AS ADA, blc.LOC, bsi.CROSS_STREET, stc2.TYPE AS TYPE2, " & "bsi.CROSS_STREET_1, bss.HARDWARE, bss.OCTA_ID, bss.SANZ_ID, " & "bsi.TBM_PAGE, bss.TRANSFERS, rcc.DESCRIPTION AS COMMENT, " & "bsi.SANZ_ID AS LANDMARK FROM ((((((((((tblBusStopSequences AS bss " & "LEFT JOIN tblBusStopInformation AS bsi ON bss.OCTA_ID = bsi.OCTA_ID) " & "LEFT JOIN tblADAStatus AS bsc ON bsi.OCTA_ID = bsc.OCTA_ID) " & "LEFT JOIN ROUTE_DIR_CODE AS rdc ON bss.RTE_DIR_ID = rdc.ID) " & "LEFT JOIN CITY_CODE AS ccc ON bsi.JURISDICTION_ID = ccc.ID) " & "LEFT JOIN ST_DIR_CODE AS sdc ON bsi.ST_DIR_ID = sdc.ID) " & "LEFT JOIN ST_TYPE_CODE AS stc1 ON (bsi.ST_TYPE_ID_1 = stc1.ID " & " OR (bsi.ST_TYPE_ID_1 IS NULL AND stc1.ID = 0))) " & "LEFT JOIN ADA_STATUS_CODE AS aaa ON bsc.ADA_STATUS_ID = aaa.ID) " & "LEFT JOIN BS_LOC_CODE AS blc ON bsi.BS_LOC_ID = blc.ID) " & "LEFT JOIN ST_TYPE_CODE AS stc2 ON (bsi.ST_TYPE_ID_2 = stc2.ID " & " OR (bsi.ST_TYPE_ID_2 IS NULL AND stc2.ID = 0))) " & "LEFT JOIN ROUTE_COMMENT_CODE AS rcc ON bss.COMMENTS = rcc.ID) " & "LEFT JOIN tblRoutes AS bsr ON (bss.RTE = bsr.RTE " & "AND bss.RTE_DIR_ID = bsr.RTE_DIR_ID)"

        strSQL = strSQL & " WHERE bsr.ACTIVE = 1 " & strWhereClause

        strSQL = strSQL & " ORDER BY bss.RTE, rdc.DIR1, " & "bss.SEQ, ccc.DESCRIPTION, bsi.STREET_OF_TRAVEL"

        rsData.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic)

        CopyADOtoAccessNoPause2(rsData, dbRep, "tblRouteReports")

        rsData.Close()
        rsData = Nothing

        strSQL = "UPDATE tblRouteReports SET LANDMARK = NULL"
        dbRep.Execute(strSQL)

        strSQL = "SELECT DISTINCT RTE, OCTA_ID FROM tblRouteReports " & "ORDER BY RTE, OCTA_ID"
        rsRS.Open(strSQL, dbRep, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

        Do While Not rsRS.EOF
            strSQL = "SELECT blm.DESCRIPTION FROM BS_LANDMARK_CODE AS blm " & "WHERE blm.ID IN (SELECT LANDMARK_ID FROM tblBusStopLandmarks AS bsl " & "WHERE bsl.RTE = " & rsRS.Fields("RTE").Value & " AND bsl.OCTA_ID = " & rsRS.Fields("OCTA_ID").Value & ")"
            rsLM.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

            If Not rsLM.EOF Then
                strLM = ""
                Do While Not rsLM.EOF
                    strLM = strLM & IIf(IsDBNull(rsLM.Fields("DESCRIPTION").Value), "", rsLM.Fields("DESCRIPTION").Value) & " - "
                    rsLM.MoveNext()
                Loop
                If strLM <> "" Then
                    strLM = strLM.Substring(0, Len(strLM) - 3)

                    strSQL = "UPDATE tblRouteReports SET LANDMARK = " & cV2Q_String(strLM) & " WHERE RTE = " & rsRS.Fields("RTE").Value & " AND OCTA_ID = " & rsRS.Fields("OCTA_ID").Value

                    dbRep.Execute(strSQL)
                End If
            End If
            rsLM.Close()
            rsRS.MoveNext()
        Loop

        rsLM = Nothing
        rsRS.Close()
        rsRS = Nothing


        dbRep.Close()
        dbRep.Open()

        'ByRef sReportName As String, ByRef sReportTitle As String, ByRef sReportStatus As String, ByRef sReportFooter As String
        frmCrystalReportsWP.LoadReport(sReportName, "", "", "")

    End Sub

    Private Sub frmRptRouteStop_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        LoadRouteCombos()

        AddHandler optCopy(0).CheckedChanged, AddressOf optCopy_CheckedChanged
        AddHandler optCopy(1).CheckedChanged, AddressOf optCopy_CheckedChanged
        AddHandler optCopy(2).CheckedChanged, AddressOf optCopy_CheckedChanged
        AddHandler optCopy(3).CheckedChanged, AddressOf optCopy_CheckedChanged
        AddHandler optCopy(4).CheckedChanged, AddressOf optCopy_CheckedChanged
        AddHandler optCopy(5).CheckedChanged, AddressOf optCopy_CheckedChanged

    End Sub

    Private Sub LoadRouteCombos()
        Dim rs As New ADODB.Recordset
        Dim strSQL As String
        strSQL = "SELECT DISTINCT RTE FROM tblRoutes WHERE ACTIVE = 1"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic)

        Dim i As Short
        For i = 0 To rs.RecordCount - 1
            cboOfficeFrom.Items.Add(rs.Fields(0).Value)
            cboOfficeTo.Items.Add(rs.Fields(0).Value)
            cboDriverFrom.Items.Add(rs.Fields(0).Value)
            cboDriverTo.Items.Add(rs.Fields(0).Value)
            cboContractorFrom.Items.Add(rs.Fields(0).Value)
            cboContractorTo.Items.Add(rs.Fields(0).Value)
            rs.MoveNext()
        Next i
        rs.Close()
    End Sub

    Private Sub optCopy_CheckedChanged(ByVal sender As System.Object, ByVal eventArgs As System.EventArgs)


        If sender.Checked Then
            intIndex = CInt(sender.tag)
            Select Case intIndex
                Case 0
                    CboEnabled(cboOfficeFrom, True)
                    CboEnabled(cboOfficeTo, True)
                    CboEnabled(cboDriverFrom, False)
                    CboEnabled(cboDriverTo, False)
                    CboEnabled(cboContractorFrom, False)
                    CboEnabled(cboContractorTo, False)
                Case 1
                    CboEnabled(cboOfficeFrom, False)
                    CboEnabled(cboOfficeTo, False)
                    CboEnabled(cboDriverFrom, False)
                    CboEnabled(cboDriverTo, False)
                    CboEnabled(cboContractorFrom, False)
                    CboEnabled(cboContractorTo, False)
                Case 2
                    CboEnabled(cboOfficeFrom, False)
                    CboEnabled(cboOfficeTo, False)
                    CboEnabled(cboDriverFrom, True)
                    CboEnabled(cboDriverTo, True)
                    CboEnabled(cboContractorFrom, False)
                    CboEnabled(cboContractorTo, False)
                Case 3
                    CboEnabled(cboOfficeFrom, False)
                    CboEnabled(cboOfficeTo, False)
                    CboEnabled(cboDriverFrom, False)
                    CboEnabled(cboDriverTo, False)
                    CboEnabled(cboContractorFrom, False)
                    CboEnabled(cboContractorTo, False)
                Case 4
                    CboEnabled(cboOfficeFrom, False)
                    CboEnabled(cboOfficeTo, False)
                    CboEnabled(cboDriverFrom, False)
                    CboEnabled(cboDriverTo, False)
                    CboEnabled(cboContractorFrom, True)
                    CboEnabled(cboContractorTo, True)
                Case 5
                    CboEnabled(cboOfficeFrom, False)
                    CboEnabled(cboOfficeTo, False)
                    CboEnabled(cboDriverFrom, False)
                    CboEnabled(cboDriverTo, False)
                    CboEnabled(cboContractorFrom, False)
                    CboEnabled(cboContractorTo, False)
            End Select
        End If
    End Sub
End Class