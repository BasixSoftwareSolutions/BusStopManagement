﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUpdateReportPath
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUpdateReportPath))
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cmdWO = New System.Windows.Forms.Button()
        Me.txtWO = New System.Windows.Forms.TextBox()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.txtSMO = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cmdSMO = New System.Windows.Forms.Button()
        Me.txtDSCE = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.cmdDSCE = New System.Windows.Forms.Button()
        Me.Frame1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdExit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdExit.Location = New System.Drawing.Point(159, 242)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExit.Size = New System.Drawing.Size(81, 25)
        Me.cmdExit.TabIndex = 5
        Me.cmdExit.Text = "&Close"
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'cmdWO
        '
        Me.cmdWO.BackColor = System.Drawing.SystemColors.Control
        Me.cmdWO.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdWO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdWO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdWO.Location = New System.Drawing.Point(343, 22)
        Me.cmdWO.Name = "cmdWO"
        Me.cmdWO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdWO.Size = New System.Drawing.Size(59, 25)
        Me.cmdWO.TabIndex = 4
        Me.cmdWO.Text = "Change"
        Me.cmdWO.UseVisualStyleBackColor = False
        '
        'txtWO
        '
        Me.txtWO.AcceptsReturn = True
        Me.txtWO.BackColor = System.Drawing.Color.White
        Me.txtWO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtWO.Enabled = False
        Me.txtWO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWO.Location = New System.Drawing.Point(27, 39)
        Me.txtWO.MaxLength = 0
        Me.txtWO.Name = "txtWO"
        Me.txtWO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtWO.Size = New System.Drawing.Size(321, 20)
        Me.txtWO.TabIndex = 6
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.Transparent
        Me.Frame1.Controls.Add(Me.cmdWO)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.Color.DimGray
        Me.Frame1.Location = New System.Drawing.Point(11, 15)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(409, 65)
        Me.Frame1.TabIndex = 7
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Work Orders"
        '
        'txtSMO
        '
        Me.txtSMO.AcceptsReturn = True
        Me.txtSMO.BackColor = System.Drawing.Color.White
        Me.txtSMO.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSMO.Enabled = False
        Me.txtSMO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSMO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSMO.Location = New System.Drawing.Point(28, 110)
        Me.txtSMO.MaxLength = 0
        Me.txtSMO.Name = "txtSMO"
        Me.txtSMO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtSMO.Size = New System.Drawing.Size(321, 20)
        Me.txtSMO.TabIndex = 8
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.cmdSMO)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.DimGray
        Me.GroupBox1.Location = New System.Drawing.Point(12, 86)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GroupBox1.Size = New System.Drawing.Size(409, 65)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Stop Modification Orders"
        '
        'cmdSMO
        '
        Me.cmdSMO.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSMO.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSMO.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSMO.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSMO.Location = New System.Drawing.Point(343, 22)
        Me.cmdSMO.Name = "cmdSMO"
        Me.cmdSMO.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSMO.Size = New System.Drawing.Size(59, 25)
        Me.cmdSMO.TabIndex = 4
        Me.cmdSMO.Text = "Change"
        Me.cmdSMO.UseVisualStyleBackColor = False
        '
        'txtDSCE
        '
        Me.txtDSCE.AcceptsReturn = True
        Me.txtDSCE.BackColor = System.Drawing.Color.White
        Me.txtDSCE.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDSCE.Enabled = False
        Me.txtDSCE.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDSCE.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDSCE.Location = New System.Drawing.Point(25, 184)
        Me.txtDSCE.MaxLength = 0
        Me.txtDSCE.Name = "txtDSCE"
        Me.txtDSCE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtDSCE.Size = New System.Drawing.Size(321, 20)
        Me.txtDSCE.TabIndex = 10
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.cmdDSCE)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.DimGray
        Me.GroupBox2.Location = New System.Drawing.Point(9, 160)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.GroupBox2.Size = New System.Drawing.Size(409, 65)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Damage Stop Cost Estimates"
        '
        'cmdDSCE
        '
        Me.cmdDSCE.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDSCE.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdDSCE.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDSCE.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdDSCE.Location = New System.Drawing.Point(343, 22)
        Me.cmdDSCE.Name = "cmdDSCE"
        Me.cmdDSCE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdDSCE.Size = New System.Drawing.Size(59, 25)
        Me.cmdDSCE.TabIndex = 4
        Me.cmdDSCE.Text = "Change"
        Me.cmdDSCE.UseVisualStyleBackColor = False
        '
        'frmUpdateReportPath
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Ivory
        Me.ClientSize = New System.Drawing.Size(430, 276)
        Me.Controls.Add(Me.txtDSCE)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.txtSMO)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.txtWO)
        Me.Controls.Add(Me.Frame1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmUpdateReportPath"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Update Report Path"
        Me.Frame1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents cmdExit As Button
    Public WithEvents cmdWO As Button
    Public WithEvents txtWO As TextBox
    Public WithEvents Frame1 As GroupBox
    Public WithEvents txtSMO As TextBox
    Public WithEvents GroupBox1 As GroupBox
    Public WithEvents cmdSMO As Button
    Public WithEvents txtDSCE As TextBox
    Public WithEvents GroupBox2 As GroupBox
    Public WithEvents cmdDSCE As Button
End Class
